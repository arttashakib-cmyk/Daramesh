package ir.daramash.app.presentation.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.daramash.app.data.backup.BackupExportManager
import ir.daramash.app.data.repository.CloudConflictException
import ir.daramash.app.data.repository.CloudConflictInfo
import ir.daramash.app.data.repository.DaramashRepository
import ir.daramash.app.domain.model.ActivityLog
import ir.daramash.app.domain.model.Advisor
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.DepositRecord
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchLink
import ir.daramash.app.domain.model.NavigationTab
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.PropertyFilterState
import ir.daramash.app.domain.model.ThemeMode
import ir.daramash.app.domain.model.UserDevice
import ir.daramash.app.domain.model.UserSession
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.domain.usecase.PropertyFilterLogic
import ir.daramash.app.domain.usecase.SmartMatchEngineUseCase
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class DaramashViewModel(
    private val repository: DaramashRepository
) : ViewModel() {

    val matchEngine = SmartMatchEngineUseCase()

    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _themeMode = MutableStateFlow(repository.prefs.getThemeMode())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _biometricEnabled = MutableStateFlow(repository.prefs.isBiometricEnabled())
    val biometricEnabled: StateFlow<Boolean> = _biometricEnabled.asStateFlow()

    private val _isBiometricLocked = MutableStateFlow(repository.prefs.isBiometricEnabled())
    val isBiometricLocked: StateFlow<Boolean> = _isBiometricLocked.asStateFlow()

    fun lockBiometric() {
        if (_biometricEnabled.value) {
            _isBiometricLocked.value = true
        }
    }

    fun unlockBiometric() {
        _isBiometricLocked.value = false
    }

    fun setBiometricEnabled(enabled: Boolean) {
        repository.prefs.setBiometricEnabled(enabled)
        _biometricEnabled.value = enabled
        if (!enabled) {
            _isBiometricLocked.value = false
        }
    }

    private val _notificationsEnabled = MutableStateFlow(repository.prefs.areNotificationsEnabled())
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _userSession = MutableStateFlow(repository.prefs.getUserSession())
    val userSession: StateFlow<UserSession> = _userSession.asStateFlow()

    private val _advisorTarget = MutableStateFlow(repository.prefs.getAdvisorTarget())
    val advisorTarget: StateFlow<AdvisorTarget> = _advisorTarget.asStateFlow()

    private val _tetherRate = MutableStateFlow<Long?>(null)
    val tetherRate: StateFlow<Long?> = _tetherRate.asStateFlow()

    private val _tetherUpdatedAt = MutableStateFlow(0L)
    val tetherUpdatedAt: StateFlow<Long> = _tetherUpdatedAt.asStateFlow()

    private val _isLoadingTether = MutableStateFlow(false)
    val isLoadingTether: StateFlow<Boolean> = _isLoadingTether.asStateFlow()

    private val _propertyFilter = MutableStateFlow(PropertyFilterState())
    val propertyFilter: StateFlow<PropertyFilterState> = _propertyFilter.asStateFlow()

    private val _customerQuery = MutableStateFlow("")
    val customerQuery: StateFlow<String> = _customerQuery.asStateFlow()

    private val _customerQualityFilter = MutableStateFlow("all")
    val customerQualityFilter: StateFlow<String> = _customerQualityFilter.asStateFlow()

    private val _selectedPropertyIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedPropertyIds: StateFlow<Set<String>> = _selectedPropertyIds.asStateFlow()

    private val _selectedCustomerIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedCustomerIds: StateFlow<Set<String>> = _selectedCustomerIds.asStateFlow()

    private val _aiResponse = MutableStateFlow("")
    val aiResponse: StateFlow<String> = _aiResponse.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarEvents = _snackbarEvents.asSharedFlow()

    // Prevent duplicate rapid form submissions
    private var lastSubmitTimestamp = 0L

    val activeProperties: StateFlow<List<Property>> = repository.activePropertiesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedProperties: StateFlow<List<Property>> = repository.archivedPropertiesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeCustomers: StateFlow<List<Customer>> = repository.activeCustomersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedCustomers: StateFlow<List<Customer>> = repository.archivedCustomersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeInvestors: StateFlow<List<Investor>> = repository.activeInvestorsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedInvestors: StateFlow<List<Investor>> = repository.archivedInvestorsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val matches: StateFlow<List<MatchLink>> = repository.matchesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activityLogs: StateFlow<List<ActivityLog>> = repository.activityLogsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val advisors: StateFlow<List<Advisor>> = repository.advisorsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredProperties: StateFlow<List<Property>> = combine(
        activeProperties,
        _propertyFilter
    ) { list, filter ->
        var out = PropertyFilterLogic.apply(list, filter)

        out = when (filter.sortMode) {
            "followup" -> out.sortedByDescending { PersianFormatters.daysSinceIso(it.lastContact) }
            "expensive" -> out.sortedByDescending { it.totalPrice }
            "cheapest" -> out.sortedBy { if (it.totalPrice > 0) it.totalPrice else Long.MAX_VALUE }
            "largest" -> out.sortedByDescending { it.area }
            else -> out.sortedByDescending { it.createdAt }
        }
        out
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredCustomers: StateFlow<List<Customer>> = combine(
        activeCustomers,
        _customerQuery,
        _customerQualityFilter
    ) { list, query, quality ->
        val q = PersianFormatters.normalizeSearch(query)
        list.filter { c ->
            val matchQuery = if (q.isEmpty()) true else {
                val haystack = (listOf(c.firstName, c.lastName, c.phone1, c.status) + c.neighborhoods)
                    .joinToString(" ") { PersianFormatters.normalizeSearch(it) }
                q.split(" ").all { word -> haystack.contains(word) }
            }
            val matchQuality = if (quality == "all") true else c.quality == quality
            matchQuery && matchQuality
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _adminUsers = MutableStateFlow<List<AdminUserRow>>(emptyList())
    val adminUsers: StateFlow<List<AdminUserRow>> = _adminUsers.asStateFlow()

    private val _cloudConflict = MutableStateFlow<CloudConflictInfo?>(null)
    val cloudConflict: StateFlow<CloudConflictInfo?> = _cloudConflict.asStateFlow()
    private var syncRunning = false

    init {
        viewModelScope.launch {
            repository.ensureInitialPortfolioSeeded()
            refreshTetherRate()
        }
        startAutoCloudSync()
        if (_userSession.value.isLoggedIn) refreshAccountStatus()
    }

    @OptIn(kotlinx.coroutines.FlowPreview::class)
    private fun startAutoCloudSync() {
        viewModelScope.launch {
            combine(activeProperties, activeCustomers, activeInvestors) { p, c, i -> Triple(p, c, i) }
                .debounce(8000)
                .collect {
                    val s = _userSession.value
                    val allowed = s.subStatus == "active" || s.subStatus == "ok"
                    if (s.isLoggedIn && s.accessToken.isNotBlank() && allowed && _cloudConflict.value == null) {
                        triggerCloudSync(silent = true)
                    }
                }
        }
    }

    fun navigateTo(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun setThemeMode(mode: ThemeMode) {
        repository.prefs.setThemeMode(mode)
        _themeMode.value = mode
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        repository.prefs.setNotificationsEnabled(enabled)
        _notificationsEnabled.value = enabled
        emitSnackbar(if (enabled) "اعلان‌های هوشمند پیگیری فعال شدند" else "اعلان‌ها غیرفعال شدند")
    }

    fun refreshTetherRate() {
        if (_isLoadingTether.value) return
        viewModelScope.launch {
            _isLoadingTether.value = true
            val rate = repository.network.fetchLiveTetherRate(_tetherRate.value)?.first
            if (rate != null && rate > 0) {
                _tetherRate.value = rate
                _tetherUpdatedAt.value = System.currentTimeMillis()
            }
            _isLoadingTether.value = false
        }
    }

    fun updatePropertyFilter(updater: (PropertyFilterState) -> PropertyFilterState) {
        _propertyFilter.update(updater)
    }

    fun setCustomerSearch(q: String) {
        _customerQuery.value = q
    }

    fun setCustomerQualityFilter(q: String) {
        _customerQualityFilter.value = q
    }

    fun togglePropertySelection(id: String) {
        _selectedPropertyIds.update { set -> if (id in set) set - id else set + id }
    }

    fun clearPropertySelection() {
        _selectedPropertyIds.value = emptySet()
    }

    fun archiveSelectedProperties() {
        val ids = _selectedPropertyIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.archiveProperties(ids)
            _selectedPropertyIds.value = emptySet()
            emitSnackbar("${PersianFormatters.toFa(ids.size)} فایل به آرشیو منتقل شد")
        }
    }

    fun toggleCustomerSelection(id: String) {
        _selectedCustomerIds.update { set -> if (id in set) set - id else set + id }
    }

    fun clearCustomerSelection() {
        _selectedCustomerIds.value = emptySet()
    }

    fun archiveSelectedCustomers() {
        val ids = _selectedCustomerIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.archiveCustomers(ids)
            _selectedCustomerIds.value = emptySet()
            emitSnackbar("${PersianFormatters.toFa(ids.size)} مشتری به آرشیو منتقل شد")
        }
    }

    fun saveProperty(property: Property, isEdit: Boolean, onSuccess: () -> Unit = {}) {
        val now = System.currentTimeMillis()
        if (now - lastSubmitTimestamp < 450L) return
        lastSubmitTimestamp = now

        viewModelScope.launch {
            val res = repository.saveProperty(property, checkDuplicate = !isEdit)
            res.onSuccess {
                emitSnackbar(if (isEdit) "تغییرات فایل ذخیره شد" else "فایل جدید ثبت شد")
                onSuccess()
            }.onFailure { err ->
                emitSnackbar(err.message ?: "خطا در ثبت فایل")
            }
        }
    }

    fun saveCustomer(customer: Customer, isEdit: Boolean, onSuccess: () -> Unit = {}) {
        val now = System.currentTimeMillis()
        if (now - lastSubmitTimestamp < 450L) return
        lastSubmitTimestamp = now

        viewModelScope.launch {
            val res = repository.saveCustomer(customer, checkDuplicate = !isEdit)
            res.onSuccess {
                emitSnackbar(if (isEdit) "اطلاعات مشتری بروزرسانی شد" else "مشتری جدید ثبت شد")
                onSuccess()
            }.onFailure { err ->
                emitSnackbar(err.message ?: "خطا در ثبت مشتری")
            }
        }
    }

    fun saveInvestor(investor: Investor, isEdit: Boolean, onSuccess: () -> Unit = {}) {
        val now = System.currentTimeMillis()
        if (now - lastSubmitTimestamp < 450L) return
        lastSubmitTimestamp = now

        viewModelScope.launch {
            repository.saveInvestor(investor)
            emitSnackbar(if (isEdit) "اطلاعات سرمایه‌گذار ذخیره شد" else "سرمایه‌گذار جدید ثبت شد")
            onSuccess()
        }
    }

    fun archiveProperty(id: String) {
        viewModelScope.launch {
            repository.archiveProperties(listOf(id))
            emitSnackbar("فایل به آرشیو منتقل شد")
        }
    }

    fun restoreProperty(id: String) {
        viewModelScope.launch {
            repository.restoreProperty(id)
            emitSnackbar("فایل به لیست فعال بازگردانده شد")
        }
    }

    fun deletePropertyPermanently(id: String) {
        viewModelScope.launch {
            repository.deletePropertiesPermanently(listOf(id))
            emitSnackbar("فایل برای همیشه حذف شد")
        }
    }

    fun archiveCustomer(id: String) {
        viewModelScope.launch {
            repository.archiveCustomers(listOf(id))
            emitSnackbar("مشتری به آرشیو منتقل شد")
        }
    }

    fun restoreCustomer(id: String) {
        viewModelScope.launch {
            repository.restoreCustomer(id)
            emitSnackbar("مشتری بازگردانی شد")
        }
    }

    fun deleteCustomerPermanently(id: String) {
        viewModelScope.launch {
            repository.deleteCustomersPermanently(listOf(id))
            emitSnackbar("مشتری حذف دائم شد")
        }
    }

    fun archiveInvestor(id: String) {
        viewModelScope.launch {
            repository.archiveInvestors(listOf(id))
            emitSnackbar("سرمایه‌گذار آرشیو شد")
        }
    }

    fun restoreInvestor(id: String) {
        viewModelScope.launch {
            repository.restoreInvestor(id)
            emitSnackbar("سرمایه‌گذار بازگردانی شد")
        }
    }

    fun deleteInvestorPermanently(id: String) {
        viewModelScope.launch {
            repository.deleteInvestorsPermanently(listOf(id))
            emitSnackbar("سرمایه‌گذار حذف دائم شد")
        }
    }

    /** links = (propertyId, needId, needKind) of files that are not linked yet */
    fun autoLinkMatches(links: List<Triple<String, String, String>>) {
        if (links.isEmpty()) return
        viewModelScope.launch {
            repository.addMatchLinks(links)
            emitSnackbar("🤝 ${PersianFormatters.toFa(links.size)} پیوند ثبت شد")
        }
    }

    fun toggleMatch(propertyId: String, needId: String, needKind: String, currentlyLinked: Boolean) {
        viewModelScope.launch {
            repository.toggleMatchLink(propertyId, needId, needKind, currentlyLinked)
            emitSnackbar(if (currentlyLinked) "پیوند لغو شد" else "🤝 پیوند موفق ثبت شد")
        }
    }

    fun recordQuickActivity(entityType: String, entityId: String, type: String, note: String) {
        viewModelScope.launch {
            repository.logActivity(entityType, entityId, type, note)
            emitSnackbar("فعالیت «$type» ثبت و تاریخ آخرین تماس بروز شد")
        }
    }

    fun toggleTargetDayTick(dayNumber: Int) {
        val current = _advisorTarget.value
        val updatedTicks = if (dayNumber in current.activeDaysTicks) {
            current.activeDaysTicks - dayNumber
        } else {
            current.activeDaysTicks + dayNumber
        }
        val next = current.copy(activeDaysTicks = updatedTicks)
        repository.prefs.saveAdvisorTarget(next)
        _advisorTarget.value = next
    }

    fun addTargetDeposit(amount: Long, title: String) {
        if (amount <= 0L) return
        val current = _advisorTarget.value
        val nextDep = DepositRecord(
            id = UUID.randomUUID().toString(),
            amount = amount,
            title = title.ifBlank { "کمیسیون معامله" },
            date = PersianFormatters.todayIso()
        )
        val next = current.copy(deposits = listOf(nextDep) + current.deposits)
        repository.prefs.saveAdvisorTarget(next)
        _advisorTarget.value = next
        emitSnackbar("مبلغ ${PersianFormatters.formatMoneyToman(amount)} تومان به تارگت ماه اضافه شد")
    }

    fun updateTargetSettings(targetFileCode: String, targetDeposit: Long, motivation: String, status: String) {
        val next = _advisorTarget.value.copy(
            status = status.ifBlank { "توکار هستم" },
            targetFileCode = targetFileCode.trim(),
            targetDeposit = targetDeposit.coerceAtLeast(10_000_000L),
            motivation = motivation.trim().ifBlank { "هر تماس، یک قدم به معامله‌ی بعدی نزدیک‌تره." }
        )
        repository.prefs.saveAdvisorTarget(next)
        _advisorTarget.value = next
        emitSnackbar("تنظیمات تارگت ماهانه ذخیره شد")
    }

    fun addAdvisor(name: String, phone: String, specialty: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.addAdvisor(name, phone, specialty)
            emitSnackbar("مشاور «$name» به پنل مدیریت اضافه شد")
        }
    }

    fun updateAdvisor(id: String, name: String, phone: String, specialty: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.updateAdvisor(id, name, phone, specialty)
            emitSnackbar("اطلاعات مشاور ذخیره شد")
        }
    }

    fun updateGroupSettings(name: String, rank: Int, type: String, value: Long) {
        val next = _advisorTarget.value.copy(
            groupName = name.trim(),
            groupRank = rank.coerceAtLeast(0),
            groupTargetType = type,
            groupTargetValue = value.coerceAtLeast(0L)
        )
        repository.prefs.saveAdvisorTarget(next)
        _advisorTarget.value = next
        emitSnackbar("تنظیمات گروه ذخیره شد")
    }

    fun clearAllArchive() {
        viewModelScope.launch {
            val p = archivedProperties.value.map { it.id }
            val c = archivedCustomers.value.map { it.id }
            val i = archivedInvestors.value.map { it.id }
            if (p.isNotEmpty()) repository.deletePropertiesPermanently(p)
            if (c.isNotEmpty()) repository.deleteCustomersPermanently(c)
            if (i.isNotEmpty()) repository.deleteInvestorsPermanently(i)
            emitSnackbar("آرشیو خالی شد")
        }
    }

    fun deleteAdvisor(id: String) {
        viewModelScope.launch {
            repository.deleteAdvisor(id)
            emitSnackbar("مشاور حذف شد")
        }
    }

    fun generateAdvisorShareCode(advisorName: String, onCodeReady: (String) -> Unit) {
        viewModelScope.launch {
            val code = repository.generateAdvisorTransferCode(advisorName)
            onCodeReady(code)
            emitSnackbar("کد انتقال مشاور تولید شد")
        }
    }

    fun importAdvisorShareCode(code: String) {
        viewModelScope.launch {
            repository.importAdvisorTransferCode(code)
                .onSuccess { count -> emitSnackbar("${PersianFormatters.toFa(count)} رکورد از کد مشاور وارد شد") }
                .onFailure { err -> emitSnackbar(err.message ?: "کد انتقال نامعتبر است") }
        }
    }



    fun logoutAccount() {
        repository.prefs.clearSession()
        _userSession.value = repository.prefs.getUserSession()
        emitSnackbar("از حساب کاربری خارج شدید (داده‌های محلی حفظ شدند)")
    }

    fun handleOAuthRedirect(uriString: String) {
        viewModelScope.launch {
            try {
                val fragIndex = uriString.indexOf('#')
                val queryOrFrag = if (fragIndex != -1) uriString.substring(fragIndex + 1) else {
                    val qIndex = uriString.indexOf('?')
                    if (qIndex != -1) uriString.substring(qIndex + 1) else ""
                }
                val params = queryOrFrag.split("&").associate { param ->
                    val parts = param.split("=")
                    if (parts.size >= 2) parts[0] to Uri.decode(parts.subList(1, parts.size).joinToString("=")) else parts[0] to ""
                }
                val token = params["access_token"] ?: ""
                val refresh = params["refresh_token"] ?: ""
                if (token.isNotBlank()) {
                    var userEmail = ""
                    var userId = ""
                    try {
                        val jwtParts = token.split(".")
                        if (jwtParts.size >= 2) {
                            val decodedBytes = android.util.Base64.decode(jwtParts[1], android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP)
                            val payloadJson = String(decodedBytes, java.nio.charset.StandardCharsets.UTF_8)
                            val jwtObj = org.json.JSONObject(payloadJson)
                            userEmail = jwtObj.optString("email")
                            userId = jwtObj.optString("sub")
                        }
                    } catch (_: Exception) {}

                    val next = _userSession.value.copy(
                        isLoggedIn = true,
                        userId = userId.ifBlank { _userSession.value.userId },
                        email = userEmail.ifBlank { _userSession.value.email },
                        accessToken = token,
                        refreshToken = refresh,
                        syncStatusText = "ورود با حساب گوگل (${userEmail.ifBlank { "جیمیل" }}) با موفقیت تأیید شد"
                    )
                    repository.prefs.saveUserSession(next)
                    _userSession.value = next
                    emitSnackbar("خوش آمدید: $userEmail")
                    refreshAccountStatus()
                    triggerCloudSync()
                } else {
                    val err = params["error_description"] ?: params["error"] ?: "ورود لغو شد"
                    emitSnackbar("ورود با گوگل انجام نشد: $err")
                }
            } catch (e: Exception) {
                emitSnackbar("خطا در پردازش نشست: ${e.localizedMessage}")
            }
        }
    }

    /** A valid access token (refreshed when expired); keeps the in-memory session in sync. */
    private suspend fun freshToken(): String {
        val token = repository.freshAccessToken()
        val stored = repository.prefs.getUserSession()
        if (stored.accessToken != _userSession.value.accessToken) {
            _userSession.value = _userSession.value.copy(accessToken = stored.accessToken, refreshToken = stored.refreshToken)
        }
        return token
    }

    fun refreshAccountStatus() {
        if (_userSession.value.accessToken.isBlank()) return
        viewModelScope.launch {
            val token = freshToken()
            val session = _userSession.value
            val deviceId = repository.prefs.getDeviceId()
            val deviceName = "اپ Android (${android.os.Build.MODEL})"
            val res = repository.network.getMyStatus(token, deviceId, deviceName)
            res.onSuccess { json ->
                val state = json.optString("state", json.optString("status", "active"))
                val expiresAtStr = json.optString("expires_at", "")
                val payText = json.optString("pay_text", "")
                val isAdmin = json.optBoolean("is_admin", false)
                val contact = json.optString("contact", "")
                val limit = json.optInt("limit", 2)

                var expiresAtMs = 0L
                if (expiresAtStr.isNotBlank()) {
                    try {
                        expiresAtMs = java.time.Instant.parse(expiresAtStr).toEpochMilli()
                    } catch (_: Exception) {}
                }
                val daysLeft = if (expiresAtMs > System.currentTimeMillis()) {
                    ((expiresAtMs - System.currentTimeMillis()) / 86_400_000L).toInt()
                } else 0

                val devicesArr = json.optJSONArray("devices")
                val devList = mutableListOf<UserDevice>()
                if (devicesArr != null) {
                    for (i in 0 until devicesArr.length()) {
                        val d = devicesArr.optJSONObject(i) ?: continue
                        devList.add(
                            UserDevice(
                                id = d.optString("id"),
                                label = d.optString("label", d.optString("device_name", "دستگاه اندروید")),
                                lastSeen = d.optString("last_seen", ""),
                                isCurrent = d.optString("id") == deviceId
                            )
                        )
                    }
                }
                val next = session.copy(
                    subStatus = state,
                    isAdmin = isAdmin,
                    payText = payText.ifBlank { session.payText },
                    contact = contact.ifBlank { session.contact },
                    maxDevices = limit,
                    subscriptionExpiresAt = expiresAtMs,
                    daysLeft = daysLeft,
                    devices = devList,
                    syncStatusText = "اشتراک: ${if (state == "active") "فعال ($daysLeft روز مانده)" else state}"
                )
                repository.prefs.saveUserSession(next)
                _userSession.value = next
                if (isAdmin) loadAdminUsers()
            }.onFailure { err ->
                val localDec = repository.prefs.decideStored()
                _userSession.value = _userSession.value.copy(subStatus = localDec)
            }
        }
    }

    fun loadDemoData() {
        viewModelScope.launch {
            repository.loadDemoData().onSuccess { count ->
                emitSnackbar("تعداد $count داده‌ی نمونه بارگذاری شد")
            }
        }
    }

    fun removeDemoData() {
        viewModelScope.launch {
            repository.removeDemoData().onSuccess { count ->
                emitSnackbar("تعداد $count داده‌ی نمونه پاک گردید")
            }
        }
    }

    fun cleanupSoldAndBought() {
        viewModelScope.launch {
            repository.cleanupSoldAndBought().onSuccess { count ->
                emitSnackbar("پاک‌سازی یک‌لمسی: $count مورد معاملاتی پاک شد")
            }
        }
    }

    fun deleteMyCloudData() {
        viewModelScope.launch {
            repository.deleteMyCloudData().onSuccess {
                _userSession.value = repository.prefs.getUserSession()
                emitSnackbar("اطلاعات ابری با موفقیت پاک شد")
            }.onFailure { err ->
                emitSnackbar(err.message ?: "خطا در حذف داده‌های ابری")
            }
        }
    }

    fun fetchCloudSnapshots(onReady: (List<ir.daramash.app.domain.model.CloudHistorySnapshot>) -> Unit) {
        viewModelScope.launch {
            repository.fetchCloudSnapshotsList().onSuccess(onReady).onFailure { err ->
                emitSnackbar(err.message ?: "خطا در دریافت نسخه‌های ابری")
            }
        }
    }

    fun restoreCloudSnapshot(id: Long) {
        viewModelScope.launch {
            repository.restoreCloudHistorySnapshot(id).onSuccess { msg ->
                emitSnackbar(msg)
            }.onFailure { err ->
                emitSnackbar(err.message ?: "خطا در بازگردانی نسخه ابری")
            }
        }
    }

    fun adminSaveConfig(contact: String, trialDays: Int, devLimit: Int, build: Int, url: String, note: String) {
        viewModelScope.launch {
            val tok = freshToken()
            if (tok.isBlank()) return@launch
            repository.network.adminSetConfig(tok, "admin_contact", contact)
            repository.network.adminSetConfig(tok, "trial_days", trialDays.toString())
            repository.network.adminSetConfig(tok, "device_limit", devLimit.toString())
            repository.network.adminSetConfig(tok, "latest_build", build.toString())
            repository.network.adminSetConfig(tok, "update_url", url)
            repository.network.adminSetConfig(tok, "update_note", note)
            emitSnackbar("تنظیمات عمومی با موفقیت ذخیره شد")
            refreshAccountStatus()
        }
    }

    fun adminSavePayText(text: String) {
        viewModelScope.launch {
            val tok = freshToken()
            if (tok.isBlank()) return@launch
            repository.network.adminSetPayText(tok, text).onSuccess {
                emitSnackbar("متن راهنمای پرداخت ذخیره شد")
                refreshAccountStatus()
            }
        }
    }

    fun removeDevice(deviceIdToRemove: String) {
        if (_userSession.value.accessToken.isBlank()) return
        viewModelScope.launch {
            val res = repository.network.removeMyDevice(freshToken(), deviceIdToRemove)
            res.onSuccess {
                emitSnackbar("دستگاه با موفقیت حذف شد")
                refreshAccountStatus()
            }.onFailure { err ->
                emitSnackbar(err.message ?: "خطا در حذف دستگاه")
            }
        }
    }

    fun triggerCloudSync(silent: Boolean = false) {
        if (syncRunning) return
        syncRunning = true
        viewModelScope.launch {
            try {
                val res = repository.performCloudSync()
                _userSession.value = repository.prefs.getUserSession()
                res.onSuccess { msg -> if (!silent) emitSnackbar(msg) }
                    .onFailure { err ->
                        if (err is CloudConflictException) {
                            _cloudConflict.value = err.info
                        } else if (!silent) {
                            emitSnackbar(err.message ?: "خطا در همگام‌سازی")
                        }
                    }
            } finally {
                syncRunning = false
            }
        }
    }

    private fun parseIsoMillis(text: String): Long {
        if (text.isBlank() || text == "null") return 0L
        return try {
            java.time.OffsetDateTime.parse(text).toInstant().toEpochMilli()
        } catch (_: Exception) {
            try {
                java.time.Instant.parse(text).toEpochMilli()
            } catch (_: Exception) {
                0L
            }
        }
    }

    fun loadAdminUsers() {
        if (_userSession.value.accessToken.isBlank()) return
        viewModelScope.launch {
            val tok = freshToken()
            val listRes = repository.network.adminList(tok)
            if (listRes.isFailure) {
                emitSnackbar("خطا در دریافت لیست: " + (listRes.exceptionOrNull()?.message ?: ""))
                return@launch
            }
            val usage = HashMap<String, Long>()
            repository.network.adminUsage(tok).getOrNull()?.optJSONArray("list")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    usage[o.optString("user_id")] = o.optLong("raw_bytes", 0L)
                }
            }
            val devs = HashMap<String, Int>()
            repository.network.adminDeviceCounts(tok).getOrNull()?.optJSONArray("list")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    devs[o.optString("user_id")] = o.optInt("n", 0)
                }
            }
            val rows = ArrayList<AdminUserRow>()
            val arr = listRes.getOrNull()?.optJSONArray("list")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val uid = o.optString("user_id")
                    rows.add(
                        AdminUserRow(
                            userId = uid,
                            email = o.optString("email"),
                            expiresAt = parseIsoMillis(o.optString("expires_at", "")),
                            blocked = o.optBoolean("blocked", false),
                            usageBytes = usage[uid] ?: 0L,
                            devices = devs[uid] ?: 0
                        )
                    )
                }
            }
            _adminUsers.value = rows
        }
    }

    fun adminExtendUser(uid: String, days: Int) {
        viewModelScope.launch {
            val tok = freshToken()
            repository.network.adminExtend(tok, uid, days)
                .onSuccess { emitSnackbar("تمدید شد ✓"); loadAdminUsers() }
                .onFailure { emitSnackbar("خطا: " + (it.message ?: "")) }
        }
    }

    fun adminSetUserBlocked(uid: String, blocked: Boolean) {
        viewModelScope.launch {
            val tok = freshToken()
            repository.network.adminSetBlocked(tok, uid, blocked)
                .onSuccess { emitSnackbar("انجام شد ✓"); loadAdminUsers() }
                .onFailure { emitSnackbar("خطا: " + (it.message ?: "")) }
        }
    }

    fun adminClearUserDevices(uid: String) {
        viewModelScope.launch {
            val tok = freshToken()
            repository.network.adminClearDevices(tok, uid)
                .onSuccess { emitSnackbar("دستگاه‌ها آزاد شد ✓"); loadAdminUsers() }
                .onFailure { emitSnackbar("خطا: " + (it.message ?: "")) }
        }
    }

    fun dismissCloudConflict() {
        _cloudConflict.value = null
    }

    fun resolveConflictUseCloud() {
        _cloudConflict.value = null
        viewModelScope.launch {
            val res = repository.pullFromCloud()
            _userSession.value = repository.prefs.getUserSession()
            res.onSuccess { msg -> emitSnackbar(msg) }
                .onFailure { err -> emitSnackbar(err.message ?: "دریافت اطلاعات از حساب انجام نشد") }
        }
    }

    fun resolveConflictKeepPhone() {
        _cloudConflict.value = null
        viewModelScope.launch {
            val res = repository.keepPhoneDataAndPush()
            _userSession.value = repository.prefs.getUserSession()
            res.onSuccess { msg -> emitSnackbar(msg) }
                .onFailure { err -> emitSnackbar(err.message ?: "ارسال اطلاعات به حساب انجام نشد") }
        }
    }

    fun exportBackupJson(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportFullBackupJson()
            onReady(json)
            emitSnackbar("فایل پشتیبان JSON آماده شد")
        }
    }

    fun restoreBackupJson(rawJson: String) {
        viewModelScope.launch {
            val res = repository.restoreFromBackupJson(rawJson)
            res.onSuccess { msg -> emitSnackbar(msg) }
                .onFailure { err -> emitSnackbar(err.message ?: "فایل پشتیبان معتبر نیست") }
        }
    }

    fun exportCsv(onReady: (String) -> Unit) {
        val csv = BackupExportManager.exportCsvString(activeProperties.value, activeCustomers.value)
        onReady(csv)
        emitSnackbar("خروجی اکسل (CSV) آماده شد")
    }

    fun exportPdfReport(context: Context, onReady: (File) -> Unit) {
        viewModelScope.launch {
            try {
                val file = BackupExportManager.generatePortfolioPdfFile(
                    context = context,
                    properties = activeProperties.value,
                    customers = activeCustomers.value,
                    investors = activeInvestors.value
                )
                onReady(file)
                emitSnackbar("گزارش PDF پرتفوی تولید شد")
            } catch (e: Exception) {
                emitSnackbar("خطا در تولید PDF: ${e.localizedMessage}")
            }
        }
    }

    fun askAiAssistant(prompt: String) {
        if (_isAiLoading.value) return
        viewModelScope.launch {
            _isAiLoading.value = true
            val reply = repository.network.askPrivacySafeAiAssistant(
                prompt = prompt.ifBlank { "تحلیل کامل فایل‌ها و پیشنهاد اولویت تماس امروز" },
                properties = activeProperties.value,
                customers = activeCustomers.value,
                investors = activeInvestors.value,
                accessToken = freshToken(),
                isAdmin = _userSession.value.isAdmin
            )
            _aiResponse.value = reply.getOrElse { e ->
                e.localizedMessage ?: "خطا در پردازش هوش مصنوعی"
            }
            _isAiLoading.value = false
        }
    }

    fun emitSnackbar(message: String) {
        _snackbarEvents.tryEmit(message)
    }

    class Factory(private val repository: DaramashRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DaramashViewModel(repository) as T
        }
    }
}

data class AdminUserRow(
    val userId: String,
    val email: String,
    val expiresAt: Long,
    val blocked: Boolean,
    val usageBytes: Long,
    val devices: Int
)
