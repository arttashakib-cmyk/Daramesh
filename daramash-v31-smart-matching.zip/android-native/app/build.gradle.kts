import java.util.Properties
import java.io.FileInputStream

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = Properties()
if (keystorePropsFile.exists()) {
    keystoreProps.load(FileInputStream(keystorePropsFile))
}

android {
    namespace = "ir.daramash.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "ir.daramash.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 31
        versionName = "31.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        buildConfigField("String", "SUPABASE_URL", "\"https://kkplxjyinzifignpjkwx.supabase.co\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtrcGx4anlpbnppZmlnbnBqa3d4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA5NTM3MzAsImV4cCI6MjEwNjUyOTczMH0.Zhw-NcNNjsOWvmVB_4J-d8aDSBlBLt6nz2vFLnokjiM\"")
        buildConfigField("String", "ADMIN_EMAIL", "\"arttashakib@gmail.com\"")
        buildConfigField("String", "AI_WORKER_URL", "\"https://daramash-ai.arttashakib.workers.dev\"")
    }

    signingConfigs {
        create("release") {
            val ksFile = file("daramash-release.jks")
            if (ksFile.exists()) {
                storeFile = ksFile
                storePassword = System.getenv("DARAMASH_KEYSTORE_PASSWORD")
                    ?: keystoreProps.getProperty("storePassword", "daramash2025")
                keyAlias = System.getenv("DARAMASH_KEY_ALIAS")
                    ?: keystoreProps.getProperty("keyAlias", "daramash")
                keyPassword = System.getenv("DARAMASH_KEY_PASSWORD")
                    ?: keystoreProps.getProperty("keyPassword", "daramash2025")
                enableV1Signing = true
                enableV2Signing = true
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        // Prefer uncompressed native libs for 16KB page size devices
        jniLibs {
            useLegacyPackaging = false
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    val composeBom = platform(libs.androidx.compose.bom)
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.biometric)
    implementation(libs.androidx.browser)
    implementation(libs.androidx.security.crypto)

    // Splash Screen API
    implementation(libs.androidx.core.splashscreen)

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.org.json)
}
