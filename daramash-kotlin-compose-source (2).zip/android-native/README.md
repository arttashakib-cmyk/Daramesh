# دارمش نیتیو اندروید (Daramash Native — Kotlin + Jetpack Compose)

این پروژه نسخه کاملاً نیتیو اندروید اپلیکیشن **دارمش (`ir.daramash.app`)** است که از پایه با **Kotlin**، **Jetpack Compose (Material 3)**، معماری **Clean Architecture + MVVM**، دیتابیس محلی **Room (SQLite)** و **WorkManager** پیاده‌سازی شده است و هیچ‌گونه وابستگی به WebView یا HTML/CSS/JS ندارد.

---

## ۱. ساختار معماری پروژه (Clean Architecture + MVVM)

```
android-native/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   ├── java/ir/daramash/app/
        │   │   ├── DaramashApplication.kt          # راه‌اندازی کانال اعلان و WorkManager
        │   │   ├── MainActivity.kt                 # اکتیویتی اصلی Jetpack Compose + Deep Links
        │   │   ├── domain/
        │   │   │   ├── model/Models.kt             # مدل‌های دامنه (Property, Customer, Investor, MatchLink, ...)
        │   │   │   └── usecase/
        │   │   │       ├── PersianFormatters.kt    # تقویم شمسی، فرمت مبالغ، نرمال‌سازی شماره و اشتراک امن
        │   │   │       └── SmartMatchEngineUseCase.kt # موتور تطبیق هوشمند دوطرفه ملک و مشتری/سرمایه‌گذار
        │   │   ├── data/
        │   │   │   ├── local/
        │   │   │   │   ├── entity/Entities.kt      # جداول Room SQLite به همراه ایندکس‌ها
        │   │   │   │   ├── dao/DaramashDao.kt      # کوئری‌های Flow و تراکنش‌های اتمیک (@Transaction)
        │   │   │   │   ├── db/DaramashDatabase.kt  # دیتابیس Room نسخه ۲ به همراه MIGRATION_1_2
        │   │   │   │   └── prefs/SecureAuthPreferences.kt # ذخیره‌سازی رمزنگاری‌شده توکن‌ها و نشست (AES256-GCM)
        │   │   │   ├── remote/
        │   │   │   │   └── CloudNetworkService.kt  # ارتباط HTTPS، سینک ابری AES-GCM + DEFLATE، تتر و هوش مصنوعی
        │   │   │   ├── backup/
        │   │   │   │   └── BackupExportManager.kt  # بکاپ و بازیابی JSON (سازگار با نسخه‌های ۱ تا ۶)، CSV و PDF
        │   │   │   └── repository/
        │   │   │       └── DaramashRepository.kt   # لایه مخزن داده، مهاجرت بکاپ و سینک ابری
        │   │   ├── presentation/
        │   │   │   ├── theme/DaramashTheme.kt      # پوسته RTL فارسی با ۳ حالت Liquid OLED، تاریک و روشن
        │   │   │   ├── viewmodel/DaramashViewModel.kt # مدیریت StateFlow، جلوگیری از ثبت تکراری و عملیات گروهی
        │   │   │   └── screens/
        │   │   │       ├── DaramashComposeApp.kt   # ۹ صفحه کامل Jetpack Compose
        │   │   │       └── DialogsAndSheets.kt     # فرم‌ها، فیلتر پیشرفته، تایم‌لاین پیگیری و دستیار هوشمند
        │   │   ├── worker/
        │   │   │   ├── FollowUpReminderWorker.kt   # بررسی دوره‌ای پرونده‌های نیازمند پیگیری در پس‌زمینه
        │   │   │   └── BootCompletedReceiver.kt    # بازیابی زمان‌بندی اعلان‌ها پس از ریستارت گوشی
        │   │   └── widget/
        │   │       └── DaramashAppWidgetProvider.kt # ویجت صفحه اصلی اندروید
        │   └── res/                                # منابع، میانبرهای لانچر (Shortcuts)، ویجت و FileProvider
        └── test/
            └── java/ir/daramash/app/
                └── DaramashUnitTests.kt            # تست‌های واحد JUnit 4
```

---

## ۲. دستورات ساخت مجدد پروژه و تولید APK امضاشده

### پیش‌نیازها
- **JDK 17**
- **Android SDK Platform 34** و **Build-Tools 34.0.0**
- **Gradle 8.7** (یا اجرای `./gradlew`)

### اجرای تست‌های واحد (Unit Tests)
```bash
cd android-native
gradle testReleaseUnitTest
```

### ساخت نسخه Debug APK
```bash
cd android-native
gradle assembleDebug
# خروجی: app/build/outputs/apk/debug/app-debug.apk
```

### ساخت نسخه Release APK امضاشده (Signed Release)
کلید امضا خارج از سورس کد و از طریق متغیرهای محیطی یا `keystore.properties` به بیلد معرفی می‌شود:
```bash
export DARAMASH_KEYSTORE_PATH="/path/to/daramash-release.jks"
export DARAMASH_KEYSTORE_PASSWORD="YOUR_KEYSTORE_PASSWORD"
export DARAMASH_KEY_ALIAS="daramash"
export DARAMASH_KEY_PASSWORD="YOUR_KEY_PASSWORD"

cd android-native
gradle assembleRelease
# خروجی امضاشده: app/build/outputs/apk/release/app-release.apk
```
