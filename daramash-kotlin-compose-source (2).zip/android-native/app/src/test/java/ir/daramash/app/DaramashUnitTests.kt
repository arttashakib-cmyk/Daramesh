package ir.daramash.app

import ir.daramash.app.data.backup.BackupExportManager
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.domain.usecase.SmartMatchEngineUseCase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DaramashUnitTests {

    private val matchEngine = SmartMatchEngineUseCase()

    @Test
    fun `test Persian and English numeral conversion and phone normalization`() {
        assertEquals("۱۰۴۲", PersianFormatters.toFa("1042"))
        assertEquals("1042", PersianFormatters.toEn("۱۰۴۲"))
        assertEquals("09121112233", PersianFormatters.normalizePhoneDigits("+98 912 111 2233"))
        assertEquals("09121112233", PersianFormatters.normalizePhoneDigits("۰۹۱۲-۱۱۱-۲۲۳۳"))
        assertEquals("۱۴ میلیارد و ۲۰۰ میلیون", PersianFormatters.formatMoneyToman(14_200_000_000L))
    }

    @Test
    fun `test Jalali calendar conversion accuracy`() {
        val (jy, jm, jd) = PersianFormatters.gregorianToJalali(2026, 3, 21)
        assertEquals(1405, jy)
        assertEquals(1, jm)
        assertEquals(1, jd)
    }

    @Test
    fun `test Privacy-safe property share never leaks owner name phone or address`() {
        val prop = Property(
            id = "p1",
            code = "1042",
            neighborhood = "پونک",
            area = 78,
            bedrooms = 2,
            totalPrice = 14_200_000_000L,
            pricePerMeter = 182_000_000L,
            sellerName = "رضا احمدی",
            sellerPhone = "09121112233",
            address = "پونک، بلوار همیلا، پلاک ۱۴"
        )
        val safeShare = PersianFormatters.formatPrivacySafePropertyShare(prop)
        assertTrue(safeShare.contains("پونک"))
        assertTrue(safeShare.contains("۷۸ متر"))
        assertFalse(safeShare.contains("رضا احمدی"))
        assertFalse(safeShare.contains("09121112233"))
        assertFalse(safeShare.contains("پلاک ۱۴"))
    }

    @Test
    fun `test SmartMatchEngineUseCase scores matching property 100 percent and rejects sold or incompatible`() {
        val customer = Customer(
            id = "c1",
            firstName = "حسین",
            lastName = "محمدی",
            neighborhoods = listOf("پونک", "همیلا"),
            areaMin = 70,
            bedroomsMin = 2,
            buildingAgeMax = 8,
            budgetMax = 15_000_000_000L,
            reqParking = true,
            reqElevator = true
        )
        val matchingProperty = Property(
            id = "p1",
            code = "1042",
            neighborhood = "پونک",
            area = 78,
            bedrooms = 2,
            buildingAge = 5,
            totalPrice = 14_200_000_000L,
            parking = true,
            elevator = true,
            status = "فروشنده"
        )

        val res = matchEngine.evaluateCustomerMatch(customer, matchingProperty)
        assertTrue(res.ok)
        assertEquals(100, res.score)

        val soldProperty = matchingProperty.copy(status = "فروش رفت")
        val soldRes = matchEngine.evaluateCustomerMatch(customer, soldProperty)
        assertFalse(soldRes.ok)
        assertEquals(0, soldRes.score)
    }

    @Test
    fun `test BackupExportManager export and validation roundtrip and corrupt rejection`() {
        val p = Property(id = "p1", code = "1042", neighborhood = "پونک", area = 85, bedrooms = 2, totalPrice = 15_000_000_000L)
        val c = Customer(id = "c1", firstName = "علی", lastName = "رضایی", phone1 = "09121112233", neighborhoods = listOf("پونک"))

        val json = BackupExportManager.exportFullBackupJson(
            properties = listOf(p),
            customers = listOf(c),
            investors = emptyList(),
            matches = emptyList(),
            activities = emptyList(),
            advisors = emptyList(),
            target = AdvisorTarget()
        )

        val parsedResult = BackupExportManager.validateAndParseBackupJson(json)
        assertTrue(parsedResult.isSuccess)
        val parsed = parsedResult.getOrThrow()
        assertEquals(1, parsed.properties.size)
        assertEquals("1042", parsed.properties.first().code)
        assertEquals(1, parsed.customers.size)
        assertEquals("علی رضایی", parsed.customers.first().fullName)

        // Corrupt JSON must fail validation gracefully
        val badResult = BackupExportManager.validateAndParseBackupJson("not-a-json")
        assertTrue(badResult.isFailure)
    }
}
