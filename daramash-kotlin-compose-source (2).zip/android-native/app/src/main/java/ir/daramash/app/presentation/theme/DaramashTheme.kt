package ir.daramash.app.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import ir.daramash.app.R
import ir.daramash.app.domain.model.ThemeMode

// Exact color tokens from original Daramash CSS (:root in src/index.css)
val DaramashBg = Color(0xFF000000)
val DaramashBgElevated = Color(0xFF0A0A0A)
val DaramashSurface = Color(0xFF111111)
val DaramashSurface2 = Color(0xFF161616)
val DaramashSurface3 = Color(0xFF1C1C1C)

val DaramashBorder = Color(0x29FFFFFF)      // rgba(255,255,255,.16)
val DaramashBorderSoft = Color(0x14FFFFFF)  // rgba(255,255,255,.08)
val DaramashSpecular = Color(0x7AFFFFFF)    // rgba(255,255,255,.48)

val DaramashText = Color(0xFFECECEC)
val DaramashMuted = Color(0xFF9B9B9B)
val DaramashFaint = Color(0xFF676767)

val RubyPrimary = Color(0xFFFF2D55)
val RubyMid = Color(0xFFFF375F)
val RubyDeep = Color(0xFFE01E48)

val EmeraldAccent = Color(0xFF10A37F)
val EmeraldHover = Color(0xFF14B890)
val EmeraldBright = Color(0xFF34D399)

val BlueInfo = Color(0xFF60A5FA)
val BlueSoft = Color(0xFF7FB0FF)
val AmberWarn = Color(0xFFFBBF24)
val AmberSoft = Color(0xFFE0A63A)
val RedDanger = Color(0xFFF87171)
val RedSolid = Color(0xFFE5534B)
val PurpleQuote = Color(0xFFA78BFA)

// Liquid Glass surface gradient stops (.hg, .pcard, .match-card, .sys-card, .mgr-card)
val GlassGradTop = Color(0xEB24242E)    // rgba(36,36,46,0.92)
val GlassGradMid = Color(0xF012121A)    // rgba(18,18,26,0.94)
val GlassGradBottom = Color(0xF70A0A10) // rgba(10,10,16,0.97)

// Embedded Vazirmatn Persian font family matching original Daramash
val VazirmatnFontFamily = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_medium, FontWeight.SemiBold),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_extrabold, FontWeight.ExtraBold),
    Font(R.font.vazirmatn_extrabold, FontWeight.Black)
)

private val LiquidOledColorScheme = darkColorScheme(
    primary = EmeraldAccent,
    onPrimary = Color.White,
    secondary = RubyPrimary,
    onSecondary = Color.White,
    tertiary = BlueInfo,
    background = DaramashBg,
    onBackground = DaramashText,
    surface = DaramashSurface,
    onSurface = DaramashText,
    surfaceVariant = DaramashSurface3,
    onSurfaceVariant = DaramashMuted,
    error = RedSolid,
    onError = Color.White
)

private val StandardDarkColorScheme = darkColorScheme(
    primary = EmeraldAccent,
    onPrimary = Color.White,
    secondary = RubyPrimary,
    onSecondary = Color.White,
    tertiary = BlueInfo,
    background = Color(0xFF0A0A0E),
    onBackground = DaramashText,
    surface = Color(0xFF14141C),
    onSurface = DaramashText,
    surfaceVariant = Color(0xFF1F1F2B),
    onSurfaceVariant = DaramashMuted,
    error = RedSolid,
    onError = Color.White
)

private val DaylightColorScheme = lightColorScheme(
    primary = EmeraldAccent,
    onPrimary = Color.White,
    secondary = RubyPrimary,
    onSecondary = Color.White,
    tertiary = Color(0xFF2563EB),
    background = Color(0xFF050508), // Original Daramash is strictly dark Liquid Glass
    onBackground = DaramashText,
    surface = Color(0xFF12121A),
    onSurface = DaramashText,
    surfaceVariant = Color(0xFF1E1E2A),
    onSurfaceVariant = DaramashMuted
)

val DaramashTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 25.sp,
        lineHeight = 34.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Black,
        fontSize = 21.sp,
        lineHeight = 29.sp
    ),
    titleLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp,
        lineHeight = 25.sp
    ),
    titleMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 14.5.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 23.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 21.sp
    ),
    labelMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun DaramashTheme(
    themeMode: ThemeMode = ThemeMode.LIQUID_OLED,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        ThemeMode.LIQUID_OLED -> LiquidOledColorScheme
        ThemeMode.DARK -> StandardDarkColorScheme
        ThemeMode.LIGHT -> DaylightColorScheme
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = DaramashTypography,
            content = content
        )
    }
}
