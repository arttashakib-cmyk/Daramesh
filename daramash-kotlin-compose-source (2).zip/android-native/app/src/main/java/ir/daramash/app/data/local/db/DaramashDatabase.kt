package ir.daramash.app.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import ir.daramash.app.data.local.dao.DaramashDao
import ir.daramash.app.data.local.entity.ActivityLogEntity
import ir.daramash.app.data.local.entity.AdvisorEntity
import ir.daramash.app.data.local.entity.CustomerEntity
import ir.daramash.app.data.local.entity.InvestorEntity
import ir.daramash.app.data.local.entity.MatchLinkEntity
import ir.daramash.app.data.local.entity.PropertyEntity

@Database(
    entities = [
        PropertyEntity::class,
        CustomerEntity::class,
        InvestorEntity::class,
        MatchLinkEntity::class,
        ActivityLogEntity::class,
        AdvisorEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class DaramashDatabase : RoomDatabase() {

    abstract fun dao(): DaramashDao

    companion object {
        @Volatile
        private var INSTANCE: DaramashDatabase? = null

        /**
         * Explicit Room SQLite Migration from v1 to v2 ensuring zero data loss on app update.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_properties_code` ON `properties` (`code`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_properties_neighborhood` ON `properties` (`neighborhood`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_customers_phone1` ON `customers` (`phone1`)")
            }
        }

        fun getInstance(context: Context): DaramashDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DaramashDatabase::class.java,
                    "daramash_native.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
