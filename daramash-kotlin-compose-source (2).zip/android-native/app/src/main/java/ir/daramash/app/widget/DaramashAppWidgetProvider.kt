package ir.daramash.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import ir.daramash.app.MainActivity
import ir.daramash.app.R
import ir.daramash.app.data.local.db.DaramashDatabase
import ir.daramash.app.domain.usecase.PersianFormatters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DaramashAppWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = DaramashDatabase.getInstance(context).dao()
                val activeProps = dao.getAllPropertiesNow().count { !it.isArchived && it.status == "فروشنده" }
                val activeCusts = dao.getAllCustomersNow().count { !it.isArchived }
                val matches = dao.getAllMatchesNow().size

                val statsText = "${PersianFormatters.toFa(activeProps)} فایل فعال · ${PersianFormatters.toFa(activeCusts)} مشتری · ${PersianFormatters.toFa(matches)} پیوند"

                for (widgetId in appWidgetIds) {
                    val intent = Intent(context, MainActivity::class.java)
                    val pendingIntent = PendingIntent.getActivity(
                        context,
                        widgetId,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    val views = RemoteViews(context.packageName, R.layout.widget_daramash).apply {
                        setTextViewText(R.id.widget_stats, statsText)
                        setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                    }
                    appWidgetManager.updateAppWidget(widgetId, views)
                }
            } catch (_: Exception) {
            } finally {
                pendingResult.finish()
            }
        }
    }
}
