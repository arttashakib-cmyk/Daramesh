package ir.daramash.app.data.remote

import android.util.Base64
import ir.daramash.app.BuildConfig
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.usecase.PersianFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

class CloudNetworkService {

    /**
     * Fetches live USDT/Toman market rate over HTTPS from Nobitex, Wallex, and Tetherland.
     * Caches the last valid price for offline use.
     */
    suspend fun fetchLiveTetherRate(cachedPrice: Long? = null): Pair<Long, String>? = withContext(Dispatchers.IO) {
        // 1. Try Nobitex API
        try {
            val conn = (URL("https://api.nobitex.ir/v2/orderbook/USDTIRT").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6500
                readTimeout = 6500
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val lastTrade = json.optDouble("lastTradePrice", 0.0)
                if (lastTrade > 100_000) {
                    val toman = (lastTrade / 10.0).toLong()
                    return@withContext Pair(toman, "Nobitex")
                }
            }
        } catch (_: Exception) {}

        // 2. Try Wallex API
        try {
            val conn = (URL("https://api.wallex.ir/v1/markets").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6500
                readTimeout = 6500
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val price = json.optJSONObject("result")
                    ?.optJSONObject("symbols")
                    ?.optJSONObject("USDTTMN")
                    ?.optJSONObject("stats")
                    ?.optDouble("lastPrice", 0.0) ?: 0.0
                if (price > 10_000) {
                    return@withContext Pair(price.toLong(), "Wallex")
                }
            }
        } catch (_: Exception) {}

        // 3. Fallback to Tetherland API
        try {
            val conn = (URL("https://api.tetherland.com/currencies").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6500
                readTimeout = 6500
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val price = json.optJSONObject("data")
                    ?.optJSONObject("currencies")
                    ?.optJSONObject("USDT")
                    ?.optDouble("price", 0.0) ?: 0.0
                if (price > 10_000) {
                    return@withContext Pair(price.toLong(), "Tetherland")
                }
            }
        } catch (_: Exception) {}

        // 4. Offline Cached Fallback
        if (cachedPrice != null && cachedPrice > 0) {
            return@withContext Pair(cachedPrice, "آخرین قیمت ذخیره‌شده (آفلاین)")
        }

        null
    }

    /**
     * Refreshes the Supabase session token.
     */
    suspend fun refreshSessionToken(refreshToken: String): Result<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val url = URL("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10000
                readTimeout = 10000
                doOutput = true
                setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
                setRequestProperty("Content-Type", "application/json")
            }
            val payload = JSONObject().apply {
                put("refresh_token", refreshToken)
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val json = JSONObject(text)
            if (code in 200..299 && json.has("access_token")) {
                Result.success(json)
            } else {
                Result.failure(Exception("انقضای نشست کاربر"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Calls a Supabase RPC function (my_status, sync_put, sync_get, etc.)
     */
    suspend fun callSupabaseRpc(
        accessToken: String,
        rpcName: String,
        params: JSONObject = JSONObject()
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val url = URL("${BuildConfig.SUPABASE_URL}/rest/v1/rpc/$rpcName")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
                setRequestProperty("Authorization", "Bearer ${accessToken.ifBlank { BuildConfig.SUPABASE_ANON_KEY }}")
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(params.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            if (code in 200..299) {
                val json = when {
                    text.trim().startsWith("{") -> JSONObject(text)
                    text.trim().startsWith("[") -> JSONObject().put("list", JSONArray(text))
                    else -> JSONObject().put("result", text)
                }
                Result.success(json)
            } else {
                val errJson = try { JSONObject(text) } catch (_: Exception) { null }
                val msg = errJson?.optString("message")
                    ?: errJson?.optString("error_description")
                    ?: "خطای سرور ($code)"
                Result.failure(Exception(msg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Calls Supabase RPC to check user subscription and registered devices.
     * Uses exact reference parameters: p_device and p_label.
     */
    suspend fun getMyStatus(accessToken: String, deviceId: String, deviceLabel: String): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_device", deviceId)
            put("p_label", deviceLabel)
        }
        return callSupabaseRpc(accessToken, "my_status", params)
    }

    /**
     * Calls Supabase RPC to unbind/remove an active device.
     * Uses exact reference parameter: p_device.
     */
    suspend fun removeMyDevice(accessToken: String, deviceIdToRemove: String): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_device", deviceIdToRemove)
        }
        return callSupabaseRpc(accessToken, "remove_my_device", params)
    }

    /**
     * Cloud Sync RPCs matching auth-module.js
     */
    suspend fun syncMeta(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "sync_meta", JSONObject())
    }

    suspend fun syncGet(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "sync_get", JSONObject())
    }

    suspend fun syncHistory(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "sync_history", JSONObject())
    }

    suspend fun syncHistoryGet(accessToken: String, historyId: Long): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_id", historyId)
        }
        return callSupabaseRpc(accessToken, "sync_history_get", params)
    }

    suspend fun deleteMyData(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "delete_my_data", JSONObject())
    }

    /**
     * Admin Panel RPCs (only callable when user is_admin)
     */
    suspend fun adminList(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "admin_list", JSONObject())
    }

    suspend fun adminExtend(accessToken: String, userId: String, days: Int): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_uid", userId)
            put("p_days", days)
        }
        return callSupabaseRpc(accessToken, "admin_extend", params)
    }

    suspend fun adminSetBlocked(accessToken: String, userId: String, blocked: Boolean): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_uid", userId)
            put("p_blocked", blocked)
        }
        return callSupabaseRpc(accessToken, "admin_set_blocked", params)
    }

    suspend fun adminUsage(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "admin_usage", JSONObject())
    }

    suspend fun adminDeviceCounts(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "admin_device_counts", JSONObject())
    }

    suspend fun adminClearDevices(accessToken: String, userId: String): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_uid", userId)
        }
        return callSupabaseRpc(accessToken, "admin_clear_devices", params)
    }

    suspend fun adminConfig(accessToken: String): Result<JSONObject> {
        return callSupabaseRpc(accessToken, "admin_config", JSONObject())
    }

    suspend fun adminSetConfig(accessToken: String, key: String, value: String): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_key", key)
            put("p_value", value)
        }
        return callSupabaseRpc(accessToken, "admin_set_config", params)
    }

    suspend fun adminSetPayText(accessToken: String, text: String): Result<JSONObject> {
        val params = JSONObject().apply {
            put("p_text", text)
        }
        return callSupabaseRpc(accessToken, "admin_set_pay_text", params)
    }

    /**
     * Packs string payload into Gzip Base64 matching pack() in src/auth-module.js.
     */
    fun packGzip(rawString: String): Pair<String, String> {
        return try {
            val rawBytes = rawString.toByteArray(StandardCharsets.UTF_8)
            val bos = ByteArrayOutputStream(rawBytes.size / 2)
            GZIPOutputStream(bos).use { it.write(rawBytes) }
            val compressed = bos.toByteArray()
            Pair("gz", Base64.encodeToString(compressed, Base64.NO_WRAP))
        } catch (_: Exception) {
            Pair("raw", rawString)
        }
    }

    fun encryptSyncPayload(userId: String, rawString: String): Pair<String, String> {
        return packGzip(rawString)
    }

    /**
     * Unpacks payload matching unpack() in src/auth-module.js.
     */
    fun unpackGzip(enc: String, data: String): String {
        return if (enc == "gz") {
            try {
                val compressedBytes = Base64.decode(data, Base64.DEFAULT)
                GZIPInputStream(ByteArrayInputStream(compressedBytes)).bufferedReader(StandardCharsets.UTF_8).use {
                    it.readText()
                }
            } catch (_: Exception) {
                data
            }
        } else {
            data
        }
    }

    /**
     * High-level privacy-safe AI assistant query:
     * - Only executed for admin.
     * - Uses real Cloudflare Worker (POST /ai).
     * - Never transmits owner name, phone, or address.
     * - Anonymizes customer and investor names into [C1], [I1] tags before sending, and restores them on device.
     */
    suspend fun askPrivacySafeAiAssistant(
        prompt: String,
        properties: List<Property>,
        customers: List<Customer>,
        investors: List<Investor>,
        accessToken: String,
        isAdmin: Boolean,
        workerUrl: String? = null
    ): Result<String> {
        if (!isAdmin) {
            return Result.failure(Exception("دستیار هوشمند فقط برای مدیر سیستم (ادمین) در دسترس است."))
        }
        if (accessToken.isBlank()) {
            return Result.failure(Exception("برای استفاده از دستیار هوشمند، ورود با گوگل الزامی است."))
        }

        // Tag mapping to strip personal identities (docs/AI.md)
        val nameMap = mutableMapOf<String, String>()
        val taggedCusts = customers.take(8).mapIndexed { idx, c ->
            val tag = "[C${idx + 1}]"
            nameMap[tag] = c.fullName
            "$tag: نیاز در ${c.neighborhoods.joinToString("، ")} با بودجه ${PersianFormatters.formatMoneyToman(c.budgetMax)} تومان"
        }
        val taggedInvs = investors.take(5).mapIndexed { idx, inv ->
            val tag = "[I${idx + 1}]"
            nameMap[tag] = inv.fullName
            "$tag: سرمایه‌گذار در ${inv.neighborhoods.joinToString("، ")} با توان خرید ${PersianFormatters.formatMoneyToman(inv.buyAmount)} تومان"
        }

        // Anonymized property summaries (NO seller name, seller phone, or exact address)
        val propSummaries = properties.take(6).map { p ->
            "کد ${PersianFormatters.toFa(p.code)} در ${p.neighborhood} · ${PersianFormatters.toFa(p.area)} متر · ${PersianFormatters.toFa(p.bedrooms)} خواب · قیمت: ${PersianFormatters.formatMoneyToman(p.totalPrice)} تومان"
        }

        val userMessage = buildString {
            appendLine(prompt.ifBlank { "برنامه‌ی تماس امروز و اولویت‌بندی پیگیری‌ها را پیشنهاد بده." })
            appendLine("\nخلاصه وضعیت فایل‌ها:")
            propSummaries.forEach { appendLine("• $it") }
            if (taggedCusts.isNotEmpty()) {
                appendLine("\nمشتریان:")
                taggedCusts.forEach { appendLine("• $it") }
            }
            if (taggedInvs.isNotEmpty()) {
                appendLine("\nسرمایه‌گذاران:")
                taggedInvs.forEach { appendLine("• $it") }
            }
        }

        val messages = listOf(
            Pair("user", userMessage)
        )

        val targetUrl = workerUrl?.trim()?.ifBlank { null } ?: BuildConfig.AI_WORKER_URL
        val res = callAiAssistant(accessToken, messages, targetUrl)
        return res.map { rawReply ->
            // Restore anonymized tags [C1], [I1] on device
            var restored = rawReply
            nameMap.forEach { (tag, actualName) ->
                restored = restored.replace(tag, actualName)
            }
            restored
        }
    }

    /**
     * Calls Cloudflare Worker AI assistant (Qwen 30B / Workers AI).
     */
    suspend fun callAiAssistant(
        accessToken: String,
        messages: List<Pair<String, String>>,
        workerUrl: String = BuildConfig.AI_WORKER_URL
    ): Result<String> = withContext(Dispatchers.IO) {
        if (accessToken.isBlank()) {
            return@withContext Result.failure(Exception("برای استفاده از هوش مصنوعی وارد حساب کاربری شو"))
        }
        try {
            val endpoint = if (workerUrl.endsWith("/ai")) workerUrl else "${workerUrl.removeSuffix("/")}/ai"
            val url = URL(endpoint)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 60000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $accessToken")
                setRequestProperty("Content-Type", "application/json")
            }
            val msgsArray = JSONArray()
            messages.forEach { (role, content) ->
                msgsArray.put(JSONObject().apply {
                    put("role", role)
                    put("content", content)
                })
            }
            val body = JSONObject().apply {
                put("messages", msgsArray)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val json = JSONObject(text)
            if (code in 200..299 && json.optBoolean("ok", true)) {
                val ans = json.optString("text", json.optString("answer", ""))
                Result.success(ans)
            } else {
                val err = json.optString("error", "خطا در پردازش هوش مصنوعی ($code)")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
