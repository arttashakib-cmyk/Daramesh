package ir.daramash.app.domain.usecase

import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchCriterion
import ir.daramash.app.domain.model.MatchLink
import ir.daramash.app.domain.model.MatchResult
import ir.daramash.app.domain.model.Property
import kotlin.math.roundToInt

class SmartMatchEngineUseCase {

    fun evaluateCustomerMatch(
        customer: Customer,
        property: Property,
        existingLinks: List<MatchLink> = emptyList()
    ): MatchResult {
        val isLinked = existingLinks.any { it.propertyId == property.id && it.needId == customer.id }

        if (property.status == "فروش رفت" || property.status == "غیرفعال" || property.isArchived) {
            return MatchResult(
                ok = false,
                score = 0,
                criteria = listOf(MatchCriterion("وضعیت: ${property.status}", false)),
                isLinked = isLinked
            )
        }

        val criteria = mutableListOf<MatchCriterion>()

        // 1. Neighborhood check
        val wantedNeighborhoods = customer.neighborhoods.map { PersianFormatters.normalizeSearch(it) }.filter { it.isNotEmpty() }
        if (wantedNeighborhoods.isNotEmpty()) {
            val propNbhd = PersianFormatters.normalizeSearch(property.neighborhood)
            val matched = propNbhd.isNotEmpty() && wantedNeighborhoods.any { w -> propNbhd.contains(w) || w.contains(propNbhd) }
            criteria.add(MatchCriterion(if (matched) "محله ${property.neighborhood} مطابق" else "محله متفاوت", matched))
        }

        // 2. Minimum area check
        if (customer.areaMin > 0) {
            val okArea = property.area >= customer.areaMin
            criteria.add(MatchCriterion(if (okArea) "متراژ کافی (${PersianFormatters.toFa(property.area)}م)" else "متراژ کمتر از حد", okArea))
        }

        // 3. Budget check (allows up to 5% negotiation margin or strict budget)
        if (customer.budgetMax > 0 && property.totalPrice > 0) {
            val okPrice = property.totalPrice <= customer.budgetMax
            criteria.add(MatchCriterion(if (okPrice) "قیمت در بودجه" else "قیمت بالاتر از بودجه", okPrice))
        }

        // 4. Bedrooms check
        if (customer.bedroomsMin > 0) {
            val okBed = property.bedrooms >= customer.bedroomsMin
            criteria.add(MatchCriterion(if (okBed) "خواب کافی" else "تعداد خواب کمتر", okBed))
        }

        // 5. Building age check
        if (customer.buildingAgeMax > 0) {
            val okAge = property.buildingAge <= customer.buildingAgeMax
            criteria.add(MatchCriterion(if (okAge) "سن بنا مطابق" else "سن بنا بالاتر از حد", okAge))
        }

        // 6. Required amenities check
        val missingFeats = mutableListOf<String>()
        if (customer.reqParking && !property.parking) missingFeats.add("پارکینگ")
        if (customer.reqStorage && !property.storage) missingFeats.add("انباری")
        if (customer.reqTerrace && !property.terrace) missingFeats.add("تراس")
        if (customer.reqElevator && !property.elevator) {
            if (customer.noElevatorMaxFloor > 0 && property.unitFloor > 0 && property.unitFloor <= customer.noElevatorMaxFloor) {
                criteria.add(MatchCriterion("بدون آسانسور اما طبقه مجاز", true))
            } else {
                missingFeats.add("آسانسور")
            }
        }

        if (missingFeats.isNotEmpty()) {
            criteria.add(MatchCriterion("❌ ${missingFeats.joinToString("، ")} ندارد", false))
        } else if (customer.reqParking || customer.reqStorage || customer.reqElevator || customer.reqTerrace) {
            criteria.add(MatchCriterion("همه امکانات الزامی", true))
        }

        val hardFail = missingFeats.isNotEmpty() || criteria.any { !it.passed }
        val passedCount = criteria.count { it.passed }
        val score = if (hardFail) {
            0
        } else if (criteria.isEmpty()) {
            100
        } else {
            ((passedCount.toDouble() / criteria.size.toDouble()) * 100.0).roundToInt()
        }

        return MatchResult(
            ok = !hardFail && score >= 60,
            score = score,
            criteria = criteria,
            isLinked = isLinked
        )
    }

    fun evaluateInvestorMatch(
        investor: Investor,
        property: Property,
        existingLinks: List<MatchLink> = emptyList()
    ): MatchResult {
        val isLinked = existingLinks.any { it.propertyId == property.id && it.needId == investor.id }

        if (property.status == "فروش رفت" || property.status == "غیرفعال" || property.isArchived) {
            return MatchResult(false, 0, listOf(MatchCriterion("فایل غیرفعال", false)), isLinked)
        }

        val criteria = mutableListOf<MatchCriterion>()
        val wantedNeighborhoods = investor.neighborhoods.map { PersianFormatters.normalizeSearch(it) }.filter { it.isNotEmpty() }
        if (wantedNeighborhoods.isNotEmpty()) {
            val propNbhd = PersianFormatters.normalizeSearch(property.neighborhood)
            val matched = propNbhd.isNotEmpty() && wantedNeighborhoods.any { w -> propNbhd.contains(w) || w.contains(propNbhd) }
            criteria.add(MatchCriterion(if (matched) "محله ${property.neighborhood} مطابق" else "محله متفاوت", matched))
        }

        if (investor.buyAmount > 0 && property.totalPrice > 0) {
            val okBudget = property.totalPrice <= investor.buyAmount
            criteria.add(MatchCriterion(if (okBudget) "در سقف خرید سرمایه‌گذار" else "بالاتر از سقف خرید", okBudget))
        }

        if (property.investable) {
            criteria.add(MatchCriterion("💼 تگ قابل سرمایه‌گذاری", true))
        }

        val failed = criteria.any { !it.passed }
        val score = if (failed) 0 else 100
        return MatchResult(ok = !failed, score = score, criteria = criteria, isLinked = isLinked)
    }
}
