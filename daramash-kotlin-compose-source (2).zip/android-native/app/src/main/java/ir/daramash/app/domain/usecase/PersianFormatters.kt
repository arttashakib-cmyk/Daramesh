package ir.daramash.app.domain.usecase

import ir.daramash.app.domain.model.Property
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.roundToLong

object PersianFormatters {

    private val FA_DIGITS = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
    private val AR_DIGITS = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

    val JALALI_MONTH_NAMES = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun toFa(input: Any?): String {
        if (input == null) return ""
        val s = input.toString()
        val sb = StringBuilder(s.length)
        for (ch in s) {
            when (ch) {
                in '0'..'9' -> sb.append(FA_DIGITS[ch - '0'])
                in '٠'..'٩' -> sb.append(FA_DIGITS[ch - '٠'])
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toEn(input: Any?): String {
        if (input == null) return ""
        val s = input.toString()
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val faIdx = FA_DIGITS.indexOf(ch)
            val arIdx = AR_DIGITS.indexOf(ch)
            when {
                faIdx >= 0 -> sb.append(('0'.code + faIdx).toChar())
                arIdx >= 0 -> sb.append(('0'.code + arIdx).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun normalizeSearch(input: String?): String {
        if (input.isNullOrBlank()) return ""
        return toEn(input)
            .replace('ي', 'ی')
            .replace('ك', 'ک')
            .replace('\u200C', ' ')
            .lowercase()
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun scrubSafeText(input: String?): String {
        if (input == null) return ""
        return input
            .replace('<', '‹')
            .replace('>', '›')
            .replace('"', '״')
            .trim()
    }

    fun normalizePhoneDigits(phone: String?): String {
        val digits = toEn(phone).replace(Regex("\\D+"), "")
        if (digits.isEmpty()) return ""
        return when {
            digits.startsWith("0098") -> "0" + digits.substring(4)
            digits.startsWith("98") && digits.length >= 12 -> "0" + digits.substring(2)
            digits.length == 10 && digits.startsWith("9") -> "0$digits"
            else -> digits
        }
    }

    fun whatsappUrl(phone: String?): String {
        val norm = normalizePhoneDigits(phone)
        if (norm.length < 10) return ""
        val intl = if (norm.startsWith("0")) "98" + norm.substring(1) else norm
        return "https://wa.me/$intl"
    }

    fun formatMoneyToman(amount: Long?): String {
        if (amount == null || amount <= 0L) return "—"
        val n = abs(amount)
        if (n >= 1_000_000_000L) {
            val b = n / 1_000_000_000L
            val m = ((n % 1_000_000_000L).toDouble() / 1_000_000.0).roundToLong()
            if (m == 1000L) return "${toFa(b + 1)} میلیارد"
            return if (m > 0L) "${toFa(b)} میلیارد و ${toFa(m)} میلیون" else "${toFa(b)} میلیارد"
        }
        if (n >= 1_000_000L) {
            val m = (n.toDouble() / 1_000_000.0 * 10.0).roundToLong() / 10.0
            val formatted = if (m % 1.0 == 0.0) m.toLong().toString() else m.toString().replace('.', '٫')
            return "${toFa(formatted)} میلیون"
        }
        if (n >= 1_000L) {
            return "${toFa((n.toDouble() / 1_000.0).roundToLong())} هزار"
        }
        return toFa(n)
    }

    /**
     * Converts Gregorian (gy, gm, gd) to Jalali (jy, jm, jd)
     */
    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gDaysInMonth = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gDaysInMonth[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return Triple(jy, jm, jd)
    }

    /**
     * Converts Jalali (jy, jm, jd) to Gregorian (gy, gm, gd)
     */
    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy2 = jy - 979
        val jm2 = jm - 1
        val jd2 = jd - 1

        var jDayNo = 365 * jy2 + (jy2 / 33) * 8 + ((jy2 % 33 + 3) / 4)
        for (i in 0 until jm2) {
            jDayNo += if (i < 6) 31 else 30
        }
        jDayNo += jd2

        var gDayNo = jDayNo + 79

        var gy = 1600 + 400 * (gDayNo / 146097)
        gDayNo %= 146097

        var leap = true
        if (gDayNo >= 36525) {
            gDayNo--
            gy += 100 * (gDayNo / 36524)
            gDayNo %= 36524

            if (gDayNo >= 365) {
                gDayNo++
            } else {
                leap = false
            }
        }

        gy += 4 * (gDayNo / 1461)
        gDayNo %= 1461

        if (gDayNo >= 366) {
            leap = false
            gDayNo--
            gy += gDayNo / 365
            gDayNo %= 365
        }

        val gDaysInMonth = intArrayOf(
            31, if (leap) 29 else 28, 31, 30, 31, 30,
            31, 31, 30, 31, 30, 31
        )
        var gm = 0
        while (gm < 12 && gDayNo >= gDaysInMonth[gm]) {
            gDayNo -= gDaysInMonth[gm]
            gm++
        }
        return Triple(gy, gm + 1, gDayNo + 1)
    }

    fun jalaliToIso(jy: Int, jm: Int, jd: Int): String {
        val (gy, gm, gd) = jalaliToGregorian(jy, jm, jd)
        return "%04d-%02d-%02d".format(gy, gm, gd)
    }

    fun todayIso(): String {
        val cal = Calendar.getInstance()
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return "%04d-%02d-%02d".format(y, m, d)
    }

    fun shiftDaysIso(daysDelta: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, daysDelta)
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return "%04d-%02d-%02d".format(y, m, d)
    }

    fun currentJalaliMonthKey(): String {
        val cal = Calendar.getInstance()
        val (jy, jm, _) = gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        return "%04d-%02d".format(jy, jm)
    }

    fun currentJalaliMonthLabel(): String {
        val cal = Calendar.getInstance()
        val (jy, jm, _) = gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        val mName = JALALI_MONTH_NAMES.getOrElse(jm - 1) { "" }
        return "$mName ${toFa(jy)}"
    }

    fun formatIsoToJalaliReadable(isoDate: String?): String {
        if (isoDate.isNullOrBlank()) return "—"
        val parts = toEn(isoDate).split("-")
        if (parts.size < 3) return toFa(isoDate)
        val gy = parts[0].toIntOrNull() ?: return toFa(isoDate)
        val gm = parts[1].toIntOrNull() ?: return toFa(isoDate)
        val gd = parts[2].take(2).toIntOrNull() ?: return toFa(isoDate)
        if (gy < 1900) {
            // Already Jalali YYYY-MM-DD
            val mName = JALALI_MONTH_NAMES.getOrElse(gm - 1) { "" }
            return "${toFa(gd)} $mName ${toFa(gy)}"
        }
        val (jy, jm, jd) = gregorianToJalali(gy, gm, gd)
        val mName = JALALI_MONTH_NAMES.getOrElse(jm - 1) { "" }
        return "${toFa(jd)} $mName ${toFa(jy)}"
    }

    fun daysSinceIso(isoDate: String?): Int {
        if (isoDate.isNullOrBlank()) return 999
        return try {
            val parts = toEn(isoDate).split("-")
            if (parts.size < 3) return 999
            val cal = Calendar.getInstance()
            cal.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].take(2).toInt(), 0, 0, 0)
            val diff = System.currentTimeMillis() - cal.timeInMillis
            (diff / 86_400_000L).toInt().coerceAtLeast(0)
        } catch (_: Exception) {
            999
        }
    }

    fun needsFollowUp(lastContactIso: String?, createdAtMs: Long, thresholdDays: Int = 7): Boolean {
        if (!lastContactIso.isNullOrBlank()) {
            return daysSinceIso(lastContactIso) >= thresholdDays
        }
        val ageDays = ((System.currentTimeMillis() - createdAtMs) / 86_400_000L).toInt()
        return ageDays >= thresholdDays
    }

    /**
     * Privacy-safe property share formatter for customers:
     * NEVER leaks sellerName, sellerPhone, or exact address.
     */
    fun formatPrivacySafePropertyShare(p: Property): String {
        val lines = mutableListOf<String>()
        lines.add("🏠 مشخصات ملک کد ${if (p.code.isNotBlank()) toFa(p.code) else "—"}")
        if (p.neighborhood.isNotBlank()) lines.add("📍 محدوده: ${p.neighborhood}")
        if (p.area > 0) lines.add("📐 متراژ: ${toFa(p.area)} متر")
        if (p.bedrooms > 0) lines.add("🛏 تعداد خواب: ${toFa(p.bedrooms)} خواب")
        if (p.unitFloor > 0) {
            val fl = if (p.floors > 0) "طبقه ${toFa(p.unitFloor)} از ${toFa(p.floors)}" else "طبقه ${toFa(p.unitFloor)}"
            lines.add("🏢 $fl")
        }
        if (p.buildingAge > 0) lines.add("🏗 سن بنا: ${toFa(p.buildingAge)} سال")
        if (p.condition.isNotBlank()) lines.add("✨ وضعیت: ${p.condition}")
        if (p.lighting.isNotBlank()) lines.add("☀️ نورگیر: ${p.lighting}")
        val feats = mutableListOf<String>()
        if (p.parking) feats.add("پارکینگ")
        if (p.storage) feats.add("انباری")
        if (p.elevator) feats.add("آسانسور")
        if (p.terrace) feats.add("تراس")
        if (feats.isNotEmpty()) lines.add("✅ امکانات: ${feats.joinToString(" · ")}")
        if (p.totalPrice > 0) lines.add("💰 قیمت کل: ${formatMoneyToman(p.totalPrice)} تومان")
        if (p.pricePerMeter > 0) lines.add("📊 قیمت متری: ${formatMoneyToman(p.pricePerMeter)} تومان")
        return lines.joinToString("\n")
    }

    /**
     * Privacy-guaranteed property share (WhatsApp / Telegram):
     * NEVER transmits sellerName, sellerPhone, or address under any circumstance!
     */
    fun formatColleaguePropertyShare(p: Property): String {
        return formatPrivacySafePropertyShare(p)
    }

    fun isSoldStatus(status: String?): Boolean {
        if (status.isNullOrBlank()) return false
        val clean = normalizeSearch(status).replace(" ", "")
        return clean.contains("فروشرفت") || clean.contains("فروخته") || clean.contains("معاملهشد")
    }

    fun isBoughtStatus(status: String?): Boolean {
        if (status.isNullOrBlank()) return false
        val clean = normalizeSearch(status).replace(" ", "")
        return clean.contains("خریدکرد") || clean.contains("خریداری")
    }
}
