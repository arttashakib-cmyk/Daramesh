package ir.daramash.app.presentation.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.daramash.app.R
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.NavigationTab
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.presentation.theme.AmberSoft
import ir.daramash.app.presentation.theme.AmberWarn
import ir.daramash.app.presentation.theme.BlueInfo
import ir.daramash.app.presentation.theme.BlueSoft
import ir.daramash.app.presentation.theme.DaramashBorder
import ir.daramash.app.presentation.theme.DaramashBorderSoft
import ir.daramash.app.presentation.theme.DaramashFaint
import ir.daramash.app.presentation.theme.DaramashMuted
import ir.daramash.app.presentation.theme.DaramashSpecular
import ir.daramash.app.presentation.theme.DaramashText
import ir.daramash.app.presentation.theme.EmeraldAccent
import ir.daramash.app.presentation.theme.EmeraldBright
import ir.daramash.app.presentation.theme.GlassGradBottom
import ir.daramash.app.presentation.theme.GlassGradMid
import ir.daramash.app.presentation.theme.GlassGradTop
import ir.daramash.app.presentation.theme.RedDanger
import ir.daramash.app.presentation.theme.RedSolid
import ir.daramash.app.presentation.theme.RubyDeep
import ir.daramash.app.presentation.theme.RubyMid
import ir.daramash.app.presentation.theme.RubyPrimary
import ir.daramash.app.presentation.theme.VazirmatnFontFamily

// ============================================================================
// 1. LIQUID GLASS SURFACE (.hg, .pcard, .sys-card, .match-card, .mgr-card)
// ============================================================================

enum class LiquidCardVariant {
    DEFAULT,
    GOLD,        // .hg.gold
    STATUS_GOOD, // .hg.status-good
    STATUS_MID,  // .hg.status-mid
    STATUS_BAD,  // .hg.status-bad
    ACCENT,      // .hg.accent
    BLUE_REPORT, // Monthly report card
    MATCHES_BIG  // .hg.matches-card
}

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 26.dp,
    variant: LiquidCardVariant = LiquidCardVariant.DEFAULT,
    isSelected: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val bgBrush = when (variant) {
        LiquidCardVariant.GOLD -> Brush.linearGradient(
            colors = listOf(Color(0x2EE0A63A), GlassGradMid, GlassGradBottom),
            start = Offset(0f, 0f),
            end = Offset(600f, 800f)
        )
        LiquidCardVariant.STATUS_GOOD, LiquidCardVariant.ACCENT, LiquidCardVariant.MATCHES_BIG -> Brush.linearGradient(
            colors = listOf(Color(0x2E10A37F), GlassGradMid, GlassGradBottom),
            start = Offset(0f, 0f),
            end = Offset(600f, 800f)
        )
        LiquidCardVariant.STATUS_MID -> Brush.linearGradient(
            colors = listOf(Color(0x2EE0A63A), GlassGradMid, GlassGradBottom),
            start = Offset(0f, 0f),
            end = Offset(600f, 800f)
        )
        LiquidCardVariant.STATUS_BAD -> Brush.linearGradient(
            colors = listOf(Color(0x2EE5534B), GlassGradMid, GlassGradBottom),
            start = Offset(0f, 0f),
            end = Offset(600f, 800f)
        )
        LiquidCardVariant.BLUE_REPORT -> Brush.linearGradient(
            colors = listOf(Color(0x1F7FB0FF), GlassGradMid, GlassGradBottom),
            start = Offset(0f, 0f),
            end = Offset(600f, 800f)
        )
        LiquidCardVariant.DEFAULT -> Brush.linearGradient(
            colors = listOf(GlassGradTop, GlassGradMid, GlassGradBottom),
            start = Offset(0f, 0f),
            end = Offset(600f, 900f)
        )
    }

    val borderColor = when {
        isSelected -> EmeraldAccent
        variant == LiquidCardVariant.GOLD -> Color(0x66E0A63A)
        variant == LiquidCardVariant.STATUS_GOOD || variant == LiquidCardVariant.ACCENT || variant == LiquidCardVariant.MATCHES_BIG -> Color(0x6110A37F)
        variant == LiquidCardVariant.STATUS_MID -> Color(0x61E0A63A)
        variant == LiquidCardVariant.STATUS_BAD -> Color(0x61E5534B)
        variant == LiquidCardVariant.BLUE_REPORT -> Color(0x477FB0FF)
        else -> DaramashBorder
    }

    val shape = RoundedCornerShape(cornerRadius)
    val clickMod = if (onClick != null) Modifier.clickable { onClick() } else Modifier

    Box(
        modifier = modifier
            .clip(shape)
            .background(bgBrush, shape)
            .border(if (isSelected) 2.dp else 1.dp, borderColor, shape)
            .then(clickMod)
    ) {
        // Top specular highlight line (::before in original CSS)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .height(1.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, DaramashSpecular, Color.Transparent)
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(contentPadding),
            content = content
        )
    }
}

// ============================================================================
// 2. CAPSULE FILTER CHIPS (.chip & .chip.active)
// ============================================================================

@Composable
fun DaramashChip(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailingClose: Boolean = false
) {
    val shape = RoundedCornerShape(50)
    val bgBrush = if (active) {
        Brush.linearGradient(
            colors = listOf(RubyPrimary, RubyMid, RubyDeep),
            start = Offset(0f, 0f),
            end = Offset(220f, 90f)
        )
    } else {
        Brush.linearGradient(
            colors = listOf(Color(0xEB2A2A36), Color(0xF012121A)),
            start = Offset(0f, 0f),
            end = Offset(180f, 90f)
        )
    }
    val borderColor = if (active) Color(0x8CFF8CA0) else Color(0x2BFFFFFF)
    val textColor = if (active) Color.White else Color(0xD1FFFFFF)

    Box(
        modifier = modifier
            .height(40.dp)
            .clip(shape)
            .background(bgBrush, shape)
            .border(1.dp, borderColor, shape)
            .clickable { onClick() }
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = label,
                color = textColor,
                fontSize = 13.sp,
                fontFamily = VazirmatnFontFamily,
                fontWeight = if (active) FontWeight.Bold else FontWeight.SemiBold,
                maxLines = 1
            )
            if (trailingClose) {
                Text(
                    text = "✕",
                    color = textColor.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ============================================================================
// 3. CAPSULE BUTTONS (.btn-primary, .btn-ghost, .btn-danger)
// ============================================================================

@Composable
fun DaramashPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    small: Boolean = false,
    enabled: Boolean = true
) {
    val shape = RoundedCornerShape(50)
    val brush = Brush.verticalGradient(
        colors = if (enabled) listOf(Color(0xFFFFFFFF), Color(0xFFE6E6EC))
        else listOf(Color(0x66FFFFFF), Color(0x66E6E6EC))
    )
    Box(
        modifier = modifier
            .height(if (small) 34.dp else 40.dp)
            .clip(shape)
            .background(brush, shape)
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = if (small) 14.dp else 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color(0xFF000000),
            fontSize = if (small) 12.sp else 13.5.sp,
            fontFamily = VazirmatnFontFamily,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
fun DaramashGhostButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    small: Boolean = false
) {
    val shape = RoundedCornerShape(50)
    val brush = Brush.linearGradient(
        colors = listOf(Color(0xEB2C2C38), Color(0xF014141C))
    )
    Box(
        modifier = modifier
            .height(if (small) 34.dp else 40.dp)
            .clip(shape)
            .background(brush, shape)
            .border(1.dp, Color(0x2BFFFFFF), shape)
            .clickable { onClick() }
            .padding(horizontal = if (small) 14.dp else 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = if (small) 12.sp else 13.sp,
            fontFamily = VazirmatnFontFamily,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@Composable
fun DaramashDangerButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    small: Boolean = false
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = modifier
            .height(if (small) 34.dp else 40.dp)
            .clip(shape)
            .background(Color(0x2EE5534B), shape)
            .border(1.dp, Color(0x6BE5534B), shape)
            .clickable { onClick() }
            .padding(horizontal = if (small) 14.dp else 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color(0xFFFF8E88),
            fontSize = if (small) 12.sp else 13.sp,
            fontFamily = VazirmatnFontFamily,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

// ============================================================================
// 4. CARD ACTION ICON BUTTON (.icon-btn, .icon-btn.wa, .icon-btn.danger)
// ============================================================================

enum class IconBtnStyle {
    DEFAULT,
    WHATSAPP,
    TELEGRAM,
    DANGER
}

@Composable
fun DaramashCardIconBtn(
    emoji: String,
    onClick: () -> Unit,
    style: IconBtnStyle = IconBtnStyle.DEFAULT,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(10.dp)
    val bg = when (style) {
        IconBtnStyle.WHATSAPP -> Color(0x2410A37F)
        IconBtnStyle.TELEGRAM -> Color(0x243B82F6)
        IconBtnStyle.DANGER -> Color(0x1AE5534B)
        IconBtnStyle.DEFAULT -> Color(0x0DFFFFFF)
    }
    val border = when (style) {
        IconBtnStyle.WHATSAPP -> Color(0x6610A37F)
        IconBtnStyle.TELEGRAM -> Color(0x6660A5FA)
        IconBtnStyle.DANGER -> Color(0x4DE5534B)
        IconBtnStyle.DEFAULT -> DaramashBorder
    }
    Box(
        modifier = modifier
            .size(34.dp)
            .clip(shape)
            .background(bg, shape)
            .border(1.dp, border, shape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = emoji,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
    }
}

// ============================================================================
// 5. STATUS PILLS & AGE BADGES (.pcard-status, .age-badge)
// ============================================================================

@Composable
fun DaramashStatusPill(
    text: String,
    colorType: String // "green", "red", "amber", "blue", "gray"
) {
    val (bg, fg, border) = when (colorType) {
        "green" -> Triple(Color(0x2E10A37F), Color(0xFF4ADE80), Color(0x7334D399))
        "red" -> Triple(Color(0x2EE5534B), Color(0xFFFF8E88), Color(0x73F87171))
        "amber" -> Triple(Color(0x2EE0A63A), Color(0xFFFCD34D), Color(0x73FBBF24))
        "blue" -> Triple(Color(0x2E7FB0FF), Color(0xFF93C5FD), Color(0x7360A5FA))
        else -> Triple(Color(0x14FFFFFF), DaramashMuted, DaramashBorder)
    }
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .clip(shape)
            .background(bg, shape)
            .border(1.dp, border, shape)
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = fg,
            fontSize = 11.sp,
            fontFamily = VazirmatnFontFamily,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DaramashAgeBadge(lastContactIso: String) {
    val days = PersianFormatters.daysSinceIso(lastContactIso)
    val (text, bg, fg, border) = when {
        lastContactIso.isBlank() -> Quad("بدون تماس", Color(0x29E0A63A), Color(0xFFFCD34D), Color(0x59E0A63A))
        days == 0 -> Quad("امروز", Color(0x2410A37F), Color(0xFF4ADE80), Color(0x4D10A37F))
        days <= 3 -> Quad("${PersianFormatters.toFa(days)} روز پیش", Color(0x2410A37F), Color(0xFF4ADE80), Color(0x4D10A37F))
        days <= 10 -> Quad("${PersianFormatters.toFa(days)} روز پیش", Color(0x29E0A63A), Color(0xFFFCD34D), Color(0x59E0A63A))
        else -> Quad("${PersianFormatters.toFa(days)} روز بی‌تماس", Color(0x2EE5534B), Color(0xFFFF8E88), Color(0x66E5534B))
    }
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(bg, shape)
            .border(1.dp, border, shape)
            .padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(fg)
        )
        Text(
            text = text,
            color = fg,
            fontSize = 10.5.sp,
            fontFamily = VazirmatnFontFamily,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

// ============================================================================
// 6. PREVIEW CARDS (.pcard for Property, Customer, Investor)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertyPreviewCard(
    property: Property,
    isSelected: Boolean = false,
    onClick: () -> Unit,
    onQuickLog: () -> Unit,
    onMatchProperty: () -> Unit,
    onEdit: () -> Unit,
    onArchive: () -> Unit
) {
    val context = LocalContext.current
    val isSold = PersianFormatters.isSoldStatus(property.status)
    val statusColor = when (property.status) {
        "فروشنده" -> "green"
        "کنسل کرد", "فروش رفت" -> "red"
        "فروشنده نیست" -> "amber"
        else -> "gray"
    }

    LiquidGlassCard(
        isSelected = isSelected,
        onClick = onClick,
        contentPadding = PaddingValues(18.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // .pcard-head
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Right: Code
                    Column {
                        Text(
                            text = "کد فایل",
                            fontSize = 10.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                        Text(
                            text = if (property.code.isNotBlank()) PersianFormatters.toFa(property.code) else "—",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                    }

                    // Middle: Neighborhood + Age Badge + Advisor Tag
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = "📍 ${property.neighborhood.ifBlank { "—" }}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                        if (property.status == "فروشنده" && property.advisorId.isBlank()) {
                            DaramashAgeBadge(property.lastContact)
                        }
                        if (property.advisorName.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0x247FB0FF))
                                    .border(1.dp, Color(0x527FB0FF), RoundedCornerShape(50))
                                    .padding(horizontal = 9.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "👤 مشاور: ${property.advisorName}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = BlueSoft,
                                    fontFamily = VazirmatnFontFamily
                                )
                            }
                        }
                    }

                    // Left: Status pill
                    DaramashStatusPill(text = property.status.ifBlank { "—" }, colorType = statusColor)
                }

                // .pcard-facts (2-column inner glass box)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0x99000000), Color(0xBA000000))
                            )
                        )
                        .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "متراژ",
                            fontSize = 10.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = if (property.area > 0) "${PersianFormatters.toFa(property.area)} متر" else "—",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "خواب",
                            fontSize = 10.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "${PersianFormatters.toFa(property.bedrooms)} خواب",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                }

                // .pcard-price & .pcard-ppm
                if (property.totalPrice > 0L) {
                    Column {
                        Text(
                            text = "قیمت کل",
                            fontSize = 10.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                        Text(
                            text = "${PersianFormatters.formatMoneyToman(property.totalPrice)} تومان",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = EmeraldBright,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                }

                if (property.pricePerMeter > 0L || property.investable) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (property.pricePerMeter > 0L) {
                            Text(
                                text = "قیمت متری: ${PersianFormatters.formatMoneyToman(property.pricePerMeter)} تومان",
                                fontSize = 11.5.sp,
                                color = DaramashMuted,
                                fontFamily = VazirmatnFontFamily
                            )
                        }
                        if (property.investable) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0x247FB0FF))
                                    .border(1.dp, Color(0x4D7FB0FF), RoundedCornerShape(50))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "💼 قابل سرمایه‌گذاری",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueSoft,
                                    fontFamily = VazirmatnFontFamily
                                )
                            }
                        }
                    }
                }

                // .pcard-feats (Amenity pills)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AmenityFeatPill("🚗 پارکینگ", property.parking)
                    AmenityFeatPill("📦 انباری", property.storage)
                    AmenityFeatPill("🛗 آسانسور", property.elevator)
                    AmenityFeatPill("🌿 تراس", property.terrace)
                }

                // .pcard-bottom
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(width = 0.dp, color = Color.Transparent)
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Right: Contact actions (📞, 💬, ✍️)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (property.sellerPhone.isNotBlank()) {
                            DaramashCardIconBtn(
                                emoji = "📞",
                                onClick = {
                                    val phone = PersianFormatters.toEn(property.sellerPhone)
                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
                                }
                            )
                            DaramashCardIconBtn(
                                emoji = "💬",
                                style = IconBtnStyle.WHATSAPP,
                                onClick = {
                                    val clean = PersianFormatters.toEn(property.sellerPhone).replace(Regex("[^0-9]"), "")
                                    val waPhone = if (clean.startsWith("0")) "98${clean.substring(1)}" else clean
                                    try {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$waPhone")))
                                    } catch (_: Exception) {}
                                }
                            )
                        }
                        DaramashCardIconBtn(
                            emoji = "✍️",
                            onClick = onQuickLog
                        )
                    }

                    // Left: Edit actions (🔎, ✏️, 🗑)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DaramashCardIconBtn(emoji = "🔎", onClick = onMatchProperty)
                        DaramashCardIconBtn(emoji = "✏️", onClick = onEdit)
                        DaramashCardIconBtn(emoji = "🗑", style = IconBtnStyle.DANGER, onClick = onArchive)
                    }
                }
            }

            // Diagonal Stamp if Sold (.stamp)
            if (isSold) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .rotate(-14f)
                        .border(2.5.dp, Color(0xE6FF6B63), RoundedCornerShape(10.dp))
                        .background(Color(0xA6000000), RoundedCornerShape(10.dp))
                        .padding(horizontal = 18.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "فروش رفت",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFF6B63),
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }
        }
    }
}

@Composable
private fun AmenityFeatPill(label: String, active: Boolean) {
    val shape = RoundedCornerShape(8.dp)
    val bg = if (active) Color(0x1F10A37F) else Color(0x05FFFFFF)
    val border = if (active) Color(0x4710A37F) else DaramashBorderSoft
    val fg = if (active) Color(0xFF4ADE80) else DaramashFaint
    Box(
        modifier = Modifier
            .clip(shape)
            .background(bg, shape)
            .border(1.dp, border, shape)
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            fontFamily = VazirmatnFontFamily
        )
    }
}

@Composable
fun CustomerPreviewCard(
    customer: Customer,
    isSelected: Boolean = false,
    onClick: () -> Unit,
    onQuickLog: () -> Unit,
    onMatchCustomer: () -> Unit,
    onEdit: () -> Unit,
    onArchive: () -> Unit
) {
    val context = LocalContext.current
    val isBought = PersianFormatters.isBoughtStatus(customer.status)
    val qColor = when (customer.quality) {
        "داغ" -> "red"
        "گرم" -> "amber"
        else -> "blue"
    }
    val initials = customer.fullName.trim().take(2).ifBlank { "م" }

    LiquidGlassCard(
        isSelected = isSelected,
        onClick = onClick,
        contentPadding = PaddingValues(18.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // .pcard-head
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Avatar (.pcard-avatar)
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0x4D10A37F), Color(0x1410A37F))
                                )
                            )
                            .border(1.dp, Color(0x6610A37F), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initials,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF4ADE80),
                            fontFamily = VazirmatnFontFamily
                        )
                    }

                    // Name + Phone + Age
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = customer.fullName,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                        Text(
                            text = if (customer.phone1.isNotBlank()) PersianFormatters.toFa(customer.phone1) else "—",
                            fontSize = 11.5.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                        DaramashAgeBadge(customer.lastContact)
                    }

                    if (customer.quality.isNotBlank()) {
                        DaramashStatusPill(text = customer.quality, colorType = qColor)
                    }
                }

                // .pcard-facts
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xA6000000))
                        .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("حداقل متراژ", fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = if (customer.areaMin > 0) "${PersianFormatters.toFa(customer.areaMin)} متر" else "—",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("خواب", fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = if (customer.bedroomsMin > 0) "${PersianFormatters.toFa(customer.bedroomsMin)} خواب" else "—",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                }

                if (customer.budgetMax > 0L) {
                    Column {
                        Text("حداکثر بودجه", fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Text(
                            text = "${PersianFormatters.formatMoneyToman(customer.budgetMax)} تومان",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = EmeraldBright,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                }

                if (customer.neighborhoods.isNotEmpty()) {
                    Text(
                        text = "📍 ${customer.neighborhoods.joinToString("، ")}",
                        fontSize = 12.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }

                // .pcard-bottom
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (customer.phone1.isNotBlank()) {
                            DaramashCardIconBtn(
                                emoji = "📞",
                                onClick = {
                                    val phone = PersianFormatters.toEn(customer.phone1)
                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
                                }
                            )
                            DaramashCardIconBtn(
                                emoji = "💬",
                                style = IconBtnStyle.WHATSAPP,
                                onClick = {
                                    val clean = PersianFormatters.toEn(customer.phone1).replace(Regex("[^0-9]"), "")
                                    val waPhone = if (clean.startsWith("0")) "98${clean.substring(1)}" else clean
                                    try {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$waPhone")))
                                    } catch (_: Exception) {}
                                }
                            )
                        }
                        DaramashCardIconBtn(emoji = "✍️", onClick = onQuickLog)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DaramashCardIconBtn(emoji = "🔎", onClick = onMatchCustomer)
                        DaramashCardIconBtn(emoji = "✏️", onClick = onEdit)
                        DaramashCardIconBtn(emoji = "🗑", style = IconBtnStyle.DANGER, onClick = onArchive)
                    }
                }
            }

            if (isBought) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .rotate(-14f)
                        .border(2.5.dp, Color(0xE6FF6B63), RoundedCornerShape(10.dp))
                        .background(Color(0xA6000000), RoundedCornerShape(10.dp))
                        .padding(horizontal = 18.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "خرید کرد",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFF6B63),
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }
        }
    }
}

@Composable
fun InvestorPreviewCard(
    investor: Investor,
    onClick: () -> Unit,
    onQuickLog: () -> Unit,
    onMatchInvestor: () -> Unit,
    onEdit: () -> Unit,
    onArchive: () -> Unit
) {
    val context = LocalContext.current
    val btColor = when (investor.businessType) {
        "آدم حسابی" -> "green"
        "چقر" -> "amber"
        "چینی" -> "blue"
        else -> if (investor.businessType.isNotBlank()) "blue" else "gray"
    }

    LiquidGlassCard(
        onClick = onClick,
        contentPadding = PaddingValues(18.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // .pcard-avatar.inv
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0x4DE0A63A), Color(0x14E0A63A))
                            )
                        )
                        .border(1.dp, Color(0x66E0A63A), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("💼", fontSize = 18.sp)
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = investor.fullName,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = if (investor.phone1.isNotBlank()) PersianFormatters.toFa(investor.phone1) else "—",
                        fontSize = 11.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                    DaramashAgeBadge(investor.lastContact)
                }

                if (investor.businessType.isNotBlank()) {
                    DaramashStatusPill(text = investor.businessType, colorType = btColor)
                }
            }

            // .pcard-facts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xA6000000))
                    .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(18.dp))
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("آخرین تماس", fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = if (investor.lastContact.isNotBlank()) PersianFormatters.formatIsoToJalaliReadable(investor.lastContact) else "—",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("خرید دارد؟", fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = investor.hasBuy.ifBlank { "بله" },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (investor.hasBuy == "بله" || investor.hasBuy.isBlank()) EmeraldBright else DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }

            if (investor.buyAmount > 0L) {
                Column {
                    Text("مبلغ خرید", fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    Text(
                        text = "${PersianFormatters.formatMoneyToman(investor.buyAmount)} تومان",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        color = EmeraldBright,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }

            if (investor.neighborhoods.isNotEmpty()) {
                Text(
                    text = "📍 ${investor.neighborhoods.joinToString("، ")}",
                    fontSize = 12.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (investor.phone1.isNotBlank()) {
                        DaramashCardIconBtn(
                            emoji = "📞",
                            onClick = {
                                val phone = PersianFormatters.toEn(investor.phone1)
                                context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
                            }
                        )
                        DaramashCardIconBtn(
                            emoji = "💬",
                            style = IconBtnStyle.WHATSAPP,
                            onClick = {
                                val clean = PersianFormatters.toEn(investor.phone1).replace(Regex("[^0-9]"), "")
                                val waPhone = if (clean.startsWith("0")) "98${clean.substring(1)}" else clean
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$waPhone")))
                                } catch (_: Exception) {}
                            }
                        )
                    }
                    DaramashCardIconBtn(emoji = "✍️", onClick = onQuickLog)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DaramashCardIconBtn(emoji = "🔎", onClick = onMatchInvestor)
                    DaramashCardIconBtn(emoji = "✏️", onClick = onEdit)
                    DaramashCardIconBtn(emoji = "🗑", style = IconBtnStyle.DANGER, onClick = onArchive)
                }
            }
        }
    }
}

// ============================================================================
// 7. EXACT VECTOR ICONS (Matching SVG paths in www/index.html)
// ============================================================================

@Composable
fun DaramashSvgIcon(
    type: String,
    tint: Color,
    modifier: Modifier = Modifier.size(20.dp)
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = w * 0.095f, cap = StrokeCap.Round, join = StrokeJoin.Round)

        when (type) {
            "menu" -> {
                // <path d="M4 6h16M4 12h16M4 18h16"/>
                drawLine(tint, Offset(w * 0.17f, h * 0.25f), Offset(w * 0.83f, h * 0.25f), stroke.width, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.17f, h * 0.50f), Offset(w * 0.83f, h * 0.50f), stroke.width, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.17f, h * 0.75f), Offset(w * 0.83f, h * 0.75f), stroke.width, StrokeCap.Round)
            }
            "search" -> {
                // <circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>
                drawCircle(tint, radius = w * 0.29f, center = Offset(w * 0.45f, h * 0.45f), style = stroke)
                drawLine(tint, Offset(w * 0.66f, h * 0.66f), Offset(w * 0.84f, h * 0.84f), stroke.width, StrokeCap.Round)
            }
            "home" -> {
                // <path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>
                val p = Path().apply {
                    moveTo(w * 0.125f, h * 0.44f)
                    lineTo(w * 0.5f, h * 0.125f)
                    lineTo(w * 0.875f, h * 0.44f)
                    lineTo(w * 0.875f, h * 0.85f)
                    lineTo(w * 0.625f, h * 0.85f)
                    lineTo(w * 0.625f, h * 0.60f)
                    lineTo(w * 0.375f, h * 0.60f)
                    lineTo(w * 0.375f, h * 0.85f)
                    lineTo(w * 0.125f, h * 0.85f)
                    close()
                }
                drawPath(p, tint, style = stroke)
            }
            "properties" -> {
                // <path d="M4 11 12 4l8 7v9H4z"/><path d="M9 20v-6h6v6"/>
                val roof = Path().apply {
                    moveTo(w * 0.16f, h * 0.46f)
                    lineTo(w * 0.50f, h * 0.16f)
                    lineTo(w * 0.84f, h * 0.46f)
                    lineTo(w * 0.84f, h * 0.84f)
                    lineTo(w * 0.16f, h * 0.84f)
                    close()
                }
                drawPath(roof, tint, style = stroke)
                val door = Path().apply {
                    moveTo(w * 0.38f, h * 0.84f)
                    lineTo(w * 0.38f, h * 0.58f)
                    lineTo(w * 0.62f, h * 0.58f)
                    lineTo(w * 0.62f, h * 0.84f)
                }
                drawPath(door, tint, style = stroke)
            }
            "matching" -> {
                // <rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/><path d="m9 15 2 2 4-4"/>
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.13f, h * 0.21f),
                    size = Size(w * 0.74f, h * 0.66f),
                    cornerRadius = CornerRadius(w * 0.08f, w * 0.08f),
                    style = stroke
                )
                drawLine(tint, Offset(w * 0.33f, h * 0.12f), Offset(w * 0.33f, h * 0.29f), stroke.width, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.67f, h * 0.12f), Offset(w * 0.67f, h * 0.29f), stroke.width, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.13f, h * 0.42f), Offset(w * 0.87f, h * 0.42f), stroke.width, StrokeCap.Round)
                val check = Path().apply {
                    moveTo(w * 0.36f, h * 0.63f)
                    lineTo(w * 0.46f, h * 0.72f)
                    lineTo(w * 0.65f, h * 0.54f)
                }
                drawPath(check, tint, style = stroke)
            }
            "customers" -> {
                // <circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.5-5.5 6.5-5.5s5.7 2 6.5 5.5"/>
                drawCircle(tint, radius = w * 0.16f, center = Offset(w * 0.42f, h * 0.33f), style = stroke)
                val body = Path().apply {
                    moveTo(w * 0.15f, h * 0.83f)
                    cubicTo(w * 0.20f, h * 0.58f, w * 0.64f, h * 0.58f, w * 0.70f, h * 0.83f)
                }
                drawPath(body, tint, style = stroke)
                drawCircle(tint, radius = w * 0.11f, center = Offset(w * 0.72f, h * 0.38f), style = stroke)
            }
            "target" -> {
                // <circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/>
                drawCircle(tint, radius = w * 0.38f, center = Offset(w * 0.5f, h * 0.5f), style = stroke)
                drawCircle(tint, radius = w * 0.21f, center = Offset(w * 0.5f, h * 0.5f), style = stroke)
                drawCircle(tint, radius = w * 0.07f, center = Offset(w * 0.5f, h * 0.5f))
            }
            "sparkles" -> {
                // <path d="M12 3l1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9L12 3z"/>
                val star = Path().apply {
                    moveTo(w * 0.50f, h * 0.12f)
                    lineTo(w * 0.60f, h * 0.36f)
                    lineTo(w * 0.84f, h * 0.46f)
                    lineTo(w * 0.60f, h * 0.56f)
                    lineTo(w * 0.50f, h * 0.80f)
                    lineTo(w * 0.40f, h * 0.56f)
                    lineTo(w * 0.16f, h * 0.46f)
                    lineTo(w * 0.40f, h * 0.36f)
                    close()
                }
                drawPath(star, tint, style = stroke)
                drawCircle(tint, radius = w * 0.06f, center = Offset(w * 0.78f, h * 0.78f))
            }
            "plus" -> {
                // <path d="M12 5v14M5 12h14"/>
                val s = w * 0.11f
                drawLine(tint, Offset(w * 0.5f, h * 0.21f), Offset(w * 0.5f, h * 0.79f), s, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.21f, h * 0.5f), Offset(w * 0.79f, h * 0.5f), s, StrokeCap.Round)
            }
            "close" -> {
                drawLine(tint, Offset(w * 0.26f, h * 0.26f), Offset(w * 0.74f, h * 0.74f), stroke.width, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.74f, h * 0.26f), Offset(w * 0.26f, h * 0.74f), stroke.width, StrokeCap.Round)
            }
            "refresh" -> {
                drawArc(
                    color = tint,
                    startAngle = -35f,
                    sweepAngle = 290f,
                    useCenter = false,
                    topLeft = Offset(w * 0.18f, h * 0.18f),
                    size = Size(w * 0.64f, h * 0.64f),
                    style = stroke
                )
            }
        }
    }
}
