package ir.daramash.app.worker

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import ir.daramash.app.MainActivity
import ir.daramash.app.R
import ir.daramash.app.data.local.db.DaramashDatabase
import ir.daramash.app.data.local.prefs.SecureAuthPreferences
import ir.daramash.app.domain.usecase.PersianFormatters
import java.util.concurrent.TimeUnit

class FollowUpReminderWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val prefs = SecureAuthPreferences(applicationContext)
        if (!prefs.areNotificationsEnabled()) return Result.success()

        val dao = DaramashDatabase.getInstance(applicationContext).dao()
        val properties = dao.getAllPropertiesNow().filter { !it.isArchived && it.status == "فروشنده" }
        val customers = dao.getAllCustomersNow().filter { !it.isArchived }

        val followUpProps = properties.count { PersianFormatters.needsFollowUp(it.lastContact, it.createdAt) }
        val followUpCusts = customers.count { PersianFormatters.needsFollowUp(it.lastContact, it.createdAt) }
        val totalFollowUp = followUpProps + followUpCusts

        if (totalFollowUp > 0) {
            postFollowUpNotification(applicationContext, followUpProps, followUpCusts)
        }
        return Result.success()
    }

    companion object {
        const val CHANNEL_ID = "daramash_followup_channel"
        const val WORK_NAME = "daramash_periodic_followup_work"
        private const val NOTIFICATION_ID = 1042

        fun createNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "یادآوری پیگیری فایل‌ها و مشتریان",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "اعلان هوشمند برای فایل‌ها و مشتریانی که بیش از ۷ روز تماس نداشته‌اند"
                }
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                manager?.createNotificationChannel(channel)
            }
        }

        fun schedulePeriodicWork(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiresBatteryNotLow(true)
                .build()

            val request = PeriodicWorkRequestBuilder<FollowUpReminderWorker>(12, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun postFollowUpNotification(context: Context, propCount: Int, custCount: Int) {
            createNotificationChannel(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    return
                }
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val title = "⏰ ${PersianFormatters.toFa(propCount + custCount)} پرونده نیازمند پیگیری فوری"
            val body = "${PersianFormatters.toFa(propCount)} فایل املاک و ${PersianFormatters.toFa(custCount)} مشتری بیش از ۷ روز بدون تماس هستند."

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_daramash)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .build()

            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }
    }
}
