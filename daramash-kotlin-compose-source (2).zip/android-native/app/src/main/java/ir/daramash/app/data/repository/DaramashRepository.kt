package ir.daramash.app.data.repository

import android.content.Context
import android.util.Base64
import ir.daramash.app.data.backup.BackupExportManager
import ir.daramash.app.data.local.dao.DaramashDao
import ir.daramash.app.data.local.entity.toEntity
import ir.daramash.app.data.local.prefs.SecureAuthPreferences
import ir.daramash.app.data.remote.CloudNetworkService
import ir.daramash.app.domain.model.ActivityLog
import ir.daramash.app.domain.model.Advisor
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchLink
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.usecase.PersianFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.UUID

class DaramashRepository(
    private val context: Context,
    private val dao: DaramashDao,
    val prefs: SecureAuthPreferences,
    val network: CloudNetworkService
) {

    val activePropertiesFlow: Flow<List<Property>> =
        dao.observeActiveProperties().map { list -> list.map { it.toDomain() } }

    val archivedPropertiesFlow: Flow<List<Property>> =
        dao.observeArchivedProperties().map { list -> list.map { it.toDomain() } }

    val activeCustomersFlow: Flow<List<Customer>> =
        dao.observeActiveCustomers().map { list -> list.map { it.toDomain() } }

    val archivedCustomersFlow: Flow<List<Customer>> =
        dao.observeArchivedCustomers().map { list -> list.map { it.toDomain() } }

    val activeInvestorsFlow: Flow<List<Investor>> =
        dao.observeActiveInvestors().map { list -> list.map { it.toDomain() } }

    val archivedInvestorsFlow: Flow<List<Investor>> =
        dao.observeArchivedInvestors().map { list -> list.map { it.toDomain() } }

    val matchesFlow: Flow<List<MatchLink>> =
        dao.observeMatches().map { list -> list.map { it.toDomain() } }

    val activityLogsFlow: Flow<List<ActivityLog>> =
        dao.observeActivityLogs().map { list -> list.map { it.toDomain() } }

    val advisorsFlow: Flow<List<Advisor>> =
        dao.observeAdvisors().map { list -> list.map { it.toDomain() } }

    /**
     * Fresh install stays 100% clean and empty.
     * Mock data is NEVER loaded automatically on first launch!
     */
    suspend fun ensureInitialPortfolioSeeded() = withContext(Dispatchers.IO) {
        // Deliberately no-op on first run. Database starts completely clean.
    }

    /**
     * Loads realistic sample demo data explicitly when user clicks "بارگذاری داده‌ی نمونه" in System.
     */
    suspend fun loadDemoData(): Result<Int> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val p1 = Property(
            id = "demo_prop_1042",
            code = "۱۰۴۲",
            area = 78,
            bedrooms = 2,
            floors = 5,
            unitsPerFloor = 2,
            unitFloor = 3,
            buildingAge = 5,
            facade = "سنگ",
            condition = "بازسازی شده",
            lighting = "دو کله نور",
            parking = true,
            storage = true,
            elevator = true,
            terrace = true,
            totalPrice = 14_200_000_000L,
            pricePerMeter = 182_051_282L,
            occupancy = "تخلیه",
            neighborhood = "پونک",
            address = "تهران، پونک، بلوار همیلا",
            visit = "با هماهنگی",
            sellerName = "رضا احمدی",
            sellerPhone = "09121112233",
            sellReason = "خرید واحد بزرگ‌تر",
            exchange = "نمی‌کند",
            regDate = PersianFormatters.shiftDaysIso(-15),
            lastContact = PersianFormatters.shiftDaysIso(-1),
            status = "فروشنده",
            investable = false,
            note = "نور عالی، بازسازی کامل سال گذشته",
            demo = true,
            createdAt = now - 15L * 86_400_000L
        )
        val p2 = Property(
            id = "demo_prop_1043",
            code = "۱۰۴۳",
            area = 82,
            bedrooms = 2,
            floors = 8,
            unitsPerFloor = 2,
            unitFloor = 5,
            buildingAge = 12,
            facade = "آجر",
            condition = "تمیز",
            lighting = "سالن پرده خور",
            parking = false,
            storage = true,
            elevator = true,
            terrace = false,
            totalPrice = 14_500_000_000L,
            pricePerMeter = 176_829_268L,
            occupancy = "ساکن",
            neighborhood = "شهرک نفت",
            address = "تهران، شهرک نفت",
            visit = "کلید املاک",
            sellerName = "فاطمه رضایی",
            sellerPhone = "09122223344",
            sellReason = "مهاجرت",
            exchange = "می‌کند",
            regDate = PersianFormatters.shiftDaysIso(-20),
            lastContact = PersianFormatters.shiftDaysIso(-12),
            status = "فروشنده",
            investable = false,
            demo = true,
            createdAt = now - 20L * 86_400_000L
        )
        val p3 = Property(
            id = "demo_prop_1044",
            code = "۱۰۴۴",
            area = 100,
            bedrooms = 3,
            floors = 4,
            unitsPerFloor = 1,
            unitFloor = 2,
            buildingAge = 2,
            facade = "تراورتن",
            condition = "بازسازی شده",
            lighting = "فول پاسیو",
            parking = true,
            storage = true,
            elevator = true,
            terrace = true,
            totalPrice = 22_000_000_000L,
            pricePerMeter = 220_000_000L,
            occupancy = "مستاجر",
            contractDuration = "۲ سال",
            deposit = 500_000_000L,
            rent = 60_000_000L,
            neighborhood = "جنت شمال",
            address = "تهران، جنت شمال",
            visit = "با هماهنگی",
            sellerName = "علی کریمی",
            sellerPhone = "09123334455",
            sellReason = "سرمایه‌گذاری",
            exchange = "می‌کند",
            regDate = PersianFormatters.shiftDaysIso(-30),
            lastContact = PersianFormatters.shiftDaysIso(-3),
            status = "فروشنده",
            investable = true,
            demo = true,
            createdAt = now - 30L * 86_400_000L
        )

        val c1 = Customer(
            id = "demo_cust_1",
            firstName = "حسین",
            lastName = "محمدی",
            phone1 = "09351112233",
            neighborhoods = listOf("پونک", "همیلا"),
            areaMin = 70,
            bedroomsMin = 2,
            buildingAgeMax = 8,
            budgetMax = 15_000_000_000L,
            reqParking = true,
            reqElevator = true,
            noElevatorMaxFloor = 2,
            quality = "داغ",
            payment = "نقد",
            purpose = "سکونت",
            status = "در جست و جو",
            regDate = PersianFormatters.shiftDaysIso(-7),
            lastContact = PersianFormatters.shiftDaysIso(-1),
            demo = true,
            createdAt = now - 7L * 86_400_000L
        )
        val c2 = Customer(
            id = "demo_cust_2",
            firstName = "مریم",
            lastName = "محمودی",
            phone1 = "09122223333",
            neighborhoods = listOf("جنت شمال", "جنت مرکز"),
            areaMin = 80,
            bedroomsMin = 2,
            buildingAgeMax = 12,
            budgetMax = 20_000_000_000L,
            reqElevator = true,
            reqStorage = true,
            quality = "گرم",
            payment = "نیاز به فروش واحد",
            purpose = "سرمایه‌گذاری",
            status = "تازه تو بازار",
            regDate = PersianFormatters.shiftDaysIso(-3),
            lastContact = PersianFormatters.shiftDaysIso(-9),
            demo = true,
            createdAt = now - 3L * 86_400_000L
        )

        val inv1 = Investor(
            id = "demo_inv_1",
            firstName = "آقای",
            lastName = "صادقی",
            phone1 = "09121234567",
            neighborhoods = listOf("جنت شمال", "باغ فیض"),
            existingUnits = "۱۰۴۲ — ۱۰۵۰",
            hasBuy = "بله",
            buyAmount = 40_000_000_000L,
            telegramChannel = "https://t.me/sadeghi_invest",
            businessType = "آدم حسابی",
            lastContact = PersianFormatters.shiftDaysIso(-2),
            note = "به دنبال ملک لوکس برای سرمایه‌گذاری بلندمدت",
            demo = true,
            createdAt = now - 5L * 86_400_000L
        )

        val match1 = MatchLink(
            id = "demo_match_1",
            propertyId = p1.id,
            needId = c1.id,
            needKind = "customer",
            demo = true,
            createdAt = now - 2L * 86_400_000L
        )

        val logs = listOf(
            ActivityLog(
                id = "demo_log_1",
                entityType = "property",
                entityId = p1.id,
                type = "تماس",
                note = "قیمت مالک تأیید شد و آماده بازدید است",
                date = PersianFormatters.shiftDaysIso(-1),
                demo = true,
                createdAt = now - 86_400_000L
            ),
            ActivityLog(
                id = "demo_log_2",
                entityType = "customer",
                entityId = c1.id,
                type = "بازدید",
                note = "بازدید از فایل ۱۰۴۲ پونک هماهنگ شد",
                date = PersianFormatters.shiftDaysIso(-2),
                demo = true,
                createdAt = now - 2L * 86_400_000L
            )
        )

        dao.upsertProperties(listOf(p1.toEntity(), p2.toEntity(), p3.toEntity()))
        dao.upsertCustomers(listOf(c1.toEntity(), c2.toEntity()))
        dao.upsertInvestors(listOf(inv1.toEntity()))
        dao.insertMatches(listOf(match1.toEntity()))
        dao.insertActivityLogs(logs.map { it.toEntity() })

        val total = 3 + 2 + 1
        Result.success(total)
    }

    /**
     * Purges all sample demo records in one clean tap.
     */
    suspend fun removeDemoData(): Result<Int> = withContext(Dispatchers.IO) {
        val demoSigs = mapOf(
            "09121112233" to "رضا احمدی",
            "09122223344" to "فاطمه رضایی",
            "09123334455" to "علی کریمی"
        )
        val demoCustSigs = mapOf(
            "09351112233" to "حسین محمدی",
            "09122223333" to "مریم محمودی"
        )
        val demoInvSigs = mapOf(
            "09121234567" to "آقای صادقی"
        )

        val allProps = dao.getAllPropertiesNow()
        val toDeletePropIds = allProps.filter { p ->
            p.id.startsWith("demo_") || (demoSigs[p.sellerPhone] != null && demoSigs[p.sellerPhone] == p.sellerName)
        }.map { it.id }

        val allCusts = dao.getAllCustomersNow()
        val toDeleteCustIds = allCusts.filter { c ->
            c.id.startsWith("demo_") || (demoCustSigs[c.phone1] != null && demoCustSigs[c.phone1] == "${c.firstName} ${c.lastName}".trim())
        }.map { it.id }

        val allInvs = dao.getAllInvestorsNow()
        val toDeleteInvIds = allInvs.filter { i ->
            i.id.startsWith("demo_") || (demoInvSigs[i.phone1] != null && demoInvSigs[i.phone1] == "${i.firstName} ${i.lastName}".trim())
        }.map { it.id }

        if (toDeletePropIds.isNotEmpty()) dao.deletePropertiesByIds(toDeletePropIds)
        if (toDeleteCustIds.isNotEmpty()) dao.deleteCustomersByIds(toDeleteCustIds)
        if (toDeleteInvIds.isNotEmpty()) dao.deleteInvestorsByIds(toDeleteInvIds)

        val total = toDeletePropIds.size + toDeleteCustIds.size + toDeleteInvIds.size
        Result.success(total)
    }

    suspend fun demoCount(): Int = withContext(Dispatchers.IO) {
        val demoSigs = setOf("09121112233", "09122223344", "09123334455")
        val demoCustSigs = setOf("09351112233", "09122223333")
        val demoInvSigs = setOf("09121234567")
        val pCount = dao.getAllPropertiesNow().count { it.id.startsWith("demo_") || it.sellerPhone in demoSigs }
        val cCount = dao.getAllCustomersNow().count { it.id.startsWith("demo_") || it.phone1 in demoCustSigs }
        val iCount = dao.getAllInvestorsNow().count { it.id.startsWith("demo_") || it.phone1 in demoInvSigs }
        pCount + cCount + iCount
    }

    suspend fun saveProperty(property: Property, checkDuplicate: Boolean = true): Result<Property> = withContext(Dispatchers.IO) {
        if (checkDuplicate && property.code.isNotBlank()) {
            val dup = dao.findPropertyByCode(property.code)
            if (dup != null && dup.id != property.id) {
                return@withContext Result.failure(IllegalArgumentException("فایلی با کد «${PersianFormatters.toFa(property.code)}» قبلاً ثبت شده است."))
            }
        }
        val normalized = property.copy(
            code = PersianFormatters.scrubSafeText(property.code),
            sellerPhone = PersianFormatters.normalizePhoneDigits(property.sellerPhone),
            pricePerMeter = if (property.totalPrice > 0 && property.area > 0) property.totalPrice / property.area else property.pricePerMeter,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertProperty(normalized.toEntity())
        Result.success(normalized)
    }

    suspend fun saveCustomer(customer: Customer, checkDuplicate: Boolean = true): Result<Customer> = withContext(Dispatchers.IO) {
        val normPhone = PersianFormatters.normalizePhoneDigits(customer.phone1)
        if (checkDuplicate && normPhone.isNotBlank()) {
            val dup = dao.findCustomerByPhone(normPhone)
            if (dup != null && dup.id != customer.id) {
                return@withContext Result.failure(IllegalArgumentException("مشتری دیگری با شماره «${PersianFormatters.toFa(normPhone)}» در سیستم وجود دارد."))
            }
        }
        val normalized = customer.copy(
            phone1 = normPhone,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertCustomer(normalized.toEntity())
        Result.success(normalized)
    }

    suspend fun saveInvestor(investor: Investor): Result<Investor> = withContext(Dispatchers.IO) {
        val normalized = investor.copy(
            phone1 = PersianFormatters.normalizePhoneDigits(investor.phone1),
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertInvestor(normalized.toEntity())
        Result.success(normalized)
    }

    suspend fun archiveProperties(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.archivePropertiesByIds(ids)
    }

    suspend fun restoreProperty(id: String) = withContext(Dispatchers.IO) {
        dao.restorePropertyById(id)
    }

    suspend fun deletePropertiesPermanently(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.deletePropertiesByIds(ids)
    }

    suspend fun archiveCustomers(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.archiveCustomersByIds(ids)
    }

    suspend fun restoreCustomer(id: String) = withContext(Dispatchers.IO) {
        dao.restoreCustomerById(id)
    }

    suspend fun deleteCustomersPermanently(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.deleteCustomersByIds(ids)
    }

    suspend fun archiveInvestors(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.archiveInvestorsByIds(ids)
    }

    suspend fun restoreInvestor(id: String) = withContext(Dispatchers.IO) {
        dao.restoreInvestorById(id)
    }

    suspend fun deleteInvestorsPermanently(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.deleteInvestorsByIds(ids)
    }

    suspend fun toggleMatchLink(propertyId: String, needId: String, needKind: String, currentlyLinked: Boolean) = withContext(Dispatchers.IO) {
        if (currentlyLinked) {
            dao.deleteMatch(propertyId, needId)
        } else {
            dao.insertMatch(
                MatchLink(
                    id = UUID.randomUUID().toString(),
                    propertyId = propertyId,
                    needId = needId,
                    needKind = needKind
                ).toEntity()
            )
        }
    }

    suspend fun logActivity(entityType: String, entityId: String, type: String, note: String) = withContext(Dispatchers.IO) {
        val today = PersianFormatters.todayIso()
        dao.insertActivityLog(
            ActivityLog(
                id = UUID.randomUUID().toString(),
                entityType = entityType,
                entityId = entityId,
                type = type,
                note = PersianFormatters.scrubSafeText(note),
                date = today
            ).toEntity()
        )
        // Update lastContact on the entity automatically
        when (entityType) {
            "property" -> {
                val p = dao.getAllPropertiesNow().find { it.id == entityId }
                if (p != null) dao.upsertProperty(p.copy(lastContact = today, updatedAt = System.currentTimeMillis()))
            }
            "customer" -> {
                val c = dao.getAllCustomersNow().find { it.id == entityId }
                if (c != null) dao.upsertCustomer(c.copy(lastContact = today, updatedAt = System.currentTimeMillis()))
            }
            "investor" -> {
                val inv = dao.getAllInvestorsNow().find { it.id == entityId }
                if (inv != null) dao.upsertInvestor(inv.copy(lastContact = today, updatedAt = System.currentTimeMillis()))
            }
        }
    }

    suspend fun addAdvisor(name: String, phone: String, specialty: String) = withContext(Dispatchers.IO) {
        dao.upsertAdvisor(
            Advisor(
                id = UUID.randomUUID().toString(),
                name = PersianFormatters.scrubSafeText(name),
                phone = PersianFormatters.normalizePhoneDigits(phone),
                specialtyNeighborhood = PersianFormatters.scrubSafeText(specialty)
            ).toEntity()
        )
    }

    suspend fun deleteAdvisor(id: String) = withContext(Dispatchers.IO) {
        dao.deleteAdvisor(id)
    }

    /**
     * Generates a compact Base64 Advisor Transfer Code (کد انتقال مشاور) for Manager Panel.
     */
    suspend fun generateAdvisorTransferCode(advisorName: String): String = withContext(Dispatchers.IO) {
        val props = dao.getAllPropertiesNow().filter { !it.isArchived }.take(10).map { it.toDomain() }
        val custs = dao.getAllCustomersNow().filter { !it.isArchived }.take(10).map { it.toDomain() }
        val json = BackupExportManager.exportFullBackupJson(
            properties = props.map { it.copy(advisorName = advisorName) },
            customers = custs.map { it.copy(advisorName = advisorName) },
            investors = emptyList(),
            matches = emptyList(),
            activities = emptyList(),
            advisors = emptyList(),
            target = prefs.getAdvisorTarget()
        )
        "DA1:" + Base64.encodeToString(json.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
    }

    suspend fun importAdvisorTransferCode(code: String): Result<Int> = withContext(Dispatchers.IO) {
        val trimmed = code.trim()
        val rawJson = if (trimmed.startsWith("DA1:")) {
            String(Base64.decode(trimmed.removePrefix("DA1:"), Base64.DEFAULT), StandardCharsets.UTF_8)
        } else {
            trimmed
        }
        val parsed = BackupExportManager.validateAndParseBackupJson(rawJson).getOrElse {
            return@withContext Result.failure(it)
        }
        dao.upsertProperties(parsed.properties.map { it.toEntity() })
        dao.upsertCustomers(parsed.customers.map { it.toEntity() })
        Result.success(parsed.properties.size + parsed.customers.size)
    }

    /**
     * Creates a full JSON backup string and also saves a local safety snapshot before any restore.
     */
    suspend fun exportFullBackupJson(): String = withContext(Dispatchers.IO) {
        BackupExportManager.exportFullBackupJson(
            properties = dao.getAllPropertiesNow().map { it.toDomain() },
            customers = dao.getAllCustomersNow().map { it.toDomain() },
            investors = dao.getAllInvestorsNow().map { it.toDomain() },
            matches = dao.getAllMatchesNow().map { it.toDomain() },
            activities = dao.getAllActivityLogsNow().map { it.toDomain() },
            advisors = dao.getAllAdvisorsNow().map { it.toDomain() },
            target = prefs.getAdvisorTarget()
        )
    }

    /**
     * Validates backup JSON, writes a pre-restore safety snapshot to internal storage,
     * and atomically replaces the SQLite database inside a Room @Transaction.
     */
    suspend fun restoreFromBackupJson(rawJson: String): Result<String> = withContext(Dispatchers.IO) {
        val parsed = BackupExportManager.validateAndParseBackupJson(rawJson).getOrElse {
            return@withContext Result.failure(it)
        }
        // Save automatic pre-restore safety backup so data is never lost
        try {
            val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
            val safetyFile = File(backupDir, "pre_restore_snapshot.json")
            safetyFile.writeText(exportFullBackupJson(), StandardCharsets.UTF_8)
        } catch (_: Exception) {}

        dao.replaceEntireDatabaseTransaction(
            properties = parsed.properties.map { it.toEntity() },
            customers = parsed.customers.map { it.toEntity() },
            investors = parsed.investors.map { it.toEntity() },
            matches = parsed.matches.map { it.toEntity() },
            activities = parsed.activities.map { it.toEntity() },
            advisors = parsed.advisors.map { it.toEntity() }
        )

        val summary = "بازیابی با موفقیت انجام شد: ${PersianFormatters.toFa(parsed.properties.size)} فایل، ${PersianFormatters.toFa(parsed.customers.size)} مشتری و ${PersianFormatters.toFa(parsed.investors.size)} سرمایه‌گذار"
        Result.success(summary)
    }

    /**
     * Counts cleanable "فروش رفت" and "خرید کرد" entities.
     */
    suspend fun getCleanableCounts(): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val sold = dao.getAllPropertiesNow().count { PersianFormatters.isSoldStatus(it.status) }
        val bought = dao.getAllCustomersNow().count { PersianFormatters.isBoughtStatus(it.status) }
        Pair(sold, bought)
    }

    /**
     * One-touch cleanup of "فروش رفت" and "خرید کرد" with automatic pre-cleanup snapshot.
     */
    suspend fun cleanupSoldAndBought(): Result<Pair<Int, Int>> = withContext(Dispatchers.IO) {
        takeLocalSnapshot("قبل از پاک‌سازی فضا", force = true)
        val allProps = dao.getAllPropertiesNow()
        val toDeleteProps = allProps.filter { PersianFormatters.isSoldStatus(it.status) }.map { it.id }
        val allCusts = dao.getAllCustomersNow()
        val toDeleteCusts = allCusts.filter { PersianFormatters.isBoughtStatus(it.status) }.map { it.id }

        if (toDeleteProps.isNotEmpty()) dao.deletePropertiesByIds(toDeleteProps)
        if (toDeleteCusts.isNotEmpty()) dao.deleteCustomersByIds(toDeleteCusts)

        Result.success(Pair(toDeleteProps.size, toDeleteCusts.size))
    }

    /**
     * Manages rotating local snapshots (up to 3 copies, daily + pre-restore).
     */
    suspend fun takeLocalSnapshot(reason: String, force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        try {
            val backupDir = File(context.filesDir, "snapshots").apply { mkdirs() }
            val manifestFile = File(backupDir, "snapshots_manifest.json")
            val existing = if (manifestFile.exists()) {
                val arr = org.json.JSONArray(manifestFile.readText(StandardCharsets.UTF_8))
                val list = mutableListOf<JSONObject>()
                for (i in 0 until arr.length()) list.add(arr.getJSONObject(i))
                list
            } else mutableListOf()

            val now = System.currentTimeMillis()
            if (!force && existing.isNotEmpty()) {
                val lastAt = existing.first().optLong("at", 0L)
                if (now - lastAt < 20L * 3600_000L) return@withContext false
            }

            val json = exportFullBackupJson()
            val fileName = "snap_${now}.json"
            val file = File(backupDir, fileName)
            file.writeText(json, StandardCharsets.UTF_8)

            val newEntry = JSONObject().apply {
                put("at", now)
                put("reason", reason)
                put("file", fileName)
                put("size", json.length)
            }
            val updatedList = mutableListOf(newEntry) + existing
            while (updatedList.size > 3) {
                val removed = updatedList.removeLast()
                val oldFile = File(backupDir, removed.optString("file"))
                if (oldFile.exists()) oldFile.delete()
            }

            val newArr = org.json.JSONArray()
            updatedList.forEach { newArr.put(it) }
            manifestFile.writeText(newArr.toString(), StandardCharsets.UTF_8)
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun clearLocalDataForAccountSwitch(): Unit = withContext(Dispatchers.IO) {
        takeLocalSnapshot("قبل از تغییر حساب", force = true)
        dao.replaceEntireDatabaseTransaction(
            properties = emptyList(),
            customers = emptyList(),
            investors = emptyList(),
            matches = emptyList(),
            activities = emptyList(),
            advisors = emptyList()
        )
    }

    suspend fun fetchCloudSnapshotsList(): Result<List<ir.daramash.app.domain.model.CloudHistorySnapshot>> = withContext(Dispatchers.IO) {
        val session = prefs.getUserSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("نشست ورود کاربر نامعتبر است"))
        val res = network.syncHistory(session.accessToken)
        res.map { json ->
            val list = mutableListOf<ir.daramash.app.domain.model.CloudHistorySnapshot>()
            val arr = json.optJSONArray("list") ?: org.json.JSONArray()
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                list.add(
                    ir.daramash.app.domain.model.CloudHistorySnapshot(
                        id = item.optLong("id"),
                        versionAt = item.optLong("version_at", System.currentTimeMillis()),
                        rawBytes = item.optLong("raw_bytes", 0L)
                    )
                )
            }
            list
        }
    }

    suspend fun restoreCloudHistorySnapshot(snapshotId: Long): Result<String> = withContext(Dispatchers.IO) {
        val session = prefs.getUserSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("نشست کاربر نامعتبر است"))
        takeLocalSnapshot("قبل از بازگردانی نسخه‌ی قبلی ابری", force = true)
        val res = network.syncHistoryGet(session.accessToken, snapshotId)
        if (res.isFailure) return@withContext Result.failure(res.exceptionOrNull() ?: Exception("خطا در دریافت نسخه ابری"))
        val body = res.getOrNull() ?: JSONObject()
        val enc = body.optString("enc", "raw")
        val data = body.optString("data", "")
        val rawJson = network.unpackGzip(enc, data)
        restoreFromBackupJson(rawJson)
    }

    suspend fun deleteMyCloudData(): Result<Boolean> = withContext(Dispatchers.IO) {
        val session = prefs.getUserSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("نشست نامعتبر"))
        val res = network.deleteMyData(session.accessToken)
        if (res.isSuccess) {
            val updated = session.copy(syncRev = 0, rawBytes = 0L, isCloudFull = false, isCloudDirty = false)
            prefs.saveUserSession(updated)
            Result.success(true)
        } else {
            Result.failure(res.exceptionOrNull() ?: Exception("خطا در حذف اطلاعات ابری"))
        }
    }

    /**
     * Performs Cloud Sync (push/pull) with the Supabase backend when authenticated.
     */
    suspend fun performCloudSync(): Result<String> = withContext(Dispatchers.IO) {
        val session = prefs.getUserSession()
        val json = exportFullBackupJson()
        val rawLen = json.toByteArray(StandardCharsets.UTF_8).size.toLong()

        // Always persist local automatic snapshot
        takeLocalSnapshot("همگام‌سازی روزانه", force = false)

        if (session.accessToken.isBlank()) {
            val updated = session.copy(
                syncRev = session.syncRev + 1,
                lastSyncAt = System.currentTimeMillis(),
                rawBytes = rawLen,
                syncStatusText = "پشتیبان محلی امن و رمزنگاری‌شده ذخیره شد"
            )
            prefs.saveUserSession(updated)
            return@withContext Result.success(updated.syncStatusText)
        }

        // Check metadata first
        val metaRes = network.syncMeta(session.accessToken)
        if (metaRes.isSuccess) {
            val metaObj = metaRes.getOrNull() ?: JSONObject()
            val cloudQuota = metaObj.optLong("quota", session.quotaBytes)
            val cloudRev = metaObj.optInt("rev", 0)

            // Quota limit enforcement (10MB / 50MB)
            if (rawLen >= cloudQuota) {
                val updated = session.copy(isCloudFull = true, rawBytes = rawLen, quotaBytes = cloudQuota)
                prefs.saveUserSession(updated)
                return@withContext Result.failure(Exception("فضای ابری پر شده است (${PersianFormatters.toFa((rawLen / 1048576.0).toInt())} از ${PersianFormatters.toFa((cloudQuota / 1048576.0).toInt())} مگابایت)"))
            }
        }

        val (enc, data) = network.encryptSyncPayload(session.userId, json)
        val params = JSONObject().apply {
            put("p_data", data)
            put("p_enc", enc)
            put("p_raw", rawLen)
            put("p_base_rev", session.syncRev)
        }
        val res = network.callSupabaseRpc(session.accessToken, "sync_put", params)
        if (res.isSuccess) {
            val body = res.getOrNull() ?: JSONObject()
            val newRev = body.optInt("rev", session.syncRev + 1)
            val quota = body.optLong("quota", session.quotaBytes)
            val updated = session.copy(
                syncRev = newRev,
                lastSyncAt = System.currentTimeMillis(),
                rawBytes = rawLen,
                quotaBytes = quota,
                isCloudFull = false,
                isCloudDirty = false,
                syncStatusText = "همگام‌سازی ابری موفق (نسخه ${PersianFormatters.toFa(newRev)})"
            )
            prefs.saveUserSession(updated)
            Result.success(updated.syncStatusText)
        } else {
            val updated = session.copy(
                lastSyncAt = System.currentTimeMillis(),
                rawBytes = rawLen,
                isCloudDirty = true,
                syncStatusText = "در صف آفلاین (همگام‌سازی خودکار پس از اتصال)"
            )
            prefs.saveUserSession(updated)
            Result.success(updated.syncStatusText)
        }
    }
}
