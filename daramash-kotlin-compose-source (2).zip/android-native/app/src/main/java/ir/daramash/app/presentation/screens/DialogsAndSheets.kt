package ir.daramash.app.presentation.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.daramash.app.domain.model.ActivityLog
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.PropertyFilterState
import ir.daramash.app.domain.model.UserSession
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.presentation.theme.DaramashBorder
import ir.daramash.app.presentation.theme.DaramashBorderSoft
import ir.daramash.app.presentation.theme.DaramashFaint
import ir.daramash.app.presentation.theme.DaramashMuted
import ir.daramash.app.presentation.theme.DaramashSpecular
import ir.daramash.app.presentation.theme.EmeraldAccent
import ir.daramash.app.presentation.theme.EmeraldBright
import ir.daramash.app.presentation.theme.GlassGradBottom
import ir.daramash.app.presentation.theme.GlassGradMid
import ir.daramash.app.presentation.theme.GlassGradTop
import ir.daramash.app.presentation.theme.RubyPrimary
import ir.daramash.app.presentation.theme.VazirmatnFontFamily
import java.util.UUID

val DEFAULT_NEIGHBORHOODS = listOf(
    "پونک", "سردار شمال", "شهرک نفت", "طالقانی", "همیلا",
    "شهرک هما", "جنت مرکز", "جنت جنوب", "جنت شمال", "باغ فیض",
    "اباذر", "آلاله شرقی", "شهرزیبا", "شهران", "سازمان شمال",
    "سازمان مرکز", "سازمان جنوب", "پروانه", "بهار N", "بهار S", "فردوس شرق"
)

// ============================================================================
// BASE LIQUID MODAL SHELL (.overlay & .modal in src/index.css)
// ============================================================================

@Composable
fun DaramashLiquidModal(
    title: String,
    onDismiss: () -> Unit,
    footer: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val shape = RoundedCornerShape(26.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 20.dp)
                .clip(shape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(GlassGradTop, GlassGradMid, GlassGradBottom)
                    ),
                    shape
                )
                .border(1.dp, DaramashBorder, shape)
        ) {
            // Top specular highlight
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .height(1.dp)
                    .align(Alignment.TopCenter)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, DaramashSpecular, Color.Transparent)
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // .modal-head
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    DaramashCardIconBtn(
                        emoji = "✕",
                        onClick = onDismiss
                    )
                }

                // Scrollable Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 470.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    content = content
                )

                // .modal-foot
                if (footer != null) {
                    Spacer(Modifier.height(16.dp))
                    footer()
                }
            }
        }
    }
}

@Composable
fun DaramashModalTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
        val shape = RoundedCornerShape(10.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = if (singleLine) 42.dp else 76.dp)
                .clip(shape)
                .background(Color(0xFF161616), shape)
                .border(1.dp, DaramashBorder, shape)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            contentAlignment = if (singleLine) Alignment.CenterStart else Alignment.TopStart
        ) {
            if (value.isEmpty() && placeholder.isNotEmpty()) {
                Text(
                    text = placeholder,
                    fontSize = 13.sp,
                    color = DaramashFaint,
                    fontFamily = VazirmatnFontFamily
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = singleLine,
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 13.5.sp,
                    fontFamily = VazirmatnFontFamily
                ),
                cursorBrush = SolidColor(EmeraldAccent),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ============================================================================
// 1. ADD CHOOSER MODAL (fabAction in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun AddEntityChooserModal(
    onDismiss: () -> Unit,
    onSelectProperty: () -> Unit,
    onSelectCustomer: () -> Unit,
    onSelectInvestor: () -> Unit
) {
    DaramashLiquidModal(
        title = "＋ افزودن",
        onDismiss = onDismiss
    ) {
        WelcomeStepButton(icon = "🏠", label = "فایل ملک", onClick = onSelectProperty)
        WelcomeStepButton(icon = "🧑", label = "مشتری", onClick = onSelectCustomer)
        WelcomeStepButton(icon = "💼", label = "سرمایه‌گذار", onClick = onSelectInvestor)
    }
}

@Composable
private fun WelcomeStepButton(
    icon: String,
    label: String,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0x0DFFFFFF), shape)
            .border(1.dp, DaramashBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x2E10A37F))
                .border(1.dp, Color(0x6110A37F), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = icon, fontSize = 16.sp)
        }
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontFamily = VazirmatnFontFamily
        )
    }
}

// ============================================================================
// 2. QUICK HELP MODAL (helpDialog in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun QuickHelpModal(onDismiss: () -> Unit) {
    val lines = listOf(
        "➕ با دکمه‌ی «＋» فایل، مشتری یا سرمایه‌گذار اضافه کن.",
        "🔎 در «پیوند» برای هر مشتری فایل مناسب (یا برعکس) را با دلیلش ببین.",
        "✍️ تماس و پیام را از روی کارت ثبت کن تا فایل‌ها «بی‌تماس» نمانند.",
        "🔍 در لیست فایل‌ها «فیلتر پیشرفته» داری؛ همه‌ی موارد را می‌شود فیلتر کرد.",
        "🎯 در «تارگت» هدف ماه را بنویس و پیشرفتت را تیک بزن.",
        "💾 داده‌ها روی همین گوشی ذخیره می‌شوند؛ از «سیستم» بکاپ بگیر.",
        "🏢 در «پنل مدیریت» مشاوران و فایل و مشتری‌هایشان را ببین.",
        "ℹ️ نسخه‌ی برنامه: ۱۸ (Native Kotlin + Jetpack Compose)"
    )
    DaramashLiquidModal(
        title = "راهنمای سریع",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "باشه", onClick = onDismiss)
            }
        }
    ) {
        lines.forEach { l ->
            Text(
                text = l,
                fontSize = 13.5.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily,
                lineHeight = 24.sp
            )
        }
    }
}

// ============================================================================
// 3. PROPERTY FORM MODAL (openForm('property') in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertyFormDialog(
    initial: Property?,
    onDismiss: () -> Unit,
    onSave: (Property) -> Unit
) {
    var code by rememberSaveable { mutableStateOf(initial?.code ?: "") }
    var neighborhood by rememberSaveable { mutableStateOf(initial?.neighborhood ?: "پونک") }
    var areaStr by rememberSaveable { mutableStateOf(initial?.area?.takeIf { it > 0 }?.toString() ?: "") }
    var bedroomsStr by rememberSaveable { mutableStateOf(initial?.bedrooms?.takeIf { it > 0 }?.toString() ?: "2") }
    var totalPriceMillionsStr by rememberSaveable {
        mutableStateOf(
            initial?.totalPrice?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: ""
        )
    }
    var buildingAgeStr by rememberSaveable { mutableStateOf(initial?.buildingAge?.takeIf { it > 0 }?.toString() ?: "") }
    var unitFloorStr by rememberSaveable { mutableStateOf(initial?.unitFloor?.takeIf { it > 0 }?.toString() ?: "") }
    var floorsStr by rememberSaveable { mutableStateOf(initial?.floors?.takeIf { it > 0 }?.toString() ?: "") }
    var unitsPerFloorStr by rememberSaveable { mutableStateOf(initial?.unitsPerFloor?.takeIf { it > 0 }?.toString() ?: "") }
    var facade by rememberSaveable { mutableStateOf(initial?.facade ?: "سنگ") }
    var condition by rememberSaveable { mutableStateOf(initial?.condition ?: "بازسازی شده") }
    var lighting by rememberSaveable { mutableStateOf(initial?.lighting ?: "دوکله نور") }
    var occupancy by rememberSaveable { mutableStateOf(initial?.occupancy ?: "تخلیه") }
    var contractDuration by rememberSaveable { mutableStateOf(initial?.contractDuration ?: "") }
    var depositMillionsStr by rememberSaveable {
        mutableStateOf(initial?.deposit?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: "")
    }
    var rentMillionsStr by rememberSaveable {
        mutableStateOf(initial?.rent?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: "")
    }
    var visit by rememberSaveable { mutableStateOf(initial?.visit ?: "با هماهنگی") }
    var sellReason by rememberSaveable { mutableStateOf(initial?.sellReason ?: "تبدیل به احسن") }
    var exchange by rememberSaveable { mutableStateOf(initial?.exchange ?: "نمی‌کند") }
    var sellerName by rememberSaveable { mutableStateOf(initial?.sellerName ?: "") }
    var sellerPhone by rememberSaveable { mutableStateOf(initial?.sellerPhone ?: "") }
    var address by rememberSaveable { mutableStateOf(initial?.address ?: "") }
    var status by rememberSaveable { mutableStateOf(initial?.status ?: "فروشنده") }
    var parking by rememberSaveable { mutableStateOf(initial?.parking ?: true) }
    var elevator by rememberSaveable { mutableStateOf(initial?.elevator ?: true) }
    var storage by rememberSaveable { mutableStateOf(initial?.storage ?: true) }
    var terrace by rememberSaveable { mutableStateOf(initial?.terrace ?: false) }
    var investable by rememberSaveable { mutableStateOf(initial?.investable ?: false) }
    var note by rememberSaveable { mutableStateOf(initial?.note ?: "") }

    val areaVal = PersianFormatters.toEn(areaStr).toIntOrNull() ?: 0
    val rawMillions = PersianFormatters.toEn(totalPriceMillionsStr).toLongOrNull() ?: 0L
    val totalVal = if (rawMillions in 1..999_999L) rawMillions * 1_000_000L else rawMillions
    val computedPpm = if (areaVal > 0 && totalVal > 0) totalVal / areaVal else 0L

    val depMillions = PersianFormatters.toEn(depositMillionsStr).toLongOrNull() ?: 0L
    val depositVal = if (depMillions in 1..999_999L) depMillions * 1_000_000L else depMillions
    val rentMillions = PersianFormatters.toEn(rentMillionsStr).toLongOrNull() ?: 0L
    val rentVal = if (rentMillions in 1..999_999L) rentMillions * 1_000_000L else rentMillions

    DaramashLiquidModal(
        title = if (initial == null) "＋ فایل جدید" else "✎ ویرایش فایل کد ${PersianFormatters.toFa(initial.code)}",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = if (initial == null) "ثبت فایل" else "ذخیره تغییرات",
                    onClick = {
                        val prop = Property(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            code = code.ifBlank { PersianFormatters.toFa((1050..9999).random()) },
                            neighborhood = neighborhood.ifBlank { "پونک" },
                            area = areaVal,
                            bedrooms = PersianFormatters.toEn(bedroomsStr).toIntOrNull() ?: 2,
                            totalPrice = totalVal,
                            pricePerMeter = computedPpm,
                            unitFloor = PersianFormatters.toEn(unitFloorStr).toIntOrNull() ?: 1,
                            floors = PersianFormatters.toEn(floorsStr).toIntOrNull() ?: 4,
                            unitsPerFloor = PersianFormatters.toEn(unitsPerFloorStr).toIntOrNull() ?: 2,
                            buildingAge = PersianFormatters.toEn(buildingAgeStr).toIntOrNull() ?: 0,
                            facade = facade,
                            condition = condition,
                            lighting = lighting,
                            occupancy = occupancy,
                            contractDuration = if (occupancy == "دست مستاجر") contractDuration else "",
                            deposit = if (occupancy == "دست مستاجر") depositVal else 0L,
                            rent = if (occupancy == "دست مستاجر") rentVal else 0L,
                            visit = visit,
                            sellReason = sellReason,
                            exchange = exchange,
                            sellerName = sellerName,
                            sellerPhone = sellerPhone,
                            address = address,
                            status = status,
                            parking = parking,
                            elevator = elevator,
                            storage = storage,
                            terrace = terrace,
                            investable = investable,
                            note = note,
                            regDate = initial?.regDate ?: PersianFormatters.todayIso(),
                            lastContact = initial?.lastContact ?: PersianFormatters.todayIso(),
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                        onSave(prop)
                    }
                )
            }
        }
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = code,
                onValueChange = { code = it },
                label = "کد فایل *",
                placeholder = "مثلاً ۱۰۴۲",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = neighborhood,
                onValueChange = { neighborhood = it },
                label = "محله *",
                placeholder = "پونک",
                modifier = Modifier.weight(1.3f)
            )
        }

        // Quick neighborhood chips
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DEFAULT_NEIGHBORHOODS.forEach { nb ->
                DaramashChip(
                    label = nb,
                    active = neighborhood == nb,
                    onClick = { neighborhood = nb }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = areaStr,
                onValueChange = { areaStr = it },
                label = "متراژ (متر)",
                placeholder = "۷۸",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = bedroomsStr,
                onValueChange = { bedroomsStr = it },
                label = "تعداد خواب",
                placeholder = "۲",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
        }

        DaramashModalTextField(
            value = totalPriceMillionsStr,
            onValueChange = { totalPriceMillionsStr = it },
            label = "قیمت کل (به میلیون تومان — مثلاً ۱۴۲۰۰ برای ۱۴٫۲ میلیارد)",
            placeholder = "۱۴۲۰۰",
            keyboardType = KeyboardType.Number
        )

        if (totalVal > 0L) {
            Text(
                text = "💰 ${PersianFormatters.formatMoneyToman(totalVal)} تومان" +
                    if (computedPpm > 0L) " · متری ${PersianFormatters.formatMoneyToman(computedPpm)} تومان" else "",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldBright,
                fontFamily = VazirmatnFontFamily
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = unitFloorStr,
                onValueChange = { unitFloorStr = it },
                label = "طبقه واحد",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = floorsStr,
                onValueChange = { floorsStr = it },
                label = "کل طبقات",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = unitsPerFloorStr,
                onValueChange = { unitsPerFloorStr = it },
                label = "واحد در طبقه",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = buildingAgeStr,
                onValueChange = { buildingAgeStr = it },
                label = "سن بنا",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
        }

        Text("نمای ساختمان:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("سنگ", "سنگ و گرانیت", "تراورتن", "آجر", "ترکیبی", "سیمان", "گرانیت", "رومی").forEach { f ->
                DaramashChip(label = f, active = facade == f, onClick = { facade = f })
            }
        }

        Text("وضعیت داخلی ملک:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("نوساز", "بازسازی شده", "تمیز", "نقاشی‌شده", "نیاز به بازسازی").forEach { c ->
                DaramashChip(label = c, active = condition == c, onClick = { condition = c })
            }
        }

        Text("نورگیری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("شمالی", "جنوبی", "دو کله نور", "خطی پرده خور", "دو خواب رو به بیرون", "سالن پرده خور", "فول پاسیو", "شرقی", "غربی").forEach { l ->
                DaramashChip(label = l, active = lighting == l, onClick = { lighting = l })
            }
        }

        Text("وضعیت سکونت:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("تخلیه", "دست مستاجر", "مالک ساکن").forEach { occ ->
                DaramashChip(label = occ, active = occupancy == occ, onClick = { occupancy = occ })
            }
        }

        if (occupancy == "دست مستاجر") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DaramashModalTextField(
                    value = contractDuration,
                    onValueChange = { contractDuration = it },
                    label = "اتمام قرارداد مستاجر",
                    placeholder = "مثلاً ۶ ماه دیگر",
                    modifier = Modifier.weight(1.2f)
                )
                DaramashModalTextField(
                    value = depositMillionsStr,
                    onValueChange = { depositMillionsStr = it },
                    label = "ودیعه مستاجر (میلیون)",
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f)
                )
                DaramashModalTextField(
                    value = rentMillionsStr,
                    onValueChange = { rentMillionsStr = it },
                    label = "اجاره ماهانه (میلیون)",
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Text("نحوه هماهنگی بازدید:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("با هماهنگی", "کلید املاک", "آزاد", "ساکن / مستاجر", "فقط عصرها").forEach { v ->
                DaramashChip(label = v, active = visit == v, onClick = { visit = v })
            }
        }

        Text("علت فروش:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("تبدیل به احسن", "مهاجرت", "خرید واحد دیگر", "نیاز مالی", "شخصی").forEach { r ->
                DaramashChip(label = r, active = sellReason == r, onClick = { sellReason = r })
            }
        }

        Text("معاوضه (تهاتر):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("نمی‌کند", "با واحد کوچک‌تر", "با واحد بزرگ‌تر", "با خودرو", "با زمین").forEach { ex ->
                DaramashChip(label = ex, active = exchange == ex, onClick = { exchange = ex })
            }
        }

        Text("وضعیت فایل:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("فروشنده", "فروش رفت", "کنسل کرد", "فروشنده نیست").forEach { st ->
                DaramashChip(
                    label = st,
                    active = status == st,
                    onClick = { status = st }
                )
            }
        }

        Text("امکانات ملک:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("🚗 پارکینگ", parking, { parking = !parking })
            DaramashChip("📦 انباری", storage, { storage = !storage })
            DaramashChip("🛗 آسانسور", elevator, { elevator = !elevator })
            DaramashChip("🌿 تراس", terrace, { terrace = !terrace })
            DaramashChip("💼 قابل سرمایه‌گذاری", investable, { investable = !investable })
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = sellerName,
                onValueChange = { sellerName = it },
                label = "نام فروشنده",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = sellerPhone,
                onValueChange = { sellerPhone = it },
                label = "شماره تماس",
                keyboardType = KeyboardType.Phone,
                modifier = Modifier.weight(1.2f)
            )
        }

        DaramashModalTextField(
            value = address,
            onValueChange = { address = it },
            label = "آدرس دقیق"
        )

        DaramashModalTextField(
            value = note,
            onValueChange = { note = it },
            label = "توضیحات",
            singleLine = false
        )
    }
}

// ============================================================================
// 4. CUSTOMER FORM MODAL (openForm('customer') in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomerFormDialog(
    initial: Customer?,
    onDismiss: () -> Unit,
    onSave: (Customer) -> Unit
) {
    var firstName by rememberSaveable { mutableStateOf(initial?.firstName ?: "") }
    var lastName by rememberSaveable { mutableStateOf(initial?.lastName ?: "") }
    var phone1 by rememberSaveable { mutableStateOf(initial?.phone1 ?: "") }
    var phone2 by rememberSaveable { mutableStateOf(initial?.phone2 ?: "") }
    var selectedNbs by rememberSaveable { mutableStateOf(initial?.neighborhoods ?: listOf("پونک")) }
    var areaMinStr by rememberSaveable { mutableStateOf(initial?.areaMin?.takeIf { it > 0 }?.toString() ?: "") }
    var bedroomsMinStr by rememberSaveable { mutableStateOf(initial?.bedroomsMin?.takeIf { it > 0 }?.toString() ?: "2") }
    var budgetMillionsStr by rememberSaveable {
        mutableStateOf(
            initial?.budgetMax?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: ""
        )
    }
    var ageMaxStr by rememberSaveable { mutableStateOf(initial?.buildingAgeMax?.takeIf { it > 0 }?.toString() ?: "") }
    var noElevatorMaxFloorStr by rememberSaveable {
        mutableStateOf(initial?.noElevatorMaxFloor?.takeIf { it > 0 }?.toString() ?: "")
    }
    var visitedUnitsStr by rememberSaveable {
        mutableStateOf(initial?.visitedUnits?.takeIf { it > 0 }?.toString() ?: "")
    }
    var quality by rememberSaveable { mutableStateOf(initial?.quality ?: "داغ") }
    var payment by rememberSaveable { mutableStateOf(initial?.payment ?: "نقد") }
    var purpose by rememberSaveable { mutableStateOf(initial?.purpose ?: "سکونت") }
    var status by rememberSaveable { mutableStateOf(initial?.status ?: "در جست و جو") }
    var reqParking by rememberSaveable { mutableStateOf(initial?.reqParking ?: true) }
    var reqElevator by rememberSaveable { mutableStateOf(initial?.reqElevator ?: true) }
    var reqStorage by rememberSaveable { mutableStateOf(initial?.reqStorage ?: false) }
    var reqTerrace by rememberSaveable { mutableStateOf(initial?.reqTerrace ?: false) }
    var note by rememberSaveable { mutableStateOf(initial?.note ?: "") }

    val rawMillions = PersianFormatters.toEn(budgetMillionsStr).toLongOrNull() ?: 0L
    val budgetVal = if (rawMillions in 1..999_999L) rawMillions * 1_000_000L else rawMillions

    DaramashLiquidModal(
        title = if (initial == null) "＋ مشتری جدید" else "✎ ویرایش ${initial.fullName}",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = if (initial == null) "ثبت مشتری" else "ذخیره تغییرات",
                    onClick = {
                        val cust = Customer(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            firstName = firstName,
                            lastName = lastName.ifBlank { "مشتری" },
                            phone1 = phone1,
                            phone2 = phone2,
                            neighborhoods = selectedNbs,
                            areaMin = PersianFormatters.toEn(areaMinStr).toIntOrNull() ?: 0,
                            bedroomsMin = PersianFormatters.toEn(bedroomsMinStr).toIntOrNull() ?: 0,
                            buildingAgeMax = PersianFormatters.toEn(ageMaxStr).toIntOrNull() ?: 0,
                            budgetMax = budgetVal,
                            noElevatorMaxFloor = PersianFormatters.toEn(noElevatorMaxFloorStr).toIntOrNull() ?: 0,
                            visitedUnits = PersianFormatters.toEn(visitedUnitsStr).toIntOrNull() ?: 0,
                            quality = quality,
                            payment = payment,
                            purpose = purpose,
                            status = status,
                            reqParking = reqParking,
                            reqElevator = reqElevator,
                            reqStorage = reqStorage,
                            reqTerrace = reqTerrace,
                            note = note,
                            regDate = initial?.regDate ?: PersianFormatters.todayIso(),
                            lastContact = initial?.lastContact ?: PersianFormatters.todayIso(),
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                        onSave(cust)
                    }
                )
            }
        }
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = firstName,
                onValueChange = { firstName = it },
                label = "نام",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = lastName,
                onValueChange = { lastName = it },
                label = "نام خانوادگی *",
                modifier = Modifier.weight(1.2f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = phone1,
                onValueChange = { phone1 = it },
                label = "شماره تماس اصلی *",
                keyboardType = KeyboardType.Phone,
                modifier = Modifier.weight(1.2f)
            )
            DaramashModalTextField(
                value = phone2,
                onValueChange = { phone2 = it },
                label = "شماره دوم (اختیاری)",
                keyboardType = KeyboardType.Phone,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("محله‌های مورد نظر (${PersianFormatters.toFa(selectedNbs.size)} انتخاب شده):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "انتخاب همه",
                    fontSize = 11.sp,
                    color = EmeraldBright,
                    fontWeight = FontWeight.Bold,
                    fontFamily = VazirmatnFontFamily,
                    modifier = Modifier.clickable { selectedNbs = DEFAULT_NEIGHBORHOODS }
                )
                Text(
                    text = "پاک کردن",
                    fontSize = 11.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily,
                    modifier = Modifier.clickable { selectedNbs = emptyList() }
                )
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val isAllSelected = selectedNbs.size == DEFAULT_NEIGHBORHOODS.size
            DaramashChip(
                label = "🌐 تمام منطقه",
                active = isAllSelected,
                onClick = { selectedNbs = if (isAllSelected) emptyList() else DEFAULT_NEIGHBORHOODS }
            )
            DEFAULT_NEIGHBORHOODS.forEach { nb ->
                val isOn = nb in selectedNbs
                DaramashChip(
                    label = nb,
                    active = isOn,
                    onClick = {
                        selectedNbs = if (isOn) selectedNbs - nb else selectedNbs + nb
                    }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = areaMinStr,
                onValueChange = { areaMinStr = it },
                label = "حداقل متراژ",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = bedroomsMinStr,
                onValueChange = { bedroomsMinStr = it },
                label = "حداقل خواب",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = ageMaxStr,
                onValueChange = { ageMaxStr = it },
                label = "حداکثر سن بنا",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = budgetMillionsStr,
                onValueChange = { budgetMillionsStr = it },
                label = "حداکثر بودجه (میلیون تومان)",
                placeholder = "مثلاً ۱۵۰۰۰",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1.3f)
            )
            DaramashModalTextField(
                value = visitedUnitsStr,
                onValueChange = { visitedUnitsStr = it },
                label = "واحدهای دیده‌شده",
                placeholder = "۰",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(0.9f)
            )
        }

        Text("کیفیت مشتری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("داغ", "گرم", "سرد").forEach { q ->
                DaramashChip(label = q, active = quality == q, onClick = { quality = q })
            }
        }

        Text("نحوه پرداخت:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("نقد", "تهاتر با ملک", "تهاتر با خودرو", "دریافت وام").forEach { p ->
                DaramashChip(label = p, active = payment == p, onClick = { payment = p })
            }
        }

        Text("قصد خرید:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("سکونت", "سرمایه‌گذاری", "تبدیل به احسن", "رهن دادن").forEach { pr ->
                DaramashChip(label = pr, active = purpose == pr, onClick = { purpose = pr })
            }
        }

        Text("وضعیت مشتری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("تازه تو بازار", "در جست و جو", "آماده بازدید", "در مذاکره", "خرید کرد", "منصرف شد", "خریدار نیست").forEach { st ->
                DaramashChip(label = st, active = status == st, onClick = { status = st })
            }
        }

        Text("امکانات مورد نیاز:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("🚗 پارکینگ", reqParking, { reqParking = !reqParking })
            DaramashChip("🛗 آسانسور", reqElevator, { reqElevator = !reqElevator })
            DaramashChip("📦 انباری", reqStorage, { reqStorage = !reqStorage })
            DaramashChip("🌿 تراس", reqTerrace, { reqTerrace = !reqTerrace })
        }

        if (!reqElevator) {
            DaramashModalTextField(
                value = noElevatorMaxFloorStr,
                onValueChange = { noElevatorMaxFloorStr = it },
                label = "حداکثر طبقه بدون آسانسور (مثلاً ۲)",
                keyboardType = KeyboardType.Number
            )
        }

        DaramashModalTextField(
            value = note,
            onValueChange = { note = it },
            label = "توضیحات و نیازمندی‌های خاص",
            singleLine = false
        )
    }
}

// ============================================================================
// 5. INVESTOR FORM MODAL (openForm('investor') in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InvestorFormDialog(
    initial: Investor?,
    allProperties: List<Property> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (Investor) -> Unit
) {
    var firstName by rememberSaveable { mutableStateOf(initial?.firstName ?: "") }
    var lastName by rememberSaveable { mutableStateOf(initial?.lastName ?: "") }
    var phone1 by rememberSaveable { mutableStateOf(initial?.phone1 ?: "") }
    var selectedNbs by rememberSaveable { mutableStateOf(initial?.neighborhoods ?: listOf("پونک")) }
    var existingUnits by rememberSaveable { mutableStateOf(initial?.existingUnits ?: "") }
    var buyMillionsStr by rememberSaveable {
        mutableStateOf(
            initial?.buyAmount?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: ""
        )
    }
    var telegramChannel by rememberSaveable { mutableStateOf(initial?.telegramChannel ?: "") }
    var businessType by rememberSaveable { mutableStateOf(initial?.businessType ?: "سازنده / سرمایه‌گذار") }
    var hasBuy by rememberSaveable { mutableStateOf(initial?.hasBuy ?: "بله") }
    var note by rememberSaveable { mutableStateOf(initial?.note ?: "") }

    val rawMillions = PersianFormatters.toEn(buyMillionsStr).toLongOrNull() ?: 0L
    val buyVal = if (rawMillions in 1..999_999L) rawMillions * 1_000_000L else rawMillions

    DaramashLiquidModal(
        title = if (initial == null) "＋ سرمایه‌گذار جدید" else "✎ ویرایش سرمایه‌گذار",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "ذخیره",
                    onClick = {
                        onSave(
                            Investor(
                                id = initial?.id ?: UUID.randomUUID().toString(),
                                firstName = firstName,
                                lastName = lastName.ifBlank { "سرمایه‌گذار" },
                                phone1 = phone1,
                                neighborhoods = selectedNbs,
                                existingUnits = existingUnits,
                                buyAmount = buyVal,
                                hasBuy = hasBuy,
                                telegramChannel = telegramChannel,
                                businessType = businessType,
                                note = note,
                                lastContact = initial?.lastContact ?: PersianFormatters.todayIso(),
                                createdAt = initial?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                    }
                )
            }
        }
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = firstName,
                onValueChange = { firstName = it },
                label = "نام",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = lastName,
                onValueChange = { lastName = it },
                label = "نام خانوادگی *",
                modifier = Modifier.weight(1.2f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = phone1,
                onValueChange = { phone1 = it },
                label = "شماره تماس *",
                keyboardType = KeyboardType.Phone,
                modifier = Modifier.weight(1.2f)
            )
            DaramashModalTextField(
                value = telegramChannel,
                onValueChange = { telegramChannel = it },
                label = "آیدی / کانال تلگرام",
                placeholder = "@daramash",
                modifier = Modifier.weight(1f)
            )
        }

        Text("قصد خرید دارد؟", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("بله", "خیر", "به‌شرط ملک خوب").forEach { hb ->
                DaramashChip(label = hb, active = hasBuy == hb, onClick = { hasBuy = hb })
            }
        }

        if (hasBuy != "خیر") {
            DaramashModalTextField(
                value = buyMillionsStr,
                onValueChange = { buyMillionsStr = it },
                label = "سقف بودجه خرید (به میلیون تومان)",
                placeholder = "مثلاً ۲۰۰۰۰ برای ۲۰ میلیارد",
                keyboardType = KeyboardType.Number
            )
        }

        Text("تیپ کاری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("سازنده / سرمایه‌گذار", "فقط خریدار", "سازنده معتبر", "فکر می‌کنه خوبه!", "آدم حسابی", "همکار / املاکی", "مشارکت‌کننده").forEach { bt ->
                DaramashChip(label = bt, active = businessType == bt, onClick = { businessType = bt })
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("محله‌های فعالیت (${PersianFormatters.toFa(selectedNbs.size)}):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "انتخاب همه",
                    fontSize = 11.sp,
                    color = EmeraldBright,
                    fontWeight = FontWeight.Bold,
                    fontFamily = VazirmatnFontFamily,
                    modifier = Modifier.clickable { selectedNbs = DEFAULT_NEIGHBORHOODS }
                )
                Text(
                    text = "پاک کردن",
                    fontSize = 11.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily,
                    modifier = Modifier.clickable { selectedNbs = emptyList() }
                )
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val isAllSelected = selectedNbs.size == DEFAULT_NEIGHBORHOODS.size
            DaramashChip(
                label = "🌐 تمام منطقه",
                active = isAllSelected,
                onClick = { selectedNbs = if (isAllSelected) emptyList() else DEFAULT_NEIGHBORHOODS }
            )
            DEFAULT_NEIGHBORHOODS.forEach { nb ->
                val isOn = nb in selectedNbs
                DaramashChip(
                    label = nb,
                    active = isOn,
                    onClick = { selectedNbs = if (isOn) selectedNbs - nb else selectedNbs + nb }
                )
            }
        }

        DaramashModalTextField(
            value = existingUnits,
            onValueChange = { existingUnits = it },
            label = "واحدهای موجود برای فروش (کد فایل، متراژ و مشخصات)",
            placeholder = "مثلاً: کد ۱۰۴۲، یا ۲ واحد ۹۵ متری در سازمان شمال",
            singleLine = false
        )

        // Live Code Lookup Previews for Investor Units
        val typedCodes = remember(existingUnits) {
            val normalized = PersianFormatters.toEn(existingUnits)
            Regex("\\b\\d{4,5}\\b").findAll(normalized).map { it.value }.distinct().toList()
        }
        if (typedCodes.isNotEmpty()) {
            Text("🔍 پیش‌نمایش کدهای تشخیص‌داده‌شده:", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                typedCodes.forEach { rawCode ->
                    val foundProp = allProperties.find { PersianFormatters.toEn(it.code) == rawCode }
                    if (foundProp != null) {
                        val statusTag = if (foundProp.isArchived) "در بایگانی 🗄" else "پیدا شد ✅"
                        DaramashChip(
                            label = "کد ${PersianFormatters.toFa(rawCode)}: ${foundProp.neighborhood} (${PersianFormatters.toFa(foundProp.area)}م) · $statusTag",
                            active = true,
                            onClick = {}
                        )
                    } else {
                        DaramashChip(
                            label = "کد ${PersianFormatters.toFa(rawCode)}: ثبت‌نشده ℹ️",
                            active = false,
                            onClick = {}
                        )
                    }
                }
            }
        }

        DaramashModalTextField(
            value = note,
            onValueChange = { note = it },
            label = "توضیحات و شرایط همکاری",
            singleLine = false
        )
    }
}

// ============================================================================
// 6. DETAIL MODALS (detailModal in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertyDetailDialog(
    property: Property,
    logs: List<ActivityLog>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onQuickLog: (String, String) -> Unit
) {
    val context = LocalContext.current
    var logType by rememberSaveable { mutableStateOf("تماس") }
    var logNote by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "🏠 فایل کد ${PersianFormatters.toFa(property.code)} · ${property.neighborhood}",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(
                    text = "📤 اشتراک فایل",
                    small = true,
                    onClick = {
                        val shareText = PersianFormatters.formatPrivacySafePropertyShare(property)
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "ارسال مشخصات فایل"))
                    }
                )
                DaramashGhostButton(text = "✎ ویرایش", small = true, onClick = onEdit)
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        DetailSectionBox("مشخصات اصلی") {
            DetailDlRow("کد فایل", PersianFormatters.toFa(property.code))
            DetailDlRow("وضعیت", property.status)
            DetailDlRow("محله", property.neighborhood)
            DetailDlRow("متراژ", "${PersianFormatters.toFa(property.area)} متر")
            DetailDlRow("خواب", PersianFormatters.toFa(property.bedrooms))
            DetailDlRow("طبقه", "${PersianFormatters.toFa(property.unitFloor)} از ${PersianFormatters.toFa(property.floors)} (${PersianFormatters.toFa(property.unitsPerFloor)} واحدی)")
            DetailDlRow("سن بنا", "${PersianFormatters.toFa(property.buildingAge)} سال")
            if (property.facade.isNotBlank()) DetailDlRow("نما", property.facade)
            if (property.condition.isNotBlank()) DetailDlRow("وضعیت داخلی", property.condition)
            if (property.lighting.isNotBlank()) DetailDlRow("نورگیری", property.lighting)
        }

        DetailSectionBox("امکانات و شرایط سکونت") {
            val feats = listOfNotNull(
                if (property.parking) "🚗 پارکینگ" else null,
                if (property.elevator) "🛗 آسانسور" else null,
                if (property.storage) "📦 انباری" else null,
                if (property.terrace) "🌿 تراس" else null
            )
            DetailDlRow("امکانات", if (feats.isNotEmpty()) feats.joinToString(" · ") else "ندارد")
            DetailDlRow("سکونت", property.occupancy)
            if (property.occupancy == "دست مستاجر") {
                if (property.contractDuration.isNotBlank()) DetailDlRow("اتمام قرارداد", property.contractDuration)
                if (property.deposit > 0) DetailDlRow("ودیعه", "${PersianFormatters.formatMoneyToman(property.deposit)} تومان")
                if (property.rent > 0) DetailDlRow("اجاره", "${PersianFormatters.formatMoneyToman(property.rent)} تومان")
            }
            DetailDlRow("نحوه بازدید", property.visit)
            DetailDlRow("علت فروش", property.sellReason)
            DetailDlRow("معاوضه", property.exchange)
        }

        DetailSectionBox("قیمت و شرایط") {
            DetailDlRow("قیمت کل", "${PersianFormatters.formatMoneyToman(property.totalPrice)} تومان")
            if (property.pricePerMeter > 0) {
                DetailDlRow("قیمت متری", "${PersianFormatters.formatMoneyToman(property.pricePerMeter)} تومان")
            }
            DetailDlRow("قابل سرمایه‌گذاری", if (property.investable) "بله 💼" else "خیر")
        }

        if (property.sellerName.isNotBlank() || property.sellerPhone.isNotBlank() || property.address.isNotBlank()) {
            DetailSectionBox("فروشنده و آدرس") {
                if (property.sellerName.isNotBlank()) DetailDlRow("نام فروشنده", property.sellerName)
                if (property.sellerPhone.isNotBlank()) DetailDlRow("شماره تماس", PersianFormatters.toFa(property.sellerPhone))
                if (property.address.isNotBlank()) DetailDlRow("آدرس", property.address)
            }
        }

        // Activity Logger (.act-bar)
        DetailSectionBox("📋 ثبت فعالیت و تاریخچه (${PersianFormatters.toFa(logs.size)})") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("تماس", "بازدید", "مذاکره", "تغییر قیمت", "یادداشت", "معامله").forEach { t ->
                    DaramashChip(label = t, active = logType == t, onClick = { logType = t })
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DaramashModalTextField(
                    value = logNote,
                    onValueChange = { logNote = it },
                    label = "توضیح کوتاه",
                    placeholder = "نتیجه تماس یا بازدید...",
                    modifier = Modifier.weight(1f)
                )
                DaramashPrimaryButton(
                    text = "＋ ثبت",
                    small = true,
                    onClick = {
                        onQuickLog(logType, logNote.ifBlank { "ثبت $logType" })
                        logNote = ""
                    }
                )
            }
            if (logs.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                logs.take(8).forEach { a ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF161616))
                            .border(1.dp, DaramashBorderSoft, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(a.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                            if (a.note.isNotBlank()) {
                                Text(a.note, fontSize = 12.sp, color = Color.White, fontFamily = VazirmatnFontFamily)
                            }
                        }
                        Text(
                            text = PersianFormatters.formatIsoToJalaliReadable(a.date),
                            fontSize = 11.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerDetailDialog(
    customer: Customer,
    logs: List<ActivityLog>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onMatch: () -> Unit,
    onArchive: () -> Unit,
    onQuickLog: (String, String) -> Unit
) {
    DaramashLiquidModal(
        title = "🧑 ${customer.fullName}",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "🔎 فایل مناسب", small = true, onClick = onMatch)
                DaramashGhostButton(text = "✎ ویرایش", small = true, onClick = onEdit)
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        DetailSectionBox("مشخصات مشتری") {
            DetailDlRow("نام", customer.fullName)
            DetailDlRow("شماره تماس اصلی", PersianFormatters.toFa(customer.phone1))
            if (customer.phone2.isNotBlank()) DetailDlRow("شماره دوم", PersianFormatters.toFa(customer.phone2))
            DetailDlRow("کیفیت", customer.quality)
            DetailDlRow("وضعیت", customer.status)
            DetailDlRow("نحوه پرداخت", customer.payment)
            DetailDlRow("قصد خرید", customer.purpose)
            DetailDlRow("حداقل متراژ", "${PersianFormatters.toFa(customer.areaMin)} متر")
            DetailDlRow("حداکثر بودجه", "${PersianFormatters.formatMoneyToman(customer.budgetMax)} تومان")
            if (customer.visitedUnits > 0) DetailDlRow("واحدهای دیده‌شده", "${PersianFormatters.toFa(customer.visitedUnits)} واحد")
            if (customer.neighborhoods.isNotEmpty()) {
                DetailDlRow("محله‌ها", customer.neighborhoods.joinToString("، "))
            }
            val reqs = listOfNotNull(
                if (customer.reqParking) "پارکینگ" else null,
                if (customer.reqElevator) "آسانسور" else null,
                if (customer.reqStorage) "انباری" else null,
                if (customer.reqTerrace) "تراس" else null
            )
            if (reqs.isNotEmpty()) DetailDlRow("امکانات الزامی", reqs.joinToString(" · "))
            if (!customer.reqElevator && customer.noElevatorMaxFloor > 0) {
                DetailDlRow("حداکثر طبقه بدون آسانسور", "طبقه ${PersianFormatters.toFa(customer.noElevatorMaxFloor)}")
            }
        }
    }
}

@Composable
fun InvestorDetailDialog(
    investor: Investor,
    logs: List<ActivityLog>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onMatch: () -> Unit,
    onArchive: () -> Unit,
    onQuickLog: (String, String) -> Unit
) {
    DaramashLiquidModal(
        title = "💼 ${investor.fullName}",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "🔎 فایل مناسب", small = true, onClick = onMatch)
                DaramashGhostButton(text = "✎ ویرایش", small = true, onClick = onEdit)
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        DetailSectionBox("مشخصات سرمایه‌گذار") {
            DetailDlRow("نام", investor.fullName)
            DetailDlRow("شماره تماس", PersianFormatters.toFa(investor.phone1))
            if (investor.telegramChannel.isNotBlank()) DetailDlRow("تلگرام", investor.telegramChannel)
            DetailDlRow("تیپ کاری", investor.businessType)
            DetailDlRow("قصد خرید", investor.hasBuy)
            if (investor.buyAmount > 0) {
                DetailDlRow("سقف بودجه خرید", "${PersianFormatters.formatMoneyToman(investor.buyAmount)} تومان")
            }
            if (investor.neighborhoods.isNotEmpty()) {
                DetailDlRow("محله‌های فعالیت", investor.neighborhoods.joinToString("، "))
            }
            if (investor.existingUnits.isNotBlank()) {
                DetailDlRow("واحدهای موجود", investor.existingUnits)
            }
        }
    }
}

@Composable
fun DeviceManagementModal(
    session: ir.daramash.app.domain.model.UserSession,
    onDismiss: () -> Unit,
    onRemoveDevice: (String) -> Unit
) {
    DaramashLiquidModal(
        title = "📱 مدیریت دستگاه‌ها و اشتراک",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        DetailSectionBox("وضعیت اشتراک دارمش") {
            val statusFa = when (session.subStatus) {
                "active" -> "فعال"
                "pending" -> "در انتظار بررسی"
                "expired" -> "منقضی شده"
                "blocked" -> "مسدود"
                "device_limit" -> "تکمیل سقف دستگاه"
                else -> session.subStatus
            }
            DetailDlRow("پلن اشتراک", session.planName)
            DetailDlRow("وضعیت اکانت", statusFa)
            DetailDlRow("روزهای باقیمانده", "${PersianFormatters.toFa(session.daysLeft)} روز")
            DetailDlRow("سقف دستگاه مجاز", "${PersianFormatters.toFa(session.maxDevices)} دستگاه")
        }

        DetailSectionBox("تمدید و پشتیبانی") {
            Text(
                text = "جهت تمدید اشتراک یا افزایش سقف دستگاه‌ها، می‌توانید با پشتیبانی دارمش به ایمیل arttashakib@gmail.com مکاتبه فرمایید.",
                fontSize = 12.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily,
                lineHeight = 20.sp
            )
        }

        DetailSectionBox("دستگاه‌های متصل (${PersianFormatters.toFa(session.devices.size)})") {
            if (session.devices.isEmpty()) {
                Text(
                    text = "اطلاعات دستگاه‌ها در حال بارگذاری است...",
                    fontSize = 12.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            } else {
                session.devices.forEach { dev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF161616))
                            .border(1.dp, DaramashBorderSoft, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = dev.name + if (dev.isCurrent) " (همین دستگاه)" else "",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (dev.isCurrent) EmeraldBright else Color.White,
                                fontFamily = VazirmatnFontFamily
                            )
                            if (dev.lastSeen.isNotBlank()) {
                                Text(
                                    text = "آخرین فعالیت: ${PersianFormatters.formatIsoToJalaliReadable(dev.lastSeen)}",
                                    fontSize = 11.sp,
                                    color = DaramashMuted,
                                    fontFamily = VazirmatnFontFamily
                                )
                            }
                        }
                        if (!dev.isCurrent) {
                            DaramashDangerButton(
                                text = "حذف",
                                small = true,
                                onClick = { onRemoveDevice(dev.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailSectionBox(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x0AFFFFFF))
            .border(1.dp, DaramashBorderSoft, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
        content()
    }
}

@Composable
private fun DetailDlRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily)
    }
}

// ============================================================================
// 7. QUICK ACTIVITY POPOVER DIALOG (showQuickLogMenu in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun QuickActivityPopoverDialog(
    title: String,
    onDismiss: () -> Unit,
    onSaveLog: (String, String) -> Unit
) {
    var customNote by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "✍️ اقدام سریع · $title",
        onDismiss = onDismiss
    ) {
        WelcomeStepButton("📞", "ثبت تماس تلفنی") { onSaveLog("تماس", customNote.ifBlank { "تماس تلفنی انجام شد" }) }
        WelcomeStepButton("💬", "ثبت پیام واتساپ") { onSaveLog("واتساپ", customNote.ifBlank { "پیام واتساپ ارسال شد" }) }
        WelcomeStepButton("👁", "ثبت بازدید حضوری") { onSaveLog("بازدید", customNote.ifBlank { "بازدید حضوری انجام شد" }) }
        WelcomeStepButton("🤝", "ثبت جلسه مذاکره") { onSaveLog("مذاکره", customNote.ifBlank { "مذاکره انجام شد" }) }
        DaramashModalTextField(
            value = customNote,
            onValueChange = { customNote = it },
            label = "یادداشت اختیاری",
            placeholder = "توضیح کوتاه..."
        )
        if (customNote.isNotBlank()) {
            DaramashPrimaryButton(
                text = "📝 ثبت یادداشت",
                onClick = { onSaveLog("یادداشت", customNote) }
            )
        }
    }
}

// ============================================================================
// 8. ADVANCED PROPERTY FILTER MODAL (openPropFilter in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdvancedPropertyFilterDialog(
    current: PropertyFilterState,
    totalMatchingCount: Int,
    onDismiss: () -> Unit,
    onApply: (PropertyFilterState) -> Unit
) {
    var minAreaStr by rememberSaveable { mutableStateOf(current.minArea?.toString() ?: "") }
    var maxAreaStr by rememberSaveable { mutableStateOf(current.maxArea?.toString() ?: "") }
    var maxPriceMillionsStr by rememberSaveable {
        mutableStateOf(current.maxPrice?.let { (it / 1_000_000L).toString() } ?: "")
    }
    var minBedsStr by rememberSaveable { mutableStateOf(current.minBedrooms?.toString() ?: "") }
    var reqParking by rememberSaveable { mutableStateOf(current.requireParking) }
    var reqElevator by rememberSaveable { mutableStateOf(current.requireElevator) }
    var reqStorage by rememberSaveable { mutableStateOf(current.requireStorage) }
    var reqTerrace by rememberSaveable { mutableStateOf(current.requireTerrace) }
    var onlyInvestable by rememberSaveable { mutableStateOf(current.statusFilter == "investable") }

    DaramashLiquidModal(
        title = "🔍 فیلتر پیشرفته‌ی فایل‌ها",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(
                    text = "پاک کردن همه",
                    onClick = {
                        onApply(PropertyFilterState())
                        onDismiss()
                    }
                )
                DaramashPrimaryButton(
                    text = "نمایش نتیجه",
                    onClick = {
                        val rawMaxM = PersianFormatters.toEn(maxPriceMillionsStr).toLongOrNull()
                        val maxPriceToman = if (rawMaxM != null && rawMaxM in 1..999_999L) rawMaxM * 1_000_000L else rawMaxM
                        onApply(
                            current.copy(
                                statusFilter = if (onlyInvestable) "investable" else if (current.statusFilter == "investable") "all" else current.statusFilter,
                                minArea = PersianFormatters.toEn(minAreaStr).toIntOrNull(),
                                maxArea = PersianFormatters.toEn(maxAreaStr).toIntOrNull(),
                                maxPrice = maxPriceToman,
                                minBedrooms = PersianFormatters.toEn(minBedsStr).toIntOrNull(),
                                requireParking = reqParking,
                                requireElevator = reqElevator,
                                requireStorage = reqStorage,
                                requireTerrace = reqTerrace
                            )
                        )
                        onDismiss()
                    }
                )
            }
        }
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = minAreaStr,
                onValueChange = { minAreaStr = it },
                label = "متراژ (از)",
                placeholder = "از",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = maxAreaStr,
                onValueChange = { maxAreaStr = it },
                label = "متراژ (تا)",
                placeholder = "تا",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
        }

        DaramashModalTextField(
            value = maxPriceMillionsStr,
            onValueChange = { maxPriceMillionsStr = it },
            label = "سقف قیمت کل (میلیون تومان)",
            placeholder = "مثلاً ۱۵۰۰۰",
            keyboardType = KeyboardType.Number
        )

        Text("تعداد خواب:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("1" to "۱ خواب", "2" to "۲ خواب", "3" to "۳ خواب", "4" to "۴ و بیشتر").forEach { (b, lbl) ->
                DaramashChip(
                    label = lbl,
                    active = minBedsStr == b,
                    onClick = { minBedsStr = if (minBedsStr == b) "" else b }
                )
            }
        }

        Text("امکانات (همه‌ی موارد انتخابی):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("🚗 پارکینگ", reqParking, { reqParking = !reqParking })
            DaramashChip("📦 انباری", reqStorage, { reqStorage = !reqStorage })
            DaramashChip("🛗 آسانسور", reqElevator, { reqElevator = !reqElevator })
            DaramashChip("🌿 تراس", reqTerrace, { reqTerrace = !reqTerrace })
            DaramashChip("💼 فقط فایل‌های قابل سرمایه‌گذاری", onlyInvestable, { onlyInvestable = !onlyInvestable })
        }
    }
}

// ============================================================================
// 9. MATCH ENTITY PICKER MODAL (openMatchPicker in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun MatchEntityPickerModal(
    isPropertyMode: Boolean,
    properties: List<Property>,
    customers: List<Customer>,
    onDismiss: () -> Unit,
    onPickProperty: (String) -> Unit,
    onPickCustomer: (String) -> Unit
) {
    var searchQ by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = if (isPropertyMode) "انتخاب فایل" else "انتخاب مشتری یا سرمایه‌گذار",
        onDismiss = onDismiss
    ) {
        DaramashModalTextField(
            value = searchQ,
            onValueChange = { searchQ = it },
            label = "جستجو",
            placeholder = if (isPropertyMode) "کد، محله، نام فروشنده..." else "نام، شماره، محله..."
        )
        val q = PersianFormatters.normalizeSearch(searchQ)
        if (isPropertyMode) {
            properties.filter {
                q.isEmpty() || PersianFormatters.normalizeSearch("${it.code} ${it.neighborhood} ${it.sellerName}").contains(q)
            }.forEach { p ->
                WelcomeStepButton(
                    icon = "🏠",
                    label = "کد ${PersianFormatters.toFa(p.code)} · ${p.neighborhood} · ${PersianFormatters.toFa(p.area)} متر",
                    onClick = { onPickProperty(p.id) }
                )
            }
        } else {
            customers.filter {
                q.isEmpty() || PersianFormatters.normalizeSearch("${it.fullName} ${it.phone1}").contains(q)
            }.forEach { c ->
                WelcomeStepButton(
                    icon = "🧑",
                    label = "${c.fullName} · ${c.neighborhoods.joinToString("، ")}",
                    onClick = { onPickCustomer(c.id) }
                )
            }
        }
    }
}

// ============================================================================
// 10. EDIT TARGET MODAL & ADVISOR MODALS & AI ASSISTANT MODAL
// ============================================================================

@Composable
fun EditTargetModal(
    current: AdvisorTarget,
    onDismiss: () -> Unit,
    onSave: (String, Long, String) -> Unit
) {
    var code by rememberSaveable { mutableStateOf(current.targetFileCode) }
    var depMillions by rememberSaveable { mutableStateOf((current.targetDeposit / 1_000_000L).toString()) }
    var mot by rememberSaveable { mutableStateOf(current.motivation) }

    DaramashLiquidModal(
        title = "🎯 ویرایش تارگت مشاور",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "ذخیره",
                    onClick = {
                        val m = PersianFormatters.toEn(depMillions).toLongOrNull() ?: 350L
                        onSave(code, m * 1_000_000L, mot)
                    }
                )
            }
        }
    ) {
        DaramashModalTextField(
            value = code,
            onValueChange = { code = it },
            label = "کد فایل هدف",
            placeholder = "۱۰۴۲"
        )
        DaramashModalTextField(
            value = depMillions,
            onValueChange = { depMillions = it },
            label = "مقدار واریزی هدف ماه (میلیون تومان)",
            keyboardType = KeyboardType.Number
        )
        DaramashModalTextField(
            value = mot,
            onValueChange = { mot = it },
            label = "جمله‌ی انگیزشی",
            singleLine = false
        )
    }
}

@Composable
fun AddAdvisorModal(
    onDismiss: () -> Unit,
    onAdd: (String, String, String) -> Unit
) {
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var area by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "＋ مشاور جدید",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "افزودن",
                    onClick = { if (name.isNotBlank()) onAdd(name, phone, area) }
                )
            }
        }
    ) {
        DaramashModalTextField(value = name, onValueChange = { name = it }, label = "اسم مشاور *")
        DaramashModalTextField(value = phone, onValueChange = { phone = it }, label = "شماره تماس", keyboardType = KeyboardType.Phone)
        DaramashModalTextField(value = area, onValueChange = { area = it }, label = "منطقه‌ی کاری", placeholder = "مثلاً پونک، ستارخان")
    }
}

@Composable
fun ImportAdvisorCodeModal(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var code by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "📥 ثبت کد یا JSON مشاور",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "ثبت",
                    onClick = { if (code.isNotBlank()) onImport(code) }
                )
            }
        }
    ) {
        DaramashModalTextField(
            value = code,
            onValueChange = { code = it },
            label = "کد DRZ1 / DRM1 یا JSON را بچسبان",
            placeholder = "DRM1:...",
            singleLine = false
        )
    }
}

@Composable
fun AiAssistantDialog(
    aiResponse: String,
    isLoading: Boolean,
    onAsk: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var prompt by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "✨ دستیار هوشمند دارمش",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "بستن", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = if (isLoading) "در حال تحلیل..." else "تحلیل هوشمند",
                    enabled = !isLoading,
                    onClick = { onAsk(prompt) }
                )
            }
        }
    ) {
        Text(
            text = "🔒 حریم خصوصی امن: نام مالکین، شماره‌ها و آدرس‌های دقیق هرگز ارسال نمی‌شوند.",
            fontSize = 12.sp,
            color = EmeraldBright,
            fontFamily = VazirmatnFontFamily
        )
        DaramashModalTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = "سوال یا دستور تحلیل",
            placeholder = "مثلاً: کدام فایل‌ها امروز اولویت تماس دارند؟"
        )
        if (isLoading) {
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = RubyPrimary)
            }
        } else if (aiResponse.isNotBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF161616))
                    .border(1.dp, DaramashBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = aiResponse,
                    fontSize = 13.sp,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

// ============================================================================
// 11. PERSIAN JALALI DATE PICKER MODAL
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DaramashPersianDatePickerModal(
    onDismiss: () -> Unit,
    onDateSelected: (String) -> Unit
) {
    val (curJy, curJm, curJd) = remember {
        val cal = java.util.Calendar.getInstance()
        PersianFormatters.gregorianToJalali(
            cal.get(java.util.Calendar.YEAR),
            cal.get(java.util.Calendar.MONTH) + 1,
            cal.get(java.util.Calendar.DAY_OF_MONTH)
        )
    }

    var selectedYear by rememberSaveable { mutableStateOf(curJy) }
    var selectedMonth by rememberSaveable { mutableStateOf(curJm) }
    var selectedDay by rememberSaveable { mutableStateOf(curJd) }

    DaramashLiquidModal(
        title = "📅 انتخاب تاریخ شمسی",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "تأیید تاریخ",
                    onClick = {
                        val iso = PersianFormatters.jalaliToIso(selectedYear, selectedMonth, selectedDay)
                        onDateSelected(iso)
                        onDismiss()
                    }
                )
            }
        }
    ) {
        Text("سال شمسی:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (1400..1406).forEach { y ->
                DaramashChip(
                    label = PersianFormatters.toFa(y),
                    active = selectedYear == y,
                    onClick = { selectedYear = y }
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("ماه:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            PersianFormatters.JALALI_MONTH_NAMES.forEachIndexed { idx, mName ->
                val mNum = idx + 1
                DaramashChip(
                    label = mName,
                    active = selectedMonth == mNum,
                    onClick = { selectedMonth = mNum }
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        val maxDays = if (selectedMonth <= 6) 31 else if (selectedMonth <= 11) 30 else 29
        Text("روز ($maxDays روز):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            (1..maxDays).forEach { d ->
                DaramashChip(
                    label = PersianFormatters.toFa(d),
                    active = selectedDay == d,
                    onClick = { selectedDay = d }
                )
            }
        }
    }
}

// ============================================================================
// 12. ADMIN SUBSCRIPTION MANAGEMENT MODAL (is_admin)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminSubscriptionModal(
    session: UserSession,
    onDismiss: () -> Unit,
    onSaveConfig: (contact: String, trialDays: Int, devLimit: Int, build: Int, url: String, note: String) -> Unit,
    onSavePayText: (String) -> Unit
) {
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var contactInput by rememberSaveable { mutableStateOf(session.contact) }
    var trialDaysInput by rememberSaveable { mutableStateOf(session.trialDays.toString()) }
    var devLimitInput by rememberSaveable { mutableStateOf(session.maxDevices.toString()) }
    var buildInput by rememberSaveable { mutableStateOf(session.latestBuild.toString()) }
    var urlInput by rememberSaveable { mutableStateOf(session.updateUrl) }
    var noteInput by rememberSaveable { mutableStateOf(session.updateNote) }
    var payTextInput by rememberSaveable { mutableStateOf(session.payText) }

    DaramashLiquidModal(
        title = "👑 مدیریت اشتراک‌ها (پنل ادمین)",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "بستن", onClick = onDismiss)
            }
        }
    ) {
        DaramashModalTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = "جستجوی ایمیل کاربر...",
            placeholder = "user@gmail.com"
        )

        Spacer(Modifier.height(8.dp))
        Text("⚙️ تنظیمات عمومی سامانه (کنترل از سرور)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
        DaramashModalTextField(value = contactInput, onValueChange = { contactInput = it }, label = "آیدی تلگرام یا شماره واتس‌اپ ادمین", placeholder = "@admin")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(value = trialDaysInput, onValueChange = { trialDaysInput = it }, label = "روز دوره آزمایشی (۰ = خاموش)", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f))
            DaramashModalTextField(value = devLimitInput, onValueChange = { devLimitInput = it }, label = "حداکثر دستگاه (۱ تا ۱۰)", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(value = buildInput, onValueChange = { buildInput = it }, label = "شماره build نسخه جدید", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f))
            DaramashModalTextField(value = urlInput, onValueChange = { urlInput = it }, label = "لینک دانلود APK (https)", placeholder = "https://...", modifier = Modifier.weight(1.5f))
        }
        DaramashModalTextField(value = noteInput, onValueChange = { noteInput = it }, label = "توضیحات به‌روزرسانی (اختیاری)")
        DaramashPrimaryButton(
            text = "💾 ذخیره تنظیمات عمومی",
            small = true,
            onClick = {
                onSaveConfig(
                    contactInput.trim(),
                    trialDaysInput.toIntOrNull() ?: 0,
                    devLimitInput.toIntOrNull() ?: 2,
                    buildInput.toIntOrNull() ?: 18,
                    urlInput.trim(),
                    noteInput.trim()
                )
            }
        )

        Spacer(Modifier.height(12.dp))
        Text("💳 متن راهنمای پرداخت (به کاربر نمایش داده می‌شود)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
        DaramashModalTextField(value = payTextInput, onValueChange = { payTextInput = it }, label = "متن کارت حساب / شرایط پرداخت", singleLine = false)
        DaramashPrimaryButton(
            text = "💾 ذخیره متن پرداخت",
            small = true,
            onClick = { onSavePayText(payTextInput.trim()) }
        )
    }
}

@Composable
fun CloudSnapshotsModal(
    snapshots: List<ir.daramash.app.domain.model.CloudHistorySnapshot>,
    onDismiss: () -> Unit,
    onRestore: (Long) -> Unit
) {
    DaramashLiquidModal(
        title = "📜 نسخه‌های ابری ذخیره‌شده (تا ۳ نسخه)",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "بستن", onClick = onDismiss)
            }
        }
    ) {
        if (snapshots.isEmpty()) {
            Text("هیچ نسخه ابری قبلی یافت نشد.", fontSize = 13.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        } else {
            snapshots.forEach { snap ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x0FFFFFFF))
                        .border(1.dp, DaramashBorderSoft, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "نسخه ${PersianFormatters.toFa(snap.id)}",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                        Text(
                            text = "${PersianFormatters.toFa(snap.rawBytes / 1024)} کیلوبایت",
                            fontSize = 11.5.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                    DaramashPrimaryButton(
                        text = "↩ بازگردانی",
                        small = true,
                        onClick = {
                            onRestore(snap.id)
                            onDismiss()
                        }
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

