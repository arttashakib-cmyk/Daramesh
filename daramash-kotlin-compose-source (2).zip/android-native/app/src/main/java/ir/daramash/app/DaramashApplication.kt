package ir.daramash.app

import android.app.Application
import ir.daramash.app.worker.FollowUpReminderWorker

class DaramashApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        FollowUpReminderWorker.createNotificationChannel(this)
        FollowUpReminderWorker.schedulePeriodicWork(this)
    }
}
