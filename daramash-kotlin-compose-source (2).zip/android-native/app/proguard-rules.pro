# Keep Room entities, DAOs, and database classes
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**
