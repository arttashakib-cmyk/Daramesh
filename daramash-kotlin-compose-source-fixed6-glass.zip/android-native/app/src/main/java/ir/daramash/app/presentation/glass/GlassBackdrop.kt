package ir.daramash.app.presentation.glass

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * Liquid-glass helpers.
 *
 * The idea (backdrop capture + blur + lens refraction + specular rim) follows the Cloudy library
 * (https://github.com/skydoves/Cloudy, Apache-2.0). Cloudy itself needs Kotlin 2.x / Compose 1.11,
 * so a small Android-only version is implemented here on top of Compose GraphicsLayer.
 *
 *  - Android 12+ (API 31): real backdrop blur
 *  - Android 13+ (API 33): + lens refraction, chromatic fringe and rim light (AGSL)
 *  - older: a solid translucent fill and the rim line
 */

@Stable
class GlassBackdropState internal constructor(internal val layer: GraphicsLayer) {
    internal var origin by mutableStateOf(Offset.Zero)
}

@androidx.compose.runtime.Composable
fun rememberGlassBackdrop(): GlassBackdropState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassBackdropState(layer) }
}

/** Marks the content that glass surfaces should "see through" (the scrolling page). */
fun Modifier.glassSource(state: GlassBackdropState): Modifier = this
    .onGloballyPositioned { state.origin = it.positionInRoot() }
    .drawWithContent {
        state.layer.record {
            this@drawWithContent.drawContent()
        }
        drawLayer(state.layer)
    }

private class EffectKey {
    var key: Any? = null
}

/** Draws a liquid-glass panel behind the content of this node. */
fun Modifier.glassSurface(
    backdrop: GlassBackdropState?,
    shape: Shape,
    blurRadius: Dp = 18.dp,
    tint: Color = Color(0x2E141420),
    fallbackFill: Color = Color(0xF20E0E14),
    lens: Boolean = true
): Modifier = composed {
    val elementLayer = rememberGraphicsLayer()
    val holder = remember { EffectKey() }
    var position by remember { mutableStateOf(Offset.Zero) }

    this
        .onGloballyPositioned { position = it.positionInRoot() }
        .drawBehind {
            val outline = shape.createOutline(size, layoutDirection, this)
            val path = Path()
            var corner = 0f
            when (outline) {
                is Outline.Rectangle -> path.addRect(outline.rect)
                is Outline.Rounded -> {
                    path.addRoundRect(outline.roundRect)
                    corner = outline.roundRect.topLeftCornerRadius.x
                }
                is Outline.Generic -> path.addPath(outline.path)
            }

            if (backdrop != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val dx = position.x - backdrop.origin.x
                val dy = position.y - backdrop.origin.y
                val radiusPx = blurRadius.toPx()
                val key = listOf(size.width, size.height, corner, radiusPx, lens)
                if (holder.key != key) {
                    elementLayer.renderEffect = buildGlassEffect(size.width, size.height, corner, radiusPx, lens)
                    holder.key = key
                }
                elementLayer.record {
                    translate(-dx, -dy) {
                        drawLayer(backdrop.layer)
                    }
                }
                clipPath(path) {
                    drawLayer(elementLayer)
                }
                drawPath(path, color = tint)
            } else {
                drawPath(path, color = fallbackFill)
            }

            // Specular rim: bright on the top-left, soft on the bottom-right.
            drawPath(
                path = path,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0x99FFFFFF), Color(0x14FFFFFF), Color(0x47FFFFFF)),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height)
                ),
                style = Stroke(width = 1.2.dp.toPx())
            )
        }
}

private fun buildGlassEffect(w: Float, h: Float, corner: Float, blurPx: Float, lens: Boolean): RenderEffect {
    if (lens && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        return buildLensEffect(w, h, corner, blurPx)
    }
    return BlurEffect(blurPx, blurPx, TileMode.Clamp)
}

@androidx.annotation.RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun buildLensEffect(w: Float, h: Float, corner: Float, blurPx: Float): RenderEffect {
    val shader = android.graphics.RuntimeShader(LENS_AGSL)
    shader.setFloatUniform("size", w, h)
    shader.setFloatUniform("corner", corner)
    shader.setFloatUniform("bend", minOf(w, h) * 0.30f)
    val lensEffect = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content")
    val blurEffect = android.graphics.RenderEffect.createBlurEffect(
        blurPx,
        blurPx,
        android.graphics.Shader.TileMode.CLAMP
    )
    return android.graphics.RenderEffect.createChainEffect(lensEffect, blurEffect).asComposeRenderEffect()
}

private const val LENS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float corner;
uniform float bend;

half4 main(float2 xy) {
    float2 hd = size * 0.5;
    float2 p = xy - hd;
    float r = min(corner, min(hd.x, hd.y));
    float2 q = abs(p) - hd + float2(r);
    float sdf = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
    float band = max(min(hd.x, hd.y) * 0.55, 1.0);
    float depth = clamp(-sdf / band, 0.0, 1.0);
    float curve = pow(1.0 - depth, 2.0);
    float2 dir = p / max(length(p), 0.0001);
    float2 shifted = xy - dir * curve * bend;
    half4 c = content.eval(shifted);
    half4 cr = content.eval(shifted - dir * curve * bend * 0.12);
    half4 cb = content.eval(shifted + dir * curve * bend * 0.12);
    half3 rgb = half3(cr.r, c.g, cb.b);
    float luma = dot(rgb, half3(0.2126, 0.7152, 0.0722));
    rgb = mix(half3(luma), rgb, 1.3);
    float edgeLine = 1.0 - smoothstep(0.0, 2.5, -sdf);
    float2 lightDir = normalize(float2(-0.6, -0.8));
    float facing = clamp(dot(dir, lightDir) * 0.5 + 0.5, 0.0, 1.0);
    rgb += half3(edgeLine * (0.10 + 0.55 * pow(facing, 3.0)));
    return half4(clamp(rgb, 0.0, 1.0), c.a);
}
"""

/** iOS-like press feel: spring scale-down, a light haptic tick, no ripple. */
fun Modifier.springPress(
    enabled: Boolean = true,
    haptic: Boolean = true,
    pressedScale: Float = 0.93f,
    onClick: () -> Unit
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "springPress"
    )
    val view = LocalView.current
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled
        ) {
            if (haptic) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onClick()
        }
}
