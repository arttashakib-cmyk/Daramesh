# Daramash v38 — UI language

Calm, Apple-style glass: soft neutral surfaces, 0.5dp hairlines, continuous corners, spring motion.

- Tokens: `presentation/theme/DaramashDesign.kt` (spacing, radii, type scale, glass, chrome sizes, motion) and
  `presentation/theme/DaramashTheme.kt` (colors).
- Shapes: `presentation/glass/ContinuousCornerShape.kt` (own implementation; pills stay plain capsules).
- Glass material: `presentation/glass/GlassBackdrop.kt` (real backdrop sampling + lens shader, softened rim).
- Shared components: `DaramashLiquidComponents.kt` (card, chip, buttons, pills); chrome in `DaramashComposeApp.kt`
  (top bar, floating tab bar with sliding selection capsule, search dock, sidebar); dialogs in `DialogsAndSheets.kt`.

Origin: the visual language (palette, radii, glass opacities, motion periods) was measured from the public
Convx project's design tokens. No Convx source code was copied (Convx is GPL-3.0); everything here is
original code written for this app.
