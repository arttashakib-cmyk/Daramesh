package ir.daramash.app.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import ir.daramash.app.R
import ir.daramash.app.domain.model.ThemeMode

// Exact color tokens from original Daramash CSS (:root in src/index.css)
// Calm Apple-style neutrals: pure black stays the OLED base, cards use soft system greys.
val DaramashBg = Color(0xFF000000)
val DaramashBgElevated = Color(0xFF121212)
val DaramashSurface = Color(0xFF1C1C1E)
val DaramashSurface2 = Color(0xFF2C2C2E)
val DaramashSurface3 = Color(0xFF3A3A3C)

val DaramashBorder = Color(0x1FFFFFFF)      // rgba(255,255,255,.12) hairline
val DaramashBorderSoft = Color(0x0FFFFFFF)  // rgba(255,255,255,.06)
val DaramashSpecular = Color(0x4DFFFFFF)    // rgba(255,255,255,.30)

val DaramashText = Color(0xFFF5F5F7)
val DaramashMuted = Color(0xFF8E8E93)
val DaramashFaint = Color(0xFF636366)

val RubyPrimary = Color(0xFFFA2D48)
val RubyMid = Color(0xFFFF453A)
val RubyDeep = Color(0xFFD9263F)

val EmeraldAccent = Color(0xFF10A37F)
val EmeraldHover = Color(0xFF14B890)
val EmeraldBright = Color(0xFF34D399)

val BlueInfo = Color(0xFF60A5FA)
val BlueSoft = Color(0xFF7FB0FF)
val AmberWarn = Color(0xFFFBBF24)
val AmberSoft = Color(0xFFE0A63A)
val RedDanger = Color(0xFFF87171)
val RedSolid = Color(0xFFE5534B)
val PurpleQuote = Color(0xFFA78BFA)

// Liquid Glass surface gradient stops (.hg, .pcard, .match-card, .sys-card, .mgr-card)
val GlassGradTop = Color(0xF2222224)    // soft grey, near-flat card
val GlassGradMid = Color(0xF21C1C1E)
val GlassGradBottom = Color(0xF71A1A1C)

// Embedded Vazirmatn Persian font family matching original Daramash
val VazirmatnFontFamily = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_medium, FontWeight.SemiBold),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_extrabold, FontWeight.ExtraBold),
    Font(R.font.vazirmatn_extrabold, FontWeight.Black)
)

private val LiquidOledColorScheme = darkColorScheme(
    primary = EmeraldAccent,
    onPrimary = Color.White,
    secondary = RubyPrimary,
    onSecondary = Color.White,
    tertiary = BlueInfo,
    background = DaramashBg,
    onBackground = DaramashText,
    surface = DaramashSurface,
    onSurface = DaramashText,
    surfaceVariant = DaramashSurface3,
    onSurfaceVariant = DaramashMuted,
    error = RedSolid,
    onError = Color.White
)

private val StandardDarkColorScheme = darkColorScheme(
    primary = EmeraldAccent,
    onPrimary = Color.White,
    secondary = RubyPrimary,
    onSecondary = Color.White,
    tertiary = BlueInfo,
    background = Color(0xFF121212),
    onBackground = DaramashText,
    surface = Color(0xFF1C1C1E),
    onSurface = DaramashText,
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = DaramashMuted,
    error = RedSolid,
    onError = Color.White
)

private val DaylightColorScheme = lightColorScheme(
    primary = EmeraldAccent,
    onPrimary = Color.White,
    secondary = RubyPrimary,
    onSecondary = Color.White,
    tertiary = Color(0xFF2563EB),
    background = Color(0xFF0A0A0A), // Original Daramash is strictly dark Liquid Glass
    onBackground = DaramashText,
    surface = Color(0xFF1C1C1E),
    onSurface = DaramashText,
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = DaramashMuted
)

val DaramashTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 41.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp,
        lineHeight = 25.sp
    ),
    titleMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 14.5.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 23.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 21.sp
    ),
    labelMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun DaramashTheme(
    themeMode: ThemeMode = ThemeMode.LIQUID_OLED,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        ThemeMode.LIQUID_OLED -> LiquidOledColorScheme
        ThemeMode.DARK -> StandardDarkColorScheme
        ThemeMode.LIGHT -> DaylightColorScheme
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = DaramashTypography,
            content = content
        )
    }
}
