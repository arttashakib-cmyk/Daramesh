package ir.daramash.app.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import ir.daramash.app.data.local.dao.DaramashDao
import ir.daramash.app.data.local.entity.ActivityLogEntity
import ir.daramash.app.data.local.entity.AdvisorEntity
import ir.daramash.app.data.local.entity.CustomerEntity
import ir.daramash.app.data.local.entity.InvestorEntity
import ir.daramash.app.data.local.entity.MatchLinkEntity
import ir.daramash.app.data.local.entity.PropertyEntity
import ir.daramash.app.data.local.entity.RadarSnapshotEntity

@Database(
    entities = [
        PropertyEntity::class,
        CustomerEntity::class,
        InvestorEntity::class,
        MatchLinkEntity::class,
        ActivityLogEntity::class,
        AdvisorEntity::class,
        RadarSnapshotEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class DaramashDatabase : RoomDatabase() {

    abstract fun dao(): DaramashDao

    companion object {
        @Volatile
        private var INSTANCE: DaramashDatabase? = null

        /**
         * Explicit Room SQLite Migration from v1 to v2 ensuring zero data loss on app update.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_properties_code` ON `properties` (`code`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_properties_neighborhood` ON `properties` (`neighborhood`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_customers_phone1` ON `customers` (`phone1`)")
            }
        }

        /**
         * v2 -> v3: sold date / final sold price on properties + weekly Market Radar snapshots.
         * Purely additive — existing rows keep their data (soldAt/soldPrice default to 0).
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `properties` ADD COLUMN `soldAt` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `properties` ADD COLUMN `soldPrice` INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `radar_snapshots` (" +
                        "`id` TEXT NOT NULL, `weekKey` INTEGER NOT NULL, `neighborhood` TEXT NOT NULL, " +
                        "`takenAt` INTEGER NOT NULL, `averagePpm` INTEGER NOT NULL, `medianPpm` INTEGER NOT NULL, " +
                        "`sampleCount` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
            }
        }

        fun getInstance(context: Context): DaramashDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DaramashDatabase::class.java,
                    "daramash_native.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
