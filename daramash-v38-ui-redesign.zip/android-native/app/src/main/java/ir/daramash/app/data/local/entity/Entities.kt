package ir.daramash.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.daramash.app.domain.model.ActivityLog
import ir.daramash.app.domain.model.Advisor
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchLink
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.RadarSnapshot

@Entity(
    tableName = "properties",
    indices = [
        Index(value = ["code"]),
        Index(value = ["neighborhood"]),
        Index(value = ["status"]),
        Index(value = ["isArchived"])
    ]
)
data class PropertyEntity(
    @PrimaryKey val id: String,
    val code: String,
    val area: Int,
    val bedrooms: Int,
    val floors: Int,
    val unitsPerFloor: Int,
    val unitFloor: Int,
    val buildingAge: Int,
    val facade: String,
    val condition: String,
    val lighting: String,
    val parking: Boolean,
    val storage: Boolean,
    val elevator: Boolean,
    val terrace: Boolean,
    val totalPrice: Long,
    val pricePerMeter: Long,
    val occupancy: String,
    val contractDuration: String,
    val deposit: Long,
    val rent: Long,
    val neighborhood: String,
    val address: String,
    val visit: String,
    val sellerName: String,
    val sellerPhone: String,
    val sellReason: String,
    val exchange: String,
    val regDate: String,
    val lastContact: String,
    val status: String,
    val investable: Boolean,
    val advisorId: String,
    val advisorName: String,
    val note: String,
    val isArchived: Boolean,
    val archivedAt: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val soldAt: Long = 0L,
    val soldPrice: Long = 0L
) {
    fun toDomain() = Property(
        id = id,
        code = code,
        area = area,
        bedrooms = bedrooms,
        floors = floors,
        unitsPerFloor = unitsPerFloor,
        unitFloor = unitFloor,
        buildingAge = buildingAge,
        facade = facade,
        condition = condition,
        lighting = lighting,
        parking = parking,
        storage = storage,
        elevator = elevator,
        terrace = terrace,
        totalPrice = totalPrice,
        pricePerMeter = if (pricePerMeter > 0) pricePerMeter else if (totalPrice > 0 && area > 0) totalPrice / area else 0L,
        occupancy = occupancy,
        contractDuration = contractDuration,
        deposit = deposit,
        rent = rent,
        neighborhood = neighborhood,
        address = address,
        visit = visit,
        sellerName = sellerName,
        sellerPhone = sellerPhone,
        sellReason = sellReason,
        exchange = exchange,
        regDate = regDate,
        lastContact = lastContact,
        status = status,
        investable = investable,
        advisorId = advisorId,
        advisorName = advisorName,
        note = note,
        isArchived = isArchived,
        archivedAt = archivedAt,
        createdAt = createdAt,
        updatedAt = updatedAt,
        soldAt = soldAt,
        soldPrice = soldPrice
    )
}

fun Property.toEntity() = PropertyEntity(
    id = id,
    code = code,
    area = area,
    bedrooms = bedrooms,
    floors = floors,
    unitsPerFloor = unitsPerFloor,
    unitFloor = unitFloor,
    buildingAge = buildingAge,
    facade = facade,
    condition = condition,
    lighting = lighting,
    parking = parking,
    storage = storage,
    elevator = elevator,
    terrace = terrace,
    totalPrice = totalPrice,
    pricePerMeter = if (totalPrice > 0 && area > 0) totalPrice / area else pricePerMeter,
    occupancy = occupancy,
    contractDuration = contractDuration,
    deposit = deposit,
    rent = rent,
    neighborhood = neighborhood,
    address = address,
    visit = visit,
    sellerName = sellerName,
    sellerPhone = sellerPhone,
    sellReason = sellReason,
    exchange = exchange,
    regDate = regDate,
    lastContact = lastContact,
    status = status,
    investable = investable,
    advisorId = advisorId,
    advisorName = advisorName,
    note = note,
    isArchived = isArchived,
    archivedAt = archivedAt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    soldAt = soldAt,
    soldPrice = soldPrice
)

@Entity(
    tableName = "customers",
    indices = [
        Index(value = ["phone1"]),
        Index(value = ["quality"]),
        Index(value = ["isArchived"])
    ]
)
data class CustomerEntity(
    @PrimaryKey val id: String,
    val firstName: String,
    val lastName: String,
    val phone1: String,
    val phone2: String,
    val neighborhoodsCsv: String,
    val areaMin: Int,
    val bedroomsMin: Int,
    val buildingAgeMax: Int,
    val budgetMax: Long,
    val reqParking: Boolean,
    val reqStorage: Boolean,
    val reqElevator: Boolean,
    val reqTerrace: Boolean,
    val noElevatorMaxFloor: Int,
    val quality: String,
    val payment: String,
    val purpose: String,
    val status: String,
    val regDate: String,
    val lastContact: String,
    val advisorId: String,
    val advisorName: String,
    val note: String,
    val isArchived: Boolean,
    val archivedAt: Long,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomain() = Customer(
        id = id,
        firstName = firstName,
        lastName = lastName,
        phone1 = phone1,
        phone2 = phone2,
        neighborhoods = neighborhoodsCsv.split("،", ",").map { it.trim() }.filter { it.isNotEmpty() },
        areaMin = areaMin,
        bedroomsMin = bedroomsMin,
        buildingAgeMax = buildingAgeMax,
        budgetMax = budgetMax,
        reqParking = reqParking,
        reqStorage = reqStorage,
        reqElevator = reqElevator,
        reqTerrace = reqTerrace,
        noElevatorMaxFloor = noElevatorMaxFloor,
        quality = quality,
        payment = payment,
        purpose = purpose,
        status = status,
        regDate = regDate,
        lastContact = lastContact,
        advisorId = advisorId,
        advisorName = advisorName,
        note = note,
        isArchived = isArchived,
        archivedAt = archivedAt,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun Customer.toEntity() = CustomerEntity(
    id = id,
    firstName = firstName,
    lastName = lastName,
    phone1 = phone1,
    phone2 = phone2,
    neighborhoodsCsv = neighborhoods.joinToString("، "),
    areaMin = areaMin,
    bedroomsMin = bedroomsMin,
    buildingAgeMax = buildingAgeMax,
    budgetMax = budgetMax,
    reqParking = reqParking,
    reqStorage = reqStorage,
    reqElevator = reqElevator,
    reqTerrace = reqTerrace,
    noElevatorMaxFloor = noElevatorMaxFloor,
    quality = quality,
    payment = payment,
    purpose = purpose,
    status = status,
    regDate = regDate,
    lastContact = lastContact,
    advisorId = advisorId,
    advisorName = advisorName,
    note = note,
    isArchived = isArchived,
    archivedAt = archivedAt,
    createdAt = createdAt,
    updatedAt = updatedAt
)

@Entity(
    tableName = "investors",
    indices = [
        Index(value = ["phone1"]),
        Index(value = ["isArchived"])
    ]
)
data class InvestorEntity(
    @PrimaryKey val id: String,
    val firstName: String,
    val lastName: String,
    val phone1: String,
    val neighborhoodsCsv: String,
    val existingUnits: String,
    val hasBuy: String,
    val buyAmount: Long,
    val telegramChannel: String,
    val businessType: String,
    val lastContact: String,
    val note: String,
    val isArchived: Boolean,
    val archivedAt: Long,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomain() = Investor(
        id = id,
        firstName = firstName,
        lastName = lastName,
        phone1 = phone1,
        neighborhoods = neighborhoodsCsv.split("،", ",").map { it.trim() }.filter { it.isNotEmpty() },
        existingUnits = existingUnits,
        hasBuy = hasBuy,
        buyAmount = buyAmount,
        telegramChannel = telegramChannel,
        businessType = businessType,
        lastContact = lastContact,
        note = note,
        isArchived = isArchived,
        archivedAt = archivedAt,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun Investor.toEntity() = InvestorEntity(
    id = id,
    firstName = firstName,
    lastName = lastName,
    phone1 = phone1,
    neighborhoodsCsv = neighborhoods.joinToString("، "),
    existingUnits = existingUnits,
    hasBuy = hasBuy,
    buyAmount = buyAmount,
    telegramChannel = telegramChannel,
    businessType = businessType,
    lastContact = lastContact,
    note = note,
    isArchived = isArchived,
    archivedAt = archivedAt,
    createdAt = createdAt,
    updatedAt = updatedAt
)

@Entity(
    tableName = "matches",
    indices = [
        Index(value = ["propertyId", "needId"], unique = true)
    ]
)
data class MatchLinkEntity(
    @PrimaryKey val id: String,
    val propertyId: String,
    val needId: String,
    val needKind: String,
    val createdAt: Long
) {
    fun toDomain() = MatchLink(
        id = id,
        propertyId = propertyId,
        needId = needId,
        needKind = needKind,
        createdAt = createdAt
    )
}

fun MatchLink.toEntity() = MatchLinkEntity(
    id = id,
    propertyId = propertyId,
    needId = needId,
    needKind = needKind,
    createdAt = createdAt
)

@Entity(
    tableName = "activity_logs",
    indices = [
        Index(value = ["entityType", "entityId"])
    ]
)
data class ActivityLogEntity(
    @PrimaryKey val id: String,
    val entityType: String,
    val entityId: String,
    val type: String,
    val note: String,
    val date: String,
    val createdAt: Long
) {
    fun toDomain() = ActivityLog(
        id = id,
        entityType = entityType,
        entityId = entityId,
        type = type,
        note = note,
        date = date,
        createdAt = createdAt
    )
}

fun ActivityLog.toEntity() = ActivityLogEntity(
    id = id,
    entityType = entityType,
    entityId = entityId,
    type = type,
    note = note,
    date = date,
    createdAt = createdAt
)

@Entity(tableName = "advisors")
data class AdvisorEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String,
    val specialtyNeighborhood: String,
    val createdAt: Long
) {
    fun toDomain() = Advisor(
        id = id,
        name = name,
        phone = phone,
        specialtyNeighborhood = specialtyNeighborhood,
        createdAt = createdAt
    )
}

fun Advisor.toEntity() = AdvisorEntity(
    id = id,
    name = name,
    phone = phone,
    specialtyNeighborhood = specialtyNeighborhood,
    createdAt = createdAt
)


@Entity(tableName = "radar_snapshots")
data class RadarSnapshotEntity(
    /** "<weekKey>|<neighborhood>" — one row per week per neighborhood (empty neighborhood = whole market). */
    @PrimaryKey val id: String,
    val weekKey: Int,
    val neighborhood: String,
    val takenAt: Long,
    val averagePpm: Long,
    val medianPpm: Long,
    val sampleCount: Int
) {
    fun toDomain() = RadarSnapshot(
        weekKey = weekKey,
        neighborhood = neighborhood,
        takenAt = takenAt,
        averagePpm = averagePpm,
        medianPpm = medianPpm,
        sampleCount = sampleCount
    )
}

fun RadarSnapshot.toEntity() = RadarSnapshotEntity(
    id = "$weekKey|$neighborhood",
    weekKey = weekKey,
    neighborhood = neighborhood,
    takenAt = takenAt,
    averagePpm = averagePpm,
    medianPpm = medianPpm,
    sampleCount = sampleCount
)
