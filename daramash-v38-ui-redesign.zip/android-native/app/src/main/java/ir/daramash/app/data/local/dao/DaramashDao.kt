package ir.daramash.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import ir.daramash.app.data.local.entity.ActivityLogEntity
import ir.daramash.app.data.local.entity.AdvisorEntity
import ir.daramash.app.data.local.entity.CustomerEntity
import ir.daramash.app.data.local.entity.InvestorEntity
import ir.daramash.app.data.local.entity.MatchLinkEntity
import ir.daramash.app.data.local.entity.PropertyEntity
import ir.daramash.app.data.local.entity.RadarSnapshotEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DaramashDao {

    // --- Properties ---
    @Query("SELECT * FROM properties WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeActiveProperties(): Flow<List<PropertyEntity>>

    @Query("SELECT * FROM properties WHERE isArchived = 1 ORDER BY archivedAt DESC")
    fun observeArchivedProperties(): Flow<List<PropertyEntity>>

    @Query("SELECT * FROM properties")
    suspend fun getAllPropertiesNow(): List<PropertyEntity>

    @Query("SELECT * FROM properties WHERE code = :code AND isArchived = 0 LIMIT 1")
    suspend fun findPropertyByCode(code: String): PropertyEntity?

    @Query("SELECT * FROM properties WHERE id = :id LIMIT 1")
    suspend fun getPropertyById(id: String): PropertyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProperty(property: PropertyEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProperties(properties: List<PropertyEntity>)

    @Query("UPDATE properties SET isArchived = 1, archivedAt = :now WHERE id IN (:ids)")
    suspend fun archivePropertiesByIds(ids: List<String>, now: Long = System.currentTimeMillis())

    @Query("UPDATE properties SET isArchived = 0, archivedAt = 0 WHERE id = :id")
    suspend fun restorePropertyById(id: String)

    @Query("DELETE FROM properties WHERE id IN (:ids)")
    suspend fun deletePropertiesByIds(ids: List<String>)

    // --- Market Radar weekly snapshots ---
    @Query("SELECT * FROM radar_snapshots ORDER BY weekKey ASC")
    fun observeRadarSnapshots(): Flow<List<RadarSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRadarSnapshots(snapshots: List<RadarSnapshotEntity>)

    @Query("DELETE FROM radar_snapshots WHERE weekKey < :minWeekKey")
    suspend fun pruneRadarSnapshots(minWeekKey: Int)

    // --- Customers ---
    @Query("SELECT * FROM customers WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeActiveCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE isArchived = 1 ORDER BY archivedAt DESC")
    fun observeArchivedCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers")
    suspend fun getAllCustomersNow(): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE phone1 = :phone AND isArchived = 0 LIMIT 1")
    suspend fun findCustomerByPhone(phone: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomer(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomers(customers: List<CustomerEntity>)

    @Query("UPDATE customers SET isArchived = 1, archivedAt = :now WHERE id IN (:ids)")
    suspend fun archiveCustomersByIds(ids: List<String>, now: Long = System.currentTimeMillis())

    @Query("UPDATE customers SET isArchived = 0, archivedAt = 0 WHERE id = :id")
    suspend fun restoreCustomerById(id: String)

    @Query("DELETE FROM customers WHERE id IN (:ids)")
    suspend fun deleteCustomersByIds(ids: List<String>)

    // --- Investors ---
    @Query("SELECT * FROM investors WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeActiveInvestors(): Flow<List<InvestorEntity>>

    @Query("SELECT * FROM investors WHERE isArchived = 1 ORDER BY archivedAt DESC")
    fun observeArchivedInvestors(): Flow<List<InvestorEntity>>

    @Query("SELECT * FROM investors")
    suspend fun getAllInvestorsNow(): List<InvestorEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvestor(investor: InvestorEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvestors(investors: List<InvestorEntity>)

    @Query("UPDATE investors SET isArchived = 1, archivedAt = :now WHERE id IN (:ids)")
    suspend fun archiveInvestorsByIds(ids: List<String>, now: Long = System.currentTimeMillis())

    @Query("UPDATE investors SET isArchived = 0, archivedAt = 0 WHERE id = :id")
    suspend fun restoreInvestorById(id: String)

    @Query("DELETE FROM investors WHERE id IN (:ids)")
    suspend fun deleteInvestorsByIds(ids: List<String>)

    // --- Matches ---
    @Query("SELECT * FROM matches ORDER BY createdAt DESC")
    fun observeMatches(): Flow<List<MatchLinkEntity>>

    @Query("SELECT * FROM matches")
    suspend fun getAllMatchesNow(): List<MatchLinkEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchLinkEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatches(matches: List<MatchLinkEntity>)

    @Query("DELETE FROM matches WHERE propertyId = :propertyId AND needId = :needId")
    suspend fun deleteMatch(propertyId: String, needId: String)

    // --- Activity Logs ---
    @Query("SELECT * FROM activity_logs ORDER BY createdAt DESC")
    fun observeActivityLogs(): Flow<List<ActivityLogEntity>>

    @Query("SELECT * FROM activity_logs")
    suspend fun getAllActivityLogsNow(): List<ActivityLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivityLog(log: ActivityLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivityLogs(logs: List<ActivityLogEntity>)

    @Query("DELETE FROM activity_logs WHERE id = :id")
    suspend fun deleteActivityLog(id: String)

    // --- Advisors ---
    @Query("SELECT * FROM advisors ORDER BY createdAt DESC")
    fun observeAdvisors(): Flow<List<AdvisorEntity>>

    @Query("SELECT * FROM advisors")
    suspend fun getAllAdvisorsNow(): List<AdvisorEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAdvisor(advisor: AdvisorEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAdvisors(advisors: List<AdvisorEntity>)

    @Query("DELETE FROM advisors WHERE id = :id")
    suspend fun deleteAdvisor(id: String)

    // --- Clear & Atomic Full-Database Transaction for Restore / Cloud Pull ---
    @Query("DELETE FROM properties")
    suspend fun clearProperties()

    @Query("DELETE FROM customers")
    suspend fun clearCustomers()

    @Query("DELETE FROM investors")
    suspend fun clearInvestors()

    @Query("DELETE FROM matches")
    suspend fun clearMatches()

    @Query("DELETE FROM activity_logs")
    suspend fun clearActivityLogs()

    @Query("DELETE FROM advisors")
    suspend fun clearAdvisors()

    @Transaction
    suspend fun replaceEntireDatabaseTransaction(
        properties: List<PropertyEntity>,
        customers: List<CustomerEntity>,
        investors: List<InvestorEntity>,
        matches: List<MatchLinkEntity>,
        activities: List<ActivityLogEntity>,
        advisors: List<AdvisorEntity>
    ) {
        clearProperties()
        clearCustomers()
        clearInvestors()
        clearMatches()
        clearActivityLogs()
        clearAdvisors()

        upsertProperties(properties)
        upsertCustomers(customers)
        upsertInvestors(investors)
        insertMatches(matches)
        insertActivityLogs(activities)
        upsertAdvisors(advisors)
    }
}
