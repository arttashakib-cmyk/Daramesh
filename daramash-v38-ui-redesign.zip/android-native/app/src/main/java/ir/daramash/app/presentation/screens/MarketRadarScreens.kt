package ir.daramash.app.presentation.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.RadarSnapshot
import ir.daramash.app.domain.usecase.MarketRadarUseCase
import ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket
import ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket
import ir.daramash.app.domain.usecase.MarketRadarUseCase.BedroomBucket
import ir.daramash.app.domain.usecase.MarketRadarUseCase.GroupSummary
import ir.daramash.app.domain.usecase.MarketRadarUseCase.NeighborhoodSort
import ir.daramash.app.domain.usecase.MarketRadarUseCase.PriceStats
import ir.daramash.app.domain.usecase.MarketRadarUseCase.RadarFilter
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.presentation.theme.AmberWarn
import ir.daramash.app.presentation.theme.DaramashMuted
import ir.daramash.app.presentation.theme.DaramashText
import ir.daramash.app.presentation.theme.EmeraldBright
import ir.daramash.app.presentation.theme.RedDanger
import ir.daramash.app.presentation.theme.VazirmatnFontFamily
import kotlin.math.abs
import kotlin.math.roundToInt

private enum class RadarSection(val labelFa: String) {
    OVERVIEW("📡 نمای کلی"),
    SOLD("✅ فروش رفته‌ها"),
    ESTIMATE("🧮 برآورد قیمت")
}

@Composable
fun MarketRadarScreen(
    properties: List<Property>,
    snapshots: List<RadarSnapshot>,
    onOpenProperty: (Property) -> Unit,
    /**
     * When false, app-level transient UI (drawer / search / multi-select) owns system Back.
     * Parent passes false while those overlays are active so this handler does not win
     * solely by later composition registration order.
     */
    allowNestedBack: Boolean = true
) {
    var selectedNeighborhood by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf(RadarFilter()) }
    // Stable identity only — never cache a GroupSummary snapshot (stale after edit/archive).
    var selectedGroupRef by remember { mutableStateOf<MarketRadarUseCase.GroupRef?>(null) }
    var section by remember { mutableStateOf(RadarSection.OVERVIEW) }
    // One "now" per data change keeps the 15-day sold window consistent across the whole screen.
    val now = remember(properties) { System.currentTimeMillis() }

    // Authoritative lighting only; clear invalid lighting selection without touching other filters.
    val safeFilter = if (filter.lighting != null && filter.lighting !in MarketRadarUseCase.LIGHTING_OPTIONS) {
        filter.copy(lighting = null)
    } else {
        filter
    }
    val onFilterChangeSafe: (RadarFilter) -> Unit = { next ->
        filter = if (next.lighting != null && next.lighting !in MarketRadarUseCase.LIGHTING_OPTIONS) {
            next.copy(lighting = null)
        } else next
    }
    val closeNeighborhood: () -> Unit = {
        selectedNeighborhood = null
        filter = RadarFilter()
        selectedGroupRef = null
    }
    val openGroup: (String, GroupSummary) -> Unit = { kind, g ->
        selectedGroupRef = MarketRadarUseCase.groupRefFor(kind, g)
    }

    // Nested system Back: group → neighborhood (keep filters) → overview tab → app (MARKET_RADAR → HOME).
    // Disabled while app overlays own Back so the earlier app-level BackHandler handles them.
    BackHandler(
        enabled = allowNestedBack &&
            (selectedGroupRef != null || selectedNeighborhood != null || section != RadarSection.OVERVIEW)
    ) {
        when {
            selectedGroupRef != null -> selectedGroupRef = null
            selectedNeighborhood != null -> closeNeighborhood()
            else -> section = RadarSection.OVERVIEW
        }
    }

    val nb = selectedNeighborhood
    val groupRef = selectedGroupRef
    when {
        nb != null && groupRef != null -> {
            val detail = remember(properties, nb, safeFilter, now) {
                MarketRadarUseCase.computeNeighborhoodDetail(properties, nb, safeFilter, now)
            }
            val liveGroup = remember(detail, groupRef) { MarketRadarUseCase.resolveGroup(detail, groupRef) }
            if (liveGroup == null) {
                // Group vanished or empty after data change — return to neighborhood safely.
                LaunchedEffect(groupRef, detail) { selectedGroupRef = null }
                NeighborhoodRadarScreen(
                    properties, nb, safeFilter, snapshots, now,
                    onFilterChangeSafe, closeNeighborhood, openGroup, onOpenProperty
                )
            } else {
                GroupDetailScreen(liveGroup, now, { selectedGroupRef = null }, onOpenProperty)
            }
        }
        nb != null -> NeighborhoodRadarScreen(
            properties, nb, safeFilter, snapshots, now,
            onFilterChangeSafe, closeNeighborhood, openGroup, onOpenProperty
        )
        else -> RadarHome(
            properties = properties,
            snapshots = snapshots,
            now = now,
            section = section,
            onSectionChange = { section = it },
            onSelectNeighborhood = {
                selectedNeighborhood = it
                filter = RadarFilter()
                selectedGroupRef = null
            },
            onOpenProperty = onOpenProperty
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Home: header + section chips
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RadarHome(
    properties: List<Property>,
    snapshots: List<RadarSnapshot>,
    now: Long,
    section: RadarSection,
    onSectionChange: (RadarSection) -> Unit,
    onSelectNeighborhood: (String) -> Unit,
    onOpenProperty: (Property) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 4.dp)) {
            RText("رادار بازار", 20f, DaramashText, FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RadarSection.entries.forEach { s ->
                    DaramashChip(label = s.labelFa, active = section == s, onClick = { onSectionChange(s) })
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (section) {
                RadarSection.OVERVIEW -> OverviewSection(properties, snapshots, now, onSelectNeighborhood)
                RadarSection.SOLD -> SoldSection(properties, now, onOpenProperty)
                RadarSection.ESTIMATE -> EstimatorSection(properties, now)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Overview
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun OverviewSection(
    properties: List<Property>,
    snapshots: List<RadarSnapshot>,
    now: Long,
    onSelectNeighborhood: (String) -> Unit
) {
    val context = LocalContext.current
    val overview = remember(properties, now) { MarketRadarUseCase.computeOverview(properties, now) }
    val trend = remember(snapshots) { MarketRadarUseCase.trendFor(snapshots, "") }
    var sort by remember { mutableStateOf(NeighborhoodSort.MOST_FILES) }
    val sorted = remember(overview, sort) { MarketRadarUseCase.sortNeighborhoods(overview.neighborhoods, sort) }
    val headline = remember(overview) { MarketRadarUseCase.marketHeadline(overview) }
    val maxAvg = remember(overview) { overview.neighborhoods.maxOfOrNull { it.stats.average } ?: 0L }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            RText(
                "میانگین قیمت هر متر از فایل‌های فروشنده فعال و فروش‌رفته‌های ${PersianFormatters.toFa(MarketRadarUseCase.SOLD_WINDOW_DAYS)} روز اخیر. برای بررسی دقیق‌تر یک محله را بزن.",
                11.5f, DaramashMuted
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatMiniCard("فایل معتبر", PersianFormatters.toFa(overview.totalEligible), Modifier.weight(1f))
                StatMiniCard("محله‌ها", PersianFormatters.toFa(overview.neighborhoodCount), Modifier.weight(1f))
                StatMiniCard("فروش‌رفتهٔ اخیر", PersianFormatters.toFa(overview.soldInWindow), Modifier.weight(1f))
            }
        }
        item {
            RadarCard {
                RText("میانگین کل بازار", 12f, DaramashMuted)
                Spacer(Modifier.height(4.dp))
                if (overview.overallStats.count == 0) {
                    RText("داده کافی موجود نیست", 15f, DaramashMuted)
                } else {
                    RText(formatPpm(overview.overallStats.average), 18f, EmeraldBright, FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    StatsRow(overview.overallStats)
                    TrendBlock(trend)
                    Spacer(Modifier.height(10.dp))
                    DaramashGhostButton(
                        text = "📤 اشتراک تصویر",
                        small = true,
                        onClick = {
                            shareRadar(
                                context,
                                RadarShareData(
                                    title = "رادار بازار — کل منطقه",
                                    dateLabel = todayLabel(),
                                    breakdownTitle = "محله‌ها (بر اساس تعداد فایل)",
                                    averagePpm = overview.overallStats.average,
                                    medianPpm = overview.overallStats.median,
                                    minPpm = overview.overallStats.min,
                                    maxPpm = overview.overallStats.max,
                                    count = overview.overallStats.count,
                                    trendChangePercent = trend.changePercent,
                                    trendSpanWeeks = trend.spanWeeks,
                                    rows = overview.neighborhoods
                                        .sortedByDescending { it.stats.count }
                                        .take(6)
                                        .map { RadarShareRow(it.name, it.stats.average, it.stats.count) }
                                )
                            )
                        }
                    )
                }
            }
        }
        headline?.let { h ->
            item {
                RadarCard {
                    RText("گران‌ترین و ارزان‌ترین محله", 12f, DaramashMuted)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            RText("گران‌ترین", 11f, DaramashMuted)
                            RText(h.priciest.name, 14f, DaramashText, FontWeight.SemiBold, maxLines = 1)
                            RText(formatPpm(h.priciest.stats.average), 11.5f, AmberWarn)
                        }
                        Column(Modifier.weight(1f)) {
                            RText("ارزان‌ترین", 11f, DaramashMuted)
                            RText(h.cheapest.name, 14f, DaramashText, FontWeight.SemiBold, maxLines = 1)
                            RText(formatPpm(h.cheapest.stats.average), 11.5f, EmeraldBright)
                        }
                    }
                    RText(
                        "فقط محله‌هایی با حداقل ${PersianFormatters.toFa(MarketRadarUseCase.MIN_SAMPLES)} فایل مقایسه شده‌اند.",
                        10f, DaramashMuted, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
        item {
            RText("محله‌ها", 14f, DaramashText, FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                NeighborhoodSort.entries.forEach { s ->
                    DaramashChip(label = s.labelFa, active = sort == s, onClick = { sort = s })
                }
            }
        }
        if (sorted.isEmpty()) {
            item { RadarCard { RText("هنوز فایل فروشنده فعالی با محله ثبت‌شده وجود ندارد.", 13f, DaramashMuted) } }
        } else {
            items(sorted, key = { it.name }) { nb ->
                RadarCard(onClick = { onSelectNeighborhood(nb.name) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        RText(nb.name, 15f, DaramashText, FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
                        RText(if (nb.stats.count == 0) "—" else formatPpm(nb.stats.average), 15f, EmeraldBright, FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    PriceBar(if (maxAvg > 0L) nb.stats.average.toFloat() / maxAvg.toFloat() else 0f)
                    Spacer(Modifier.height(8.dp))
                    RText(
                        "${PersianFormatters.toFa(nb.stats.count)} فایل · ${nb.stats.sampleLabel}",
                        11f, DaramashMuted
                    )
                    if (nb.stats.count > 0) {
                        RText(
                            "میانه ${formatPpm(nb.stats.median)}  ·  کمینه ${formatPpm(nb.stats.min)}  ·  بیشینه ${formatPpm(nb.stats.max)}",
                            10f, DaramashMuted, modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    val ac = nb.amenityCounts
                    RText(
                        "🛗 ${PersianFormatters.toFa(ac.withElevator)}  ·  🚗 ${PersianFormatters.toFa(ac.withParking)}  ·  📦 ${PersianFormatters.toFa(ac.withStorage)}  ·  🌿 ${PersianFormatters.toFa(ac.withTerrace)}",
                        11f, DaramashMuted, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun PriceBar(fraction: Float) {
    val f = fraction.coerceIn(0.04f, 1f)
    Box(
        Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(Color(0x1FFFFFFF))
    ) {
        Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(50)).background(EmeraldBright))
    }
}

@Composable
private fun TrendBlock(trend: MarketRadarUseCase.TrendSummary) {
    Spacer(Modifier.height(10.dp))
    RText("روند قیمت (میانگین هفتگی)", 11f, DaramashMuted)
    if (!trend.hasTrend) {
        RText(
            "روند از همین هفته ثبت می‌شود؛ بعد از دو هفته نمودارش اینجا ظاهر می‌شود.",
            11f, DaramashMuted, modifier = Modifier.padding(top = 2.dp)
        )
        return
    }
    val change = trend.changePercent ?: 0.0
    val rounded = change.roundToInt()
    val color = when {
        rounded > 0 -> EmeraldBright
        rounded < 0 -> RedDanger
        else -> DaramashMuted
    }
    Sparkline(trend.points.map { it.averagePpm }, color, Modifier.padding(vertical = 6.dp))
    val weeks = PersianFormatters.toFa(trend.spanWeeks)
    val pct = PersianFormatters.toFa(abs(rounded))
    RText(
        when {
            rounded > 0 -> "$pct٪ افزایش در $weeks هفتهٔ اخیر"
            rounded < 0 -> "$pct٪ کاهش در $weeks هفتهٔ اخیر"
            else -> "بدون تغییر محسوس در $weeks هفتهٔ اخیر"
        },
        12f, color, FontWeight.SemiBold
    )
    RText(
        "هر نقطه یک هفته است؛ ترکیب فایل‌ها هر هفته کمی فرق می‌کند.",
        10f, DaramashMuted, modifier = Modifier.padding(top = 2.dp)
    )
}

@Composable
private fun Sparkline(values: List<Long>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxWidth().height(52.dp)) {
        if (values.size < 2) return@Canvas
        val lo = values.min()
        val hi = values.max()
        val range = (hi - lo).coerceAtLeast(1L).toFloat()
        val pad = 6.dp.toPx()
        val usableH = size.height - pad * 2
        val step = (size.width - pad * 2) / (values.size - 1)
        fun pt(i: Int): Offset {
            val ratio = if (hi == lo) 0.5f else (values[i] - lo).toFloat() / range
            return Offset(pad + step * i, pad + usableH * (1f - ratio))
        }
        val path = Path()
        for (i in values.indices) {
            val o = pt(i)
            if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawCircle(color = color, radius = 4.5.dp.toPx(), center = pt(values.lastIndex))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Sold files
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun SoldSection(properties: List<Property>, now: Long, onOpenProperty: (Property) -> Unit) {
    val summary = remember(properties, now) { MarketRadarUseCase.computeSold(properties, now) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            RText(
                "قیمت فایل فروش‌رفته تا ${PersianFormatters.toFa(MarketRadarUseCase.SOLD_WINDOW_DAYS)} روز بعد از فروش در میانگین بازار حساب می‌شود (تورم ماهانه بالاست)؛ بعد از آن از آمار خارج می‌شود. قیمت نهایی فروش را در ویرایش فایل ثبت کن تا فاصله‌اش با قیمت اعلامی دیده شود.",
                11.5f, DaramashMuted
            )
        }
        item {
            RadarCard {
                RText("خلاصهٔ ۹۰ روز اخیر", 12f, DaramashMuted)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatCell("فروش رفته", PersianFormatters.toFa(summary.rows.size))
                    StatCell("فاصله با اعلامی", summary.avgGapPercent?.let { gapText(it) } ?: "—")
                    StatCell("میانگین زمان فروش", summary.avgDaysOnMarket?.let { "${PersianFormatters.toFa(it)} روز" } ?: "—")
                }
                if (summary.avgGapPercent != null) {
                    RText(
                        "فاصله بر پایهٔ ${PersianFormatters.toFa(summary.gapSampleCount)} فایلِ دارای قیمت نهایی محاسبه شده است.",
                        10f, DaramashMuted, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
        if (summary.rows.isEmpty()) {
            item { RadarCard { RText("در ۹۰ روز اخیر فایلی با وضعیت «فروش رفت» ثبت نشده است.", 13f, DaramashMuted) } }
        } else {
            items(summary.rows, key = { it.property.id }) { row -> SoldRowCard(row) { onOpenProperty(row.property) } }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun SoldRowCard(row: MarketRadarUseCase.SoldRow, onClick: () -> Unit) {
    val p = row.property
    RadarCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                RText(
                    buildString {
                        append(if (p.code.isNotBlank()) "کد ${PersianFormatters.toFa(p.code)}" else "بدون کد")
                        append(" · "); append(PersianFormatters.toFa(p.area)); append(" متر")
                        if (p.neighborhood.isNotBlank()) append(" · ${p.neighborhood}")
                    },
                    13f, DaramashText, FontWeight.SemiBold
                )
                RText(
                    buildString {
                        append("${PersianFormatters.toFa(row.daysAgo)} روز پیش فروش رفت")
                        row.daysOnMarket?.let { append(" · ${PersianFormatters.toFa(it)} روز تا فروش") }
                    },
                    11f, DaramashMuted
                )
            }
            RText(
                if (row.inStats) "در آمار · ${PersianFormatters.toFa(row.daysLeftInStats)} روز مانده" else "خارج از آمار",
                10.5f,
                if (row.inStats) EmeraldBright else DaramashMuted,
                FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatCell("قیمت اعلامی", formatPpm(row.askingPpm))
            StatCell("قیمت نهایی", if (row.soldPpm > 0L) formatPpm(row.soldPpm) else "ثبت نشده")
            StatCell(
                "فاصله",
                row.gapPercent?.let { gapText(it) } ?: "—"
            )
        }
    }
}

private fun gapText(percent: Int): String = when {
    percent < 0 -> "${PersianFormatters.toFa(abs(percent))}٪ کمتر"
    percent > 0 -> "${PersianFormatters.toFa(percent)}٪ بیشتر"
    else -> "برابر"
}

// ─────────────────────────────────────────────────────────────────────────────
// Price estimator for a new file
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EstimatorSection(properties: List<Property>, now: Long) {
    val overview = remember(properties, now) { MarketRadarUseCase.computeOverview(properties, now) }
    var nbName by rememberSaveable { mutableStateOf("") }
    var areaStr by rememberSaveable { mutableStateOf("") }
    var ageStr by rememberSaveable { mutableStateOf("") }
    var bedStr by rememberSaveable { mutableStateOf("2") }
    // Same defaults as the new-file form
    var elevator by rememberSaveable { mutableStateOf(true) }
    var parking by rememberSaveable { mutableStateOf(true) }
    var storage by rememberSaveable { mutableStateOf(true) }
    var terrace by rememberSaveable { mutableStateOf(false) }

    val area = PersianFormatters.toEn(areaStr).toIntOrNull() ?: 0
    val age = PersianFormatters.toEn(ageStr).toIntOrNull() ?: 0
    val beds = PersianFormatters.toEn(bedStr).toIntOrNull() ?: 2
    val estimate = remember(properties, now, nbName, area, age, beds, elevator, parking, storage, terrace) {
        if (nbName.isBlank() || area <= 0) null
        else MarketRadarUseCase.estimate(
            properties,
            MarketRadarUseCase.EstimateInput(nbName, area, age, beds, elevator, parking, storage, terrace),
            now
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        RText(
            "بازهٔ قیمت پیشنهادی برای فایل جدید، از نزدیک‌ترین فایل‌های واقعی همان محله (متراژ تا ±۲۵٪ و سن بنا تا ±۸ سال). ضریب یا عدد ساختگی در کار نیست.",
            11.5f, DaramashMuted
        )
        RadarCard {
            RText("محله:", 11.5f, DaramashMuted)
            Spacer(Modifier.height(4.dp))
            if (overview.neighborhoods.isEmpty()) {
                RText("هنوز فایلی با محله ثبت‌شده نیست.", 12f, DaramashMuted)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    overview.neighborhoods.forEach { n ->
                        DaramashChip(label = n.name, active = nbName == n.name, onClick = { nbName = n.name })
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DaramashModalTextField(
                    value = areaStr, onValueChange = { areaStr = it },
                    label = "متراژ", placeholder = "۸۰",
                    keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f)
                )
                DaramashModalTextField(
                    value = ageStr, onValueChange = { ageStr = it },
                    label = "سن بنا", placeholder = "۵",
                    keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f)
                )
                DaramashModalTextField(
                    value = bedStr, onValueChange = { bedStr = it },
                    label = "خواب", placeholder = "۲",
                    keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            RText("امکانات:", 11.5f, DaramashMuted)
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                DaramashChip("🚗 پارکینگ", parking, { parking = !parking })
                DaramashChip("📦 انباری", storage, { storage = !storage })
                DaramashChip("🛗 آسانسور", elevator, { elevator = !elevator })
                DaramashChip("🌿 تراس", terrace, { terrace = !terrace })
            }
        }
        RadarCard {
            when {
                nbName.isBlank() || area <= 0 ->
                    RText("محله و متراژ را وارد کن تا بازه‌ی قیمت نشان داده شود.", 12.5f, DaramashMuted)
                estimate == null ->
                    RText(
                        "برای این مشخصات حداقل ${PersianFormatters.toFa(MarketRadarUseCase.MIN_SAMPLES)} فایل مشابه در محله پیدا نشد؛ پس عددی نمی‌دهم. متراژ یا سن را کمی تغییر بده یا فایل‌های بیشتری ثبت کن.",
                        12.5f, DaramashMuted
                    )
                else -> {
                    RText("بازهٔ قیمت پیشنهادی", 12f, DaramashMuted)
                    Spacer(Modifier.height(4.dp))
                    RText(
                        "${PersianFormatters.formatMoneyToman(estimate.lowTotal)} تا ${PersianFormatters.formatMoneyToman(estimate.highTotal)} تومان",
                        17f, EmeraldBright, FontWeight.Bold
                    )
                    RText(
                        "میانگین مشابه‌ها: ${PersianFormatters.formatMoneyToman(estimate.midTotal)} تومان",
                        12f, DaramashText, modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        StatCell("متری (کمینه)", formatPpm(estimate.lowPpm))
                        StatCell("متری (میانگین)", formatPpm(estimate.midPpm))
                        StatCell("متری (بیشینه)", formatPpm(estimate.highPpm))
                    }
                    RText(
                        "بر پایهٔ ${PersianFormatters.toFa(estimate.sampleCount)} فایل مشابه · ${estimate.reliability}",
                        10.5f, DaramashMuted, modifier = Modifier.padding(top = 8.dp)
                    )
                    RText(
                        "این یک تحلیل از قیمت‌های واقعی ثبت‌شده است، نه پیش‌بینی؛ وضعیت داخلی، نور و موقعیت دقیق واحد را خودت در نظر بگیر.",
                        10.5f, DaramashMuted, modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(120.dp))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Neighborhood
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NeighborhoodRadarScreen(
    properties: List<Property>,
    neighborhood: String,
    filter: RadarFilter,
    snapshots: List<RadarSnapshot>,
    now: Long,
    onFilterChange: (RadarFilter) -> Unit,
    onBack: () -> Unit,
    onOpenGroup: (String, GroupSummary) -> Unit,
    onOpenProperty: (Property) -> Unit
) {
    val context = LocalContext.current
    val detail = remember(properties, neighborhood, filter, now) {
        MarketRadarUseCase.computeNeighborhoodDetail(properties, neighborhood, filter, now)
    }
    val trend = remember(snapshots, neighborhood) { MarketRadarUseCase.trendFor(snapshots, neighborhood) }
    var showFilters by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DaramashGhostButton(text = "→ بازگشت", small = true, onClick = onBack)
            Column(Modifier.weight(1f)) {
                RText(neighborhood, 16f, DaramashText, FontWeight.Bold, maxLines = 1)
                RText("رادار محله", 11f, DaramashMuted)
            }
            DaramashChip(
                label = if (filter.activeCount() > 0)
                    "🔍 فیلتر (${PersianFormatters.toFa(filter.activeCount())})"
                else
                    "🔍 فیلتر",
                active = filter.activeCount() > 0,
                onClick = { showFilters = true }
            )
        }
        if (showFilters) {
            RadarFiltersPanel(
                filter = filter,
                properties = properties,
                neighborhood = neighborhood,
                onFilterChange = onFilterChange,
                onDismiss = { showFilters = false }
            )
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                RadarCard {
                    val filtered = filter.activeCount() > 0
                    RText(
                        if (filtered) "آمار بخش انتخاب‌شده (فیلتر فعال)" else "آمار کامل محله (بدون فیلتر)",
                        12f, DaramashMuted
                    )
                    Spacer(Modifier.height(4.dp))
                    if (detail.stats.count == 0) RText("داده کافی موجود نیست", 15f, DaramashMuted)
                    else {
                        RText(formatPpm(detail.stats.average), 18f, EmeraldBright, FontWeight.Bold)
                        RText("میانگین قیمت هر مترمربع", 11f, DaramashMuted)
                        Spacer(Modifier.height(6.dp))
                        StatsRow(detail.stats)
                        val soldCount = detail.properties.count { MarketRadarUseCase.isSold(it) }
                        if (soldCount > 0) {
                            RText(
                                "شامل ${PersianFormatters.toFa(soldCount)} فایل فروش‌رفتهٔ ${PersianFormatters.toFa(MarketRadarUseCase.SOLD_WINDOW_DAYS)} روز اخیر",
                                10.5f, DaramashMuted, modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        if (!filtered) TrendBlock(trend)
                        Spacer(Modifier.height(10.dp))
                        DaramashGhostButton(
                            text = "📤 اشتراک تصویر",
                            small = true,
                            onClick = {
                                shareRadar(
                                    context,
                                    RadarShareData(
                                        title = if (filtered) "رادار $neighborhood (فیلترشده)" else "رادار بازار — $neighborhood",
                                        dateLabel = todayLabel(),
                                        breakdownTitle = "بر اساس متراژ",
                                        averagePpm = detail.stats.average,
                                        medianPpm = detail.stats.median,
                                        minPpm = detail.stats.min,
                                        maxPpm = detail.stats.max,
                                        count = detail.stats.count,
                                        trendChangePercent = if (filtered) null else trend.changePercent,
                                        trendSpanWeeks = if (filtered) 0 else trend.spanWeeks,
                                        rows = detail.byArea.map { RadarShareRow(it.label, it.stats.average, it.stats.count) }
                                    )
                                )
                            }
                        )
                    }
                }
            }
            item { SectionTitle("بر اساس متراژ") }
            items(detail.byArea, key = { "a_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("area", g) } }
            if (detail.byArea.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس تعداد خواب") }
            items(detail.byBedrooms, key = { "b_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("bedrooms", g) } }
            if (detail.byBedrooms.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس سن بنا") }
            items(detail.byAge, key = { "age_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("age", g) } }
            if (detail.byAge.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس امکانات") }
            items(detail.byAmenity, key = { "am_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("amenity", g) } }
            if (detail.byAmenity.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس وضعیت داخلی") }
            items(detail.byCondition, key = { "c_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("condition", g) } }
            if (detail.byCondition.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس نور") }
            items(detail.byLighting, key = { "l_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("lighting", g) } }
            if (detail.byLighting.isEmpty()) item { EmptyHint() }
            item { SectionTitle("فایل‌های مشارکت‌کننده (${PersianFormatters.toFa(detail.properties.size)})") }
            items(detail.properties, key = { it.id }) { p -> PropertyRadarRow(p, now) { onOpenProperty(p) } }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RadarFiltersPanel(
    filter: RadarFilter,
    properties: List<Property>,
    neighborhood: String,
    onFilterChange: (RadarFilter) -> Unit,
    onDismiss: () -> Unit
) {
    val eligibleInNb = remember(properties, neighborhood) {
        MarketRadarUseCase.eligibleProperties(properties).filter { it.neighborhood == neighborhood }
    }
    val availableLightings = remember(eligibleInNb) {
        MarketRadarUseCase.LIGHTING_OPTIONS.filter { opt ->
            eligibleInNb.any { it.lighting == opt }
        }
    }
    val matchCount = remember(properties, neighborhood, filter) {
        MarketRadarUseCase.computeNeighborhoodDetail(properties, neighborhood, filter).stats.count
    }

    // Same shell as AdvancedPropertyFilterDialog (DaramashLiquidModal + section labels + DaramashChip).
    // Live updates: each chip mutates RadarFilter immediately (no Apply draft).
    DaramashLiquidModal(
        title = "🔍 فیلتر رادار محله",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(
                    text = "پاک کردن همه",
                    onClick = {
                        onFilterChange(RadarFilter(neighborhood = neighborhood))
                    }
                )
                DaramashPrimaryButton(
                    text = "نمایش ${PersianFormatters.toFa(matchCount.toString())} فایل",
                    onClick = onDismiss
                )
            }
        }
    ) {
        Text("متراژ:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            AreaBucket.entries.forEach { b ->
                DaramashChip(
                    label = b.labelFa,
                    active = filter.areaBucket == b,
                    onClick = { onFilterChange(filter.copy(areaBucket = if (filter.areaBucket == b) null else b)) }
                )
            }
        }

        Text("تعداد خواب:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            BedroomBucket.entries.forEach { b ->
                DaramashChip(
                    label = b.labelFa,
                    active = filter.bedroomBucket == b,
                    onClick = { onFilterChange(filter.copy(bedroomBucket = if (filter.bedroomBucket == b) null else b)) }
                )
            }
        }

        Text("سن بنا:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            AgeBucket.entries.forEach { b ->
                DaramashChip(
                    label = b.labelFa,
                    active = filter.ageBucket == b,
                    onClick = { onFilterChange(filter.copy(ageBucket = if (filter.ageBucket == b) null else b)) }
                )
            }
        }

        Text("وضعیت داخلی:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            MarketRadarUseCase.CONDITION_OPTIONS.forEach { c ->
                DaramashChip(
                    label = c,
                    active = filter.condition == c,
                    onClick = { onFilterChange(filter.copy(condition = if (filter.condition == c) null else c)) }
                )
            }
        }

        if (availableLightings.isNotEmpty()) {
            Text("نورگیری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                availableLightings.forEach { l ->
                    DaramashChip(
                        label = l,
                        active = filter.lighting == l,
                        onClick = { onFilterChange(filter.copy(lighting = if (filter.lighting == l) null else l)) }
                    )
                }
            }
        }

        Text("امکانات:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        AmenityTriStateRow("🚗 پارکینگ", filter.parking) { v -> onFilterChange(filter.copy(parking = v)) }
        AmenityTriStateRow("🛗 آسانسور", filter.elevator) { v -> onFilterChange(filter.copy(elevator = v)) }
        AmenityTriStateRow("📦 انباری", filter.storage) { v -> onFilterChange(filter.copy(storage = v)) }
        AmenityTriStateRow("🌿 تراس", filter.terrace) { v -> onFilterChange(filter.copy(terrace = v)) }

        Text("طبقه‌ی واحد:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(
                "۱ و ۲" to setOf(1, 2),
                "۳" to setOf(3),
                "۴" to setOf(4)
            ).forEach { (label, floors) ->
                DaramashChip(
                    label = label,
                    active = filter.floors == floors,
                    onClick = { onFilterChange(filter.copy(floors = if (filter.floors == floors) null else floors)) }
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AmenityTriStateRow(title: String, value: Boolean?, onChange: (Boolean?) -> Unit) {
    Text(title, fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily, modifier = Modifier.padding(top = 4.dp, bottom = 2.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        DaramashChip(label = "بدون فیلتر", active = value == null, onClick = { onChange(null) })
        DaramashChip(label = "دارد", active = value == true, onClick = { onChange(true) })
        DaramashChip(label = "ندارد", active = value == false, onClick = { onChange(false) })
    }
}

@Composable
private fun GroupDetailScreen(group: GroupSummary, now: Long, onBack: () -> Unit, onOpenProperty: (Property) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            DaramashGhostButton(text = "→ بازگشت", small = true, onClick = onBack)
            Spacer(Modifier.width(10.dp))
            RText(group.label, 15f, DaramashText, FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 2)
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                RadarCard {
                    if (group.stats.count == 0) RText("داده کافی موجود نیست", 14f, DaramashMuted)
                    else {
                        RText(formatPpm(group.stats.average), 18f, EmeraldBright, FontWeight.Bold)
                        Spacer(Modifier.height(6.dp)); StatsRow(group.stats)
                    }
                }
            }
            item { SectionTitle("فایل‌های این گروه (${PersianFormatters.toFa(group.properties.size)})") }
            items(group.properties, key = { it.id }) { p -> PropertyRadarRow(p, now) { onOpenProperty(p) } }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable
private fun GroupRow(g: GroupSummary, onClick: () -> Unit) {
    RadarCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                RText(g.label, 13f, DaramashText, FontWeight.Medium, maxLines = 2)
                RText("${PersianFormatters.toFa(g.stats.count)} فایل · ${g.stats.sampleLabel}", 11f, DaramashMuted)
            }
            RText(
                if (g.stats.count == 0) "—" else formatPpm(g.stats.average),
                13f,
                if (g.stats.count == 0) DaramashMuted else EmeraldBright,
                FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PropertyRadarRow(p: Property, now: Long, onClick: () -> Unit) {
    val ppm = MarketRadarUseCase.pricePerSqm(p)
    val sold = MarketRadarUseCase.isSold(p)
    RadarCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                RText(
                    buildString {
                        append(if (p.code.isNotBlank()) "کد ${PersianFormatters.toFa(p.code)}" else "بدون کد")
                        append(" · "); append(PersianFormatters.toFa(p.area)); append(" متر")
                        if (p.bedrooms > 0) append(" · ${PersianFormatters.toFa(p.bedrooms)} خواب")
                    },
                    13f, DaramashText, FontWeight.SemiBold
                )
                RText(
                    buildString {
                        if (p.buildingAge >= 0) append("سن ${PersianFormatters.toFa(p.buildingAge)} · ")
                        append(listOfNotNull(if (p.parking) "پارکینگ" else null, if (p.elevator) "آسانسور" else null, if (p.storage) "انباری" else null, if (p.terrace) "تراس" else null).joinToString("، ").ifEmpty { "بدون امکانات خاص" })
                        if (p.condition.isNotBlank()) append(" · ${p.condition}")
                        if (p.lighting.isNotBlank()) append(" · ${p.lighting}")
                    },
                    11f, DaramashMuted, maxLines = 2
                )
                if (sold) {
                    RText(
                        "✅ فروش رفته · ${PersianFormatters.toFa(MarketRadarUseCase.soldDaysAgo(p, now))} روز پیش" +
                            if (p.soldPrice > 0L) " (بر پایهٔ قیمت نهایی)" else "",
                        10.5f, RedDanger, FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                RText(formatPpm(ppm), 12f, EmeraldBright, FontWeight.Bold)
                RText(
                    MarketRadarUseCase.effectivePrice(p).let { if (it > 0L) PersianFormatters.formatMoneyToman(it) else "—" },
                    10f, DaramashMuted
                )
            }
        }
    }
}

@Composable
private fun StatsRow(s: PriceStats) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        StatCell("تعداد", PersianFormatters.toFa(s.count))
        StatCell("میانه", formatPpm(s.median))
        StatCell("کمینه", formatPpm(s.min))
        StatCell("بیشینه", formatPpm(s.max))
    }
    RText(s.sampleLabel, 10f, DaramashMuted, modifier = Modifier.padding(top = 4.dp))
}

@Composable private fun StatCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        RText(label, 10f, DaramashMuted)
        RText(value, 11f, DaramashText, FontWeight.SemiBold)
    }
}

@Composable private fun StatMiniCard(title: String, value: String, modifier: Modifier = Modifier) {
    RadarCard(modifier = modifier) {
        RText(title, 11f, DaramashMuted)
        RText(value, 18f, DaramashText, FontWeight.Bold)
    }
}

@Composable private fun SectionTitle(text: String) {
    RText(text, 13f, DaramashText, FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
}

@Composable private fun EmptyHint() {
    RText("داده کافی موجود نیست", 12f, DaramashMuted, modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
private fun RText(
    text: String,
    size: Float,
    color: Color = DaramashText,
    weight: FontWeight? = null,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text = text,
        fontSize = size.sp,
        color = color,
        fontWeight = weight,
        fontFamily = VazirmatnFontFamily,
        modifier = modifier,
        maxLines = maxLines,
        overflow = if (maxLines == Int.MAX_VALUE) TextOverflow.Clip else TextOverflow.Ellipsis
    )
}

@Composable
private fun RadarCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    LiquidGlassCard(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 20.dp,
        contentPadding = PaddingValues(14.dp),
        onClick = onClick,
        content = content
    )
}

private fun formatPpm(value: Long): String {
    if (value <= 0L) return "—"
    return PersianFormatters.formatMoneyToman(value) + " /متر"
}

private fun todayLabel(): String =
    PersianFormatters.formatIsoToJalaliReadable(PersianFormatters.todayIso())

/** Renders the radar picture and opens the system share sheet. Never throws into the UI. */
private fun shareRadar(context: Context, data: RadarShareData) {
    try {
        val file = RadarShareImage.render(context, data)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری تصویر رادار"))
    } catch (e: Exception) {
        Toast.makeText(context, "ساخت تصویر ناموفق بود", Toast.LENGTH_SHORT).show()
    }
}
