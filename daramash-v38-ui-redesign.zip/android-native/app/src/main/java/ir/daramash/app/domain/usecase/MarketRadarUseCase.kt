package ir.daramash.app.domain.usecase

import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.RadarSnapshot
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * رادار بازار — تحلیل آفلاین میانگین قیمت هر مترمربع فایل‌های فروشنده فعال.
 * فایل‌های «فروش رفت» تا ۱۵ روز بعد از تاریخ فروش هم در آمار می‌مانند
 * (به‌دلیل تورم ماهانه بالا، قیمت معامله‌شده‌ی تازه هنوز سیگنال معتبر بازار است).
 * تمام محاسبات محلی و بدون وابستگی به شبکه یا AI.
 */
object MarketRadarUseCase {

    /** A sold unit keeps counting in the averages for this many days after the sale. */
    const val SOLD_WINDOW_DAYS = 15
    private const val DAY_MS = 86_400_000L
    private const val SOLD_WINDOW_MS = SOLD_WINDOW_DAYS * DAY_MS

    /** Minimum number of comparable files before any comparison / estimate is shown. */
    const val MIN_SAMPLES = 3

    fun isSold(p: Property): Boolean = PersianFormatters.isSoldStatus(p.status)

    /** Sale moment; legacy sold files without a stored date fall back to their last update. */
    fun soldAtOf(p: Property): Long = if (p.soldAt > 0L) p.soldAt else p.updatedAt

    fun soldDaysAgo(p: Property, now: Long = System.currentTimeMillis()): Int =
        ((now - soldAtOf(p)) / DAY_MS).toInt().coerceAtLeast(0)

    fun soldDaysLeftInStats(p: Property, now: Long = System.currentTimeMillis()): Int =
        (SOLD_WINDOW_DAYS - soldDaysAgo(p, now)).coerceAtLeast(0)

    /** Price used for the per-sqm figure: the final sold price when entered, otherwise the listed price. */
    fun effectivePrice(p: Property): Long =
        if (isSold(p) && p.soldPrice > 0L) p.soldPrice else p.totalPrice

    fun isEligible(p: Property, now: Long = System.currentTimeMillis()): Boolean {
        if (p.isArchived) return false
        if (p.area <= 0) return false
        if (effectivePrice(p) <= 0L) return false
        return when {
            isSold(p) -> now - soldAtOf(p) <= SOLD_WINDOW_MS
            p.status == "فروشنده" -> true
            else -> false
        }
    }

    fun pricePerSqm(p: Property): Long {
        val price = effectivePrice(p)
        if (p.area <= 0 || price <= 0L) return 0L
        return (price.toDouble() / p.area).roundToLong()
    }

    fun eligibleProperties(all: List<Property>, now: Long = System.currentTimeMillis()): List<Property> =
        all.filter { isEligible(it, now) }

    enum class AreaBucket(val labelFa: String, val minExclusive: Int, val maxInclusive: Int) {
        UP_TO_50("تا ۵۰ متر", Int.MIN_VALUE, 50),
        A51_60("۵۱ تا ۶۰ متر", 50, 60),
        A61_70("۶۱ تا ۷۰ متر", 60, 70),
        A71_80("۷۱ تا ۸۰ متر", 70, 80),
        A81_90("۸۱ تا ۹۰ متر", 80, 90),
        A91_100("۹۱ تا ۱۰۰ متر", 90, 100),
        A101_120("۱۰۱ تا ۱۲۰ متر", 100, 120),
        OVER_120("بالای ۱۲۰ متر", 120, Int.MAX_VALUE);
        fun contains(area: Int): Boolean = area > minExclusive && area <= maxInclusive
        companion object {
            fun of(area: Int): AreaBucket? = entries.firstOrNull { it.contains(area) }
        }
    }

    enum class BedroomBucket(val labelFa: String) {
        ZERO("بدون خواب"), ONE("یک خواب"), TWO("دو خواب"), THREE("سه خواب"), FOUR_PLUS("چهار خواب و بیشتر");
        companion object {
            fun of(bedrooms: Int): BedroomBucket? = when {
                bedrooms < 0 -> null
                bedrooms == 0 -> ZERO
                bedrooms == 1 -> ONE
                bedrooms == 2 -> TWO
                bedrooms == 3 -> THREE
                bedrooms >= 4 -> FOUR_PLUS
                else -> null
            }
        }
    }

    enum class AgeBucket(val labelFa: String, val minInclusive: Int, val maxExclusive: Int) {
        NEW("نوساز (زیر ۲ سال)", 0, 2),
        A2_5("۲ تا ۵ سال", 2, 5),
        A5_10("۵ تا ۱۰ سال", 5, 10),
        A10_15("۱۰ تا ۱۵ سال", 10, 15),
        A15_22("۱۵ تا ۲۲ سال", 15, 22),
        A22_27("۲۲ تا ۲۷ سال", 22, 28);
        fun contains(age: Int): Boolean = age >= minInclusive && age < maxExclusive
        companion object {
            fun of(age: Int): AgeBucket? {
                if (age < 0) return null
                return entries.firstOrNull { it.contains(age) }
            }
        }
    }

    /**
     * Exclusive amenity classification — each property maps to at most one display label.
     * Spec: 16 Boolean combinations; 5 of them split by floor → 26 possible display groups.
     */
    data class IndependentAmenityCounts(
        val withElevator: Int,
        val withoutElevator: Int,
        val withParking: Int,
        val withoutParking: Int,
        val withStorage: Int,
        val withoutStorage: Int,
        val withTerrace: Int,
        val withoutTerrace: Int
    ) {
        companion object {
            fun from(props: List<Property>): IndependentAmenityCounts {
                var e1 = 0; var e0 = 0; var p1 = 0; var p0 = 0
                var s1 = 0; var s0 = 0; var t1 = 0; var t0 = 0
                for (p in props) {
                    if (p.elevator) e1++ else e0++
                    if (p.parking) p1++ else p0++
                    if (p.storage) s1++ else s0++
                    if (p.terrace) t1++ else t0++
                }
                return IndependentAmenityCounts(e1, e0, p1, p0, s1, s0, t1, t0)
            }
        }
    }

    private val FLOOR_1_2 = "طبقات اول و دوم"
    private val FLOOR_3 = "طبقه سوم"
    private val FLOOR_4 = "طبقه چهارم"

    /**
     * Classify a property into exactly one exclusive amenity display label, or null when
     * the combination is floor-dependent and unitFloor is invalid (not in 1..4).
     */
    fun classifyExclusive(p: Property): String? {
        val e = p.elevator
        val pk = p.parking
        val s = p.storage
        val t = p.terrace
        val base = when {
            !e && !pk && !s && !t -> "بدون هیچ امکانات"
            !e && !pk && !s && t -> "فقط تراس‌دار"
            !e && !pk && s && !t -> "فقط انباری‌دار"
            !e && !pk && s && t -> "انباری و تراس‌دار"
            !e && pk && !s && !t -> "پارکینگ‌دار (بدون آسانسور)"
            !e && pk && !s && t -> "پارکینگ و تراس‌دار"
            !e && pk && s && !t -> "پارکینگ، انباری‌دار (بدون آسانسور)"
            !e && pk && s && t -> "پارکینگ، انباری و تراس‌دار"
            e && !pk && !s && !t -> "آسانسوردار بدون پارکینگ"
            e && !pk && !s && t -> "آسانسور، تراس‌دار"
            e && !pk && s && !t -> "آسانسور، انباری‌دار"
            e && !pk && s && t -> "آسانسور، انباری، تراس‌دار"
            e && pk && !s && !t -> "آسانسور و پارکینگ‌دار"
            e && pk && !s && t -> "آسانسور، پارکینگ و تراس‌دار"
            e && pk && s && !t -> "فول امکانات"
            e && pk && s && t -> "فول امکانات + تراس"
            else -> return null // unreachable for Boolean quadruples
        }
        val floorSplit = !e && when (base) {
            "بدون هیچ امکانات",
            "پارکینگ‌دار (بدون آسانسور)",
            "پارکینگ و تراس‌دار",
            "پارکینگ، انباری‌دار (بدون آسانسور)",
            "پارکینگ، انباری و تراس‌دار" -> true
            else -> false
        }
        if (!floorSplit) return base
        val floorLabel = when (p.unitFloor) {
            1, 2 -> FLOOR_1_2
            3 -> FLOOR_3
            4 -> FLOOR_4
            else -> return null
        }
        return "$base — $floorLabel"
    }

    /** All 26 exclusive display labels (stable order for tests/UI). */
    fun allExclusiveDisplayLabels(): List<String> {
        val noFloor = listOf(
            "فقط تراس‌دار",
            "فقط انباری‌دار",
            "انباری و تراس‌دار",
            "آسانسوردار بدون پارکینگ",
            "آسانسور، تراس‌دار",
            "آسانسور، انباری‌دار",
            "آسانسور، انباری، تراس‌دار",
            "آسانسور و پارکینگ‌دار",
            "آسانسور، پارکینگ و تراس‌دار",
            "فول امکانات",
            "فول امکانات + تراس"
        )
        val bases = listOf(
            "بدون هیچ امکانات",
            "پارکینگ‌دار (بدون آسانسور)",
            "پارکینگ و تراس‌دار",
            "پارکینگ، انباری‌دار (بدون آسانسور)",
            "پارکینگ، انباری و تراس‌دار"
        )
        val floors = listOf(FLOOR_1_2, FLOOR_3, FLOOR_4)
        return bases.flatMap { b -> floors.map { f -> "$b — $f" } } + noFloor
    }

    val CONDITION_OPTIONS = listOf("نوساز", "بازسازی شده", "تمیز", "نقاشی‌شده", "نیاز به بازسازی")
    val LIGHTING_OPTIONS = listOf(
        "خطی پرده خور", "دوکله نور جنوبی", "دوکله نور شمالی",
        "خواب رو به بیرون", "فول پاسیو", "پاسیو باز", "سالن پرده خور"
    )

    data class RadarFilter(
        val neighborhood: String? = null,
        val areaBucket: AreaBucket? = null,
        val bedroomBucket: BedroomBucket? = null,
        val ageBucket: AgeBucket? = null,
        /** Independent amenity filters: null = no filter. */
        val elevator: Boolean? = null,
        val parking: Boolean? = null,
        val storage: Boolean? = null,
        val terrace: Boolean? = null,
        /** Optional floor set (e.g. setOf(1,2)); null = no floor filter. */
        val floors: Set<Int>? = null,
        val condition: String? = null,
        val lighting: String? = null
    ) {
        fun activeCount(): Int {
            var n = 0
            if (neighborhood != null) n++
            if (areaBucket != null) n++
            if (bedroomBucket != null) n++
            if (ageBucket != null) n++
            if (elevator != null) n++
            if (parking != null) n++
            if (storage != null) n++
            if (terrace != null) n++
            if (floors != null) n++
            if (condition != null) n++
            if (lighting != null) n++
            return n
        }
    }

    fun applyFilter(list: List<Property>, f: RadarFilter, now: Long = System.currentTimeMillis()): List<Property> {
        return list.filter { p ->
            if (!isEligible(p, now)) return@filter false
            if (f.neighborhood != null && p.neighborhood != f.neighborhood) return@filter false
            if (f.areaBucket != null && AreaBucket.of(p.area) != f.areaBucket) return@filter false
            if (f.bedroomBucket != null) {
                val b = BedroomBucket.of(p.bedrooms)
                if (b == null || b != f.bedroomBucket) return@filter false
            }
            if (f.ageBucket != null) {
                val a = AgeBucket.of(p.buildingAge)
                if (a == null || a != f.ageBucket) return@filter false
            }
            if (f.elevator != null && p.elevator != f.elevator) return@filter false
            if (f.parking != null && p.parking != f.parking) return@filter false
            if (f.storage != null && p.storage != f.storage) return@filter false
            if (f.terrace != null && p.terrace != f.terrace) return@filter false
            if (f.floors != null) {
                if (p.unitFloor <= 0 || p.unitFloor !in f.floors!!) return@filter false
            }
            if (f.condition != null && (p.condition.isBlank() || p.condition != f.condition)) return@filter false
            if (f.lighting != null) {
                // Invalid / non-form lighting filter must not produce matches.
                if (f.lighting !in LIGHTING_OPTIONS) return@filter false
                if (p.lighting != f.lighting) return@filter false
            }
            true
        }
    }

    data class PriceStats(
        val count: Int,
        val average: Long,
        val median: Long,
        val min: Long,
        val max: Long,
        val sampleLabel: String
    ) {
        companion object {
            val EMPTY = PriceStats(0, 0, 0, 0, 0, "داده کافی موجود نیست")
            fun from(prices: List<Long>): PriceStats {
                if (prices.isEmpty()) return EMPTY
                val sorted = prices.sorted()
                val avg = (sorted.sum().toDouble() / sorted.size).roundToLong()
                val med = if (sorted.size % 2 == 1) sorted[sorted.size / 2]
                else ((sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0).roundToLong()
                return PriceStats(sorted.size, avg, med, sorted.first(), sorted.last(), sampleReliability(sorted.size))
            }
            fun sampleReliability(n: Int): String = when {
                n <= 0 -> "داده کافی موجود نیست"
                n <= 2 -> "داده ناکافی"
                n <= 5 -> "نمونه محدود"
                n <= 10 -> "نمونه قابل بررسی"
                else -> "نمونه مناسب‌تر برای مقایسه"
            }
        }
    }

    data class NeighborhoodSummary(val name: String, val stats: PriceStats, val properties: List<Property>, val amenityCounts: IndependentAmenityCounts)
    data class GroupSummary(val key: String, val label: String, val stats: PriceStats, val properties: List<Property>)
    data class MarketOverview(
        val totalEligible: Int,
        val neighborhoodCount: Int,
        val overallStats: PriceStats,
        val neighborhoods: List<NeighborhoodSummary>,
        /** How many of [totalEligible] are recently sold units still inside the 15-day window. */
        val soldInWindow: Int = 0
    )

    fun computeOverview(all: List<Property>, now: Long = System.currentTimeMillis()): MarketOverview {
        val eligible = eligibleProperties(all, now)
        val overall = PriceStats.from(eligible.map { pricePerSqm(it) })
        val byNb = eligible.filter { it.neighborhood.isNotBlank() }
            .groupBy { it.neighborhood }
            .map { (name, props) ->
                NeighborhoodSummary(
                    name,
                    PriceStats.from(props.map { pricePerSqm(it) }),
                    props,
                    IndependentAmenityCounts.from(props)
                )
            }
            .sortedByDescending { it.stats.count }
        return MarketOverview(eligible.size, byNb.size, overall, byNb, eligible.count { isSold(it) })
    }

    data class NeighborhoodDetail(
        val neighborhood: String,
        val stats: PriceStats,
        val properties: List<Property>,
        val byArea: List<GroupSummary>,
        val byBedrooms: List<GroupSummary>,
        val byAge: List<GroupSummary>,
        val byAmenity: List<GroupSummary>,
        val byCondition: List<GroupSummary>,
        val byLighting: List<GroupSummary>
    )

    fun computeNeighborhoodDetail(
        all: List<Property>,
        neighborhood: String,
        filter: RadarFilter = RadarFilter(),
        now: Long = System.currentTimeMillis()
    ): NeighborhoodDetail {
        val base = eligibleProperties(all, now).filter { it.neighborhood == neighborhood }
        val filtered = applyFilter(base, filter.copy(neighborhood = neighborhood), now)
        val stats = PriceStats.from(filtered.map { pricePerSqm(it) })

        fun groupBy(keyOf: (Property) -> String?, labelOf: (String) -> String = { it }): List<GroupSummary> =
            filtered.mapNotNull { p -> keyOf(p)?.let { it to p } }
                .groupBy({ it.first }, { it.second })
                .map { (k, props) -> GroupSummary(k, labelOf(k), PriceStats.from(props.map { pricePerSqm(it) }), props) }
                .sortedByDescending { it.stats.count }

        val byArea = AreaBucket.entries.mapNotNull { bucket ->
            val props = filtered.filter { AreaBucket.of(it.area) == bucket }
            if (props.isEmpty()) null else GroupSummary(bucket.name, bucket.labelFa, PriceStats.from(props.map { pricePerSqm(it) }), props)
        }
        val byBeds = BedroomBucket.entries.mapNotNull { bucket ->
            val props = filtered.filter { BedroomBucket.of(it.bedrooms) == bucket }
            if (props.isEmpty()) null else GroupSummary(bucket.name, bucket.labelFa, PriceStats.from(props.map { pricePerSqm(it) }), props)
        }
        val byAge = AgeBucket.entries.mapNotNull { bucket ->
            val props = filtered.filter { AgeBucket.of(it.buildingAge) == bucket }
            if (props.isEmpty()) null else GroupSummary(bucket.name, bucket.labelFa, PriceStats.from(props.map { pricePerSqm(it) }), props)
        }
        // Exclusive amenity groups: at most one group per property.
        val byAmenity = filtered.mapNotNull { p -> classifyExclusive(p)?.let { label -> label to p } }
            .groupBy({ it.first }, { it.second })
            .map { (label, props) ->
                GroupSummary(label, label, PriceStats.from(props.map { pricePerSqm(it) }), props)
            }
            .sortedByDescending { it.stats.count }
        val byCondition = groupBy({ p -> p.condition.takeIf { it.isNotBlank() && it in CONDITION_OPTIONS } })
        // Only registration-form lighting options; blank/unknown values excluded from lighting groups only.
        val byLighting = groupBy({ p -> p.lighting.takeIf { it.isNotBlank() && it in LIGHTING_OPTIONS } })

        return NeighborhoodDetail(neighborhood, stats, filtered, byArea, byBeds, byAge, byAmenity, byCondition, byLighting)
    }

    /** Stable identity for a statistical group (avoids caching a stale GroupSummary snapshot). */
    data class GroupRef(val kind: String, val key: String)

    /**
     * Resolve a [GroupRef] against the latest neighborhood detail.
     * Returns null when the group no longer exists or has zero properties.
     */
    fun resolveGroup(detail: NeighborhoodDetail, ref: GroupRef): GroupSummary? {
        val list = when (ref.kind) {
            "area" -> detail.byArea
            "bedrooms" -> detail.byBedrooms
            "age" -> detail.byAge
            "amenity" -> detail.byAmenity
            "condition" -> detail.byCondition
            "lighting" -> detail.byLighting
            else -> emptyList()
        }
        return list.firstOrNull { it.key == ref.key }?.takeIf { it.properties.isNotEmpty() }
    }

    fun groupRefFor(kind: String, summary: GroupSummary): GroupRef = GroupRef(kind, summary.key)

    // ─────────────────────────────────────────────────────────────────────────
    // Neighborhood comparison (sorting + headline)
    // ─────────────────────────────────────────────────────────────────────────

    enum class NeighborhoodSort(val labelFa: String) {
        MOST_FILES("بیشترین فایل"),
        PRICIEST("گران‌ترین"),
        CHEAPEST("ارزان‌ترین")
    }

    fun sortNeighborhoods(list: List<NeighborhoodSummary>, sort: NeighborhoodSort): List<NeighborhoodSummary> =
        when (sort) {
            NeighborhoodSort.MOST_FILES -> list.sortedByDescending { it.stats.count }
            NeighborhoodSort.PRICIEST -> list.sortedByDescending { it.stats.average }
            NeighborhoodSort.CHEAPEST -> list.sortedBy { it.stats.average }
        }

    data class MarketHeadline(val priciest: NeighborhoodSummary, val cheapest: NeighborhoodSummary)

    /** Only neighborhoods with enough files are compared; null when fewer than two qualify. */
    fun marketHeadline(overview: MarketOverview): MarketHeadline? {
        val solid = overview.neighborhoods.filter { it.stats.count >= MIN_SAMPLES }
        if (solid.size < 2) return null
        val hi = solid.maxByOrNull { it.stats.average } ?: return null
        val lo = solid.minByOrNull { it.stats.average } ?: return null
        if (hi.name == lo.name) return null
        return MarketHeadline(hi, lo)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Weekly snapshots → price trend
    // ─────────────────────────────────────────────────────────────────────────

    /** Iran: UTC+3:30 (no DST). Weeks start on Saturday; epoch day 2 (1970-01-03) is a Saturday. */
    fun weekKeyOf(nowMillis: Long, utcOffsetMillis: Long = 12_600_000L): Int {
        val epochDay = Math.floorDiv(nowMillis + utcOffsetMillis, DAY_MS)
        return Math.floorDiv(epochDay - 2L, 7L).toInt()
    }

    /** One row for the whole market (neighborhood = "") plus one per neighborhood. Empty when nothing is eligible. */
    fun buildSnapshots(all: List<Property>, now: Long, weekKey: Int): List<RadarSnapshot> {
        val eligible = eligibleProperties(all, now)
        if (eligible.isEmpty()) return emptyList()
        fun snap(name: String, props: List<Property>): RadarSnapshot {
            val st = PriceStats.from(props.map { pricePerSqm(it) })
            return RadarSnapshot(weekKey, name, now, st.average, st.median, st.count)
        }
        val out = mutableListOf(snap("", eligible))
        eligible.filter { it.neighborhood.isNotBlank() }
            .groupBy { it.neighborhood }
            .forEach { (name, props) -> out += snap(name, props) }
        return out
    }

    data class TrendPoint(val weekKey: Int, val averagePpm: Long, val sampleCount: Int)
    data class TrendSummary(
        val points: List<TrendPoint>,
        /** Percent change between the latest week and ~4 weeks earlier (or the oldest point if history is shorter). */
        val changePercent: Double?,
        val spanWeeks: Int
    ) {
        val hasTrend: Boolean get() = points.size >= 2 && changePercent != null
    }

    fun trendFor(snapshots: List<RadarSnapshot>, neighborhood: String, maxPoints: Int = 12): TrendSummary {
        val pts = snapshots.filter { it.neighborhood == neighborhood && it.averagePpm > 0L }
            .sortedBy { it.weekKey }
            .takeLast(maxPoints)
            .map { TrendPoint(it.weekKey, it.averagePpm, it.sampleCount) }
        if (pts.size < 2) return TrendSummary(pts, null, 0)
        val last = pts.last()
        val ref = pts.lastOrNull { it.weekKey <= last.weekKey - 4 } ?: pts.first()
        if (ref.weekKey == last.weekKey || ref.averagePpm <= 0L) return TrendSummary(pts, null, 0)
        val change = (last.averagePpm - ref.averagePpm).toDouble() / ref.averagePpm * 100.0
        return TrendSummary(pts, change, last.weekKey - ref.weekKey)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // File vs market
    // ─────────────────────────────────────────────────────────────────────────

    enum class MarketVerdict { BELOW, FAIR, ABOVE }

    data class MarketComparison(
        val basisLabel: String,
        val comparableCount: Int,
        val marketAveragePpm: Long,
        val thisPpm: Long,
        /** Negative = cheaper than comparable files. */
        val diffPercent: Int,
        val verdict: MarketVerdict
    )

    /**
     * Compares one file's per-sqm price with comparable files in the same neighborhood.
     * Tries the tightest group first (same area bucket + age bucket), then widens.
     * Returns null when the file has no price/area/neighborhood or fewer than [MIN_SAMPLES] comparables exist.
     */
    fun compareToMarket(
        p: Property,
        all: List<Property>,
        now: Long = System.currentTimeMillis()
    ): MarketComparison? {
        val thisPpm = pricePerSqm(p)
        if (thisPpm <= 0L || p.neighborhood.isBlank()) return null
        val pool = eligibleProperties(all, now).filter { it.id != p.id && it.neighborhood == p.neighborhood }
        val areaB = AreaBucket.of(p.area)
        val ageB = AgeBucket.of(p.buildingAge)

        data class Level(val label: String, val props: List<Property>)
        val levels = buildList {
            if (areaB != null && ageB != null) {
                add(Level("هم‌محله، هم‌متراژ و هم‌سن", pool.filter { AreaBucket.of(it.area) == areaB && AgeBucket.of(it.buildingAge) == ageB }))
            }
            if (areaB != null) {
                add(Level("هم‌محله و هم‌متراژ (${areaB.labelFa})", pool.filter { AreaBucket.of(it.area) == areaB }))
            }
            add(Level("همهٔ فایل‌های محله", pool))
        }
        val level = levels.firstOrNull { it.props.size >= MIN_SAMPLES } ?: return null
        val avg = PriceStats.from(level.props.map { pricePerSqm(it) }).average
        if (avg <= 0L) return null
        val diff = ((thisPpm - avg).toDouble() / avg * 100.0).roundToInt()
        val verdict = when {
            diff < -5 -> MarketVerdict.BELOW
            diff > 5 -> MarketVerdict.ABOVE
            else -> MarketVerdict.FAIR
        }
        return MarketComparison(level.label, level.props.size, avg, thisPpm, diff, verdict)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Price estimator for a new file (nearest real comparables — no invented multipliers)
    // ─────────────────────────────────────────────────────────────────────────

    data class EstimateInput(
        val neighborhood: String,
        val area: Int,
        val buildingAge: Int,
        val bedrooms: Int,
        val elevator: Boolean,
        val parking: Boolean,
        val storage: Boolean,
        val terrace: Boolean
    )

    data class Estimate(
        val lowPpm: Long,
        val midPpm: Long,
        val highPpm: Long,
        val lowTotal: Long,
        val midTotal: Long,
        val highTotal: Long,
        val sampleCount: Int,
        val reliability: String
    )

    private const val EST_MAX_AREA_DIFF = 0.25
    private const val EST_MAX_AGE_DIFF = 8
    private const val EST_MAX_SAMPLES = 8

    private fun percentile(sorted: List<Long>, q: Double): Long {
        if (sorted.isEmpty()) return 0L
        if (sorted.size == 1) return sorted[0]
        val pos = q * (sorted.size - 1)
        val lo = pos.toInt()
        val hi = minOf(lo + 1, sorted.size - 1)
        val frac = pos - lo
        return (sorted[lo] + (sorted[hi] - sorted[lo]) * frac).roundToLong()
    }

    /**
     * Uses the closest real files in the same neighborhood (area within ±25%, age within ±8 years).
     * Returns null — never a made-up number — when fewer than [MIN_SAMPLES] qualify.
     */
    fun estimate(all: List<Property>, input: EstimateInput, now: Long = System.currentTimeMillis()): Estimate? {
        if (input.neighborhood.isBlank() || input.area <= 0) return null
        val scored = eligibleProperties(all, now)
            .filter { it.neighborhood == input.neighborhood }
            .mapNotNull { p ->
                val areaDiff = abs(p.area - input.area).toDouble() / input.area
                if (areaDiff > EST_MAX_AREA_DIFF) return@mapNotNull null
                val ageDiff = abs(p.buildingAge - input.buildingAge)
                if (ageDiff > EST_MAX_AGE_DIFF) return@mapNotNull null
                var d = areaDiff * 4.0 + ageDiff * 0.08
                if (p.bedrooms != input.bedrooms) d += 0.25
                if (p.elevator != input.elevator) d += 0.2
                if (p.parking != input.parking) d += 0.2
                if (p.storage != input.storage) d += 0.2
                if (p.terrace != input.terrace) d += 0.2
                p to d
            }
            .sortedBy { it.second }
            .take(EST_MAX_SAMPLES)
        if (scored.size < MIN_SAMPLES) return null
        val ppms = scored.map { pricePerSqm(it.first) }.sorted()
        val mid = (ppms.sum().toDouble() / ppms.size).roundToLong()
        val low = if (ppms.size >= 5) percentile(ppms, 0.25) else ppms.first()
        val high = if (ppms.size >= 5) percentile(ppms, 0.75) else ppms.last()
        val area = input.area.toLong()
        return Estimate(
            lowPpm = low, midPpm = mid, highPpm = high,
            lowTotal = low * area, midTotal = mid * area, highTotal = high * area,
            sampleCount = ppms.size,
            reliability = PriceStats.sampleReliability(ppms.size)
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Sold files: asking vs final price, time on market
    // ─────────────────────────────────────────────────────────────────────────

    data class SoldRow(
        val property: Property,
        val soldAt: Long,
        val daysAgo: Int,
        val inStats: Boolean,
        val daysLeftInStats: Int,
        val askingPpm: Long,
        /** 0 when the final price was not entered. */
        val soldPpm: Long,
        /** (final - asking) / asking × 100; negative = sold below asking. Null without both prices. */
        val gapPercent: Int?,
        val daysOnMarket: Int?
    )

    data class SoldSummary(
        val rows: List<SoldRow>,
        val avgGapPercent: Int?,
        val gapSampleCount: Int,
        val avgDaysOnMarket: Int?
    )

    fun computeSold(all: List<Property>, now: Long = System.currentTimeMillis(), lookbackDays: Int = 90): SoldSummary {
        val rows = all.asSequence()
            .filter { !it.isArchived && isSold(it) && it.area > 0 }
            .filter { it.totalPrice > 0L || it.soldPrice > 0L }
            .filter { now - soldAtOf(it) <= lookbackDays * DAY_MS }
            .map { p ->
                val at = soldAtOf(p)
                val asking = if (p.totalPrice > 0L) (p.totalPrice.toDouble() / p.area).roundToLong() else 0L
                val soldPpm = if (p.soldPrice > 0L) (p.soldPrice.toDouble() / p.area).roundToLong() else 0L
                val gap = if (p.soldPrice > 0L && p.totalPrice > 0L)
                    ((p.soldPrice - p.totalPrice).toDouble() / p.totalPrice * 100.0).roundToInt() else null
                val dom = if (p.createdAt > 0L && at >= p.createdAt) ((at - p.createdAt) / DAY_MS).toInt() else null
                SoldRow(p, at, soldDaysAgo(p, now), isEligible(p, now), soldDaysLeftInStats(p, now), asking, soldPpm, gap, dom)
            }
            .sortedByDescending { it.soldAt }
            .toList()
        val gaps = rows.mapNotNull { it.gapPercent }
        val doms = rows.mapNotNull { it.daysOnMarket }
        return SoldSummary(
            rows = rows,
            avgGapPercent = if (gaps.isEmpty()) null else gaps.average().roundToInt(),
            gapSampleCount = gaps.size,
            avgDaysOnMarket = if (doms.isEmpty()) null else doms.average().roundToInt()
        )
    }

}
