package ir.daramash.app.presentation.theme

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Single source of truth for the app's calm, Apple-style glass language:
 * soft neutral surfaces, hairline borders, continuous corners, spring motion.
 *
 * Shared components read from here so the whole look can be retuned in one place.
 */
object DaramashDesign {

    // --- Rhythm ---------------------------------------------------------------------------
    val Gutter = 20.dp
    val ItemGap = 16.dp
    val SectionGap = 24.dp

    // --- Corner radii (all continuous except pills) ---------------------------------------
    object Radius {
        val Control = 8.dp
        val Card = 14.dp
        val CardLarge = 18.dp
        val Dialog = 30.dp
    }

    // --- Type scale -----------------------------------------------------------------------
    object Type {
        val TitleLarge = 34.sp
        val TitleLargeLine = 41.sp
        val SectionHeader = 22.sp
        val SectionHeaderLine = 28.sp
        val ItemTitle = 15.sp
        val ItemSubtitle = 13.sp
        val Caption = 12.sp
        val NavLabel = 10.sp
    }

    // --- Glass material -------------------------------------------------------------------
    object Glass {
        /** White "lift" of a glass surface over its backdrop (dark mode). */
        const val BaseOpacity = 0.15f
        const val HairlineAlpha = 0.12f
        val Hairline = Color.White.copy(alpha = HairlineAlpha)
        val DialogBorder = Color.White.copy(alpha = 0.15f)
        val Blur = 14.dp
        val ShadowColor = Color(0x59000000)

        /** Dark capsule that sits behind the selected tab. */
        val Puck = Color(0xFF2E2E2E).copy(alpha = 0.72f)
        const val ControlFillAlpha = 0.08f
        const val SelectedPillAlpha = 0.92f
    }

    // --- Chrome sizes ---------------------------------------------------------------------
    object Chrome {
        val NavRowHeight = 68.dp
        val TopBarHeight = 52.dp
        val SearchBarHeight = 48.dp
        val GlassButton = 44.dp
    }

    // --- Semantic chrome colors -----------------------------------------------------------
    val SelectedRed = Color(0xFFFF453A)
    val InactiveGrey = Color(0xFF8E8E93)

    // --- Motion ---------------------------------------------------------------------------
    // Springs modelled on SwiftUI's .smooth (0.5s period, no bounce), .snappy and a gentle bounce.
    // Compose takes stiffness where SwiftUI takes a period: stiffness = (2*pi / period)^2.
    object Motion {
        const val Stiffness = 158f

        /** Default for almost everything: no overshoot. */
        fun <T> smooth(): FiniteAnimationSpec<T> =
            spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Stiffness)

        /** Selection, toggles, emphasis: a hint of bounce. */
        fun <T> snappy(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.85f, stiffness = Stiffness)

        /** Entrances (dialogs, sheets). */
        fun <T> expressive(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.76f, stiffness = Stiffness)

        /** The sliding selection capsule in the tab bar: quicker than [snappy] so it keeps up with the tap. */
        fun <T> puck(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.78f, stiffness = 420f)

        /** Cross-fades, where a spring has nothing to overshoot. */
        fun <T> fade(): FiniteAnimationSpec<T> = tween(durationMillis = 200)
    }
}
