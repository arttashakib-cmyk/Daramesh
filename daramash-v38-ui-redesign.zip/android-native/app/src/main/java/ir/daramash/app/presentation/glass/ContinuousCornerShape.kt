package ir.daramash.app.presentation.glass

import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection

/**
 * Rounded rectangle with "continuous" (squircle-style) corners.
 *
 * A circular arc meets the straight edge with a sudden change of curvature, which the eye reads
 * as a slightly hard corner. A continuous corner eases into the curve over a longer stretch of the
 * edge (about 1.53x the radius), the way iOS shapes do. Each corner is three cubic Bezier segments
 * built from the published iOS-style corner coefficients below; the radius is the nominal radius
 * of the equivalent circular corner.
 *
 * Pill shapes (radius = half the height) should keep using a plain capsule; a continuous corner
 * would clamp to a smaller radius there.
 */
@Immutable
class ContinuousCornerShape(
    private val topStart: Dp,
    private val topEnd: Dp,
    private val bottomEnd: Dp,
    private val bottomStart: Dp
) : Shape {

    constructor(radius: Dp) : this(radius, radius, radius, radius)

    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = resolve(size, layoutDirection, density)
        return Outline.Generic(buildPath(size.width, size.height, r[0], r[1], r[2], r[3]))
    }

    /** Largest effective corner radius in px for this size; used to size the glass lens shader. */
    fun effectiveCornerPx(size: Size, layoutDirection: LayoutDirection, density: Density): Float {
        val r = resolve(size, layoutDirection, density)
        return maxOf(maxOf(r[0], r[1]), maxOf(r[2], r[3]))
    }

    /** Radii in px as [topLeft, topRight, bottomRight, bottomLeft], clamped so neighbouring curves never overlap. */
    private fun resolve(size: Size, layoutDirection: LayoutDirection, density: Density): FloatArray {
        val ltr = layoutDirection == LayoutDirection.Ltr
        val tl = with(density) { (if (ltr) topStart else topEnd).toPx() }
        val tr = with(density) { (if (ltr) topEnd else topStart).toPx() }
        val br = with(density) { (if (ltr) bottomEnd else bottomStart).toPx() }
        val bl = with(density) { (if (ltr) bottomStart else bottomEnd).toPx() }
        val limit = minOf(size.width, size.height) / (2f * REACH)
        return floatArrayOf(
            tl.coerceIn(0f, limit),
            tr.coerceIn(0f, limit),
            br.coerceIn(0f, limit),
            bl.coerceIn(0f, limit)
        )
    }

    private fun buildPath(w: Float, h: Float, tl: Float, tr: Float, br: Float, bl: Float): Path {
        val p = Path()
        p.moveTo(REACH * tl, 0f)

        // top edge -> top-right corner
        p.lineTo(w - REACH * tr, 0f)
        p.cubicTo(w - C1 * tr, 0f, w - C2 * tr, 0f, w - C3 * tr, C4 * tr)
        p.cubicTo(w - C5 * tr, C6 * tr, w - C6 * tr, C5 * tr, w - C4 * tr, C3 * tr)
        p.cubicTo(w, C2 * tr, w, C1 * tr, w, REACH * tr)

        // right edge -> bottom-right corner
        p.lineTo(w, h - REACH * br)
        p.cubicTo(w, h - C1 * br, w, h - C2 * br, w - C4 * br, h - C3 * br)
        p.cubicTo(w - C6 * br, h - C5 * br, w - C5 * br, h - C6 * br, w - C3 * br, h - C4 * br)
        p.cubicTo(w - C2 * br, h, w - C1 * br, h, w - REACH * br, h)

        // bottom edge -> bottom-left corner
        p.lineTo(REACH * bl, h)
        p.cubicTo(C1 * bl, h, C2 * bl, h, C3 * bl, h - C4 * bl)
        p.cubicTo(C5 * bl, h - C6 * bl, C6 * bl, h - C5 * bl, C4 * bl, h - C3 * bl)
        p.cubicTo(0f, h - C2 * bl, 0f, h - C1 * bl, 0f, h - REACH * bl)

        // left edge -> top-left corner
        p.lineTo(0f, REACH * tl)
        p.cubicTo(0f, C1 * tl, 0f, C2 * tl, C4 * tl, C3 * tl)
        p.cubicTo(C6 * tl, C5 * tl, C5 * tl, C6 * tl, C3 * tl, C4 * tl)
        p.cubicTo(C2 * tl, 0f, C1 * tl, 0f, REACH * tl, 0f)

        p.close()
        return p
    }

    private companion object {
        /** How far along each edge a corner reaches, in multiples of the nominal radius. */
        const val REACH = 1.52866483f
        const val C1 = 1.08849296f
        const val C2 = 0.86840694f
        const val C3 = 0.63149379f
        const val C4 = 0.07491139f
        const val C5 = 0.37282383f
        const val C6 = 0.16905899f
    }
}
