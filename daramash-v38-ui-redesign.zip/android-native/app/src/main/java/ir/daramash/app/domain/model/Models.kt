package ir.daramash.app.domain.model

enum class ThemeMode {
    LIQUID_OLED,
    DARK,
    LIGHT
}

enum class NavigationTab(val route: String, val titleFa: String, val shortLabelFa: String) {
    HOME("home", "خانه", "خانه"),
    PROPERTIES("properties", "فایل‌های املاک", "املاک"),
    CUSTOMERS("customers", "مشتری‌ها", "مشتری"),
    INVESTORS("investors", "سرمایه‌گذاران", "سرمایه‌گذاران"),
    MATCHING("matching", "پیوند سازی هوشمند", "پیوند"),
    TARGET("target", "تارگت مشاور", "تارگت"),
    MANAGER("manager", "پنل مدیریت املاک", "پنل مدیریت"),
    ARCHIVE("archive", "آرشیو", "آرشیو"),
    SYSTEM("system", "سیستم", "سیستم"),
    MARKET_RADAR("market_radar", "رادار بازار", "رادار")
}

data class Property(
    val id: String,
    val code: String = "",
    val area: Int = 0,
    val bedrooms: Int = 0,
    val floors: Int = 0,
    val unitsPerFloor: Int = 0,
    val unitFloor: Int = 0,
    val buildingAge: Int = 0,
    val facade: String = "",
    val condition: String = "",
    val lighting: String = "",
    val parking: Boolean = false,
    val storage: Boolean = false,
    val elevator: Boolean = false,
    val terrace: Boolean = false,
    val totalPrice: Long = 0L,
    val pricePerMeter: Long = 0L,
    val occupancy: String = "تخلیه",
    val contractDuration: String = "",
    val deposit: Long = 0L,
    val rent: Long = 0L,
    val neighborhood: String = "",
    val address: String = "",
    val visit: String = "با هماهنگی",
    val sellerName: String = "",
    val sellerPhone: String = "",
    val sellReason: String = "",
    val exchange: String = "نمی‌کند",
    val regDate: String = "",
    val lastContact: String = "",
    val status: String = "فروشنده",
    val investable: Boolean = false,
    val advisorId: String = "",
    val advisorName: String = "",
    val note: String = "",
    val demo: Boolean = false,
    val isArchived: Boolean = false,
    val archivedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    /** Moment the file was marked sold (0 = unknown / not sold). Used by Market Radar's 15-day window. */
    val soldAt: Long = 0L,
    /** Optional final closing price in Toman (0 = not entered). */
    val soldPrice: Long = 0L
)

/** One weekly Market Radar reading (neighborhood = "" means whole market). */
data class RadarSnapshot(
    val weekKey: Int,
    val neighborhood: String,
    val takenAt: Long,
    val averagePpm: Long,
    val medianPpm: Long,
    val sampleCount: Int
)

data class Customer(
    val id: String,
    val firstName: String = "",
    val lastName: String = "",
    val phone1: String = "",
    val phone2: String = "",
    val neighborhoods: List<String> = emptyList(),
    val areaMin: Int = 0,
    val bedroomsMin: Int = 0,
    val buildingAgeMax: Int = 0,
    val budgetMax: Long = 0L,
    val reqParking: Boolean = false,
    val reqStorage: Boolean = false,
    val reqElevator: Boolean = false,
    val reqTerrace: Boolean = false,
    val noElevatorMaxFloor: Int = 0,
    val visitedUnits: Int = 0,
    val quality: String = "داغ",
    val payment: String = "نقد",
    val purpose: String = "سکونت",
    val status: String = "در جست و جو",
    val regDate: String = "",
    val lastContact: String = "",
    val advisorId: String = "",
    val advisorName: String = "",
    val note: String = "",
    val demo: Boolean = false,
    val isArchived: Boolean = false,
    val archivedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val fullName: String
        get() = listOf(firstName.trim(), lastName.trim()).filter { it.isNotEmpty() }.joinToString(" ").ifEmpty { "بدون نام" }
}

data class Investor(
    val id: String,
    val firstName: String = "",
    val lastName: String = "",
    val phone1: String = "",
    val neighborhoods: List<String> = emptyList(),
    val existingUnits: String = "",
    val hasBuy: String = "بله",
    val buyAmount: Long = 0L,
    val telegramChannel: String = "",
    val businessType: String = "سازنده / سرمایه‌گذار",
    val lastContact: String = "",
    val note: String = "",
    val demo: Boolean = false,
    val isArchived: Boolean = false,
    val archivedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val fullName: String
        get() = listOf(firstName.trim(), lastName.trim()).filter { it.isNotEmpty() }.joinToString(" ").ifEmpty { "سرمایه‌گذار" }
}

data class MatchLink(
    val id: String,
    val propertyId: String,
    val needId: String,
    val needKind: String, // "customer" or "investor"
    val demo: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class ActivityLog(
    val id: String,
    val entityType: String, // "property", "customer", "investor"
    val entityId: String,
    val type: String, // "تماس", "واتساپ", "بازدید", "مذاکره", "تغییر قیمت", "یادداشت", "معامله"
    val note: String,
    val date: String,
    val demo: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class Advisor(
    val id: String,
    val name: String,
    val phone: String = "",
    val specialtyNeighborhood: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class ManagerGroup(
    val name: String = "",
    val rank: Int? = null,
    val targetType: String = "", // "contracts", "deposit", "files"
    val targetValue: Long? = null
)

data class ManagerAdvisor(
    val id: String,
    val name: String,
    val phone: String = "",
    val area: String = "",
    val meterMin: Int? = null,
    val meterMax: Int? = null,
    val targetType: String = "",
    val targetValue: Long? = null,
    val filesMonth: Int? = null,
    val discipline: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class DepositRecord(
    val id: String,
    val amount: Long,
    val title: String,
    val date: String
)

/** Progress of one Jalali month: contract ticks (contracts target) and deposits (deposit target). */
data class MonthProgress(
    val ticks: List<Boolean> = emptyList(),
    val deposits: List<DepositRecord> = emptyList()
)

data class AdvisorTarget(
    val motivation: String = "هر تماس، یک قدم به معامله‌ی بعدی نزدیک‌تره.",
    val targetFileCode: String = "",
    val status: String = "در حال تلاش",
    val rank: Int = 0,                 // 0 = not set
    val targetType: String = "deposit", // "deposit" or "contracts"
    val targetDeposit: Long = 0L,      // 0 = not set
    val targetContracts: Int = 0,      // 0 = not set
    val progress: Map<String, MonthProgress> = emptyMap(), // key: "1405-08"
    val groupName: String = "",
    val groupRank: Int = 0,
    val groupTargetType: String = "files", // "files", "contracts", "deposit"
    val groupTargetValue: Long = 0L
)

data class MatchCriterion(
    val label: String,
    val passed: Boolean,
    val partial: Boolean = false
)

data class MatchResult(
    val ok: Boolean,
    val score: Int,
    val criteria: List<MatchCriterion>,
    val isLinked: Boolean = false,
    val rejected: Boolean = false
)

data class PropertyFilterState(
    val query: String = "",
    val statusFilter: String = "all", // "all", "active", "sold", "inactive", "investable"
    val sortMode: String = "newest", // "newest", "followup", "expensive", "cheapest", "largest"
    val minArea: Int? = null,
    val maxArea: Int? = null,
    val minPrice: Long? = null,
    val maxPrice: Long? = null,
    val minBedrooms: Int? = null,
    val requireParking: Boolean = false,
    val requireElevator: Boolean = false,
    val requireStorage: Boolean = false,
    val requireTerrace: Boolean = false,
    val advisorId: String = "all",
    val neighborhoods: Set<String> = emptySet(),
    val code: String = "",
    val minAge: Int? = null,
    val maxAge: Int? = null,
    val minFloor: Int? = null,
    val maxFloor: Int? = null,
    val minUnitsPerFloor: Int? = null,
    val maxUnitsPerFloor: Int? = null,
    val bedChoices: Set<Int> = emptySet(),
    val dateFrom: String = "",
    val dateTo: String = ""
)

data class UserDevice(
    val id: String,
    val label: String,
    val lastSeen: String,
    val isCurrent: Boolean = false
)

data class CloudHistorySnapshot(
    val id: Long,
    val versionAt: Long,
    val rawBytes: Long
)

data class UserSession(
    val isLoggedIn: Boolean = false,
    val userId: String = "",
    val email: String = "",
    val accessToken: String = "",
    val refreshToken: String = "",
    val isAdmin: Boolean = false,
    val planName: String = "اشتراک دارمش",
    val maxDevices: Int = 2,
    val usedDevices: Int = 1,
    val subscriptionExpiresAt: Long = 0L,
    val subStatus: String = "login", // "active", "pending", "expired", "blocked", "device_limit", "update", "offline", "login", "error"
    val statusErrorMsg: String = "",
    val daysLeft: Int = 0,
    val payText: String = "",
    val contact: String = "",
    val devices: List<UserDevice> = emptyList(),
    val verifiedAt: Long = 0L,
    val lastSeenAt: Long = 0L,
    val syncRev: Int = 0,
    val lastSyncAt: Long = 0L,
    val rawBytes: Long = 0L,
    val quotaBytes: Long = 10L * 1048576L,
    val isCloudFull: Boolean = false,
    val isCloudDirty: Boolean = false,
    val syncStatusText: String = "آماده همگام‌سازی",
    val latestBuild: Int = 0,
    val updateUrl: String = "",
    val updateNote: String = "",
    val trialDays: Int = 0
)
