package ir.daramash.app.presentation.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.res.ResourcesCompat
import ir.daramash.app.R
import ir.daramash.app.domain.usecase.PersianFormatters
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.roundToInt

/** One line in the "breakdown" card of the shared picture. */
data class RadarShareRow(val label: String, val averagePpm: Long, val count: Int)

/** Everything the shared Market Radar picture shows. Contains no seller names, phones or file codes. */
data class RadarShareData(
    val title: String,
    val dateLabel: String,
    val breakdownTitle: String,
    val averagePpm: Long,
    val medianPpm: Long,
    val minPpm: Long,
    val maxPpm: Long,
    val count: Int,
    val trendChangePercent: Double?,
    val trendSpanWeeks: Int,
    val rows: List<RadarShareRow>
)

/**
 * Renders a 1080×1350 PNG (Instagram/Telegram/WhatsApp friendly) in the app's black + emerald look.
 * Pure android.graphics — no network, no extra dependencies.
 */
object RadarShareImage {

    private const val W = 1080
    private const val H = 1350
    private const val M = 64f

    private val EMERALD = Color.parseColor("#34D399")
    private val TEXT = Color.parseColor("#ECECEC")
    private val MUTED = Color.parseColor("#9B9B9B")
    private val RED = Color.parseColor("#F87171")
    private val CARD = Color.parseColor("#111111")
    private val BORDER = Color.parseColor("#33FFFFFF")

    fun render(context: Context, d: RadarShareData): File {
        val regular = ResourcesCompat.getFont(context, R.font.vazirmatn_regular) ?: Typeface.DEFAULT
        val bold = ResourcesCompat.getFont(context, R.font.vazirmatn_bold) ?: Typeface.DEFAULT_BOLD

        fun paint(size: Float, color: Int, face: Typeface, align: Paint.Align = Paint.Align.RIGHT) =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                this.color = color
                typeface = face
                textAlign = align
            }

        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        // Background: black with a faint emerald glow at the top
        c.drawColor(Color.BLACK)
        val glow = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, 520f, Color.parseColor("#1410A37F"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, W.toFloat(), 520f, glow)

        fun fit(text: String, p: TextPaint, maxWidth: Float): String =
            TextUtils.ellipsize(text, p, maxWidth, TextUtils.TruncateAt.END).toString()

        val right = W - M
        val left = M

        // Header
        c.drawText("دارمش", right, 112f, paint(40f, EMERALD, bold))
        val titleP = paint(60f, TEXT, bold)
        c.drawText(fit(d.title, titleP, W - 2 * M), right, 206f, titleP)
        c.drawText(d.dateLabel, right, 262f, paint(32f, MUTED, regular))

        // Main stats card
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CARD }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = BORDER; style = Paint.Style.STROKE; strokeWidth = 2f }
        fun card(top: Float, bottom: Float) {
            val r = RectF(M, top, W - M, bottom)
            c.drawRoundRect(r, 44f, 44f, cardPaint)
            c.drawRoundRect(r, 44f, 44f, borderPaint)
        }
        card(310f, 760f)
        c.drawText("میانگین قیمت هر مترمربع", right - 40f, 380f, paint(34f, MUTED, regular))
        c.drawText(PersianFormatters.formatMoneyToman(d.averagePpm), right - 40f, 480f, paint(86f, EMERALD, bold))
        c.drawText("تومان", right - 40f, 535f, paint(32f, MUTED, regular))

        // Four stat columns (RTL: first column on the right)
        val colW = (W - 2 * M - 80f) / 4f
        val stats = listOf(
            "تعداد فایل" to PersianFormatters.toFa(d.count),
            "میانه" to PersianFormatters.formatMoneyToman(d.medianPpm),
            "کمینه" to PersianFormatters.formatMoneyToman(d.minPpm),
            "بیشینه" to PersianFormatters.formatMoneyToman(d.maxPpm)
        )
        stats.forEachIndexed { i, (label, value) ->
            val x = right - 40f - colW * i
            c.drawText(label, x, 610f, paint(27f, MUTED, regular))
            val vp = paint(34f, TEXT, bold)
            c.drawText(fit(value, vp, colW - 10f), x, 660f, vp)
        }

        // Trend line (words instead of +/- signs to avoid bidi glitches)
        val change = d.trendChangePercent
        if (change != null && d.trendSpanWeeks > 0) {
            val pct = PersianFormatters.toFa(abs(change).roundToInt())
            val weeks = PersianFormatters.toFa(d.trendSpanWeeks)
            val (text, color) = when {
                change.roundToInt() > 0 -> "$pct٪ افزایش در $weeks هفته اخیر" to EMERALD
                change.roundToInt() < 0 -> "$pct٪ کاهش در $weeks هفته اخیر" to RED
                else -> "بدون تغییر محسوس در $weeks هفته اخیر" to MUTED
            }
            c.drawText(text, right - 40f, 728f, paint(32f, color, bold))
        }

        // Breakdown card
        val rows = d.rows.take(6)
        if (rows.isNotEmpty()) {
            val rowH = 96f
            val top = 800f
            val bottom = top + 100f + rows.size * rowH
            card(top, bottom)
            c.drawText(d.breakdownTitle, right - 40f, top + 70f, paint(36f, TEXT, bold))
            rows.forEachIndexed { i, row ->
                val y = top + 100f + i * rowH
                val divider = Paint().apply { color = Color.parseColor("#1FFFFFFF"); strokeWidth = 2f }
                c.drawLine(M + 40f, y, W - M - 40f, y, divider)
                val lp = paint(32f, TEXT, regular)
                c.drawText(fit(row.label, lp, 520f), right - 40f, y + 46f, lp)
                c.drawText("${PersianFormatters.toFa(row.count)} فایل", right - 40f, y + 82f, paint(24f, MUTED, regular))
                c.drawText(
                    PersianFormatters.formatMoneyToman(row.averagePpm),
                    left + 40f, y + 56f, paint(34f, EMERALD, bold, Paint.Align.LEFT)
                )
            }
        }

        // Footer
        val fp = paint(25f, MUTED, regular, Paint.Align.CENTER)
        c.drawText("آمار از فایل‌های واقعی ثبت‌شده در دفتر — تحلیل قیمت، نه پیش‌بینی", W / 2f, H - 56f, fp)

        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        // keep the cache tidy: drop older radar pictures
        dir.listFiles { f -> f.name.startsWith("radar-") && f.name.endsWith(".png") }
            ?.sortedByDescending { it.lastModified() }?.drop(3)?.forEach { it.delete() }
        val out = File(dir, "radar-${System.currentTimeMillis()}.png")
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return out
    }
}
