package ir.daramash.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import ir.daramash.app.data.local.db.DaramashDatabase
import ir.daramash.app.data.local.prefs.SecureAuthPreferences
import ir.daramash.app.data.remote.CloudNetworkService
import ir.daramash.app.data.repository.DaramashRepository
import ir.daramash.app.domain.model.NavigationTab
import ir.daramash.app.domain.model.UserSession
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.presentation.screens.DaramashComposeApp
import ir.daramash.app.presentation.screens.DaramashDangerButton
import ir.daramash.app.presentation.screens.DaramashGhostButton
import ir.daramash.app.presentation.screens.DaramashPrimaryButton
import ir.daramash.app.presentation.theme.DaramashBg
import ir.daramash.app.presentation.theme.DaramashBorder
import ir.daramash.app.presentation.theme.DaramashMuted
import ir.daramash.app.presentation.theme.DaramashTheme
import ir.daramash.app.presentation.theme.EmeraldAccent
import ir.daramash.app.presentation.theme.RedDanger
import ir.daramash.app.presentation.theme.VazirmatnFontFamily
import ir.daramash.app.presentation.viewmodel.DaramashViewModel
import ir.daramash.app.security.BiometricSecurityManager
import ir.daramash.app.security.GoogleChromeAuthLauncher

class MainActivity : FragmentActivity() {

    private lateinit var viewModel: DaramashViewModel
    private var backgroundTimestamp: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = DaramashDatabase.getInstance(applicationContext)
        val prefs = SecureAuthPreferences(applicationContext)
        val network = CloudNetworkService()
        val repository = DaramashRepository(
            context = applicationContext,
            dao = database.dao(),
            prefs = prefs,
            network = network
        )
        viewModel = ViewModelProvider(
            this,
            DaramashViewModel.Factory(repository)
        )[DaramashViewModel::class.java]

        handleIncomingIntent(intent)

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isLocked by viewModel.isBiometricLocked.collectAsState()

            val userSession by viewModel.userSession.collectAsState()

            DaramashTheme(themeMode = themeMode) {
                if (!userSession.isLoggedIn || userSession.accessToken.isBlank()) {
                    MandatoryGoogleAuthScreen(
                        onLaunchGoogleAuth = {
                            GoogleChromeAuthLauncher.launch(this@MainActivity)
                        }
                    )
                } else if (userSession.subStatus != "active" && userSession.subStatus != "ok") {
                    SubscriptionGateScreen(
                        session = userSession,
                        onRecheck = { viewModel.refreshAccountStatus() },
                        onLogout = { viewModel.logoutAccount() },
                        onRemoveDevice = { viewModel.removeDevice(it) }
                    )
                } else if (isLocked) {
                    BiometricLockScreen(
                        onUnlock = {
                            triggerBiometricUnlock()
                        }
                    )
                } else {
                    DaramashComposeApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (backgroundTimestamp > 0L) {
            val elapsed = System.currentTimeMillis() - backgroundTimestamp
            if (elapsed > 10_000L && viewModel.biometricEnabled.value) {
                viewModel.lockBiometric()
            }
            backgroundTimestamp = 0L
        }
    }

    override fun onStop() {
        super.onStop()
        backgroundTimestamp = System.currentTimeMillis()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun triggerBiometricUnlock() {
        BiometricSecurityManager.authenticate(
            activity = this,
            title = "ورود به دارمش",
            subtitle = "برای دسترسی به اطلاعات مالی و مشتریان، هویت خود را تأیید کنید",
            onSuccess = {
                viewModel.unlockBiometric()
                viewModel.emitSnackbar("قفل برنامه با موفقیت باز شد")
            },
            onError = { err ->
                viewModel.emitSnackbar(err)
            }
        )
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                val data: Uri? = intent.data
                if (data != null) {
                    val uriStr = data.toString()
                    if (data.scheme == "ir.daramash.app" && data.host == "auth") {
                        // Supabase Google OAuth Redirect
                        viewModel.handleOAuthRedirect(uriStr)
                        return
                    }
                    val tabParam = data.getQueryParameter("tab")
                    when (tabParam) {
                        "properties" -> viewModel.navigateTo(NavigationTab.PROPERTIES)
                        "matching" -> viewModel.navigateTo(NavigationTab.MATCHING)
                        "target" -> viewModel.navigateTo(NavigationTab.TARGET)
                        "customers" -> viewModel.navigateTo(NavigationTab.CUSTOMERS)
                    }
                }
            }
            Intent.ACTION_SEND -> {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (!sharedText.isNullOrBlank() && sharedText.trim().startsWith("{")) {
                    viewModel.restoreBackupJson(sharedText)
                }
            }
        }
    }
}

@Composable
fun BiometricLockScreen(onUnlock: () -> Unit) {
    LaunchedEffect(Unit) {
        onUnlock()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DaramashBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(Color(0x1F10A37F))
                    .border(1.5.dp, EmeraldAccent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🔒", fontSize = 40.sp)
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = "دارمش قفل است",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                fontFamily = VazirmatnFontFamily
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = "جهت محافظت از فایل‌های محرمانه املاک و مشخصات مشتریان، لطفاً اثرانگشت یا پین خود را تایید کنید.",
                fontSize = 13.5.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            Spacer(Modifier.height(32.dp))

            DaramashPrimaryButton(
                text = "🔓 باز کردن قفل با اثرانگشت",
                onClick = onUnlock
            )
        }
    }
}

@Composable
fun MandatoryGoogleAuthScreen(onLaunchGoogleAuth: () -> Unit) {
    val context = LocalContext.current
    var showChromeRequiredDialog by remember { mutableStateOf(false) }

    if (showChromeRequiredDialog) {
        AlertDialog(
            onDismissRequest = { showChromeRequiredDialog = false },
            title = {
                Text(
                    text = "نصب مرورگر Google Chrome الزامی است",
                    fontFamily = VazirmatnFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = "جهت تضمین امنیت و تأیید هویت رسمی جی‌میل، احراز هویت منحصراً از طریق مرورگر Google Chrome انجام می‌شود. لطفاً برای ورود، ابتدا گوگل کروم را نصب یا فعال کنید.",
                    fontFamily = VazirmatnFontFamily,
                    fontSize = 13.5.sp,
                    color = Color(0xFFD1D5DB),
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showChromeRequiredDialog = false
                        GoogleChromeAuthLauncher.openChromeInPlayStore(context)
                    }
                ) {
                    Text(
                        text = "نصب Google Chrome از گوگل‌پلی",
                        fontFamily = VazirmatnFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldAccent
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showChromeRequiredDialog = false }) {
                    Text(
                        text = "انصراف",
                        fontFamily = VazirmatnFontFamily,
                        color = Color(0xFF9CA3AF)
                    )
                }
            },
            containerColor = Color(0xFF18181B),
            shape = RoundedCornerShape(24.dp)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF0A0A0A))
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(22.dp))
                .padding(horizontal = 22.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.daramash_house_circle),
                contentDescription = "دارمش",
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = "ورود به دارمش",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                fontFamily = VazirmatnFontFamily,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "برای شروع، با حساب گوگلت وارد شو.",
                fontSize = 14.sp,
                color = Color(0xFFC9C9CD),
                fontFamily = VazirmatnFontFamily,
                lineHeight = 25.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .clickable {
                        if (!GoogleChromeAuthLauncher.isChromeInstalled(context)) {
                            showChromeRequiredDialog = true
                        } else {
                            onLaunchGoogleAuth()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ورود با گوگل",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    fontFamily = VazirmatnFontFamily
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                text = "اولین ورود به اینترنت نیاز داره. اگه گوگل باز نشد، VPN رو روشن کن.",
                fontSize = 12.sp,
                color = Color(0xFF8A8A8E),
                fontFamily = VazirmatnFontFamily,
                lineHeight = 22.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun SubscriptionGateScreen(
    session: UserSession,
    onRecheck: () -> Unit,
    onLogout: () -> Unit,
    onRemoveDevice: (String) -> Unit
) {
    val context = LocalContext.current
    val contactUrl = remember(session.contact, session.email) {
        val c = session.contact.trim()
        val msg = Uri.encode("سلام، درخواست فعال‌سازی/تمدید اشتراک دارمش برای حساب ${session.email}")
        when {
            c.isBlank() -> ""
            c.startsWith("@") -> "https://t.me/${c.substring(1)}?text=$msg"
            c.startsWith("http") -> c
            else -> {
                val clean = c.replace(Regex("\\D"), "")
                val intl = if (clean.startsWith("0")) "98${clean.substring(1)}" else clean
                "https://wa.me/$intl?text=$msg"
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 440.dp)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.daramash_house_circle),
                contentDescription = "دارمش",
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
            )

            when (session.subStatus) {
                "pending" -> {
                    Text(text = "حسابت ساخته شد", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    Text(
                        text = "حساب ${session.email} هنوز فعال نشده است. پس از پرداخت و تأیید مدیر، اشتراکتان فعال می‌شود.",
                        fontSize = 13.5.sp, color = Color(0xFF94A3B8), fontFamily = VazirmatnFontFamily, textAlign = TextAlign.Center, lineHeight = 22.sp
                    )
                }
                "expired" -> {
                    Text(text = "اشتراکت تموم شده", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    val dateText = if (session.subscriptionExpiresAt > 0) " در تاریخ ${PersianFormatters.formatIsoToJalaliReadable(session.subscriptionExpiresAt.toString())}" else ""
                    Text(
                        text = "اشتراک این حساب$dateText پایان یافته است. برای تمدید، مبلغ اشتراک را واریز کرده و به مدیر اطلاع دهید.",
                        fontSize = 13.5.sp, color = Color(0xFF94A3B8), fontFamily = VazirmatnFontFamily, textAlign = TextAlign.Center, lineHeight = 22.sp
                    )
                }
                "blocked" -> {
                    Text(text = "دسترسی بسته شده", fontSize = 22.sp, fontWeight = FontWeight.Black, color = RedDanger, fontFamily = VazirmatnFontFamily)
                    Text(
                        text = "دسترسی این حساب کاربری توسط مدیر مسدود شده است. جهت اطلاع بیشتر با پشتیبانی تماس بگیرید.",
                        fontSize = 13.5.sp, color = Color(0xFF94A3B8), fontFamily = VazirmatnFontFamily, textAlign = TextAlign.Center, lineHeight = 22.sp
                    )
                }
                "device_limit" -> {
                    Text(text = "تعداد دستگاه‌ها پر شده", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    Text(
                        text = "هر حساب منحصراً روی ${PersianFormatters.toFa(session.maxDevices)} دستگاه فعال می‌شود. یکی از دستگاه‌های قبلی را حذف کنید:",
                        fontSize = 13.5.sp, color = Color(0xFF94A3B8), fontFamily = VazirmatnFontFamily, textAlign = TextAlign.Center, lineHeight = 22.sp
                    )
                    session.devices.forEach { dev ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF18181B))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(dev.label, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold, fontFamily = VazirmatnFontFamily)
                                Text("آخرین استفاده: ${PersianFormatters.formatIsoToJalaliReadable(dev.lastSeen)}", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                            }
                            DaramashDangerButton(text = "حذف", small = true, onClick = { onRemoveDevice(dev.id) })
                        }
                    }
                }
                "update" -> {
                    Text(text = "نسخه‌ی اپ قدیمیه", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    Text(
                        text = "برای ادامه استفاده، باید جدیدترین نسخه دارمش را نصب کنید.${if (session.updateNote.isNotBlank()) "\n\nتوضیحات: ${session.updateNote}" else ""}",
                        fontSize = 13.5.sp, color = Color(0xFF94A3B8), fontFamily = VazirmatnFontFamily, textAlign = TextAlign.Center, lineHeight = 22.sp
                    )
                    if (session.updateUrl.isNotBlank()) {
                        DaramashPrimaryButton(
                            text = "📥 دانلود نسخه‌ی جدید",
                            onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(session.updateUrl))) }
                        )
                    }
                }
                else -> { // offline / error
                    Text(text = "اتصال برقرار نشد", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    Text(
                        text = session.statusErrorMsg.ifBlank { "برای تأیید اشتراک باید به اینترنت وصل شوید. در صورت نیاز فیلترشکن را روشن کنید." },
                        fontSize = 13.5.sp, color = Color(0xFF94A3B8), fontFamily = VazirmatnFontFamily, textAlign = TextAlign.Center, lineHeight = 22.sp
                    )
                }
            }

            if (session.payText.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF121824))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Text(text = session.payText, fontSize = 12.5.sp, color = Color(0xFFCBD5E1), fontFamily = VazirmatnFontFamily, lineHeight = 20.sp)
                }
            }

            DaramashPrimaryButton(text = "🔄 بررسی دوباره اشتراک", onClick = onRecheck)

            if (contactUrl.isNotBlank()) {
                DaramashGhostButton(
                    text = "💬 پیام به ادمین",
                    onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(contactUrl))) }
                )
            }

            DaramashDangerButton(text = "🚪 خروج / تغییر حساب", onClick = onLogout)
        }
    }
}

