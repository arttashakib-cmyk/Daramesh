# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-keep class ir.daramash.app.data.local.entity.** { *; }
-keep class ir.daramash.app.domain.model.** { *; }

# Kotlin / Coroutines
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# Compose
-dontwarn androidx.compose.**
-keep class androidx.compose.runtime.** { *; }

# Security / Tink
-dontwarn com.google.crypto.tink.**
-keep class com.google.crypto.tink.** { *; }

# Coil
-dontwarn coil.**
-keep class coil.** { *; }

# SplashScreen
-keep class androidx.core.splashscreen.** { *; }

# BuildConfig runtime fields
-keepclassmembers class ir.daramash.app.BuildConfig {
    public static final java.lang.String *;
}

# Biometric / FragmentActivity
-keep class androidx.biometric.** { *; }
-keep class androidx.fragment.app.** { *; }
