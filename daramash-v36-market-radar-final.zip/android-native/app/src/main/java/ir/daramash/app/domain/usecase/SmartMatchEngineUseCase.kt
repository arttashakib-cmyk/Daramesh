package ir.daramash.app.domain.usecase

import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchCriterion
import ir.daramash.app.domain.model.MatchResult
import ir.daramash.app.domain.model.Property
import kotlin.math.roundToInt

/**
 * Data that depends on the whole portfolio (computed once per input change):
 *  - median price per meter of each neighborhood (to spot cheap / expensive files)
 *  - neighborhood affinity learned from the customers: neighborhoods that the same people often
 *    pick together are treated as "close" to each other
 */
class MatchContext private constructor(
    private val medianPpm: Map<String, Long>,
    private val affinity: Map<String, Double>
) {
    fun medianPricePerMeter(neighborhood: String): Long = medianPpm[key(neighborhood)] ?: 0L

    fun affinity(a: String, b: String): Double = affinity[pair(key(a), key(b))] ?: 0.0

    companion object {
        val EMPTY = MatchContext(emptyMap(), emptyMap())

        private fun key(s: String): String = PersianFormatters.normalizeSearch(s)
        private fun pair(a: String, b: String): String = if (a < b) "$a|$b" else "$b|$a"

        fun pricePerMeter(p: Property): Long = when {
            p.pricePerMeter > 0L -> p.pricePerMeter
            p.area > 0 && p.totalPrice > 0L -> p.totalPrice / p.area
            else -> 0L
        }

        fun build(properties: List<Property>, customers: List<Customer>, investors: List<Investor>): MatchContext {
            val byNeighborhood = HashMap<String, MutableList<Long>>()
            properties.forEach { p ->
                val ppm = pricePerMeter(p)
                val k = key(p.neighborhood)
                if (ppm > 0L && k.isNotEmpty() && !p.isArchived) byNeighborhood.getOrPut(k) { ArrayList() }.add(ppm)
            }
            val medians = HashMap<String, Long>()
            byNeighborhood.forEach { (k, list) ->
                if (list.size >= 3) {
                    list.sort()
                    medians[k] = list[list.size / 2]
                }
            }

            val single = HashMap<String, Int>()
            val together = HashMap<String, Int>()
            val lists = ArrayList<List<String>>()
            customers.forEach { c -> if (!c.isArchived) lists.add(c.neighborhoods) }
            investors.forEach { i -> if (!i.isArchived) lists.add(i.neighborhoods) }
            lists.forEach { raw ->
                val ns = raw.map { key(it) }.filter { it.isNotEmpty() }.distinct()
                ns.forEach { single[it] = (single[it] ?: 0) + 1 }
                // very long lists mean "everywhere" and say nothing about closeness
                if (ns.size in 2..6) {
                    for (i in ns.indices) for (j in i + 1 until ns.size) {
                        val k = pair(ns[i], ns[j])
                        together[k] = (together[k] ?: 0) + 1
                    }
                }
            }
            val aff = HashMap<String, Double>()
            together.forEach { (k, n) ->
                if (n >= 2) {
                    val parts = k.split("|")
                    val denom = minOf(single[parts[0]] ?: 1, single[parts[1]] ?: 1).coerceAtLeast(1)
                    aff[k] = (n.toDouble() / denom).coerceAtMost(1.0)
                }
            }
            return MatchContext(medians, aff)
        }
    }
}

/**
 * "Purchase probability" engine. Starts at 100% and multiplies a factor for every mismatch,
 * based on how real buyers behave:
 *  - never: fewer bedrooms than wanted, no parking when it is required, an elevator-requiring buyer on a
 *    high floor, price more than 5% over budget, an investor with a file that is not tagged investable
 *  - sometimes: another neighborhood (more likely if it is close), 65 m when 70 m was wanted,
 *    a low floor without elevator, missing storage / terrace, a few years older, price up to 5% over budget
 */
class SmartMatchEngineUseCase {

    private class Prob {
        var p = 1.0
        var rejected = false
        val criteria = ArrayList<MatchCriterion>()

        fun ok(label: String) {
            criteria.add(MatchCriterion("✓ $label", true))
        }

        fun info(label: String) {
            criteria.add(MatchCriterion(label, true))
        }

        fun factor(f: Double, label: String) {
            p *= f
            val cut = ((1.0 - f) * 100.0).roundToInt()
            criteria.add(MatchCriterion("$label (−${PersianFormatters.toFa(cut)}٪)", passed = false, partial = f >= 0.5))
        }

        fun reject(label: String) {
            rejected = true
            criteria.add(MatchCriterion(label, false))
        }

        fun result(linked: Boolean): MatchResult {
            val score = if (rejected) 0 else (p * 100.0).roundToInt().coerceIn(0, 100)
            // worst news first, good news last
            val sorted = criteria.sortedBy { if (it.passed) 2 else if (it.partial) 1 else 0 }
            return MatchResult(
                ok = !rejected && score >= 50,
                score = score,
                criteria = sorted,
                isLinked = linked,
                rejected = rejected
            )
        }
    }

    private fun norm(s: String): String = PersianFormatters.normalizeSearch(s)

    private fun fa(n: Int): String = PersianFormatters.toFa(n)

    private fun isInactive(property: Property): Boolean =
        property.isArchived || PersianFormatters.isSoldStatus(property.status) || property.status == "غیرفعال"

    private fun rejectedResult(label: String, linked: Boolean): MatchResult =
        MatchResult(
            ok = false,
            score = 0,
            criteria = listOf(MatchCriterion(label, false)),
            isLinked = linked,
            rejected = true
        )

    private fun firstWord(n: String): String = n.substringBefore(" ")

    /** Neighborhood: exact match, else how close the file's neighborhood is to what the person wants. */
    private fun neighborhoodRule(pr: Prob, wantedRaw: List<String>, propertyNeighborhood: String, ctx: MatchContext) {
        val pairs = wantedRaw.map { it to norm(it) }.filter { it.second.isNotEmpty() }
        if (pairs.isEmpty()) return
        val wanted = pairs.map { it.second }
        val p = norm(propertyNeighborhood)
        if (p.isEmpty()) {
            pr.factor(0.9, "محله‌ی فایل ثبت نشده")
            return
        }
        if (wanted.any { it == p }) {
            pr.ok("محله $propertyNeighborhood مطابق")
            return
        }
        var best = when {
            wanted.size == 1 -> 0.50
            wanted.size <= 4 -> 0.45
            else -> 0.60
        }
        var closeTo = ""
        pairs.forEach { (raw, w) ->
            val sameArea = firstWord(w).length >= 3 && firstWord(w) == firstWord(p)
            val fam = if (sameArea) 0.85 else 0.0
            val aff = ctx.affinity(w, p)
            val byAff = if (aff > 0.0) (0.55 + 0.30 * aff).coerceAtMost(0.85) else 0.0
            val s = maxOf(fam, byAff)
            if (s > best) {
                best = s
                closeTo = raw
            }
        }
        val label = if (closeTo.isNotEmpty()) "محله‌ی نزدیک ($propertyNeighborhood، نزدیک $closeTo)" else "محله‌ی دیگر ($propertyNeighborhood)"
        pr.factor(best, label)
    }

    private fun budgetRule(pr: Prob, budget: Long, price: Long, who: String) {
        if (budget <= 0L) return
        when {
            price <= 0L -> pr.factor(0.95, "قیمت فایل ثبت نشده")
            price <= budget -> {
                if (price < budget * 0.6) pr.factor(0.92, "خیلی ارزان‌تر از $who")
                else pr.ok("قیمت در $who")
            }
            else -> {
                val over = (price - budget).toDouble() / budget.toDouble()
                val pct = (over * 100.0).roundToInt().coerceAtLeast(1)
                when {
                    over <= 0.02 -> pr.factor(0.92, "حدود ${fa(pct)}٪ بالاتر از $who")
                    over <= 0.05 -> pr.factor(0.82, "حدود ${fa(pct)}٪ بالاتر از $who")
                    else -> pr.reject("💰 قیمت ${fa(pct)}٪ بالاتر از $who (${PersianFormatters.formatMoneyToman(price)})")
                }
            }
        }
    }

    private fun marketRule(pr: Prob, property: Property, ctx: MatchContext, caresAboutValue: Boolean) {
        val median = ctx.medianPricePerMeter(property.neighborhood)
        val ppm = MatchContext.pricePerMeter(property)
        if (median <= 0L || ppm <= 0L) return
        val ratio = ppm.toDouble() / median.toDouble()
        if (ratio <= 0.90) {
            pr.info("💎 قیمت متری ${fa(((1.0 - ratio) * 100).roundToInt())}٪ زیر میانگین محله")
        } else if (caresAboutValue && ratio >= 1.15) {
            pr.factor(0.85, "قیمت متری ${fa(((ratio - 1.0) * 100).roundToInt())}٪ بالاتر از میانگین محله")
        }
    }

    fun evaluateCustomerMatch(
        customer: Customer,
        property: Property,
        linked: Boolean = false,
        ctx: MatchContext = MatchContext.EMPTY
    ): MatchResult {
        if (isInactive(property)) return rejectedResult("فایل فعال نیست (${property.status})", linked)
        if (PersianFormatters.isBoughtStatus(customer.status)) return rejectedResult("این مشتری قبلاً خرید کرده", linked)

        val pr = Prob()

        // 1) price: buyers usually stretch up to 5% over budget, not more
        budgetRule(pr, customer.budgetMax, property.totalPrice, "بودجه")

        // 2) bedrooms: nobody who wants 2 bedrooms buys 1
        if (customer.bedroomsMin > 0) {
            val beds = property.bedrooms
            when {
                beds <= 0 -> pr.factor(0.95, "تعداد خواب فایل ثبت نشده")
                beds < customer.bedroomsMin ->
                    pr.reject("❌ ${fa(customer.bedroomsMin)} خواب می‌خواهد؛ این فایل ${fa(beds)} خواب دارد")
                beds == customer.bedroomsMin -> pr.ok("تعداد خواب مطابق")
                beds == customer.bedroomsMin + 1 -> pr.factor(0.96, "یک خواب بیشتر از نیاز")
                else -> pr.factor(0.88, "خواب خیلی بیشتر از نیاز")
            }
        }

        // 3) amenities
        val fullFacilities = customer.reqParking && customer.reqStorage && customer.reqElevator && customer.reqTerrace
        if (customer.reqParking) {
            if (property.parking) pr.ok("پارکینگ دارد") else pr.reject("❌ پارکینگ ندارد")
        }
        val floor = property.unitFloor
        if (customer.reqElevator) {
            if (property.elevator) {
                pr.ok("آسانسور دارد")
            } else {
                // a low floor without elevator happens: 1st/2nd floor, or what the customer accepts
                val allowed = maxOf(2, customer.noElevatorMaxFloor)
                when {
                    floor in 1..allowed -> pr.factor(if (floor == 1) 0.88 else 0.80, "بدون آسانسور، طبقه‌ی ${fa(floor)} پایین است")
                    floor <= 0 -> pr.factor(0.60, "آسانسور ندارد و طبقه ثبت نشده")
                    else -> pr.reject("❌ آسانسور ندارد (طبقه‌ی ${fa(floor)})")
                }
            }
        } else if (!property.elevator && floor > 0) {
            if (customer.noElevatorMaxFloor > 0 && floor > customer.noElevatorMaxFloor) {
                pr.reject("❌ بدون آسانسور در طبقه‌ی ${fa(floor)} (مشتری تا طبقه‌ی ${fa(customer.noElevatorMaxFloor)})")
            } else if (customer.noElevatorMaxFloor <= 0) {
                if (floor >= 5) pr.factor(0.70, "طبقه‌ی ${fa(floor)} بدون آسانسور")
                else if (floor == 4) pr.factor(0.85, "طبقه‌ی ${fa(floor)} بدون آسانسور")
            }
        }
        // storage / terrace: a "full facilities" buyer still buys without them (about 90% for both missing)
        if (customer.reqStorage) {
            if (property.storage) pr.ok("انباری دارد") else pr.factor(if (fullFacilities) 0.95 else 0.85, "انباری ندارد")
        }
        if (customer.reqTerrace) {
            if (property.terrace) pr.ok("تراس دارد") else pr.factor(if (fullFacilities) 0.95 else 0.85, "تراس ندارد")
        }

        // 4) area: 65 m instead of 70 m is usually fine
        if (customer.areaMin > 0) {
            val area = property.area
            if (area <= 0) {
                pr.factor(0.95, "متراژ فایل ثبت نشده")
            } else if (area >= customer.areaMin) {
                pr.ok("متراژ کافی (${fa(area)} متر)")
            } else {
                val short = (customer.areaMin - area).toDouble() / customer.areaMin.toDouble()
                val lack = "${fa(customer.areaMin - area)} متر کمتر از نیاز"
                when {
                    short <= 0.03 -> pr.factor(0.93, lack)
                    short <= 0.08 -> pr.factor(0.82, lack)
                    short <= 0.12 -> pr.factor(0.55, lack)
                    short <= 0.20 -> pr.factor(0.25, lack)
                    else -> pr.reject("❌ متراژ خیلی کمتر از نیاز (${fa(area)} از ${fa(customer.areaMin)})")
                }
            }
        }

        // 5) neighborhood: people do buy somewhere else, more likely nearby
        neighborhoodRule(pr, customer.neighborhoods, property.neighborhood, ctx)

        // 6) building age: up to 5 years older is possible (nova -> 5, 10 -> 15, 15 -> 20 at about 50%)
        if (customer.buildingAgeMax > 0) {
            val age = property.buildingAge
            if (age <= customer.buildingAgeMax) {
                pr.ok("سن بنا مطابق")
            } else {
                val excess = age - customer.buildingAgeMax
                if (excess <= 5) pr.factor(1.0 - 0.10 * excess, "${fa(excess)} سال بالاتر از سن مورد نظر")
                else pr.factor(0.25, "سن بنا خیلی بالاتر از حد (${fa(age)} سال)")
            }
        }

        // 7) purpose / payment / occupancy
        val rented = property.occupancy.contains("مستاجر")
        if (rented && customer.purpose == "سکونت") pr.factor(0.82, "مستاجر دارد؛ تخلیه زمان می‌برد")
        if (rented && (customer.purpose == "سرمایه‌گذاری" || customer.purpose == "رهن دادن")) {
            pr.info("مستاجر دارد؛ برای سرمایه‌گذاری مناسب است")
        }
        // older records may still hold "با خودرو" / "با زمین"; anything except "نمی‌کند" means the seller accepts exchange
        val sellerExchanges = property.exchange.isNotBlank() && property.exchange != "نمی‌کند"
        when (customer.payment) {
            "نیاز به فروش واحد" ->
                if (sellerExchanges) pr.ok("فروشنده معاوضه می‌کند (مناسب مشتری‌ای که باید واحدش را بفروشد)")
                else pr.factor(0.80, "مشتری باید اول واحد خودش را بفروشد و فروشنده معاوضه نمی‌کند")
            "ضعیف" -> pr.factor(0.90, "توان پرداخت مشتری ضعیف ثبت شده")
            // values of the previous version of the form
            "تهاتر با ملک", "تهاتر با خودرو" ->
                if (sellerExchanges) pr.ok("فروشنده معاوضه می‌کند") else pr.factor(0.65, "فروشنده معاوضه نمی‌کند")
            "دریافت وام" -> if (rented) pr.factor(0.90, "مستاجر دارد؛ وام‌گرفتن سخت‌تر است")
        }

        // 8) market insight
        marketRule(pr, property, ctx, caresAboutValue = false)

        if (pr.criteria.isEmpty()) return rejectedResult("برای این مشتری هنوز نیازی ثبت نشده", linked).copy(rejected = false)
        return pr.result(linked)
    }

    fun evaluateInvestorMatch(
        investor: Investor,
        property: Property,
        linked: Boolean = false,
        ctx: MatchContext = MatchContext.EMPTY
    ): MatchResult {
        if (isInactive(property)) return rejectedResult("فایل فعال نیست (${property.status})", linked)
        // investors only get files that are tagged "investable"
        if (!property.investable) return rejectedResult("💼 فایل تیک «قابل سرمایه‌گذاری» ندارد", linked)

        val pr = Prob()
        pr.ok("💼 قابل سرمایه‌گذاری")

        val budget = if (investor.hasBuy == "بله" && investor.buyAmount > 0L) investor.buyAmount else 0L
        budgetRule(pr, budget, property.totalPrice, "سقف خرید")

        neighborhoodRule(pr, investor.neighborhoods, property.neighborhood, ctx)

        marketRule(pr, property, ctx, caresAboutValue = true)
        return pr.result(linked)
    }
}
