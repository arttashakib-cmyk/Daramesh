package ir.daramash.app.data.local.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import ir.daramash.app.data.backup.TargetCodec
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.DepositRecord
import ir.daramash.app.domain.model.ThemeMode
import ir.daramash.app.domain.model.UserSession
import ir.daramash.app.domain.usecase.PersianFormatters
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class SecureAuthPreferences(context: Context) {

    private val prefs: SharedPreferences = createSecurePrefs(context.applicationContext)

    private fun createSecurePrefs(ctx: Context): SharedPreferences {
        fun create(): SharedPreferences {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            return EncryptedSharedPreferences.create(
                "daramash_secure_prefs",
                masterKeyAlias,
                ctx,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            create()
        } catch (_: Exception) {
            // the file and the Keystore key can get out of sync (OS update, restored data):
            // start clean once instead of dropping to unencrypted storage
            try {
                ctx.deleteSharedPreferences("daramash_secure_prefs")
                create()
            } catch (_: Exception) {
                ctx.getSharedPreferences("daramash_fallback_prefs", Context.MODE_PRIVATE)
            }
        }
    }

    fun getDeviceId(): String {
        val existing = prefs.getString("device_id", null)
        if (!existing.isNullOrBlank()) return existing
        val created = "and_" + UUID.randomUUID().toString().replace("-", "").take(20)
        prefs.edit().putString("device_id", created).apply()
        return created
    }

    fun isSeeded(): Boolean = prefs.getBoolean("initial_seeded_v18", false)

    fun markSeeded() {
        prefs.edit().putBoolean("initial_seeded_v18", true).apply()
    }

    fun getThemeMode(): ThemeMode {
        val name = prefs.getString("theme_mode", ThemeMode.LIQUID_OLED.name) ?: ThemeMode.LIQUID_OLED.name
        return try {
            ThemeMode.valueOf(name)
        } catch (_: Exception) {
            ThemeMode.LIQUID_OLED
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString("theme_mode", mode.name).apply()
    }

    fun isBiometricEnabled(): Boolean = prefs.getBoolean("biometric_enabled", false)

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("biometric_enabled", enabled).apply()
    }

    fun areNotificationsEnabled(): Boolean = prefs.getBoolean("notifications_enabled", true)

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("notifications_enabled", enabled).apply()
    }

    fun getUserSession(): UserSession {
        val token = prefs.getString("auth_access_token", "") ?: ""
        val email = prefs.getString("auth_email", "") ?: ""
        val loggedIn = prefs.getBoolean("auth_logged_in", false) && token.isNotBlank()
        return UserSession(
            isLoggedIn = loggedIn,
            userId = prefs.getString("auth_user_id", "") ?: "",
            email = email,
            accessToken = token,
            refreshToken = prefs.getString("auth_refresh_token", "") ?: "",
            isAdmin = prefs.getBoolean("auth_is_admin", false),
            planName = prefs.getString("auth_plan_name", "اشتراک دارمش") ?: "اشتراک دارمش",
            maxDevices = prefs.getInt("auth_max_devices", 2),
            usedDevices = prefs.getInt("auth_used_devices", 1),
            subscriptionExpiresAt = prefs.getLong("auth_sub_exp", 0L),
            subStatus = prefs.getString("auth_sub_status", "login") ?: "login",
            statusErrorMsg = prefs.getString("auth_status_err", "") ?: "",
            daysLeft = prefs.getInt("auth_days_left", 0),
            payText = prefs.getString("auth_pay_text", "") ?: "",
            contact = prefs.getString("auth_contact", "") ?: "",
            verifiedAt = prefs.getLong("auth_verified_at", 0L),
            lastSeenAt = prefs.getLong("auth_last_seen_at", 0L),
            syncRev = prefs.getInt("sync_rev", 0),
            lastSyncAt = prefs.getLong("sync_last_at", 0L),
            rawBytes = prefs.getLong("sync_raw_bytes", 0L),
            quotaBytes = prefs.getLong("sync_quota_bytes", 10L * 1048576L),
            isCloudFull = prefs.getBoolean("sync_is_full", false),
            isCloudDirty = prefs.getBoolean("sync_is_dirty", false),
            syncStatusText = prefs.getString("sync_status_text", "آماده همگام‌سازی") ?: "آماده همگام‌سازی",
            latestBuild = prefs.getInt("app_latest_build", 0),
            updateUrl = prefs.getString("app_update_url", "") ?: "",
            updateNote = prefs.getString("app_update_note", "") ?: "",
            trialDays = prefs.getInt("cfg_trial_days", 0)
        )
    }

    fun saveUserSession(session: UserSession) {
        prefs.edit()
            .putBoolean("auth_logged_in", session.isLoggedIn)
            .putString("auth_user_id", session.userId)
            .putString("auth_email", session.email)
            .putString("auth_access_token", session.accessToken)
            .putString("auth_refresh_token", session.refreshToken)
            .putBoolean("auth_is_admin", session.isAdmin)
            .putString("auth_plan_name", session.planName)
            .putInt("auth_max_devices", session.maxDevices)
            .putInt("auth_used_devices", session.usedDevices)
            .putLong("auth_sub_exp", session.subscriptionExpiresAt)
            .putString("auth_sub_status", session.subStatus)
            .putString("auth_status_err", session.statusErrorMsg)
            .putInt("auth_days_left", session.daysLeft)
            .putString("auth_pay_text", session.payText)
            .putString("auth_contact", session.contact)
            .putLong("auth_verified_at", session.verifiedAt)
            .putLong("auth_last_seen_at", session.lastSeenAt)
            .putInt("sync_rev", session.syncRev)
            .putLong("sync_last_at", session.lastSyncAt)
            .putLong("sync_raw_bytes", session.rawBytes)
            .putLong("sync_quota_bytes", session.quotaBytes)
            .putBoolean("sync_is_full", session.isCloudFull)
            .putBoolean("sync_is_dirty", session.isCloudDirty)
            .putString("sync_status_text", session.syncStatusText)
            .putInt("app_latest_build", session.latestBuild)
            .putString("app_update_url", session.updateUrl)
            .putString("app_update_note", session.updateNote)
            .putInt("cfg_trial_days", session.trialDays)
            .apply()
    }

    /**
     * Exact decideStored logic from auth-module.js:
     * - Offline access is only allowed for an already verified session.
     * - Grace period is strictly 7 days (7 * 86,400,000 ms).
     * - Clock-rollback protection: now must not be before (seen - 1 hour).
     */
    fun decideStored(now: Long = System.currentTimeMillis()): String {
        val s = getUserSession()
        if (!s.isLoggedIn || s.accessToken.isBlank()) return "login"
        val state = s.subStatus
        if (state == "update") return "update"
        if (state == "device_limit") return "device_limit"
        if (state == "blocked") return "blocked"
        if (state == "pending") return "pending"
        val grace = 7L * 86_400_000L
        if (state == "active" && s.subscriptionExpiresAt > now && (now - s.verifiedAt) <= grace && now >= (s.lastSeenAt - 3_600_000L)) {
            return "ok"
        }
        return "offline"
    }

    fun markSeen(now: Long = System.currentTimeMillis()) {
        val cur = getUserSession()
        val nextSeen = if (now > cur.lastSeenAt) now else cur.lastSeenAt
        prefs.edit().putLong("auth_last_seen_at", nextSeen).apply()
    }

    fun getCachedTetherPrice(): Long? {
        val p = prefs.getLong("tether_cached_price", 0L)
        return if (p > 0L) p else null
    }

    fun saveCachedTetherPrice(price: Long) {
        prefs.edit()
            .putLong("tether_cached_price", price)
            .putLong("tether_cached_at", System.currentTimeMillis())
            .apply()
    }

    fun clearSession() {
        prefs.edit()
            .putBoolean("auth_logged_in", false)
            .putString("auth_access_token", "")
            .putString("auth_refresh_token", "")
            .putString("auth_sub_status", "login")
            .putInt("sync_rev", 0)
            .apply()
    }

    fun getSyncOwner(): String = prefs.getString("sync_owner", "") ?: ""

    fun setSyncOwner(value: String) {
        prefs.edit().putString("sync_owner", value).apply()
    }

    fun getSyncFingerprint(): String = prefs.getString("sync_fp", "") ?: ""

    fun setSyncFingerprint(value: String) {
        prefs.edit().putString("sync_fp", value).apply()
    }

    fun getAdvisorTarget(): AdvisorTarget {
        val raw = prefs.getString("advisor_target_json", null) ?: return AdvisorTarget()
        return try {
            val obj = JSONObject(raw)
            if (obj.has("progress")) TargetCodec.fromJson(obj) else migrateLegacyTarget(obj)
        } catch (_: Exception) {
            AdvisorTarget()
        }
    }

    /** The first native layout kept global deposits and invented defaults (350M, 3 contracts, file 1042, rank 1). */
    private fun migrateLegacyTarget(obj: JSONObject): AdvisorTarget {
        val base = TargetCodec.fromJson(obj)
        val byMonth = LinkedHashMap<String, MutableList<DepositRecord>>()
        val depsArr = obj.optJSONArray("deposits") ?: JSONArray()
        for (i in 0 until depsArr.length()) {
            val d = depsArr.optJSONObject(i) ?: continue
            val amount = d.optLong("amount", 0L)
            if (amount <= 0L) continue
            val rec = DepositRecord(
                id = d.optString("id", UUID.randomUUID().toString()),
                amount = amount,
                title = d.optString("title", "واریزی"),
                date = d.optString("date", PersianFormatters.todayIso())
            )
            byMonth.getOrPut(PersianFormatters.jalaliMonthKeyFromIso(rec.date)) { ArrayList() }.add(rec)
        }
        return base.copy(
            targetFileCode = if (base.targetFileCode == "۱۰۴۲") "" else base.targetFileCode,
            targetDeposit = if (base.targetDeposit == 350_000_000L) 0L else base.targetDeposit,
            targetContracts = if (base.targetContracts == 3) 0 else base.targetContracts,
            rank = 0,
            progress = byMonth.mapValues { (_, list) -> ir.daramash.app.domain.model.MonthProgress(deposits = list) }
        )
    }

    fun saveAdvisorTarget(target: AdvisorTarget) {
        prefs.edit().putString("advisor_target_json", TargetCodec.toJson(target).toString()).apply()
    }
}
