package ir.daramash.app.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import ir.daramash.app.BuildConfig

object GoogleChromeAuthLauncher {

    const val CHROME_PACKAGE = "com.android.chrome"
    const val GOOGLE_OAUTH_REDIRECT_URI = "ir.daramash.app://auth"

    /**
     * Checks if Google Chrome is installed and enabled on the Android device.
     */
    fun isChromeInstalled(context: Context): Boolean {
        val pm = context.packageManager
        return try {
            val pi = pm.getPackageInfo(CHROME_PACKAGE, 0)
            pi != null
        } catch (_: Exception) {
            val testIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://accounts.google.com")).apply {
                setPackage(CHROME_PACKAGE)
            }
            testIntent.resolveActivity(pm) != null
        }
    }

    /**
     * Builds the Supabase Google OAuth verification URL with account selector prompt.
     */
    fun buildGoogleOAuthUrl(codeChallenge: String): String {
        return "${BuildConfig.SUPABASE_URL}/auth/v1/authorize?provider=google&redirect_to=$GOOGLE_OAUTH_REDIRECT_URI" +
            "&prompt=select_account&code_challenge=$codeChallenge&code_challenge_method=s256"
    }

    /**
     * Opens Google Play Store directly on the Google Chrome app page.
     */
    fun openChromeInPlayStore(context: Context) {
        val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$CHROME_PACKAGE")).apply {
            setPackage("com.android.vending")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(playStoreIntent)
        } catch (_: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$CHROME_PACKAGE")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(webIntent)
            } catch (_: Exception) {
                // Ignore
            }
        }
    }

    /**
     * Launches the Google OAuth verification flow EXCLUSIVELY inside Google Chrome.
     * Strictly enforces `com.android.chrome`. Never falls back to Samsung Internet, Mi Browser, or other apps.
     */
    fun launch(
        context: Context,
        onChromeMissing: (() -> Unit)? = null
    ) {
        if (!isChromeInstalled(context)) {
            Toast.makeText(
                context,
                "مرورگر Google Chrome روی گوشی شما یافت نشد. جهت امنیت، احراز هویت جیمیل فقط از طریق کروم مجاز است.",
                Toast.LENGTH_LONG
            ).show()

            if (onChromeMissing != null) {
                onChromeMissing()
            } else {
                openChromeInPlayStore(context)
            }
            return
        }

        val oauthUrl = buildGoogleOAuthUrl(PkceLogin.begin(context))
        val uri = Uri.parse(oauthUrl)

        // Directly launch Google Chrome application (never Custom Tabs to prevent Samsung Internet from hijacking)
        val directChromeIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage(CHROME_PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            context.startActivity(directChromeIntent)
        } catch (e: Exception) {
            // Fallback to CustomTabs specifically bound to com.android.chrome
            try {
                val customTabsIntent = CustomTabsIntent.Builder()
                    .setShowTitle(true)
                    .setUrlBarHidingEnabled(false)
                    .setColorScheme(CustomTabsIntent.COLOR_SCHEME_DARK)
                    .build()
                customTabsIntent.intent.setPackage(CHROME_PACKAGE)
                customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                customTabsIntent.launchUrl(context, uri)
            } catch (err: Exception) {
                Toast.makeText(
                    context,
                    "خطا در اجرای Google Chrome: ${err.message}",
                    Toast.LENGTH_LONG
                ).show()
                openChromeInPlayStore(context)
            }
        }
    }
}
