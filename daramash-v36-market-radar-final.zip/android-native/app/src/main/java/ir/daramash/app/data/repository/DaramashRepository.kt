package ir.daramash.app.data.repository

import android.content.Context
import android.util.Base64
import ir.daramash.app.data.backup.BackupExportManager
import ir.daramash.app.data.backup.RestorePreview
import ir.daramash.app.data.local.dao.DaramashDao
import ir.daramash.app.data.local.entity.toEntity
import ir.daramash.app.data.local.prefs.SecureAuthPreferences
import ir.daramash.app.data.remote.CloudNetworkService
import ir.daramash.app.domain.model.ActivityLog
import ir.daramash.app.domain.model.Advisor
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchLink
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.UserSession
import ir.daramash.app.domain.usecase.PersianFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.UUID

class DaramashRepository(
    private val context: Context,
    private val dao: DaramashDao,
    val prefs: SecureAuthPreferences,
    val network: CloudNetworkService
) {

    val activePropertiesFlow: Flow<List<Property>> =
        dao.observeActiveProperties().map { list -> list.map { it.toDomain() } }

    val archivedPropertiesFlow: Flow<List<Property>> =
        dao.observeArchivedProperties().map { list -> list.map { it.toDomain() } }

    val activeCustomersFlow: Flow<List<Customer>> =
        dao.observeActiveCustomers().map { list -> list.map { it.toDomain() } }

    val archivedCustomersFlow: Flow<List<Customer>> =
        dao.observeArchivedCustomers().map { list -> list.map { it.toDomain() } }

    val activeInvestorsFlow: Flow<List<Investor>> =
        dao.observeActiveInvestors().map { list -> list.map { it.toDomain() } }

    val archivedInvestorsFlow: Flow<List<Investor>> =
        dao.observeArchivedInvestors().map { list -> list.map { it.toDomain() } }

    val matchesFlow: Flow<List<MatchLink>> =
        dao.observeMatches().map { list -> list.map { it.toDomain() } }

    val activityLogsFlow: Flow<List<ActivityLog>> =
        dao.observeActivityLogs().map { list -> list.map { it.toDomain() } }

    val advisorsFlow: Flow<List<Advisor>> =
        dao.observeAdvisors().map { list -> list.map { it.toDomain() } }

    /**
     * Fresh install stays 100% clean and empty.
     * Mock data is NEVER loaded automatically on first launch!
     */
    suspend fun ensureInitialPortfolioSeeded() = withContext(Dispatchers.IO) {
        // Deliberately no-op on first run. Database starts completely clean.
    }

    /**
     * Loads realistic sample demo data explicitly when user clicks "بارگذاری داده‌ی نمونه" in System.
     */
    suspend fun loadDemoData(): Result<Int> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val p1 = Property(
            id = "demo_prop_1042",
            code = "۱۰۴۲",
            area = 78,
            bedrooms = 2,
            floors = 5,
            unitsPerFloor = 2,
            unitFloor = 3,
            buildingAge = 5,
            facade = "سنگ",
            condition = "بازسازی شده",
            lighting = "دوکله نور جنوبی",
            parking = true,
            storage = true,
            elevator = true,
            terrace = true,
            totalPrice = 14_200_000_000L,
            pricePerMeter = 182_051_282L,
            occupancy = "تخلیه",
            neighborhood = "پونک",
            address = "تهران، پونک، بلوار همیلا",
            visit = "با هماهنگی",
            sellerName = "رضا احمدی",
            sellerPhone = "09121112233",
            sellReason = "خرید واحد بزرگ‌تر",
            exchange = "نمی‌کند",
            regDate = PersianFormatters.shiftDaysIso(-15),
            lastContact = PersianFormatters.shiftDaysIso(-1),
            status = "فروشنده",
            investable = false,
            note = "نور عالی، بازسازی کامل سال گذشته",
            demo = true,
            createdAt = now - 15L * 86_400_000L
        )
        val p2 = Property(
            id = "demo_prop_1043",
            code = "۱۰۴۳",
            area = 82,
            bedrooms = 2,
            floors = 8,
            unitsPerFloor = 2,
            unitFloor = 5,
            buildingAge = 12,
            facade = "آجر",
            condition = "تمیز",
            lighting = "سالن پرده خور",
            parking = false,
            storage = true,
            elevator = true,
            terrace = false,
            totalPrice = 14_500_000_000L,
            pricePerMeter = 176_829_268L,
            occupancy = "ساکن",
            neighborhood = "شهرک نفت",
            address = "تهران، شهرک نفت",
            visit = "کلید املاک",
            sellerName = "فاطمه رضایی",
            sellerPhone = "09122223344",
            sellReason = "مهاجرت",
            exchange = "می‌کند",
            regDate = PersianFormatters.shiftDaysIso(-20),
            lastContact = PersianFormatters.shiftDaysIso(-12),
            status = "فروشنده",
            investable = false,
            demo = true,
            createdAt = now - 20L * 86_400_000L
        )
        val p3 = Property(
            id = "demo_prop_1044",
            code = "۱۰۴۴",
            area = 100,
            bedrooms = 3,
            floors = 4,
            unitsPerFloor = 1,
            unitFloor = 2,
            buildingAge = 2,
            facade = "تراورتن",
            condition = "بازسازی شده",
            lighting = "فول پاسیو",
            parking = true,
            storage = true,
            elevator = true,
            terrace = true,
            totalPrice = 22_000_000_000L,
            pricePerMeter = 220_000_000L,
            occupancy = "مستاجر",
            contractDuration = "۲ سال",
            deposit = 500_000_000L,
            rent = 60_000_000L,
            neighborhood = "جنت شمال",
            address = "تهران، جنت شمال",
            visit = "با هماهنگی",
            sellerName = "علی کریمی",
            sellerPhone = "09123334455",
            sellReason = "سرمایه‌گذاری",
            exchange = "می‌کند",
            regDate = PersianFormatters.shiftDaysIso(-30),
            lastContact = PersianFormatters.shiftDaysIso(-3),
            status = "فروشنده",
            investable = true,
            demo = true,
            createdAt = now - 30L * 86_400_000L
        )

        val c1 = Customer(
            id = "demo_cust_1",
            firstName = "حسین",
            lastName = "محمدی",
            phone1 = "09351112233",
            neighborhoods = listOf("پونک", "همیلا"),
            areaMin = 70,
            bedroomsMin = 2,
            buildingAgeMax = 8,
            budgetMax = 15_000_000_000L,
            reqParking = true,
            reqElevator = true,
            noElevatorMaxFloor = 2,
            quality = "داغ",
            payment = "نقد",
            purpose = "سکونت",
            status = "در جست و جو",
            regDate = PersianFormatters.shiftDaysIso(-7),
            lastContact = PersianFormatters.shiftDaysIso(-1),
            demo = true,
            createdAt = now - 7L * 86_400_000L
        )
        val c2 = Customer(
            id = "demo_cust_2",
            firstName = "مریم",
            lastName = "محمودی",
            phone1 = "09122223333",
            neighborhoods = listOf("جنت شمال", "جنت مرکز"),
            areaMin = 80,
            bedroomsMin = 2,
            buildingAgeMax = 12,
            budgetMax = 20_000_000_000L,
            reqElevator = true,
            reqStorage = true,
            quality = "گرم",
            payment = "نیاز به فروش واحد",
            purpose = "سرمایه‌گذاری",
            status = "تازه تو بازار",
            regDate = PersianFormatters.shiftDaysIso(-3),
            lastContact = PersianFormatters.shiftDaysIso(-9),
            demo = true,
            createdAt = now - 3L * 86_400_000L
        )

        val inv1 = Investor(
            id = "demo_inv_1",
            firstName = "آقای",
            lastName = "صادقی",
            phone1 = "09121234567",
            neighborhoods = listOf("جنت شمال", "باغ فیض"),
            existingUnits = "۱۰۴۲ — ۱۰۵۰",
            hasBuy = "بله",
            buyAmount = 40_000_000_000L,
            telegramChannel = "https://t.me/sadeghi_invest",
            businessType = "آدم حسابی",
            lastContact = PersianFormatters.shiftDaysIso(-2),
            note = "به دنبال ملک لوکس برای سرمایه‌گذاری بلندمدت",
            demo = true,
            createdAt = now - 5L * 86_400_000L
        )

        val match1 = MatchLink(
            id = "demo_match_1",
            propertyId = p1.id,
            needId = c1.id,
            needKind = "customer",
            demo = true,
            createdAt = now - 2L * 86_400_000L
        )

        val logs = listOf(
            ActivityLog(
                id = "demo_log_1",
                entityType = "property",
                entityId = p1.id,
                type = "تماس",
                note = "قیمت مالک تأیید شد و آماده بازدید است",
                date = PersianFormatters.shiftDaysIso(-1),
                demo = true,
                createdAt = now - 86_400_000L
            ),
            ActivityLog(
                id = "demo_log_2",
                entityType = "customer",
                entityId = c1.id,
                type = "بازدید",
                note = "بازدید از فایل ۱۰۴۲ پونک هماهنگ شد",
                date = PersianFormatters.shiftDaysIso(-2),
                demo = true,
                createdAt = now - 2L * 86_400_000L
            )
        )

        dao.upsertProperties(listOf(p1.toEntity(), p2.toEntity(), p3.toEntity()))
        dao.upsertCustomers(listOf(c1.toEntity(), c2.toEntity()))
        dao.upsertInvestors(listOf(inv1.toEntity()))
        dao.insertMatches(listOf(match1.toEntity()))
        dao.insertActivityLogs(logs.map { it.toEntity() })

        val total = 3 + 2 + 1
        Result.success(total)
    }

    /**
     * Purges all sample demo records in one clean tap.
     */
    suspend fun removeDemoData(): Result<Int> = withContext(Dispatchers.IO) {
        val demoSigs = mapOf(
            "09121112233" to "رضا احمدی",
            "09122223344" to "فاطمه رضایی",
            "09123334455" to "علی کریمی"
        )
        val demoCustSigs = mapOf(
            "09351112233" to "حسین محمدی",
            "09122223333" to "مریم محمودی"
        )
        val demoInvSigs = mapOf(
            "09121234567" to "آقای صادقی"
        )

        val allProps = dao.getAllPropertiesNow()
        val toDeletePropIds = allProps.filter { p ->
            p.id.startsWith("demo_") || (demoSigs[p.sellerPhone] != null && demoSigs[p.sellerPhone] == p.sellerName)
        }.map { it.id }

        val allCusts = dao.getAllCustomersNow()
        val toDeleteCustIds = allCusts.filter { c ->
            c.id.startsWith("demo_") || (demoCustSigs[c.phone1] != null && demoCustSigs[c.phone1] == "${c.firstName} ${c.lastName}".trim())
        }.map { it.id }

        val allInvs = dao.getAllInvestorsNow()
        val toDeleteInvIds = allInvs.filter { i ->
            i.id.startsWith("demo_") || (demoInvSigs[i.phone1] != null && demoInvSigs[i.phone1] == "${i.firstName} ${i.lastName}".trim())
        }.map { it.id }

        if (toDeletePropIds.isNotEmpty()) dao.deletePropertiesByIds(toDeletePropIds)
        if (toDeleteCustIds.isNotEmpty()) dao.deleteCustomersByIds(toDeleteCustIds)
        if (toDeleteInvIds.isNotEmpty()) dao.deleteInvestorsByIds(toDeleteInvIds)

        val total = toDeletePropIds.size + toDeleteCustIds.size + toDeleteInvIds.size
        Result.success(total)
    }

    suspend fun demoCount(): Int = withContext(Dispatchers.IO) {
        val demoSigs = setOf("09121112233", "09122223344", "09123334455")
        val demoCustSigs = setOf("09351112233", "09122223333")
        val demoInvSigs = setOf("09121234567")
        val pCount = dao.getAllPropertiesNow().count { it.id.startsWith("demo_") || it.sellerPhone in demoSigs }
        val cCount = dao.getAllCustomersNow().count { it.id.startsWith("demo_") || it.phone1 in demoCustSigs }
        val iCount = dao.getAllInvestorsNow().count { it.id.startsWith("demo_") || it.phone1 in demoInvSigs }
        pCount + cCount + iCount
    }

    suspend fun saveProperty(property: Property, checkDuplicate: Boolean = true): Result<Property> = withContext(Dispatchers.IO) {
        if (checkDuplicate && property.code.isNotBlank()) {
            val dup = dao.findPropertyByCode(property.code)
            if (dup != null && dup.id != property.id) {
                return@withContext Result.failure(IllegalArgumentException("فایلی با کد «${PersianFormatters.toFa(property.code)}» قبلاً ثبت شده است."))
            }
        }
        val normalized = property.copy(
            code = PersianFormatters.scrubSafeText(property.code),
            sellerPhone = PersianFormatters.normalizePhoneDigits(property.sellerPhone),
            pricePerMeter = if (property.totalPrice > 0 && property.area > 0) property.totalPrice / property.area else property.pricePerMeter,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertProperty(normalized.toEntity())
        Result.success(normalized)
    }

    suspend fun saveCustomer(customer: Customer, checkDuplicate: Boolean = true): Result<Customer> = withContext(Dispatchers.IO) {
        val normPhone = PersianFormatters.normalizePhoneDigits(customer.phone1)
        if (checkDuplicate && normPhone.isNotBlank()) {
            val dup = dao.findCustomerByPhone(normPhone)
            if (dup != null && dup.id != customer.id) {
                return@withContext Result.failure(IllegalArgumentException("مشتری دیگری با شماره «${PersianFormatters.toFa(normPhone)}» در سیستم وجود دارد."))
            }
        }
        val normalized = customer.copy(
            phone1 = normPhone,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertCustomer(normalized.toEntity())
        Result.success(normalized)
    }

    suspend fun saveInvestor(investor: Investor): Result<Investor> = withContext(Dispatchers.IO) {
        val normalized = investor.copy(
            phone1 = PersianFormatters.normalizePhoneDigits(investor.phone1),
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertInvestor(normalized.toEntity())
        Result.success(normalized)
    }

    suspend fun archiveProperties(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.archivePropertiesByIds(ids)
    }

    suspend fun restoreProperty(id: String) = withContext(Dispatchers.IO) {
        dao.restorePropertyById(id)
    }

    suspend fun deletePropertiesPermanently(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.deletePropertiesByIds(ids)
    }

    suspend fun archiveCustomers(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.archiveCustomersByIds(ids)
    }

    suspend fun restoreCustomer(id: String) = withContext(Dispatchers.IO) {
        dao.restoreCustomerById(id)
    }

    suspend fun deleteCustomersPermanently(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.deleteCustomersByIds(ids)
    }

    suspend fun archiveInvestors(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.archiveInvestorsByIds(ids)
    }

    suspend fun restoreInvestor(id: String) = withContext(Dispatchers.IO) {
        dao.restoreInvestorById(id)
    }

    suspend fun deleteInvestorsPermanently(ids: List<String>) = withContext(Dispatchers.IO) {
        dao.deleteInvestorsByIds(ids)
    }

    suspend fun addMatchLinks(links: List<Triple<String, String, String>>) = withContext(Dispatchers.IO) {
        if (links.isEmpty()) return@withContext
        dao.insertMatches(
            links.map { (propertyId, needId, kind) ->
                MatchLink(
                    id = UUID.randomUUID().toString(),
                    propertyId = propertyId,
                    needId = needId,
                    needKind = kind
                ).toEntity()
            }
        )
    }

    suspend fun toggleMatchLink(propertyId: String, needId: String, needKind: String, currentlyLinked: Boolean) = withContext(Dispatchers.IO) {
        if (currentlyLinked) {
            dao.deleteMatch(propertyId, needId)
        } else {
            dao.insertMatch(
                MatchLink(
                    id = UUID.randomUUID().toString(),
                    propertyId = propertyId,
                    needId = needId,
                    needKind = needKind
                ).toEntity()
            )
        }
    }

    suspend fun logActivity(entityType: String, entityId: String, type: String, note: String) = withContext(Dispatchers.IO) {
        val today = PersianFormatters.todayIso()
        dao.insertActivityLog(
            ActivityLog(
                id = UUID.randomUUID().toString(),
                entityType = entityType,
                entityId = entityId,
                type = type,
                note = PersianFormatters.scrubSafeText(note),
                date = today
            ).toEntity()
        )
        // Update lastContact on the entity automatically
        when (entityType) {
            "property" -> {
                val p = dao.getAllPropertiesNow().find { it.id == entityId }
                if (p != null) dao.upsertProperty(p.copy(lastContact = today, updatedAt = System.currentTimeMillis()))
            }
            "customer" -> {
                val c = dao.getAllCustomersNow().find { it.id == entityId }
                if (c != null) dao.upsertCustomer(c.copy(lastContact = today, updatedAt = System.currentTimeMillis()))
            }
            "investor" -> {
                val inv = dao.getAllInvestorsNow().find { it.id == entityId }
                if (inv != null) dao.upsertInvestor(inv.copy(lastContact = today, updatedAt = System.currentTimeMillis()))
            }
        }
    }

    suspend fun addAdvisor(name: String, phone: String, specialty: String) = withContext(Dispatchers.IO) {
        dao.upsertAdvisor(
            Advisor(
                id = UUID.randomUUID().toString(),
                name = PersianFormatters.scrubSafeText(name),
                phone = PersianFormatters.normalizePhoneDigits(phone),
                specialtyNeighborhood = PersianFormatters.scrubSafeText(specialty)
            ).toEntity()
        )
    }

    suspend fun updateAdvisor(id: String, name: String, phone: String, specialty: String) = withContext(Dispatchers.IO) {
        val old = dao.getAllAdvisorsNow().firstOrNull { it.id == id } ?: return@withContext
        dao.upsertAdvisor(
            old.copy(
                name = PersianFormatters.scrubSafeText(name),
                phone = PersianFormatters.normalizePhoneDigits(phone),
                specialtyNeighborhood = PersianFormatters.scrubSafeText(specialty)
            )
        )
    }

    suspend fun deleteAdvisor(id: String) = withContext(Dispatchers.IO) {
        dao.deleteAdvisor(id)
    }

    /**
     * Generates a compact Base64 Advisor Transfer Code (کد انتقال مشاور) for Manager Panel.
     */
    suspend fun generateAdvisorTransferCode(advisorName: String): String = withContext(Dispatchers.IO) {
        val props = dao.getAllPropertiesNow().filter { !it.isArchived }.take(10).map { it.toDomain() }
        val custs = dao.getAllCustomersNow().filter { !it.isArchived }.take(10).map { it.toDomain() }
        val json = BackupExportManager.exportFullBackupJson(
            properties = props.map { it.copy(advisorName = advisorName) },
            customers = custs.map { it.copy(advisorName = advisorName) },
            investors = emptyList(),
            matches = emptyList(),
            activities = emptyList(),
            advisors = emptyList(),
            target = prefs.getAdvisorTarget()
        )
        "DA1:" + Base64.encodeToString(json.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
    }

    suspend fun importAdvisorTransferCode(code: String): Result<Int> = withContext(Dispatchers.IO) {
        val trimmed = code.trim()
        val rawJson = if (trimmed.startsWith("DA1:")) {
            String(Base64.decode(trimmed.removePrefix("DA1:"), Base64.DEFAULT), StandardCharsets.UTF_8)
        } else {
            trimmed
        }
        val parsed = BackupExportManager.validateAndParseBackupJson(rawJson).getOrElse {
            return@withContext Result.failure(it)
        }
        dao.upsertProperties(parsed.properties.map { it.toEntity() })
        dao.upsertCustomers(parsed.customers.map { it.toEntity() })
        Result.success(parsed.properties.size + parsed.customers.size)
    }

    /**
     * Creates a full JSON backup string and also saves a local safety snapshot before any restore.
     */
    suspend fun exportFullBackupJson(): String = withContext(Dispatchers.IO) {
        BackupExportManager.exportFullBackupJson(
            properties = dao.getAllPropertiesNow().map { it.toDomain() },
            customers = dao.getAllCustomersNow().map { it.toDomain() },
            investors = dao.getAllInvestorsNow().map { it.toDomain() },
            matches = dao.getAllMatchesNow().map { it.toDomain() },
            activities = dao.getAllActivityLogsNow().map { it.toDomain() },
            advisors = dao.getAllAdvisorsNow().map { it.toDomain() },
            target = prefs.getAdvisorTarget()
        )
    }

    /** Reads a backup (file or pasted text) and reports what is inside, without touching any data. */
    suspend fun previewBackup(rawJson: String): Result<RestorePreview> = withContext(Dispatchers.IO) {
        val parsed = BackupExportManager.validateAndParseBackupJson(rawJson).getOrElse {
            return@withContext Result.failure(it)
        }
        val total = parsed.properties.size + parsed.customers.size + parsed.investors.size
        if (total == 0 && parsed.target == null) {
            return@withContext Result.failure(IllegalArgumentException("این فایل معتبر است ولی هیچ فایل، مشتری یا سرمایه‌گذاری داخلش نیست."))
        }
        Result.success(BackupExportManager.buildPreview(rawJson, parsed))
    }

    /**
     * Validates backup JSON, writes a pre-restore safety snapshot to internal storage,
     * and atomically replaces the SQLite database inside a Room @Transaction.
     */
    suspend fun restoreFromBackupJson(rawJson: String): Result<String> = withContext(Dispatchers.IO) {
        val parsed = BackupExportManager.validateAndParseBackupJson(rawJson).getOrElse {
            return@withContext Result.failure(it)
        }
        // Safety copies so nothing is lost: a rotating local snapshot and the single pre-restore file
        try {
            takeLocalSnapshot("قبل از بازگردانی", force = true)
            val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
            val safetyFile = File(backupDir, "pre_restore_snapshot.json")
            safetyFile.writeText(exportFullBackupJson(), StandardCharsets.UTF_8)
        } catch (_: Exception) {}

        dao.replaceEntireDatabaseTransaction(
            properties = parsed.properties.map { it.toEntity() },
            customers = parsed.customers.map { it.toEntity() },
            investors = parsed.investors.map { it.toEntity() },
            matches = parsed.matches.map { it.toEntity() },
            activities = parsed.activities.map { it.toEntity() },
            advisors = parsed.advisors.map { it.toEntity() }
        )
        parsed.target?.let { prefs.saveAdvisorTarget(it) }

        val summary = "بازیابی با موفقیت انجام شد: ${PersianFormatters.toFa(parsed.properties.size)} فایل، ${PersianFormatters.toFa(parsed.customers.size)} مشتری و ${PersianFormatters.toFa(parsed.investors.size)} سرمایه‌گذار"
        Result.success(summary)
    }

    /**
     * Counts cleanable "فروش رفت" and "خرید کرد" entities.
     */
    suspend fun getCleanableCounts(): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val sold = dao.getAllPropertiesNow().count { PersianFormatters.isSoldStatus(it.status) }
        val bought = dao.getAllCustomersNow().count { PersianFormatters.isBoughtStatus(it.status) }
        Pair(sold, bought)
    }

    /**
     * One-touch cleanup of "فروش رفت" and "خرید کرد" with automatic pre-cleanup snapshot.
     */
    suspend fun cleanupSoldAndBought(): Result<Pair<Int, Int>> = withContext(Dispatchers.IO) {
        takeLocalSnapshot("قبل از پاک‌سازی فضا", force = true)
        val allProps = dao.getAllPropertiesNow()
        val toDeleteProps = allProps.filter { PersianFormatters.isSoldStatus(it.status) }.map { it.id }
        val allCusts = dao.getAllCustomersNow()
        val toDeleteCusts = allCusts.filter { PersianFormatters.isBoughtStatus(it.status) }.map { it.id }

        if (toDeleteProps.isNotEmpty()) dao.deletePropertiesByIds(toDeleteProps)
        if (toDeleteCusts.isNotEmpty()) dao.deleteCustomersByIds(toDeleteCusts)

        Result.success(Pair(toDeleteProps.size, toDeleteCusts.size))
    }

    /**
     * Manages rotating local snapshots (up to 3 copies, daily + pre-restore).
     */
    suspend fun takeLocalSnapshot(reason: String, force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        try {
            val backupDir = File(context.filesDir, "snapshots").apply { mkdirs() }
            val manifestFile = File(backupDir, "snapshots_manifest.json")
            val existing = if (manifestFile.exists()) {
                val arr = org.json.JSONArray(manifestFile.readText(StandardCharsets.UTF_8))
                val list = mutableListOf<JSONObject>()
                for (i in 0 until arr.length()) list.add(arr.getJSONObject(i))
                list
            } else mutableListOf()

            val now = System.currentTimeMillis()
            if (!force && existing.isNotEmpty()) {
                val lastAt = existing.first().optLong("at", 0L)
                if (now - lastAt < 20L * 3600_000L) return@withContext false
            }

            val json = exportFullBackupJson()
            val fileName = "snap_${now}.json"
            val file = File(backupDir, fileName)
            file.writeText(json, StandardCharsets.UTF_8)

            val newEntry = JSONObject().apply {
                put("at", now)
                put("reason", reason)
                put("file", fileName)
                put("size", json.length)
            }
            val updatedList = (listOf(newEntry) + existing).toMutableList()
            while (updatedList.size > 3) {
                val removed = updatedList.removeAt(updatedList.lastIndex)
                val oldFile = File(backupDir, removed.optString("file"))
                if (oldFile.exists()) oldFile.delete()
            }

            val newArr = org.json.JSONArray()
            updatedList.forEach { newArr.put(it) }
            manifestFile.writeText(newArr.toString(), StandardCharsets.UTF_8)
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun clearLocalDataForAccountSwitch(): Unit = withContext(Dispatchers.IO) {
        takeLocalSnapshot("قبل از تغییر حساب", force = true)
        dao.replaceEntireDatabaseTransaction(
            properties = emptyList(),
            customers = emptyList(),
            investors = emptyList(),
            matches = emptyList(),
            activities = emptyList(),
            advisors = emptyList()
        )
    }

    suspend fun fetchCloudSnapshotsList(): Result<List<ir.daramash.app.domain.model.CloudHistorySnapshot>> = withContext(Dispatchers.IO) {
        val session = currentSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("نشست ورود کاربر نامعتبر است"))
        val res = network.syncHistory(session.accessToken)
        res.map { json ->
            val list = mutableListOf<ir.daramash.app.domain.model.CloudHistorySnapshot>()
            val arr = json.optJSONArray("list") ?: org.json.JSONArray()
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                list.add(
                    ir.daramash.app.domain.model.CloudHistorySnapshot(
                        id = item.optLong("id"),
                        versionAt = item.optLong("version_at", System.currentTimeMillis()),
                        rawBytes = item.optLong("raw_bytes", 0L)
                    )
                )
            }
            list
        }
    }

    suspend fun restoreCloudHistorySnapshot(snapshotId: Long): Result<String> = withContext(Dispatchers.IO) {
        val session = currentSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("نشست کاربر نامعتبر است"))
        takeLocalSnapshot("قبل از بازگردانی نسخه‌ی قبلی ابری", force = true)
        val res = network.syncHistoryGet(session.accessToken, snapshotId)
        if (res.isFailure) return@withContext Result.failure(res.exceptionOrNull() ?: Exception("خطا در دریافت نسخه ابری"))
        val body = res.getOrNull() ?: JSONObject()
        val enc = body.optString("enc", "raw")
        val data = body.optString("data", "")
        val rawJson = network.unpackGzip(enc, data)
        restoreFromBackupJson(rawJson)
    }

    suspend fun deleteMyCloudData(): Result<Boolean> = withContext(Dispatchers.IO) {
        val session = currentSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("نشست نامعتبر"))
        val res = network.deleteMyData(session.accessToken)
        if (res.isSuccess) {
            val updated = session.copy(syncRev = 0, rawBytes = 0L, isCloudFull = false, isCloudDirty = false)
            prefs.saveUserSession(updated)
            Result.success(true)
        } else {
            Result.failure(res.exceptionOrNull() ?: Exception("خطا در حذف اطلاعات ابری"))
        }
    }

    private val tokenMutex = Mutex()

    private fun jwtExpiryMs(token: String): Long {
        return try {
            val parts = token.split(".")
            if (parts.size < 2) return 0L
            val bytes = android.util.Base64.decode(
                parts[1],
                android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP
            )
            JSONObject(String(bytes, StandardCharsets.UTF_8)).optLong("exp", 0L) * 1000L
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * Supabase access tokens live about one hour. Returns a valid token, refreshing it with the
     * refresh token when it is expired or about to expire. Serialized so two callers never use the
     * same (rotating) refresh token twice.
     */
    suspend fun freshAccessToken(): String = withContext(Dispatchers.IO) {
        tokenMutex.withLock {
            val s = prefs.getUserSession()
            if (s.accessToken.isBlank()) return@withLock ""
            val exp = jwtExpiryMs(s.accessToken)
            if (exp == 0L || exp - System.currentTimeMillis() > 90_000L) return@withLock s.accessToken
            if (s.refreshToken.isBlank()) return@withLock s.accessToken
            val j = network.refreshSessionToken(s.refreshToken).getOrNull() ?: return@withLock s.accessToken
            val access = j.optString("access_token", "")
            if (access.isBlank()) return@withLock s.accessToken
            prefs.saveUserSession(
                s.copy(accessToken = access, refreshToken = j.optString("refresh_token", s.refreshToken))
            )
            access
        }
    }

    private suspend fun currentSession(): UserSession {
        freshAccessToken()
        return prefs.getUserSession()
    }

    private suspend fun isLocalEmpty(): Boolean {
        return dao.getAllPropertiesNow().isEmpty() &&
            dao.getAllCustomersNow().isEmpty() &&
            dao.getAllInvestorsNow().isEmpty() &&
            dao.getAllActivityLogsNow().isEmpty()
    }

    /** A cheap fingerprint of local data; differs from the stored one when something changed since the last sync. */
    private suspend fun localFingerprint(): String {
        val p = dao.getAllPropertiesNow()
        val c = dao.getAllCustomersNow()
        val i = dao.getAllInvestorsNow()
        val sum = p.sumOf { it.updatedAt } + c.sumOf { it.updatedAt } + i.sumOf { it.updatedAt }
        return "${p.size}:${c.size}:${i.size}:$sum"
    }

    private suspend fun buildConflict(cloudRevHint: Int): CloudConflictException {
        val session = prefs.getUserSession()
        var rev = cloudRevHint
        var cp = 0
        var cc = 0
        var ci = 0
        try {
            val g = network.syncGet(session.accessToken).getOrNull()
            if (g != null) {
                rev = g.optInt("rev", rev)
                val raw = network.unpackGzip(g.optString("enc", "raw"), g.optString("data", ""))
                val parsed = BackupExportManager.validateAndParseBackupJson(raw).getOrNull()
                if (parsed != null) {
                    cp = parsed.properties.size
                    cc = parsed.customers.size
                    ci = parsed.investors.size
                }
            }
        } catch (_: Exception) {
        }
        return CloudConflictException(
            CloudConflictInfo(
                cloudRev = rev,
                cloudProps = cp,
                cloudCusts = cc,
                cloudInvs = ci,
                localProps = dao.getAllPropertiesNow().size,
                localCusts = dao.getAllCustomersNow().size,
                localInvs = dao.getAllInvestorsNow().size
            )
        )
    }

    /** Downloads the account's cloud data (sync_get) and replaces local data with it. A local snapshot is taken first. */
    suspend fun pullFromCloud(): Result<String> = withContext(Dispatchers.IO) {
        val session = currentSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("ابتدا وارد حساب شو"))
        val g = network.syncGet(session.accessToken)
        if (g.isFailure) {
            return@withContext Result.failure(g.exceptionOrNull() ?: Exception("دریافت اطلاعات از حساب انجام نشد"))
        }
        val body = g.getOrNull() ?: JSONObject()
        val raw = network.unpackGzip(body.optString("enc", "raw"), body.optString("data", ""))
        if (raw.isBlank()) return@withContext Result.failure(Exception("اطلاعات ابری خالی است"))
        takeLocalSnapshot("قبل از دریافت از ابر", force = true)
        val res = restoreFromBackupJson(raw)
        if (res.isFailure) return@withContext res
        val rev = body.optInt("rev", session.syncRev)
        val fresh = prefs.getUserSession()
        val updated = fresh.copy(
            syncRev = rev,
            lastSyncAt = System.currentTimeMillis(),
            rawBytes = body.optLong("raw_bytes", raw.toByteArray(StandardCharsets.UTF_8).size.toLong()),
            isCloudDirty = false,
            isCloudFull = false,
            syncStatusText = "اطلاعات از حساب دریافت شد (نسخه ${PersianFormatters.toFa(rev)})"
        )
        prefs.saveUserSession(updated)
        prefs.setSyncOwner(updated.userId)
        prefs.setSyncFingerprint(localFingerprint())
        Result.success("اطلاعاتت از حساب برگشت. " + (res.getOrNull() ?: ""))
    }

    /** Resolves a conflict in favour of this phone: reads the cloud revision, then overwrites the cloud. */
    suspend fun keepPhoneDataAndPush(): Result<String> = withContext(Dispatchers.IO) {
        val session = currentSession()
        if (session.accessToken.isBlank()) return@withContext Result.failure(Exception("ابتدا وارد حساب شو"))
        val meta = network.syncMeta(session.accessToken)
        if (meta.isFailure) {
            return@withContext Result.failure(meta.exceptionOrNull() ?: Exception("ارتباط با سرور برقرار نشد"))
        }
        val body = meta.getOrNull() ?: JSONObject()
        val rev = body.optInt("rev", 0)
        val quota = body.optLong("quota", session.quotaBytes)
        val withRev = session.copy(syncRev = rev)
        prefs.saveUserSession(withRev)
        pushToCloud(withRev, quota)
    }

    private suspend fun pushToCloud(session: UserSession, cloudQuota: Long): Result<String> {
        val json = exportFullBackupJson()
        val rawLen = json.toByteArray(StandardCharsets.UTF_8).size.toLong()
        if (rawLen >= cloudQuota) {
            prefs.saveUserSession(session.copy(isCloudFull = true, rawBytes = rawLen, quotaBytes = cloudQuota))
            return Result.failure(
                Exception("فضای ابری پر شده است. از بخش سیستم، پاک‌سازی «فروش رفت» و «خرید کرد» را بزن.")
            )
        }
        val (enc, data) = network.encryptSyncPayload(session.userId, json)
        val params = JSONObject().apply {
            put("p_data", data)
            put("p_enc", enc)
            put("p_raw", rawLen)
            put("p_base_rev", session.syncRev)
        }
        val res = network.callSupabaseRpc(session.accessToken, "sync_put", params)
        val queuedText = "در صف آفلاین (همگام‌سازی خودکار پس از اتصال)"
        if (res.isFailure) {
            val queued = session.copy(rawBytes = rawLen, isCloudDirty = true, syncStatusText = queuedText)
            prefs.saveUserSession(queued)
            return Result.success(queuedText)
        }
        val body = res.getOrNull() ?: JSONObject()
        if (body.optBoolean("ok", false)) {
            val newRev = body.optInt("rev", session.syncRev + 1)
            val quota = body.optLong("quota", cloudQuota)
            val updated = session.copy(
                syncRev = newRev,
                lastSyncAt = System.currentTimeMillis(),
                rawBytes = rawLen,
                quotaBytes = quota,
                isCloudFull = false,
                isCloudDirty = false,
                syncStatusText = "همگام‌سازی ابری موفق (نسخه ${PersianFormatters.toFa(newRev)})"
            )
            prefs.saveUserSession(updated)
            prefs.setSyncOwner(session.userId)
            prefs.setSyncFingerprint(localFingerprint())
            return Result.success(updated.syncStatusText)
        }
        return when (body.optString("reason", "")) {
            "quota" -> {
                prefs.saveUserSession(session.copy(isCloudFull = true, rawBytes = rawLen))
                Result.failure(Exception("فضای ابری پر شده است. از بخش سیستم، پاک‌سازی «فروش رفت» و «خرید کرد» را بزن."))
            }
            "conflict" -> Result.failure(buildConflict(body.optInt("rev", session.syncRev)))
            else -> {
                prefs.saveUserSession(session.copy(rawBytes = rawLen, isCloudDirty = true, syncStatusText = queuedText))
                Result.success(queuedText)
            }
        }
    }

    /**
     * Cloud sync, same logic as reconcile() in the reference auth-module.js:
     * pulls the account data when the phone is empty or unchanged, asks the user on a real conflict,
     * otherwise pushes local changes.
     */
    suspend fun performCloudSync(): Result<String> = withContext(Dispatchers.IO) {
        var session = currentSession()
        takeLocalSnapshot("همگام‌سازی روزانه", force = false)

        if (session.accessToken.isBlank()) {
            val json = exportFullBackupJson()
            val rawLen = json.toByteArray(StandardCharsets.UTF_8).size.toLong()
            val updated = session.copy(
                lastSyncAt = System.currentTimeMillis(),
                rawBytes = rawLen,
                syncStatusText = "پشتیبان محلی ذخیره شد"
            )
            prefs.saveUserSession(updated)
            return@withContext Result.success(updated.syncStatusText)
        }

        val metaRes = network.syncMeta(session.accessToken)
        if (metaRes.isFailure) {
            val text = "در صف آفلاین (همگام‌سازی خودکار پس از اتصال)"
            prefs.saveUserSession(session.copy(isCloudDirty = true, syncStatusText = text))
            return@withContext Result.success(text)
        }
        val meta = metaRes.getOrNull() ?: JSONObject()
        val cloudRev = meta.optInt("rev", 0)
        val cloudQuota = meta.optLong("quota", session.quotaBytes)
        val me = session.userId
        val owner = prefs.getSyncOwner()

        // A different account was used on this phone before: keep a snapshot, then start clean.
        if (owner.isNotBlank() && me.isNotBlank() && owner != me) {
            takeLocalSnapshot("قبل از تغییر حساب", force = true)
            dao.replaceEntireDatabaseTransaction(
                properties = emptyList(),
                customers = emptyList(),
                investors = emptyList(),
                matches = emptyList(),
                activities = emptyList(),
                advisors = emptyList()
            )
            prefs.setSyncFingerprint("")
            session = session.copy(syncRev = 0, isCloudDirty = false)
            prefs.saveUserSession(session)
        }

        val localEmpty = isLocalEmpty()
        val owned = owner == me
        val dirty = session.isCloudDirty || prefs.getSyncFingerprint() != localFingerprint()

        if (cloudRev > session.syncRev) {
            if (localEmpty || (owned && !dirty)) return@withContext pullFromCloud()
            return@withContext Result.failure(buildConflict(cloudRev))
        }
        if (cloudRev < session.syncRev) {
            session = session.copy(syncRev = cloudRev)
            prefs.saveUserSession(session)
        }
        if (cloudRev == 0 && localEmpty) {
            prefs.setSyncOwner(me)
            return@withContext Result.success("حسابت آماده است؛ با اولین ثبت، اطلاعاتت همگام می‌شود")
        }
        if (owned && !dirty && cloudRev == session.syncRev && cloudRev > 0) {
            return@withContext Result.success("اطلاعات این گوشی با حساب همگام است")
        }
        pushToCloud(session, cloudQuota)
    }
}

data class CloudConflictInfo(
    val cloudRev: Int,
    val cloudProps: Int,
    val cloudCusts: Int,
    val cloudInvs: Int,
    val localProps: Int,
    val localCusts: Int,
    val localInvs: Int
)

class CloudConflictException(val info: CloudConflictInfo) : Exception("cloud_conflict")
