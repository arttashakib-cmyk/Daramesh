package ir.daramash.app.domain.usecase

import ir.daramash.app.domain.model.Property
import kotlin.math.roundToLong

/**
 * رادار بازار — تحلیل آفلاین میانگین قیمت هر مترمربع فایل‌های فروشنده فعال.
 * تمام محاسبات محلی و بدون وابستگی به شبکه یا AI.
 */
object MarketRadarUseCase {

    fun isEligible(p: Property): Boolean {
        if (p.isArchived) return false
        if (p.status != "فروشنده") return false
        if (PersianFormatters.isSoldStatus(p.status)) return false
        if (p.area <= 0) return false
        if (p.totalPrice <= 0L) return false
        return true
    }

    fun pricePerSqm(p: Property): Long {
        if (p.area <= 0 || p.totalPrice <= 0L) return 0L
        return p.totalPrice / p.area
    }

    fun eligibleProperties(all: List<Property>): List<Property> =
        all.filter { isEligible(it) }

    enum class AreaBucket(val labelFa: String, val minExclusive: Int, val maxInclusive: Int) {
        UP_TO_50("تا ۵۰ متر", Int.MIN_VALUE, 50),
        A51_60("بیشتر از ۵۰ تا ۶۰ متر", 50, 60),
        A61_70("بیشتر از ۶۰ تا ۷۰ متر", 60, 70),
        A71_80("بیشتر از ۷۰ تا ۸۰ متر", 70, 80),
        A81_90("بیشتر از ۸۰ تا ۹۰ متر", 80, 90),
        A91_100("بیشتر از ۹۰ تا ۱۰۰ متر", 90, 100),
        A101_120("بیشتر از ۱۰۰ تا ۱۲۰ متر", 100, 120),
        OVER_120("بیشتر از ۱۲۰ متر", 120, Int.MAX_VALUE);
        fun contains(area: Int): Boolean = area > minExclusive && area <= maxInclusive
        companion object {
            fun of(area: Int): AreaBucket? = entries.firstOrNull { it.contains(area) }
        }
    }

    enum class BedroomBucket(val labelFa: String) {
        ZERO("بدون خواب"), ONE("یک خواب"), TWO("دو خواب"), THREE("سه خواب"), FOUR_PLUS("چهار خواب و بیشتر");
        companion object {
            fun of(bedrooms: Int): BedroomBucket? = when {
                bedrooms < 0 -> null
                bedrooms == 0 -> ZERO
                bedrooms == 1 -> ONE
                bedrooms == 2 -> TWO
                bedrooms == 3 -> THREE
                bedrooms >= 4 -> FOUR_PLUS
                else -> null
            }
        }
    }

    enum class AgeBucket(val labelFa: String, val minInclusive: Int, val maxExclusive: Int) {
        NEW("نوساز (کمتر از ۲ سال)", 0, 2),
        A2_5("۲ تا کمتر از ۵ سال", 2, 5),
        A5_10("۵ تا کمتر از ۱۰ سال", 5, 10),
        A10_15("۱۰ تا کمتر از ۱۵ سال", 10, 15),
        A15_22("۱۵ تا کمتر از ۲۲ سال", 15, 22),
        A22_27("۲۲ تا ۲۷ سال", 22, 28);
        fun contains(age: Int): Boolean = age >= minInclusive && age < maxExclusive
        companion object {
            fun of(age: Int): AgeBucket? {
                if (age < 0) return null
                return entries.firstOrNull { it.contains(age) }
            }
        }
    }

    /**
     * Exclusive amenity classification — each property maps to at most one display label.
     * Spec: 16 Boolean combinations; 5 of them split by floor → 26 possible display groups.
     */
    data class IndependentAmenityCounts(
        val withElevator: Int,
        val withoutElevator: Int,
        val withParking: Int,
        val withoutParking: Int,
        val withStorage: Int,
        val withoutStorage: Int,
        val withTerrace: Int,
        val withoutTerrace: Int
    ) {
        companion object {
            fun from(props: List<Property>): IndependentAmenityCounts {
                var e1 = 0; var e0 = 0; var p1 = 0; var p0 = 0
                var s1 = 0; var s0 = 0; var t1 = 0; var t0 = 0
                for (p in props) {
                    if (p.elevator) e1++ else e0++
                    if (p.parking) p1++ else p0++
                    if (p.storage) s1++ else s0++
                    if (p.terrace) t1++ else t0++
                }
                return IndependentAmenityCounts(e1, e0, p1, p0, s1, s0, t1, t0)
            }
        }
    }

    private val FLOOR_1_2 = "طبقات اول و دوم"
    private val FLOOR_3 = "طبقه سوم"
    private val FLOOR_4 = "طبقه چهارم"

    /**
     * Classify a property into exactly one exclusive amenity display label, or null when
     * the combination is floor-dependent and unitFloor is invalid (not in 1..4).
     */
    fun classifyExclusive(p: Property): String? {
        val e = p.elevator
        val pk = p.parking
        val s = p.storage
        val t = p.terrace
        val base = when {
            !e && !pk && !s && !t -> "بدون هیچ امکانات"
            !e && !pk && !s && t -> "فقط تراس‌دار"
            !e && !pk && s && !t -> "فقط انباری‌دار"
            !e && !pk && s && t -> "انباری و تراس‌دار"
            !e && pk && !s && !t -> "پارکینگ‌دار (بدون آسانسور)"
            !e && pk && !s && t -> "پارکینگ و تراس‌دار"
            !e && pk && s && !t -> "پارکینگ، انباری‌دار (بدون آسانسور)"
            !e && pk && s && t -> "پارکینگ، انباری و تراس‌دار"
            e && !pk && !s && !t -> "آسانسوردار بدون پارکینگ"
            e && !pk && !s && t -> "آسانسور، تراس‌دار"
            e && !pk && s && !t -> "آسانسور، انباری‌دار"
            e && !pk && s && t -> "آسانسور، انباری، تراس‌دار"
            e && pk && !s && !t -> "آسانسور و پارکینگ‌دار"
            e && pk && !s && t -> "آسانسور، پارکینگ و تراس‌دار"
            e && pk && s && !t -> "فول امکانات"
            e && pk && s && t -> "فول امکانات + تراس"
            else -> return null // unreachable for Boolean quadruples
        }
        val floorSplit = !e && when (base) {
            "بدون هیچ امکانات",
            "پارکینگ‌دار (بدون آسانسور)",
            "پارکینگ و تراس‌دار",
            "پارکینگ، انباری‌دار (بدون آسانسور)",
            "پارکینگ، انباری و تراس‌دار" -> true
            else -> false
        }
        if (!floorSplit) return base
        val floorLabel = when (p.unitFloor) {
            1, 2 -> FLOOR_1_2
            3 -> FLOOR_3
            4 -> FLOOR_4
            else -> return null
        }
        return "$base — $floorLabel"
    }

    /** All 26 exclusive display labels (stable order for tests/UI). */
    fun allExclusiveDisplayLabels(): List<String> {
        val noFloor = listOf(
            "فقط تراس‌دار",
            "فقط انباری‌دار",
            "انباری و تراس‌دار",
            "آسانسوردار بدون پارکینگ",
            "آسانسور، تراس‌دار",
            "آسانسور، انباری‌دار",
            "آسانسور، انباری، تراس‌دار",
            "آسانسور و پارکینگ‌دار",
            "آسانسور، پارکینگ و تراس‌دار",
            "فول امکانات",
            "فول امکانات + تراس"
        )
        val bases = listOf(
            "بدون هیچ امکانات",
            "پارکینگ‌دار (بدون آسانسور)",
            "پارکینگ و تراس‌دار",
            "پارکینگ، انباری‌دار (بدون آسانسور)",
            "پارکینگ، انباری و تراس‌دار"
        )
        val floors = listOf(FLOOR_1_2, FLOOR_3, FLOOR_4)
        return bases.flatMap { b -> floors.map { f -> "$b — $f" } } + noFloor
    }

    val CONDITION_OPTIONS = listOf("نوساز", "بازسازی شده", "تمیز", "نقاشی‌شده", "نیاز به بازسازی")
    val LIGHTING_OPTIONS = listOf(
        "خطی پرده خور", "دوکله نور جنوبی", "دوکله نور شمالی",
        "خواب رو به بیرون", "فول پاسیو", "پاسیو باز", "سالن پرده خور"
    )

    data class RadarFilter(
        val neighborhood: String? = null,
        val areaBucket: AreaBucket? = null,
        val bedroomBucket: BedroomBucket? = null,
        val ageBucket: AgeBucket? = null,
        /** Independent amenity filters: null = no filter. */
        val elevator: Boolean? = null,
        val parking: Boolean? = null,
        val storage: Boolean? = null,
        val terrace: Boolean? = null,
        /** Optional floor set (e.g. setOf(1,2)); null = no floor filter. */
        val floors: Set<Int>? = null,
        val condition: String? = null,
        val lighting: String? = null
    ) {
        fun activeCount(): Int {
            var n = 0
            if (neighborhood != null) n++
            if (areaBucket != null) n++
            if (bedroomBucket != null) n++
            if (ageBucket != null) n++
            if (elevator != null) n++
            if (parking != null) n++
            if (storage != null) n++
            if (terrace != null) n++
            if (floors != null) n++
            if (condition != null) n++
            if (lighting != null) n++
            return n
        }
    }

    fun applyFilter(list: List<Property>, f: RadarFilter): List<Property> {
        return list.filter { p ->
            if (!isEligible(p)) return@filter false
            if (f.neighborhood != null && p.neighborhood != f.neighborhood) return@filter false
            if (f.areaBucket != null && AreaBucket.of(p.area) != f.areaBucket) return@filter false
            if (f.bedroomBucket != null) {
                val b = BedroomBucket.of(p.bedrooms)
                if (b == null || b != f.bedroomBucket) return@filter false
            }
            if (f.ageBucket != null) {
                val a = AgeBucket.of(p.buildingAge)
                if (a == null || a != f.ageBucket) return@filter false
            }
            if (f.elevator != null && p.elevator != f.elevator) return@filter false
            if (f.parking != null && p.parking != f.parking) return@filter false
            if (f.storage != null && p.storage != f.storage) return@filter false
            if (f.terrace != null && p.terrace != f.terrace) return@filter false
            if (f.floors != null) {
                if (p.unitFloor <= 0 || p.unitFloor !in f.floors!!) return@filter false
            }
            if (f.condition != null && (p.condition.isBlank() || p.condition != f.condition)) return@filter false
            if (f.lighting != null) {
                // Invalid / non-form lighting filter must not produce matches.
                if (f.lighting !in LIGHTING_OPTIONS) return@filter false
                if (p.lighting != f.lighting) return@filter false
            }
            true
        }
    }

    data class PriceStats(
        val count: Int,
        val average: Long,
        val median: Long,
        val min: Long,
        val max: Long,
        val sampleLabel: String
    ) {
        companion object {
            val EMPTY = PriceStats(0, 0, 0, 0, 0, "داده کافی موجود نیست")
            fun from(prices: List<Long>): PriceStats {
                if (prices.isEmpty()) return EMPTY
                val sorted = prices.sorted()
                val avg = (sorted.sum().toDouble() / sorted.size).roundToLong()
                val med = if (sorted.size % 2 == 1) sorted[sorted.size / 2]
                else ((sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0).roundToLong()
                return PriceStats(sorted.size, avg, med, sorted.first(), sorted.last(), sampleReliability(sorted.size))
            }
            fun sampleReliability(n: Int): String = when {
                n <= 0 -> "داده کافی موجود نیست"
                n <= 2 -> "داده ناکافی"
                n <= 5 -> "نمونه محدود"
                n <= 10 -> "نمونه قابل بررسی"
                else -> "نمونه مناسب‌تر برای مقایسه"
            }
        }
    }

    data class NeighborhoodSummary(val name: String, val stats: PriceStats, val properties: List<Property>, val amenityCounts: IndependentAmenityCounts)
    data class GroupSummary(val key: String, val label: String, val stats: PriceStats, val properties: List<Property>)
    data class MarketOverview(
        val totalEligible: Int,
        val neighborhoodCount: Int,
        val overallStats: PriceStats,
        val neighborhoods: List<NeighborhoodSummary>
    )

    fun computeOverview(all: List<Property>): MarketOverview {
        val eligible = eligibleProperties(all)
        val overall = PriceStats.from(eligible.map { pricePerSqm(it) })
        val byNb = eligible.filter { it.neighborhood.isNotBlank() }
            .groupBy { it.neighborhood }
            .map { (name, props) ->
                NeighborhoodSummary(
                    name,
                    PriceStats.from(props.map { pricePerSqm(it) }),
                    props,
                    IndependentAmenityCounts.from(props)
                )
            }
            .sortedByDescending { it.stats.count }
        return MarketOverview(eligible.size, byNb.size, overall, byNb)
    }

    data class NeighborhoodDetail(
        val neighborhood: String,
        val stats: PriceStats,
        val properties: List<Property>,
        val byArea: List<GroupSummary>,
        val byBedrooms: List<GroupSummary>,
        val byAge: List<GroupSummary>,
        val byAmenity: List<GroupSummary>,
        val byCondition: List<GroupSummary>,
        val byLighting: List<GroupSummary>
    )

    fun computeNeighborhoodDetail(
        all: List<Property>,
        neighborhood: String,
        filter: RadarFilter = RadarFilter()
    ): NeighborhoodDetail {
        val base = eligibleProperties(all).filter { it.neighborhood == neighborhood }
        val filtered = applyFilter(base, filter.copy(neighborhood = neighborhood))
        val stats = PriceStats.from(filtered.map { pricePerSqm(it) })

        fun groupBy(keyOf: (Property) -> String?, labelOf: (String) -> String = { it }): List<GroupSummary> =
            filtered.mapNotNull { p -> keyOf(p)?.let { it to p } }
                .groupBy({ it.first }, { it.second })
                .map { (k, props) -> GroupSummary(k, labelOf(k), PriceStats.from(props.map { pricePerSqm(it) }), props) }
                .sortedByDescending { it.stats.count }

        val byArea = AreaBucket.entries.mapNotNull { bucket ->
            val props = filtered.filter { AreaBucket.of(it.area) == bucket }
            if (props.isEmpty()) null else GroupSummary(bucket.name, bucket.labelFa, PriceStats.from(props.map { pricePerSqm(it) }), props)
        }
        val byBeds = BedroomBucket.entries.mapNotNull { bucket ->
            val props = filtered.filter { BedroomBucket.of(it.bedrooms) == bucket }
            if (props.isEmpty()) null else GroupSummary(bucket.name, bucket.labelFa, PriceStats.from(props.map { pricePerSqm(it) }), props)
        }
        val byAge = AgeBucket.entries.mapNotNull { bucket ->
            val props = filtered.filter { AgeBucket.of(it.buildingAge) == bucket }
            if (props.isEmpty()) null else GroupSummary(bucket.name, bucket.labelFa, PriceStats.from(props.map { pricePerSqm(it) }), props)
        }
        // Exclusive amenity groups: at most one group per property.
        val byAmenity = filtered.mapNotNull { p -> classifyExclusive(p)?.let { label -> label to p } }
            .groupBy({ it.first }, { it.second })
            .map { (label, props) ->
                GroupSummary(label, label, PriceStats.from(props.map { pricePerSqm(it) }), props)
            }
            .sortedByDescending { it.stats.count }
        val byCondition = groupBy({ p -> p.condition.takeIf { it.isNotBlank() && it in CONDITION_OPTIONS } })
        // Only registration-form lighting options; blank/unknown values excluded from lighting groups only.
        val byLighting = groupBy({ p -> p.lighting.takeIf { it.isNotBlank() && it in LIGHTING_OPTIONS } })

        return NeighborhoodDetail(neighborhood, stats, filtered, byArea, byBeds, byAge, byAmenity, byCondition, byLighting)
    }

    /** Stable identity for a statistical group (avoids caching a stale GroupSummary snapshot). */
    data class GroupRef(val kind: String, val key: String)

    /**
     * Resolve a [GroupRef] against the latest neighborhood detail.
     * Returns null when the group no longer exists or has zero properties.
     */
    fun resolveGroup(detail: NeighborhoodDetail, ref: GroupRef): GroupSummary? {
        val list = when (ref.kind) {
            "area" -> detail.byArea
            "bedrooms" -> detail.byBedrooms
            "age" -> detail.byAge
            "amenity" -> detail.byAmenity
            "condition" -> detail.byCondition
            "lighting" -> detail.byLighting
            else -> emptyList()
        }
        return list.firstOrNull { it.key == ref.key }?.takeIf { it.properties.isNotEmpty() }
    }

    fun groupRefFor(kind: String, summary: GroupSummary): GroupRef = GroupRef(kind, summary.key)
}
