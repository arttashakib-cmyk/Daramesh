package ir.daramash.app.security

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * PKCE for the Google login. The one-time secret (code verifier) never leaves the app, so another app
 * that registers the same ir.daramash.app://auth scheme cannot use an intercepted code, and a login
 * redirect that this app did not start is ignored.
 */
object PkceLogin {
    private const val PREFS = "daramash_pending_login"
    private const val KEY_VERIFIER = "v"
    private const val KEY_AT = "t"
    private const val MAX_AGE_MS = 10 * 60 * 1000L

    private val FLAGS = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    private fun challengeOf(verifier: String): String =
        Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)), FLAGS)

    /** Starts a login: stores a fresh verifier and returns the matching code_challenge. */
    fun begin(context: Context): String {
        val bytes = ByteArray(48)
        SecureRandom().nextBytes(bytes)
        val verifier = Base64.encodeToString(bytes, FLAGS)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_VERIFIER, verifier)
            .putLong(KEY_AT, System.currentTimeMillis())
            .apply()
        return challengeOf(verifier)
    }

    /** Returns the verifier of the login this app started (once, and only for 10 minutes), else null. */
    fun consume(context: Context): String? {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val verifier = sp.getString(KEY_VERIFIER, null)
        val at = sp.getLong(KEY_AT, 0L)
        sp.edit().clear().apply()
        if (verifier.isNullOrBlank()) return null
        if (System.currentTimeMillis() - at > MAX_AGE_MS) return null
        return verifier
    }
}
