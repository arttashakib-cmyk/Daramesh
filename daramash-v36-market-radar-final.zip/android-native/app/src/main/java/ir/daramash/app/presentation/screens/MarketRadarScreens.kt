package ir.daramash.app.presentation.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.usecase.MarketRadarUseCase
import ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket
import ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket
import ir.daramash.app.domain.usecase.MarketRadarUseCase.BedroomBucket
import ir.daramash.app.domain.usecase.MarketRadarUseCase.GroupSummary
import ir.daramash.app.domain.usecase.MarketRadarUseCase.PriceStats
import ir.daramash.app.domain.usecase.MarketRadarUseCase.RadarFilter
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.presentation.theme.DaramashBorder
import ir.daramash.app.presentation.theme.DaramashMuted
import ir.daramash.app.presentation.theme.EmeraldBright
import ir.daramash.app.presentation.theme.VazirmatnFontFamily

@Composable
fun MarketRadarScreen(
    properties: List<Property>,
    onOpenProperty: (Property) -> Unit,
    /**
     * When false, app-level transient UI (drawer / search / multi-select) owns system Back.
     * Parent passes false while those overlays are active so this handler does not win
     * solely by later composition registration order.
     */
    allowNestedBack: Boolean = true
) {
    var selectedNeighborhood by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf(RadarFilter()) }
    // Stable identity only — never cache a GroupSummary snapshot (stale after edit/archive).
    var selectedGroupRef by remember { mutableStateOf<MarketRadarUseCase.GroupRef?>(null) }

    // Authoritative lighting only; clear invalid lighting selection without touching other filters.
    val safeFilter = if (filter.lighting != null && filter.lighting !in MarketRadarUseCase.LIGHTING_OPTIONS) {
        filter.copy(lighting = null)
    } else {
        filter
    }
    val onFilterChangeSafe: (RadarFilter) -> Unit = { next ->
        filter = if (next.lighting != null && next.lighting !in MarketRadarUseCase.LIGHTING_OPTIONS) {
            next.copy(lighting = null)
        } else next
    }

    // Nested system Back: group → neighborhood (keep filters) → overview.
    // Disabled while app overlays own Back so the earlier app-level BackHandler handles them.
    // Overview (no nested state) leaves Back to the app handler (MARKET_RADAR → HOME).
    BackHandler(
        enabled = allowNestedBack && (selectedGroupRef != null || selectedNeighborhood != null)
    ) {
        when {
            selectedGroupRef != null -> {
                selectedGroupRef = null
            }
            selectedNeighborhood != null -> {
                selectedNeighborhood = null
                filter = RadarFilter()
                selectedGroupRef = null
            }
        }
    }

    when {
        selectedGroupRef != null && selectedNeighborhood != null -> {
            val detail = remember(properties, selectedNeighborhood, safeFilter) {
                MarketRadarUseCase.computeNeighborhoodDetail(properties, selectedNeighborhood!!, safeFilter)
            }
            val liveGroup = remember(detail, selectedGroupRef) {
                selectedGroupRef?.let { MarketRadarUseCase.resolveGroup(detail, it) }
            }
            if (liveGroup == null) {
                // Group vanished or empty after data change — return to neighborhood safely.
                LaunchedEffect(selectedGroupRef, detail) { selectedGroupRef = null }
                NeighborhoodRadarScreen(
                    properties, selectedNeighborhood!!, safeFilter,
                    onFilterChangeSafe,
                    { selectedNeighborhood = null; filter = RadarFilter(); selectedGroupRef = null },
                    { kind, g -> selectedGroupRef = MarketRadarUseCase.groupRefFor(kind, g) },
                    onOpenProperty
                )
            } else {
                GroupDetailScreen(liveGroup, { selectedGroupRef = null }, onOpenProperty)
            }
        }
        selectedNeighborhood != null -> NeighborhoodRadarScreen(
            properties, selectedNeighborhood!!, safeFilter,
            onFilterChangeSafe,
            { selectedNeighborhood = null; filter = RadarFilter(); selectedGroupRef = null },
            { kind, g -> selectedGroupRef = MarketRadarUseCase.groupRefFor(kind, g) },
            onOpenProperty
        )
        else -> MarketRadarDashboard(properties) {
            selectedNeighborhood = it
            filter = RadarFilter()
            selectedGroupRef = null
        }
    }
}

@Composable
private fun MarketRadarDashboard(properties: List<Property>, onSelectNeighborhood: (String) -> Unit) {
    val overview = remember(properties) { MarketRadarUseCase.computeOverview(properties) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("رادار بازار", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
            Text(
                "ارزیابی سریع بازار بر اساس همهٔ فایل‌های فروشنده فعال — بدون فیلتر اولیه",
                fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily,
                modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
            Text(
                "برای بررسی دقیق‌تر، یک محله را انتخاب کنید و فیلترها را دستی اعمال کنید.",
                fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatMiniCard("فایل معتبر", PersianFormatters.toFa(overview.totalEligible.toString()), Modifier.weight(1f))
                StatMiniCard("محله‌ها", PersianFormatters.toFa(overview.neighborhoodCount.toString()), Modifier.weight(1f))
            }
        }
        item {
            RadarCard {
                Text("میانگین کل بازار", fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                Spacer(Modifier.height(4.dp))
                if (overview.overallStats.count == 0) {
                    Text("داده کافی موجود نیست", fontSize = 15.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                } else {
                    Text(formatPpm(overview.overallStats.average), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                    Spacer(Modifier.height(6.dp))
                    StatsRow(overview.overallStats)
                }
            }
        }
        item {
            Text("محله‌ها", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily, modifier = Modifier.padding(top = 4.dp))
        }
        if (overview.neighborhoods.isEmpty()) {
            item { RadarCard { Text("هنوز فایل فروشنده فعالی با محله ثبت‌شده وجود ندارد.", fontSize = 13.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily) } }
        } else {
            items(overview.neighborhoods, key = { it.name }) { nb ->
                RadarCard(onClick = { onSelectNeighborhood(nb.name) }) {
                    Text(nb.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (nb.stats.count == 0) "—" else formatPpm(nb.stats.average),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldBright,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text("میانگین قیمت هر مترمربع", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "${PersianFormatters.toFa(nb.stats.count.toString())} فایل واجد شرایط · ${nb.stats.sampleLabel}",
                        fontSize = 11.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                    if (nb.stats.count > 0) {
                        Text(
                            "کمینه ${formatPpm(nb.stats.min)}  ·  بیشینه ${formatPpm(nb.stats.max)}",
                            fontSize = 10.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    val ac = nb.amenityCounts
                    Text(
                        "🛗 ${PersianFormatters.toFa(ac.withElevator.toString())}  ·  🚗 ${PersianFormatters.toFa(ac.withParking.toString())}  ·  📦 ${PersianFormatters.toFa(ac.withStorage.toString())}  ·  🌿 ${PersianFormatters.toFa(ac.withTerrace.toString())}",
                        fontSize = 11.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NeighborhoodRadarScreen(
    properties: List<Property>,
    neighborhood: String,
    filter: RadarFilter,
    onFilterChange: (RadarFilter) -> Unit,
    onBack: () -> Unit,
    onOpenGroup: (String, GroupSummary) -> Unit,
    onOpenProperty: (Property) -> Unit
) {
    val detail = remember(properties, neighborhood, filter) {
        MarketRadarUseCase.computeNeighborhoodDetail(properties, neighborhood, filter)
    }
    var showFilters by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("← بازگشت", fontSize = 13.sp, color = EmeraldBright, fontFamily = VazirmatnFontFamily, modifier = Modifier.clickable { onBack() })
            Column(Modifier.weight(1f)) {
                Text(neighborhood, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("رادار محله", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            }
            Text(
                if (showFilters) "بستن فیلتر" else "فیلترها${if (filter.activeCount() > 0) " (${PersianFormatters.toFa(filter.activeCount().toString())})" else ""}",
                fontSize = 12.sp, color = if (filter.activeCount() > 0) EmeraldBright else EmeraldBright, fontFamily = VazirmatnFontFamily,
                modifier = Modifier.clickable { showFilters = !showFilters }
            )
        }
        if (showFilters) {
            RadarFiltersPanel(filter, properties, neighborhood, onFilterChange)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                RadarCard {
                    val filtered = filter.activeCount() > 0
                    Text(
                        if (filtered) "آمار بخش انتخاب‌شده (فیلتر فعال)" else "آمار کامل محله (بدون فیلتر)",
                        fontSize = 12.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                    Spacer(Modifier.height(4.dp))
                    if (detail.stats.count == 0) Text("داده کافی موجود نیست", fontSize = 15.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    else {
                        Text(formatPpm(detail.stats.average), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                        Text("میانگین قیمت هر مترمربع", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        StatsRow(detail.stats)
                    }
                }
            }
            item { SectionTitle("بر اساس متراژ") }
            items(detail.byArea, key = { "a_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("area", g) } }
            if (detail.byArea.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس تعداد خواب") }
            items(detail.byBedrooms, key = { "b_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("bedrooms", g) } }
            if (detail.byBedrooms.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس سن بنا") }
            items(detail.byAge, key = { "age_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("age", g) } }
            if (detail.byAge.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس امکانات") }
            items(detail.byAmenity, key = { "am_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("amenity", g) } }
            if (detail.byAmenity.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس وضعیت داخلی") }
            items(detail.byCondition, key = { "c_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("condition", g) } }
            if (detail.byCondition.isEmpty()) item { EmptyHint() }
            item { SectionTitle("بر اساس نور") }
            items(detail.byLighting, key = { "l_${it.key}" }) { g -> GroupRow(g) { onOpenGroup("lighting", g) } }
            if (detail.byLighting.isEmpty()) item { EmptyHint() }
            item { SectionTitle("فایل‌های مشارکت‌کننده (${PersianFormatters.toFa(detail.properties.size.toString())})") }
            items(detail.properties, key = { it.id }) { p -> PropertyRadarRow(p) { onOpenProperty(p) } }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RadarFiltersPanel(filter: RadarFilter, properties: List<Property>, neighborhood: String, onFilterChange: (RadarFilter) -> Unit) {
    val eligibleInNb = remember(properties, neighborhood) {
        MarketRadarUseCase.eligibleProperties(properties).filter { it.neighborhood == neighborhood }
    }
    // Chips only from registration-form options that appear in current eligible data.
    val availableLightings = remember(eligibleInNb) {
        MarketRadarUseCase.LIGHTING_OPTIONS.filter { opt ->
            eligibleInNb.any { it.lighting == opt }
        }
    }
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF121018)).border(BorderStroke(1.dp, DaramashBorder))
            .padding(12.dp).height(260.dp).verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("فیلترهای تجمعی", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily)
            if (filter.activeCount() > 0) {
                Text("پاک کردن همه", fontSize = 12.sp, color = Color(0xFFFF6B6B), fontFamily = VazirmatnFontFamily,
                    modifier = Modifier.clickable { onFilterChange(RadarFilter(neighborhood = neighborhood)) })
            }
        }
        Spacer(Modifier.height(8.dp))
        FilterChipSection("متراژ", AreaBucket.entries.map { it.labelFa to (filter.areaBucket == it) }) { i ->
            val b = AreaBucket.entries[i]; onFilterChange(filter.copy(areaBucket = if (filter.areaBucket == b) null else b))
        }
        FilterChipSection("خواب", BedroomBucket.entries.map { it.labelFa to (filter.bedroomBucket == it) }) { i ->
            val b = BedroomBucket.entries[i]; onFilterChange(filter.copy(bedroomBucket = if (filter.bedroomBucket == b) null else b))
        }
        FilterChipSection("سن بنا", AgeBucket.entries.map { it.labelFa to (filter.ageBucket == it) }) { i ->
            val b = AgeBucket.entries[i]; onFilterChange(filter.copy(ageBucket = if (filter.ageBucket == b) null else b))
        }
        FilterChipSection("وضعیت داخلی", MarketRadarUseCase.CONDITION_OPTIONS.map { it to (filter.condition == it) }) { i ->
            val c = MarketRadarUseCase.CONDITION_OPTIONS[i]; onFilterChange(filter.copy(condition = if (filter.condition == c) null else c))
        }
        if (availableLightings.isNotEmpty()) {
            FilterChipSection("نور", availableLightings.map { it to (filter.lighting == it) }) { i ->
                val l = availableLightings[i]; onFilterChange(filter.copy(lighting = if (filter.lighting == l) null else l))
            }
        }
        // Independent Boolean amenity filters (AND). Cycle: no filter → has → lacks → no filter.
        TriStateAmenitySection("آسانسور", filter.elevator) { v -> onFilterChange(filter.copy(elevator = v)) }
        TriStateAmenitySection("پارکینگ", filter.parking) { v -> onFilterChange(filter.copy(parking = v)) }
        TriStateAmenitySection("انباری", filter.storage) { v -> onFilterChange(filter.copy(storage = v)) }
        TriStateAmenitySection("تراس", filter.terrace) { v -> onFilterChange(filter.copy(terrace = v)) }
        FilterChipSection(
            "طبقه",
            listOf(
                "۱ و ۲" to (filter.floors == setOf(1, 2)),
                "۳" to (filter.floors == setOf(3)),
                "۴" to (filter.floors == setOf(4))
            )
        ) { i ->
            val sets = listOf(setOf(1, 2), setOf(3), setOf(4))
            val s = sets[i]
            onFilterChange(filter.copy(floors = if (filter.floors == s) null else s))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TriStateAmenitySection(title: String, value: Boolean?, onChange: (Boolean?) -> Unit) {
    Text(title, fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(
            "بدون فیلتر" to null,
            "دارد" to true,
            "ندارد" to false
        ).forEach { (label, state) ->
            val active = value == state
            val bg = if (active) EmeraldBright.copy(alpha = 0.22f) else Color(0xFF1A1620)
            val border = if (active) EmeraldBright else DaramashBorder
            val fg = if (active) EmeraldBright else Color.White
            Box(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(bg)
                    .border(BorderStroke(1.dp, border), RoundedCornerShape(10.dp))
                    .clickable { onChange(state) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(label, fontSize = 11.sp, color = fg, fontFamily = VazirmatnFontFamily)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FilterChipSection(title: String, items: List<Pair<String, Boolean>>, onToggle: (Int) -> Unit) {
    Text(title, fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEachIndexed { i, (label, active) ->
            val bg = if (active) EmeraldBright.copy(alpha = 0.22f) else Color(0xFF1A1620)
            val border = if (active) EmeraldBright else DaramashBorder
            val fg = if (active) EmeraldBright else Color.White
            Box(Modifier.clip(RoundedCornerShape(10.dp)).background(bg).border(1.dp, border, RoundedCornerShape(10.dp)).clickable { onToggle(i) }.padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text(label, fontSize = 11.sp, color = fg, fontFamily = VazirmatnFontFamily, maxLines = 2)
            }
        }
    }
}

@Composable
private fun GroupDetailScreen(group: GroupSummary, onBack: () -> Unit, onOpenProperty: (Property) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("← بازگشت", fontSize = 13.sp, color = EmeraldBright, fontFamily = VazirmatnFontFamily, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(10.dp))
            Text(group.label, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                RadarCard {
                    if (group.stats.count == 0) Text("داده کافی موجود نیست", color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    else {
                        Text(formatPpm(group.stats.average), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp)); StatsRow(group.stats)
                    }
                }
            }
            item { SectionTitle("فایل‌های این گروه (${PersianFormatters.toFa(group.properties.size.toString())})") }
            items(group.properties, key = { it.id }) { p -> PropertyRadarRow(p) { onOpenProperty(p) } }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable
private fun GroupRow(g: GroupSummary, onClick: () -> Unit) {
    RadarCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(g.label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White, fontFamily = VazirmatnFontFamily, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${PersianFormatters.toFa(g.stats.count.toString())} فایل · ${g.stats.sampleLabel}", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            }
            Text(if (g.stats.count == 0) "—" else formatPpm(g.stats.average), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (g.stats.count == 0) DaramashMuted else EmeraldBright, fontFamily = VazirmatnFontFamily)
        }
    }
}

@Composable
private fun PropertyRadarRow(p: Property, onClick: () -> Unit) {
    val ppm = MarketRadarUseCase.pricePerSqm(p)
    RadarCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(
                    buildString {
                        append(if (p.code.isNotBlank()) "کد ${p.code}" else "بدون کد")
                        append(" · "); append(PersianFormatters.toFa(p.area.toString())); append(" متر")
                        if (p.bedrooms > 0) append(" · ${PersianFormatters.toFa(p.bedrooms.toString())} خواب")
                    },
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily
                )
                Text(
                    buildString {
                        if (p.buildingAge >= 0) append("سن ${PersianFormatters.toFa(p.buildingAge.toString())} · ")
                        append(listOfNotNull(if (p.parking) "پارکینگ" else null, if (p.elevator) "آسانسور" else null, if (p.storage) "انباری" else null, if (p.terrace) "تراس" else null).joinToString("، ").ifEmpty { "بدون امکانات خاص" })
                        if (p.condition.isNotBlank()) append(" · ${p.condition}")
                        if (p.lighting.isNotBlank()) append(" · ${p.lighting}")
                    },
                    fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(formatPpm(ppm), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                Text(if (p.totalPrice > 0) PersianFormatters.formatMoneyToman(p.totalPrice) else "—", fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            }
        }
    }
}

@Composable
private fun StatsRow(s: PriceStats) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        StatCell("تعداد", PersianFormatters.toFa(s.count.toString()))
        StatCell("میانه", formatPpm(s.median))
        StatCell("کمینه", formatPpm(s.min))
        StatCell("بیشینه", formatPpm(s.max))
    }
    Text(s.sampleLabel, fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily, modifier = Modifier.padding(top = 4.dp))
}

@Composable private fun StatCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 10.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily)
    }
}

@Composable private fun StatMiniCard(title: String, value: String, modifier: Modifier = Modifier) {
    RadarCard(modifier = modifier) {
        Text(title, fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
    }
}

@Composable private fun SectionTitle(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily, modifier = Modifier.padding(top = 6.dp))
}

@Composable private fun EmptyHint() {
    Text("داده کافی موجود نیست", fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily, modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
private fun RadarCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1C1824), Color(0xFF141018))))
            .border(1.dp, DaramashBorder, shape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(12.dp),
        content = content
    )
}

private fun formatPpm(value: Long): String {
    if (value <= 0L) return "—"
    return PersianFormatters.formatMoneyToman(value) + " /متر"
}
