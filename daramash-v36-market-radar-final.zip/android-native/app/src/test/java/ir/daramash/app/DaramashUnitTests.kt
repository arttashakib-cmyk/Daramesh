package ir.daramash.app

import ir.daramash.app.data.backup.BackupExportManager
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.domain.usecase.SmartMatchEngineUseCase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DaramashUnitTests {

    private val matchEngine = SmartMatchEngineUseCase()

    @Test
    fun `test Persian and English numeral conversion and phone normalization`() {
        assertEquals("۱۰۴۲", PersianFormatters.toFa("1042"))
        assertEquals("1042", PersianFormatters.toEn("۱۰۴۲"))
        assertEquals("09121112233", PersianFormatters.normalizePhoneDigits("+98 912 111 2233"))
        assertEquals("09121112233", PersianFormatters.normalizePhoneDigits("۰۹۱۲-۱۱۱-۲۲۳۳"))
        assertEquals("۱۴ میلیارد و ۲۰۰ میلیون", PersianFormatters.formatMoneyToman(14_200_000_000L))
    }

    @Test
    fun `test Jalali calendar conversion accuracy`() {
        val (jy, jm, jd) = PersianFormatters.gregorianToJalali(2026, 3, 21)
        assertEquals(1405, jy)
        assertEquals(1, jm)
        assertEquals(1, jd)
    }

    @Test
    fun `test Privacy-safe property share never leaks owner name phone or address`() {
        val prop = Property(
            id = "p1",
            code = "1042",
            neighborhood = "پونک",
            area = 78,
            bedrooms = 2,
            totalPrice = 14_200_000_000L,
            pricePerMeter = 182_000_000L,
            sellerName = "رضا احمدی",
            sellerPhone = "09121112233",
            address = "پونک، بلوار همیلا، پلاک ۱۴"
        )
        val safeShare = PersianFormatters.formatPrivacySafePropertyShare(prop)
        assertTrue(safeShare.contains("پونک"))
        assertTrue(safeShare.contains("۷۸ متر"))
        assertFalse(safeShare.contains("رضا احمدی"))
        assertFalse(safeShare.contains("09121112233"))
        assertFalse(safeShare.contains("پلاک ۱۴"))
    }

    @Test
    fun `test SmartMatchEngineUseCase scores matching property 100 percent and rejects sold or incompatible`() {
        val customer = Customer(
            id = "c1",
            firstName = "حسین",
            lastName = "محمدی",
            neighborhoods = listOf("پونک", "همیلا"),
            areaMin = 70,
            bedroomsMin = 2,
            buildingAgeMax = 8,
            budgetMax = 15_000_000_000L,
            reqParking = true,
            reqElevator = true
        )
        val matchingProperty = Property(
            id = "p1",
            code = "1042",
            neighborhood = "پونک",
            area = 78,
            bedrooms = 2,
            buildingAge = 5,
            totalPrice = 14_200_000_000L,
            parking = true,
            elevator = true,
            status = "فروشنده"
        )

        val res = matchEngine.evaluateCustomerMatch(customer, matchingProperty)
        assertTrue(res.ok)
        assertEquals(100, res.score)

        val soldProperty = matchingProperty.copy(status = "فروش رفت")
        val soldRes = matchEngine.evaluateCustomerMatch(customer, soldProperty)
        assertFalse(soldRes.ok)
        assertEquals(0, soldRes.score)
    }

    @Test
    fun `test BackupExportManager export and validation roundtrip and corrupt rejection`() {
        val p = Property(id = "p1", code = "1042", neighborhood = "پونک", area = 85, bedrooms = 2, totalPrice = 15_000_000_000L)
        val c = Customer(id = "c1", firstName = "علی", lastName = "رضایی", phone1 = "09121112233", neighborhoods = listOf("پونک"))

        val json = BackupExportManager.exportFullBackupJson(
            properties = listOf(p),
            customers = listOf(c),
            investors = emptyList(),
            matches = emptyList(),
            activities = emptyList(),
            advisors = emptyList(),
            target = AdvisorTarget()
        )

        val parsedResult = BackupExportManager.validateAndParseBackupJson(json)
        assertTrue(parsedResult.isSuccess)
        val parsed = parsedResult.getOrThrow()
        assertEquals(1, parsed.properties.size)
        assertEquals("1042", parsed.properties.first().code)
        assertEquals(1, parsed.customers.size)
        assertEquals("علی رضایی", parsed.customers.first().fullName)

        // Corrupt JSON must fail validation gracefully
        val badResult = BackupExportManager.validateAndParseBackupJson("not-a-json")
        assertTrue(badResult.isFailure)
    }

    // ─── Market Radar ───────────────────────────────────────────────────────

    @Test
    fun `market radar only includes active seller files with valid price and area`() {
        val sellers = listOf(
            Property(id = "1", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, isArchived = false, neighborhood = "پونک"),
            Property(id = "2", status = "فروشنده", area = 0, totalPrice = 8_000_000_000L, isArchived = false, neighborhood = "پونک"),
            Property(id = "3", status = "فروشنده", area = 80, totalPrice = 0L, isArchived = false, neighborhood = "پونک"),
            Property(id = "4", status = "فروش رفت", area = 80, totalPrice = 8_000_000_000L, isArchived = false, neighborhood = "پونک"),
            Property(id = "5", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, isArchived = true, neighborhood = "پونک"),
            Property(id = "6", status = "فروشنده نیست", area = 80, totalPrice = 8_000_000_000L, isArchived = false, neighborhood = "پونک")
        )
        val eligible = ir.daramash.app.domain.usecase.MarketRadarUseCase.eligibleProperties(sellers)
        assertEquals(1, eligible.size)
        assertEquals("1", eligible.first().id)
    }

    @Test
    fun `market radar price per sqm is totalPrice divided by area`() {
        val p = Property(id = "1", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L)
        assertEquals(100_000_000L, ir.daramash.app.domain.usecase.MarketRadarUseCase.pricePerSqm(p))
    }

    @Test
    fun `market radar area buckets have no overlap`() {
        val buckets = ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.entries
        for (a in 1..150) {
            val matches = buckets.filter { it.contains(a) }
            assertTrue("area $a matched ${matches.size} buckets", matches.size <= 1)
        }
        assertEquals(ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.UP_TO_50, ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.of(50))
        assertEquals(ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.A51_60, ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.of(51))
        assertEquals(ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.OVER_120, ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.of(121))
    }

    @Test
    fun `market radar age buckets have no overlap and exclude over 27`() {
        assertEquals(ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket.NEW, ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket.of(0))
        assertEquals(ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket.A2_5, ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket.of(2))
        assertEquals(ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket.A22_27, ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket.of(27))
        assertEquals(null, ir.daramash.app.domain.usecase.MarketRadarUseCase.AgeBucket.of(28))
    }

    @Test
    fun `market radar average is arithmetic mean of per-sqm prices`() {
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 100, totalPrice = 10_000_000_000L, neighborhood = "پونک"),
            Property(id = "2", status = "فروشنده", area = 50, totalPrice = 10_000_000_000L, neighborhood = "پونک")
        )
        val overview = ir.daramash.app.domain.usecase.MarketRadarUseCase.computeOverview(props)
        assertEquals(2, overview.totalEligible)
        assertEquals(150_000_000L, overview.overallStats.average)
    }

    @Test
    fun `market radar lighting groups accept only registration form options`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک", lighting = "دوکله نور جنوبی"),
            Property(id = "2", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک", lighting = ""),
            Property(id = "3", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک", lighting = "نور سفارشی قدیمی"),
            Property(id = "4", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک", lighting = "سالن پرده خور")
        )
        val detail = radar.computeNeighborhoodDetail(props, "پونک")
        // All four remain in neighborhood stats
        assertEquals(4, detail.stats.count)
        // Only the two form-valid lightings appear in byLighting
        assertEquals(2, detail.byLighting.sumOf { it.stats.count })
        assertTrue(detail.byLighting.any { it.key == "دوکله نور جنوبی" })
        assertTrue(detail.byLighting.any { it.key == "سالن پرده خور" })
        assertFalse(detail.byLighting.any { it.key == "نور سفارشی قدیمی" })
        assertFalse(detail.byLighting.any { it.key.isBlank() })
    }

    @Test
    fun `market radar invalid lighting filter never matches properties`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک", lighting = "دوکله نور جنوبی"),
            Property(id = "2", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک", lighting = "نور سفارشی قدیمی")
        )
        val invalid = radar.RadarFilter(neighborhood = "پونک", lighting = "نور سفارشی قدیمی")
        assertEquals(0, radar.applyFilter(props, invalid).size)
        val valid = radar.RadarFilter(neighborhood = "پونک", lighting = "دوکله نور جنوبی")
        assertEquals(1, radar.applyFilter(props, valid).size)
        assertEquals("1", radar.applyFilter(props, valid).first().id)
    }

    @Test
    fun `market radar resolveGroup reflects property removal without stale snapshot`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 75, totalPrice = 7_500_000_000L, bedrooms = 2, neighborhood = "پونک"),
            Property(id = "2", status = "فروشنده", area = 75, totalPrice = 7_500_000_000L, bedrooms = 2, neighborhood = "پونک")
        )
        val detail1 = radar.computeNeighborhoodDetail(props, "پونک")
        val group = detail1.byArea.first { it.key == "A71_80" }
        val ref = radar.groupRefFor("area", group)
        assertEquals(2, radar.resolveGroup(detail1, ref)!!.stats.count)

        // Simulate archive/removal of one property — recalculate from latest list
        val propsAfter = props.filter { it.id != "1" }
        val detail2 = radar.computeNeighborhoodDetail(propsAfter, "پونک")
        val resolved = radar.resolveGroup(detail2, ref)
        assertEquals(1, resolved!!.stats.count)
        assertEquals("2", resolved.properties.single().id)

        // Remove last member — group must resolve to null
        val detail3 = radar.computeNeighborhoodDetail(emptyList(), "پونک")
        assertEquals(null, radar.resolveGroup(detail3, ref))
    }

    @Test
    fun `market radar exclusive amenity maps all 16 combinations and is unique`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val expected = mapOf(
            listOf(false, false, false, false) to "بدون هیچ امکانات",
            listOf(false, false, false, true) to "فقط تراس‌دار",
            listOf(false, false, true, false) to "فقط انباری‌دار",
            listOf(false, false, true, true) to "انباری و تراس‌دار",
            listOf(false, true, false, false) to "پارکینگ‌دار (بدون آسانسور)",
            listOf(false, true, false, true) to "پارکینگ و تراس‌دار",
            listOf(false, true, true, false) to "پارکینگ، انباری‌دار (بدون آسانسور)",
            listOf(false, true, true, true) to "پارکینگ، انباری و تراس‌دار",
            listOf(true, false, false, false) to "آسانسوردار بدون پارکینگ",
            listOf(true, false, false, true) to "آسانسور، تراس‌دار",
            listOf(true, false, true, false) to "آسانسور، انباری‌دار",
            listOf(true, false, true, true) to "آسانسور، انباری، تراس‌دار",
            listOf(true, true, false, false) to "آسانسور و پارکینگ‌دار",
            listOf(true, true, false, true) to "آسانسور، پارکینگ و تراس‌دار",
            listOf(true, true, true, false) to "فول امکانات",
            listOf(true, true, true, true) to "فول امکانات + تراس"
        )
        assertEquals(16, expected.size)
        expected.forEach { (flags, base) ->
            val (e, p, s, t) = flags
            val prop = Property(
                id = "x", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L,
                elevator = e, parking = p, storage = s, terrace = t, unitFloor = 2
            )
            val label = radar.classifyExclusive(prop)!!
            if (!e && base in listOf(
                    "بدون هیچ امکانات",
                    "پارکینگ‌دار (بدون آسانسور)",
                    "پارکینگ و تراس‌دار",
                    "پارکینگ، انباری‌دار (بدون آسانسور)",
                    "پارکینگ، انباری و تراس‌دار"
                )
            ) {
                assertEquals("$base — طبقات اول و دوم", label)
            } else {
                assertEquals(base, label)
            }
        }
        assertEquals(26, radar.allExclusiveDisplayLabels().size)
        assertEquals(26, radar.allExclusiveDisplayLabels().toSet().size)
    }

    @Test
    fun `market radar exclusive amenity only no amenities when all false`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val withParking = Property(
            id = "1", status = "فروشنده", area = 80, totalPrice = 1L,
            elevator = false, parking = true, storage = false, terrace = false, unitFloor = 2
        )
        assertFalse(radar.classifyExclusive(withParking)!!.startsWith("بدون هیچ امکانات"))
        val none = Property(
            id = "2", status = "فروشنده", area = 80, totalPrice = 1L,
            elevator = false, parking = false, storage = false, terrace = false, unitFloor = 3
        )
        assertEquals("بدون هیچ امکانات — طبقه سوم", radar.classifyExclusive(none))
    }

    @Test
    fun `market radar exclusive floor split and invalid floor`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        fun p(floor: Int) = Property(
            id = "1", status = "فروشنده", area = 80, totalPrice = 1L,
            elevator = false, parking = true, storage = true, terrace = false, unitFloor = floor
        )
        assertEquals("پارکینگ، انباری‌دار (بدون آسانسور) — طبقات اول و دوم", radar.classifyExclusive(p(1)))
        assertEquals("پارکینگ، انباری‌دار (بدون آسانسور) — طبقات اول و دوم", radar.classifyExclusive(p(2)))
        assertEquals("پارکینگ، انباری‌دار (بدون آسانسور) — طبقه سوم", radar.classifyExclusive(p(3)))
        assertEquals("پارکینگ، انباری‌دار (بدون آسانسور) — طبقه چهارم", radar.classifyExclusive(p(4)))
        assertEquals(null, radar.classifyExclusive(p(0)))
        assertEquals(null, radar.classifyExclusive(p(5)))
        // Elevator property ignores floor for classification
        val elev = Property(
            id = "e", status = "فروشنده", area = 80, totalPrice = 1L,
            elevator = true, parking = true, storage = true, terrace = true, unitFloor = 9
        )
        assertEquals("فول امکانات + تراس", radar.classifyExclusive(elev))
    }

    @Test
    fun `market radar independent amenity counts overlap and ignore exclusive null floor`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 80, totalPrice = 1L, elevator = true, parking = true, storage = true, terrace = true, unitFloor = 2),
            Property(id = "2", status = "فروشنده", area = 80, totalPrice = 1L, elevator = false, parking = true, storage = false, terrace = false, unitFloor = 9)
        )
        val counts = radar.IndependentAmenityCounts.from(props)
        assertEquals(1, counts.withElevator)
        assertEquals(1, counts.withoutElevator)
        assertEquals(2, counts.withParking)
        assertEquals(0, counts.withoutParking)
        assertEquals(1, counts.withStorage)
        assertEquals(1, counts.withTerrace)
        // exclusive: first in full+terrace, second null (invalid floor) but still eligible for independent counts
        assertEquals("فول امکانات + تراس", radar.classifyExclusive(props[0]))
        assertEquals(null, radar.classifyExclusive(props[1]))
        val detail = radar.computeNeighborhoodDetail(props.map { it.copy(neighborhood = "پونک") }, "پونک")
        assertEquals(1, detail.byAmenity.size) // only the valid exclusive one
        assertEquals(2, detail.stats.count) // both still in neighborhood stats
    }

    @Test
    fun `market radar independent amenity boolean filters combine with AND`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 80, totalPrice = 1L, neighborhood = "پونک", elevator = true, parking = false, storage = true, terrace = false),
            Property(id = "2", status = "فروشنده", area = 80, totalPrice = 1L, neighborhood = "پونک", elevator = true, parking = true, storage = true, terrace = false),
            Property(id = "3", status = "فروشنده", area = 80, totalPrice = 1L, neighborhood = "پونک", elevator = false, parking = false, storage = true, terrace = false)
        )
        val f = radar.RadarFilter(elevator = true, storage = true, parking = false)
        val filtered = radar.applyFilter(props, f)
        assertEquals(1, filtered.size)
        assertEquals("1", filtered.first().id)
    }

    @Test
    fun `market radar cumulative filters narrow results`() {
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 75, totalPrice = 7_500_000_000L, bedrooms = 2, neighborhood = "پونک", condition = "تمیز"),
            Property(id = "2", status = "فروشنده", area = 75, totalPrice = 7_500_000_000L, bedrooms = 3, neighborhood = "پونک", condition = "تمیز"),
            Property(id = "3", status = "فروشنده", area = 95, totalPrice = 9_500_000_000L, bedrooms = 2, neighborhood = "پونک", condition = "نوساز")
        )
        val f = ir.daramash.app.domain.usecase.MarketRadarUseCase.RadarFilter(
            neighborhood = "پونک",
            areaBucket = ir.daramash.app.domain.usecase.MarketRadarUseCase.AreaBucket.A71_80,
            bedroomBucket = ir.daramash.app.domain.usecase.MarketRadarUseCase.BedroomBucket.TWO
        )
        val filtered = ir.daramash.app.domain.usecase.MarketRadarUseCase.applyFilter(props, f)
        assertEquals(1, filtered.size)
        assertEquals("1", filtered.first().id)
    }

    @Test
    fun `market radar overview lists every eligible neighborhood without filters`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک"),
            Property(id = "2", status = "فروشنده", area = 90, totalPrice = 9_000_000_000L, neighborhood = "پونک"),
            Property(id = "3", status = "فروشنده", area = 70, totalPrice = 7_000_000_000L, neighborhood = "سعادت‌آباد"),
            Property(id = "4", status = "فروشنده", area = 80, totalPrice = 8_000_000_000L, neighborhood = "پونک", isArchived = true),
            Property(id = "5", status = "خریدار", area = 80, totalPrice = 8_000_000_000L, neighborhood = "ونک"),
            Property(id = "6", status = "فروشنده", area = 0, totalPrice = 8_000_000_000L, neighborhood = "ونک"),
            Property(id = "7", status = "فروشنده", area = 80, totalPrice = 0L, neighborhood = "ونک")
        )
        val overview = radar.computeOverview(props)
        assertEquals(2, overview.neighborhoodCount)
        assertEquals(3, overview.totalEligible)
        val names = overview.neighborhoods.map { it.name }.toSet()
        assertEquals(setOf("پونک", "سعادت‌آباد"), names)
        val ponak = overview.neighborhoods.first { it.name == "پونک" }
        assertEquals(2, ponak.stats.count)
        // average of 100m and 100m ppm: 8e9/80 and 9e9/90
        val expectedAvg = ((8_000_000_000L / 80) + (9_000_000_000L / 90)) / 2
        // PriceStats uses round of double mean
        assertEquals(2, ponak.stats.count)
        assertTrue(ponak.stats.average > 0)
        // No filters applied — independent of RadarFilter defaults
        val detail = radar.computeNeighborhoodDetail(props, "پونک", radar.RadarFilter())
        assertEquals(2, detail.stats.count)
        assertEquals(ponak.stats.count, detail.stats.count)
    }

    @Test
    fun `market radar neighborhood detail starts unfiltered and AND filters narrow`() {
        val radar = ir.daramash.app.domain.usecase.MarketRadarUseCase
        val props = listOf(
            Property(id = "1", status = "فروشنده", area = 65, totalPrice = 6_500_000_000L, bedrooms = 2, neighborhood = "پونک", elevator = true, parking = true),
            Property(id = "2", status = "فروشنده", area = 65, totalPrice = 6_500_000_000L, bedrooms = 3, neighborhood = "پونک", elevator = true, parking = false),
            Property(id = "3", status = "فروشنده", area = 85, totalPrice = 8_500_000_000L, bedrooms = 2, neighborhood = "پونک", elevator = true, parking = true)
        )
        val full = radar.computeNeighborhoodDetail(props, "پونک", radar.RadarFilter())
        assertEquals(3, full.stats.count)
        val filtered = radar.computeNeighborhoodDetail(
            props,
            "پونک",
            radar.RadarFilter(
                areaBucket = radar.AreaBucket.A61_70,
                bedroomBucket = radar.BedroomBucket.TWO,
                elevator = true,
                parking = true
            )
        )
        assertEquals(1, filtered.stats.count)
        assertEquals("1", filtered.properties.first().id)
        val cleared = radar.computeNeighborhoodDetail(props, "پونک", radar.RadarFilter())
        assertEquals(3, cleared.stats.count)
    }

}
