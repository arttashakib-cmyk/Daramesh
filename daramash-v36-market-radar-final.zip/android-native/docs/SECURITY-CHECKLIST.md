# Daramash security checklist

## Things already in the app (v36)
- Google login uses PKCE; a login redirect the app did not start is ignored.
- Tokens live in EncryptedSharedPreferences. It no longer silently drops to plain storage after the first failure.
- Android Auto Backup / device transfer is off: client names and phones never go to Google Drive.
- The recents screen is blank (Android 13+). Screenshots are blocked while the app lock is on.
- Follow-up notifications hide their content on the lock screen.
- Restore (file, paste or shared text) always shows a preview and asks for confirmation first.
- The release build is minified (R8); no default signing passwords in build.gradle.kts.

## Signing key (do this once)
1. `base64 -w0 daramash-release.jks` -> GitHub: Settings > Secrets and variables > Actions > New repository secret
   - `DARAMASH_KEYSTORE_B64` (the base64 text)
   - `DARAMASH_KEYSTORE_PASSWORD`, `DARAMASH_KEY_ALIAS`, `DARAMASH_KEY_PASSWORD`
2. Then delete `daramash-release.jks` and `keystore.properties` from the zip in the repo (keep a private copy of the .jks elsewhere).
3. Never send the .jks or its passwords to an AI tool or chat. Whoever has it can publish an "update" of your app.
   Keep the SAME key: a new key makes Android refuse to update the installed app.

## Supabase self-audit (SQL editor)
```sql
-- 1) every table in public must have RLS on (rowsecurity = true)
select tablename, rowsecurity from pg_tables where schemaname = 'public';

-- 2) which functions can anonymous callers run? (should only be harmless ones)
select routine_name, grantee from information_schema.routine_privileges
where routine_schema = 'public' and grantee in ('anon', 'public') order by 1;

-- 3) policies
select tablename, policyname, cmd, roles, qual from pg_policies where schemaname = 'public';
```
- Every `admin_*` function must check the caller itself (inside the function) and must not be executable by `anon`.
- Keep `service_role` key out of every app, zip and chat. Only the `anon` key belongs in the apps.
- Authentication > Providers: keep only Google. Authentication > URL Configuration: only your real site URLs and `ir.daramash.app://auth`.
- Turn on "Leaked password protection" / rate limits in Authentication if you ever add other login methods.
