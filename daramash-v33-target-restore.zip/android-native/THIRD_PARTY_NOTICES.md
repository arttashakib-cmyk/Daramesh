# Third-party notices

## Cloudy (https://github.com/skydoves/Cloudy) - Apache License 2.0
The liquid-glass effect in `presentation/glass/GlassBackdrop.kt` (backdrop capture, blur, lens-style
refraction with chromatic fringe, specular rim light) is an Android-only re-implementation inspired by
Cloudy's `Modifier.cloudy(sky = ...)` and `Modifier.liquidGlass(...)`. No Cloudy source file is copied;
Cloudy itself requires Kotlin 2.x and Compose 1.11, which this project does not use.
Copyright 2022 skydoves (Jaewoong Eum).
