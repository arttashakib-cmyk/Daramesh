package ir.daramash.app.domain.usecase

import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.MonthProgress
import kotlin.math.roundToInt

data class TargetStats(
    val type: String,
    val isSet: Boolean,
    val target: Long,
    val done: Long,
    val pct: Int,
    val remaining: Long,
    val monthKey: String,
    val progress: MonthProgress
)

/** Same rules as targetStats() in the web app: the month target is counted per Jalali month. */
object TargetMath {

    fun monthProgress(t: AdvisorTarget, key: String = PersianFormatters.currentJalaliMonthKey()): MonthProgress =
        t.progress[key] ?: MonthProgress()

    fun stats(t: AdvisorTarget, key: String = PersianFormatters.currentJalaliMonthKey()): TargetStats {
        val mp = monthProgress(t, key)
        val target: Long
        val done: Long
        if (t.targetType == "contracts") {
            target = t.targetContracts.toLong()
            done = (0 until t.targetContracts).count { mp.ticks.getOrElse(it) { false } }.toLong()
        } else {
            target = t.targetDeposit
            done = mp.deposits.sumOf { it.amount }
        }
        val pct = if (target > 0L) (done * 100.0 / target.toDouble()).roundToInt().coerceIn(0, 100) else 0
        return TargetStats(t.targetType, target > 0L, target, done, pct, (target - done).coerceAtLeast(0L), key, mp)
    }
}
