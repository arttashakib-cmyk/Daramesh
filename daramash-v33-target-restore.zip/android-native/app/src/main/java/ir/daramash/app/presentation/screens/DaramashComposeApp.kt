package ir.daramash.app.presentation.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import ir.daramash.app.R
import ir.daramash.app.domain.model.Advisor
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchLink
import ir.daramash.app.domain.model.NavigationTab
import ir.daramash.app.presentation.glass.GlassBackdropState
import ir.daramash.app.presentation.glass.glassSource
import ir.daramash.app.presentation.glass.glassSurface
import ir.daramash.app.presentation.glass.LiquidGlassStyle
import ir.daramash.app.presentation.glass.rememberGlassBackdrop
import ir.daramash.app.presentation.glass.springPress
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.PropertyFilterState
import ir.daramash.app.domain.model.ThemeMode
import ir.daramash.app.domain.usecase.MatchContext
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.domain.usecase.TargetMath
import ir.daramash.app.presentation.theme.AmberSoft
import ir.daramash.app.presentation.theme.AmberWarn
import ir.daramash.app.presentation.theme.BlueInfo
import ir.daramash.app.presentation.theme.BlueSoft
import ir.daramash.app.presentation.theme.DaramashBg
import ir.daramash.app.presentation.theme.DaramashBorder
import ir.daramash.app.presentation.theme.DaramashBorderSoft
import ir.daramash.app.presentation.theme.DaramashFaint
import ir.daramash.app.presentation.theme.DaramashMuted
import ir.daramash.app.presentation.theme.DaramashSpecular
import ir.daramash.app.presentation.theme.DaramashText
import ir.daramash.app.presentation.theme.EmeraldAccent
import ir.daramash.app.presentation.theme.EmeraldBright
import ir.daramash.app.presentation.theme.PurpleQuote
import ir.daramash.app.presentation.theme.RedDanger
import ir.daramash.app.presentation.theme.RedSolid
import ir.daramash.app.presentation.theme.RubyDeep
import ir.daramash.app.presentation.theme.RubyMid
import ir.daramash.app.presentation.theme.RubyPrimary
import ir.daramash.app.presentation.theme.VazirmatnFontFamily
import ir.daramash.app.presentation.viewmodel.DaramashViewModel
import ir.daramash.app.security.GoogleChromeAuthLauncher
import ir.daramash.app.worker.FollowUpReminderWorker
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DaramashComposeApp(viewModel: DaramashViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }

    val currentTab by viewModel.currentTab.collectAsState()
    val activeProperties by viewModel.activeProperties.collectAsState()
    val filteredProperties by viewModel.filteredProperties.collectAsState()
    val activeCustomers by viewModel.activeCustomers.collectAsState()
    val filteredCustomers by viewModel.filteredCustomers.collectAsState()
    val activeInvestors by viewModel.activeInvestors.collectAsState()
    val archivedProperties by viewModel.archivedProperties.collectAsState()
    val archivedCustomers by viewModel.archivedCustomers.collectAsState()
    val archivedInvestors by viewModel.archivedInvestors.collectAsState()
    val matches by viewModel.matches.collectAsState()
    val activityLogs by viewModel.activityLogs.collectAsState()
    val advisors by viewModel.advisors.collectAsState()
    val advisorTarget by viewModel.advisorTarget.collectAsState()
    val tetherRate by viewModel.tetherRate.collectAsState()
    val tetherUpdatedAt by viewModel.tetherUpdatedAt.collectAsState()
    val propertyFilter by viewModel.propertyFilter.collectAsState()
    val customerQuery by viewModel.customerQuery.collectAsState()
    val customerQualityFilter by viewModel.customerQualityFilter.collectAsState()
    val selectedPropertyIds by viewModel.selectedPropertyIds.collectAsState()
    val aiResponse by viewModel.aiResponse.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val userSession by viewModel.userSession.collectAsState()
    val cloudConflict by viewModel.cloudConflict.collectAsState()
    val adminUsers by viewModel.adminUsers.collectAsState()
    val pendingRequests = adminUsers.count { !it.blocked && it.expiresAt <= 0L }

    var bottomSearchOpen by rememberSaveable { mutableStateOf(false) }
    var globalSearchText by rememberSaveable { mutableStateOf("") }

    var editingProperty by remember { mutableStateOf<Property?>(null) }
    var showPropertyForm by rememberSaveable { mutableStateOf(false) }
    var detailProperty by remember { mutableStateOf<Property?>(null) }

    var editingCustomer by remember { mutableStateOf<Customer?>(null) }
    var showCustomerForm by rememberSaveable { mutableStateOf(false) }
    var detailCustomer by remember { mutableStateOf<Customer?>(null) }

    var editingInvestor by remember { mutableStateOf<Investor?>(null) }
    var showInvestorForm by rememberSaveable { mutableStateOf(false) }
    var detailInvestor by remember { mutableStateOf<Investor?>(null) }

    var showAddChooserModal by rememberSaveable { mutableStateOf(false) }
    var showHelpModal by rememberSaveable { mutableStateOf(false) }
    var showAdvancedFilter by rememberSaveable { mutableStateOf(false) }
    var showAiDialog by rememberSaveable { mutableStateOf(false) }
    var showTargetEditModal by rememberSaveable { mutableStateOf(false) }
    var showAdminPanel by rememberSaveable { mutableStateOf(false) }
    var advisorCodeToShare by rememberSaveable { mutableStateOf("") }
    var showPasteRestore by rememberSaveable { mutableStateOf(false) }
    val restorePreview by viewModel.restorePreview.collectAsState()
    val restoreError by viewModel.restoreError.collectAsState()
    var showCloudSnapshotsModal by rememberSaveable { mutableStateOf(false) }
    var cloudSnapshotsList by remember { mutableStateOf<List<ir.daramash.app.domain.model.CloudHistorySnapshot>>(emptyList()) }
    var showDeleteCloudConfirmDialog by rememberSaveable { mutableStateOf(false) }

    var quickLogTarget by remember { mutableStateOf<Triple<String, String, String>?>(null) } // type, id, title
    var preselectedMatchPropertyId by rememberSaveable { mutableStateOf<String?>(null) }
    var preselectedMatchNeedId by rememberSaveable { mutableStateOf<String?>(null) }
    var matchDirectionMode by rememberSaveable { mutableStateOf("needToProperty") } // "needToProperty" or "propertyToNeed"

    // Pending export payloads for Storage Access Framework
    var pendingExportJson by remember { mutableStateOf<String?>(null) }
    var pendingExportCsv by remember { mutableStateOf<String?>(null) }

    val saveJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        val payload = pendingExportJson
        if (uri != null && payload != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(payload.toByteArray(Charsets.UTF_8))
                }
                viewModel.emitSnackbar("✅ فایل بکاپ JSON ذخیره شد")
            } catch (e: Exception) {
                viewModel.emitSnackbar("خطا در ذخیره فایل: ${e.localizedMessage}")
            }
        }
    }

    val saveCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        val payload = pendingExportCsv
        if (uri != null && payload != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(payload.toByteArray(Charsets.UTF_8))
                }
                viewModel.emitSnackbar("✅ فایل اکسل CSV ذخیره شد")
            } catch (e: Exception) {
                viewModel.emitSnackbar("خطا در ذخیره CSV: ${e.localizedMessage}")
            }
        }
    }

    val openBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val content = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                when {
                    content.isNullOrBlank() -> viewModel.emitSnackbar("فایل خالی است یا خوانده نشد")
                    content.length > 25_000_000 -> viewModel.emitSnackbar("فایل خیلی بزرگ است (بیش از ۲۵ مگ)")
                    else -> viewModel.previewRestore(content)
                }
            } catch (e: Exception) {
                viewModel.emitSnackbar("خطا در خواندن فایل: ${e.localizedMessage}")
            }
        }
    }

    val voiceSearchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                globalSearchText = spoken
                viewModel.updatePropertyFilter { it.copy(query = spoken) }
                viewModel.setCustomerSearch(spoken)
                viewModel.emitSnackbar("🎙 جستجوی صوتی: «$spoken»")
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    BackHandler(enabled = drawerState.isOpen || bottomSearchOpen || selectedPropertyIds.isNotEmpty() || currentTab != NavigationTab.HOME) {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            bottomSearchOpen -> {
                bottomSearchOpen = false
                globalSearchText = ""
                viewModel.updatePropertyFilter { it.copy(query = "") }
                viewModel.setCustomerSearch("")
            }
            selectedPropertyIds.isNotEmpty() -> viewModel.clearPropertySelection()
            currentTab != NavigationTab.HOME -> viewModel.navigateTo(NavigationTab.HOME)
        }
    }

    val totalArchiveCount = archivedProperties.size + archivedCustomers.size + archivedInvestors.size

    val glassBackdrop = rememberGlassBackdrop()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color.Transparent,
                drawerTonalElevation = 0.dp,
                modifier = Modifier.width(272.dp)
            ) {
                DaramashSidebarDrawer(
                    currentTab = currentTab,
                    propertiesCount = activeProperties.size,
                    customersCount = activeCustomers.size,
                    investorsCount = activeInvestors.size,
                    advisorsCount = advisors.size,
                    archiveCount = totalArchiveCount,
                    userEmail = if (userSession.isLoggedIn) userSession.email else "advisor@daramash.ir",
                    isAdmin = userSession.isAdmin,
                    onSelectTab = { tab ->
                        viewModel.navigateTo(tab)
                        scope.launch { drawerState.close() }
                    },
                    onOpenHelp = {
                        scope.launch { drawerState.close() }
                        showHelpModal = true
                    },
                    onOpenAdminPanel = {
                        scope.launch { drawerState.close() }
                        showAdminPanel = true
                    },
                    adminPendingCount = pendingRequests
                )
            }
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DaramashBg)
        ) {
            // Main Column: Topbar + Scrollable Page Content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                // 1. EXACT TOPBAR (.topbar)
                DaramashTopBar(
                    title = currentTab.titleFa,
                    onMenuClick = { scope.launch { drawerState.open() } },
                    onSearchClick = {
                        if (currentTab !in listOf(NavigationTab.PROPERTIES, NavigationTab.CUSTOMERS, NavigationTab.INVESTORS)) {
                            viewModel.navigateTo(NavigationTab.PROPERTIES)
                        }
                        bottomSearchOpen = !bottomSearchOpen
                    }
                )

                // 2. ACTIVE TAB PANE (.content)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .glassSource(glassBackdrop)
                ) {
                    when (currentTab) {
                        NavigationTab.HOME -> HomeScreen(
                            properties = activeProperties,
                            customers = activeCustomers,
                            investors = activeInvestors,
                            matchesCount = matches.size,
                            activitiesCount = activityLogs.size,
                            target = advisorTarget,
                            tetherRate = tetherRate,
                            tetherUpdatedAt = tetherUpdatedAt,
                            onRefreshTether = { viewModel.refreshTetherRate() },
                            onNavigate = { viewModel.navigateTo(it) },
                            onOpenProperty = { detailProperty = it },
                            onQuickLogProperty = { p ->
                                quickLogTarget = Triple("property", p.id, "کد ${PersianFormatters.toFa(p.code)} · ${p.neighborhood}")
                            },
                            onMatchProperty = { p ->
                                preselectedMatchPropertyId = p.id
                                matchDirectionMode = "propertyToNeed"
                                viewModel.navigateTo(NavigationTab.MATCHING)
                            },
                            onEditProperty = { p ->
                                editingProperty = p
                                showPropertyForm = true
                            },
                            onArchiveProperty = { p -> viewModel.archiveProperty(p.id) },
                            onAddProperty = {
                                editingProperty = null
                                showPropertyForm = true
                            },
                            onAddCustomer = {
                                editingCustomer = null
                                showCustomerForm = true
                            },
                            onOpenHelp = { showHelpModal = true },
                            onLoadSampleData = { viewModel.loadDemoData() }
                        )

                        NavigationTab.PROPERTIES -> PropertiesScreen(
                            allPropertiesCount = activeProperties.size,
                            properties = filteredProperties,
                            filter = propertyFilter,
                            selectedIds = selectedPropertyIds,
                            onFilterChange = { updater -> viewModel.updatePropertyFilter(updater) },
                            onOpenAdvancedFilter = { showAdvancedFilter = true },
                            onSelectToggle = { viewModel.togglePropertySelection(it) },
                            onClearSelection = { viewModel.clearPropertySelection() },
                            onArchiveSelected = { viewModel.archiveSelectedProperties() },
                            onOpenDetail = { detailProperty = it },
                            onQuickLog = { p ->
                                quickLogTarget = Triple("property", p.id, "کد ${PersianFormatters.toFa(p.code)} · ${p.neighborhood}")
                            },
                            onMatchProperty = { p ->
                                preselectedMatchPropertyId = p.id
                                matchDirectionMode = "propertyToNeed"
                                viewModel.navigateTo(NavigationTab.MATCHING)
                            },
                            onEdit = {
                                editingProperty = it
                                showPropertyForm = true
                            },
                            onArchive = { viewModel.archiveProperty(it.id) },
                            onAddNew = {
                                editingProperty = null
                                showPropertyForm = true
                            }
                        )

                        NavigationTab.CUSTOMERS -> CustomersScreen(
                            allCustomersCount = activeCustomers.size,
                            customers = filteredCustomers,
                            query = customerQuery,
                            qualityFilter = customerQualityFilter,
                            onQueryChange = { viewModel.setCustomerSearch(it) },
                            onQualityChange = { viewModel.setCustomerQualityFilter(it) },
                            onOpenDetail = { detailCustomer = it },
                            onQuickLog = { c ->
                                quickLogTarget = Triple("customer", c.id, c.fullName)
                            },
                            onMatchCustomer = { c ->
                                preselectedMatchNeedId = c.id
                                matchDirectionMode = "needToProperty"
                                viewModel.navigateTo(NavigationTab.MATCHING)
                            },
                            onAddNew = {
                                editingCustomer = null
                                showCustomerForm = true
                            },
                            onEdit = {
                                editingCustomer = it
                                showCustomerForm = true
                            },
                            onArchive = { viewModel.archiveCustomer(it.id) }
                        )

                        NavigationTab.INVESTORS -> InvestorsScreen(
                            investors = activeInvestors,
                            query = globalSearchText,
                            onOpenDetail = { detailInvestor = it },
                            onQuickLog = { inv ->
                                quickLogTarget = Triple("investor", inv.id, inv.fullName)
                            },
                            onMatchInvestor = { inv ->
                                preselectedMatchNeedId = inv.id
                                matchDirectionMode = "needToProperty"
                                viewModel.navigateTo(NavigationTab.MATCHING)
                            },
                            onAddNew = {
                                editingInvestor = null
                                showInvestorForm = true
                            },
                            onEdit = {
                                editingInvestor = it
                                showInvestorForm = true
                            },
                            onArchive = { viewModel.archiveInvestor(it.id) }
                        )

                        NavigationTab.MATCHING -> SmartMatchingScreen(
                            viewModel = viewModel,
                            properties = activeProperties,
                            customers = activeCustomers,
                            investors = activeInvestors,
                            matches = matches,
                            initialMode = matchDirectionMode,
                            initialPropertyId = preselectedMatchPropertyId,
                            initialNeedId = preselectedMatchNeedId,
                            onModeChange = { matchDirectionMode = it },
                            onPropertySelect = { preselectedMatchPropertyId = it },
                            onNeedSelect = { preselectedMatchNeedId = it },
                            onOpenProperty = { detailProperty = it },
                            onOpenCustomer = { detailCustomer = it },
                            onOpenInvestor = { detailInvestor = it }
                        )

                        NavigationTab.TARGET -> TargetScreen(
                            target = advisorTarget,
                            properties = activeProperties,
                            customers = activeCustomers,
                            investors = activeInvestors,
                            matches = matches,
                            archivedProperties = archivedProperties,
                            onToggleContract = { viewModel.toggleTargetContract(it) },
                            onAddDeposit = { amount, title -> viewModel.addTargetDeposit(amount, title) },
                            onRemoveDeposit = { viewModel.removeTargetDeposit(it) },
                            onOpenEditTarget = { showTargetEditModal = true },
                            onOpenProperty = { detailProperty = it },
                            onQuickLogProperty = { p ->
                                quickLogTarget = Triple("property", p.id, "کد ${PersianFormatters.toFa(p.code)} · ${p.neighborhood}")
                            },
                            onMatchProperty = { p ->
                                preselectedMatchPropertyId = p.id
                                matchDirectionMode = "propertyToNeed"
                                viewModel.navigateTo(NavigationTab.MATCHING)
                            },
                            onEditProperty = { p ->
                                editingProperty = p
                                showPropertyForm = true
                            },
                            onArchiveProperty = { p -> viewModel.archiveProperty(p.id) }
                        )

                        NavigationTab.MANAGER -> ManagerPanelScreen(
                            advisors = advisors,
                            properties = activeProperties,
                            customers = activeCustomers,
                            onAddAdvisor = { name, phone, spec -> viewModel.addAdvisor(name, phone, spec) },
                            onDeleteAdvisor = { viewModel.deleteAdvisor(it) },
                            groupSettings = advisorTarget,
                            onUpdateAdvisor = { id, name, phone, spec -> viewModel.updateAdvisor(id, name, phone, spec) },
                            onSaveGroup = { name, rank, type, value -> viewModel.updateGroupSettings(name, rank, type, value) },
                            onGenerateCode = { name ->
                                viewModel.generateAdvisorShareCode(name) { code ->
                                    advisorCodeToShare = code
                                }
                            },
                            onImportCode = { viewModel.importAdvisorShareCode(it) },
                            onOpenProperty = { detailProperty = it },
                            onOpenCustomer = { detailCustomer = it }
                        )

                        NavigationTab.ARCHIVE -> ArchiveScreen(
                            archivedProperties = archivedProperties,
                            archivedCustomers = archivedCustomers,
                            archivedInvestors = archivedInvestors,
                            onRestoreProperty = { viewModel.restoreProperty(it) },
                            onDeleteProperty = { viewModel.deletePropertyPermanently(it) },
                            onRestoreCustomer = { viewModel.restoreCustomer(it) },
                            onDeleteCustomer = { viewModel.deleteCustomerPermanently(it) },
                            onRestoreInvestor = { viewModel.restoreInvestor(it) },
                            onDeleteInvestor = { viewModel.deleteInvestorPermanently(it) },
                            onClearAll = { viewModel.clearAllArchive() }
                        )

                        NavigationTab.SYSTEM -> SystemAndSyncScreen(
                            viewModel = viewModel,
                            onOpenCloudSnapshots = {
                                viewModel.fetchCloudSnapshots { list ->
                                    cloudSnapshotsList = list
                                    showCloudSnapshotsModal = true
                                }
                            },
                            onDeleteCloudData = { showDeleteCloudConfirmDialog = true },
                            onExportJson = {
                                viewModel.exportBackupJson { json ->
                                    pendingExportJson = json
                                    saveJsonLauncher.launch("daramash-backup-${PersianFormatters.todayIso()}.json")
                                }
                            },
                            onImportJson = { openBackupLauncher.launch("*/*") },
                            onPasteJson = { showPasteRestore = true },
                            onExportCsv = {
                                viewModel.exportCsv { csv ->
                                    pendingExportCsv = csv
                                    saveCsvLauncher.launch("daramash-export-${PersianFormatters.todayIso()}.csv")
                                }
                            },
                            onExportPdf = {
                                viewModel.exportPdfReport(context) { pdfFile ->
                                    try {
                                        val uri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.fileprovider",
                                            pdfFile
                                        )
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/pdf"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری گزارش PDF"))
                                    } catch (e: Exception) {
                                        viewModel.emitSnackbar("فایل PDF در حافظه برنامه ساخته شد: ${pdfFile.name}")
                                    }
                                }
                            },
                            onTestNotification = {
                                FollowUpReminderWorker.postFollowUpNotification(
                                    context,
                                    activeProperties.count { PersianFormatters.needsFollowUp(it.lastContact, it.createdAt) }.coerceAtLeast(1),
                                    activeCustomers.count { PersianFormatters.needsFollowUp(it.lastContact, it.createdAt) }.coerceAtLeast(1)
                                )
                                viewModel.emitSnackbar("🔔 اعلان پیگیری ارسال شد")
                            }
                        )
                    }
                }
            }

            // 3. FLOATING RIGHT-HAND CIRCULAR GLASS TOOLS (.liquid-right-tools)
            // Note: In RTL layout direction, Alignment.BottomStart is the RIGHT edge of the screen!
            if (!bottomSearchOpen && currentTab in listOf(
                    NavigationTab.HOME,
                    NavigationTab.PROPERTIES,
                    NavigationTab.CUSTOMERS,
                    NavigationTab.INVESTORS,
                    NavigationTab.MATCHING,
                    NavigationTab.TARGET
                )
            ) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .navigationBarsPadding()
                        .padding(start = 14.dp, bottom = 86.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Top Circle (48.dp): ✨ AI Assistant (.lrt-circle.sm)
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .glassSurface(
                                backdrop = glassBackdrop,
                                shape = CircleShape,
                                blurRadius = 24.dp,
                                tint = Color(0x28FFFFFF),
                                fallbackFill = Color(0xE6282834),
                                style = LiquidGlassStyle.Regular,
                                specularStrength = 1.2f
                            )
                            .clip(CircleShape)
                            .clickable {
                                showAiDialog = true
                                if (aiResponse.isBlank()) viewModel.askAiAssistant("")
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        DaramashSvgIcon(
                            type = "sparkles",
                            tint = Color.White,
                            modifier = Modifier.size(21.dp)
                        )
                    }

                    // Bottom Circle (58.dp): ＋ Add Button (.lrt-circle.lg)
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0x52FF2D55), Color(0xEB282834), Color(0xF50E0E14))
                                ),
                                CircleShape
                            )
                            .border(1.dp, Color(0x59FF7896), CircleShape)
                            .clickable {
                                when (currentTab) {
                                    NavigationTab.PROPERTIES -> {
                                        editingProperty = null
                                        showPropertyForm = true
                                    }
                                    NavigationTab.CUSTOMERS -> {
                                        editingCustomer = null
                                        showCustomerForm = true
                                    }
                                    NavigationTab.INVESTORS -> {
                                        editingInvestor = null
                                        showInvestorForm = true
                                    }
                                    else -> showAddChooserModal = true
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        DaramashSvgIcon(
                            type = "plus",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            // 4. FLOATING CAPSULE BOTTOM NAVIGATION BAR (.mobile-nav) OR MORPHING BOTTOM SEARCH DOCK (.bottom-search-dock)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                AnimatedContent(
                    targetState = bottomSearchOpen,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "BottomDockMorph"
                ) { isSearchMode ->
                    if (!isSearchMode) {
                        DaramashFloatingBottomNav(
                            backdrop = glassBackdrop,
                            currentTab = currentTab,
                            propertiesCount = activeProperties.size,
                            customersCount = activeCustomers.size,
                            onSelectTab = { viewModel.navigateTo(it) },
                            onOpenSearch = {
                                if (currentTab !in listOf(NavigationTab.PROPERTIES, NavigationTab.CUSTOMERS, NavigationTab.INVESTORS)) {
                                    viewModel.navigateTo(NavigationTab.PROPERTIES)
                                }
                                bottomSearchOpen = true
                            }
                        )
                    } else {
                        DaramashBottomSearchDock(
                            backdrop = glassBackdrop,
                            currentTab = currentTab,
                            query = if (currentTab == NavigationTab.CUSTOMERS) customerQuery else propertyFilter.query,
                            propertyStatusFilter = propertyFilter.statusFilter,
                            customerQualityFilter = customerQualityFilter,
                            onQueryChange = { q ->
                                globalSearchText = q
                                viewModel.updatePropertyFilter { it.copy(query = q) }
                                viewModel.setCustomerSearch(q)
                            },
                            onPropertyStatusChange = { st ->
                                viewModel.updatePropertyFilter { it.copy(statusFilter = st) }
                            },
                            onCustomerQualityChange = { qf ->
                                viewModel.setCustomerQualityFilter(qf)
                            },
                            onOpenAdvancedFilter = { showAdvancedFilter = true },
                            onVoiceSearch = {
                                try {
                                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, "نام محله یا کد فایل را بگویید...")
                                    }
                                    voiceSearchLauncher.launch(intent)
                                } catch (_: Exception) {
                                    viewModel.emitSnackbar("ورودی صوتی روی این دستگاه فعال نیست")
                                }
                            },
                            onClose = {
                                val hasText = (if (currentTab == NavigationTab.CUSTOMERS) customerQuery else propertyFilter.query).isNotBlank()
                                if (hasText) {
                                    globalSearchText = ""
                                    viewModel.updatePropertyFilter { it.copy(query = "") }
                                    viewModel.setCustomerSearch("")
                                } else {
                                    bottomSearchOpen = false
                                }
                            }
                        )
                    }
                }
            }

            // Toast / Snackbar Host
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 82.dp)
            )
        }
    }

    // ========================================================================
    // MODALS & DIALOGS
    // ========================================================================

    if (showAddChooserModal) {
        AddEntityChooserModal(
            onDismiss = { showAddChooserModal = false },
            onSelectProperty = {
                showAddChooserModal = false
                editingProperty = null
                showPropertyForm = true
            },
            onSelectCustomer = {
                showAddChooserModal = false
                editingCustomer = null
                showCustomerForm = true
            },
            onSelectInvestor = {
                showAddChooserModal = false
                editingInvestor = null
                showInvestorForm = true
            }
        )
    }

    if (showHelpModal) {
        QuickHelpModal(onDismiss = { showHelpModal = false })
    }

    if (showPropertyForm) {
        PropertyFormDialog(
            initial = editingProperty,
            onDismiss = { showPropertyForm = false },
            onSave = { prop ->
                viewModel.saveProperty(prop, isEdit = editingProperty != null) {
                    showPropertyForm = false
                }
            }
        )
    }

    if (showCustomerForm) {
        CustomerFormDialog(
            initial = editingCustomer,
            onDismiss = { showCustomerForm = false },
            onSave = { cust ->
                viewModel.saveCustomer(cust, isEdit = editingCustomer != null) {
                    showCustomerForm = false
                }
            }
        )
    }

    if (showInvestorForm) {
        InvestorFormDialog(
            initial = editingInvestor,
            onDismiss = { showInvestorForm = false },
            onSave = { inv ->
                viewModel.saveInvestor(inv, isEdit = editingInvestor != null) {
                    showInvestorForm = false
                }
            }
        )
    }

    detailProperty?.let { prop ->
        val logsForProp = activityLogs.filter { it.entityId == prop.id }
        PropertyDetailDialog(
            property = prop,
            logs = logsForProp,
            onDismiss = { detailProperty = null },
            onEdit = {
                val p = prop
                detailProperty = null
                editingProperty = p
                showPropertyForm = true
            },
            onQuickLog = { type, note ->
                viewModel.recordQuickActivity("property", prop.id, type, note)
            }
        )
    }

    detailCustomer?.let { cust ->
        val logsForCust = activityLogs.filter { it.entityId == cust.id }
        CustomerDetailDialog(
            customer = cust,
            logs = logsForCust,
            onDismiss = { detailCustomer = null },
            onEdit = {
                val c = cust
                detailCustomer = null
                editingCustomer = c
                showCustomerForm = true
            },
            onMatch = {
                val c = cust
                detailCustomer = null
                preselectedMatchNeedId = c.id
                matchDirectionMode = "needToProperty"
                viewModel.navigateTo(NavigationTab.MATCHING)
            },
            onArchive = {
                val c = cust
                detailCustomer = null
                viewModel.archiveCustomer(c.id)
            },
            onQuickLog = { type, note ->
                viewModel.recordQuickActivity("customer", cust.id, type, note)
            }
        )
    }

    detailInvestor?.let { inv ->
        val logsForInv = activityLogs.filter { it.entityId == inv.id }
        InvestorDetailDialog(
            investor = inv,
            logs = logsForInv,
            onDismiss = { detailInvestor = null },
            onEdit = {
                val i = inv
                detailInvestor = null
                editingInvestor = i
                showInvestorForm = true
            },
            onMatch = {
                val i = inv
                detailInvestor = null
                preselectedMatchNeedId = i.id
                matchDirectionMode = "needToProperty"
                viewModel.navigateTo(NavigationTab.MATCHING)
            },
            onArchive = {
                val i = inv
                detailInvestor = null
                viewModel.archiveInvestor(i.id)
            },
            onQuickLog = { type, note ->
                viewModel.recordQuickActivity("investor", inv.id, type, note)
            }
        )
    }

    quickLogTarget?.let { (entityType, entityId, title) ->
        QuickActivityPopoverDialog(
            title = title,
            onDismiss = { quickLogTarget = null },
            onSaveLog = { actType, note ->
                viewModel.recordQuickActivity(entityType, entityId, actType, note)
                quickLogTarget = null
            }
        )
    }

    if (showAdvancedFilter) {
        AdvancedPropertyFilterDialog(
            current = propertyFilter,
            allProperties = activeProperties,
            onDismiss = { showAdvancedFilter = false },
            onApply = { next -> viewModel.updatePropertyFilter { next } }
        )
    }

    if (showTargetEditModal) {
        EditTargetModal(
            current = advisorTarget,
            properties = activeProperties,
            archivedProperties = archivedProperties,
            onDismiss = { showTargetEditModal = false },
            onSave = { code, mot, status, rank, type, dep, cnt ->
                viewModel.updateTargetSettings(code, mot, status, rank, type, dep, cnt)
                showTargetEditModal = false
            }
        )
    }

    if (showAiDialog) {
        AiAssistantDialog(
            aiResponse = aiResponse,
            isLoading = isAiLoading,
            onAsk = { viewModel.askAiAssistant(it) },
            onDismiss = { showAiDialog = false }
        )
    }

    if (showAdminPanel) {
        AdminSubscriptionModal(
            session = userSession,
            users = adminUsers,
            onReload = { viewModel.loadAdminUsers() },
            onExtend = { uid, days -> viewModel.adminExtendUser(uid, days) },
            onBlock = { uid, blocked -> viewModel.adminSetUserBlocked(uid, blocked) },
            onClearDevices = { uid -> viewModel.adminClearUserDevices(uid) },
            onDismiss = { showAdminPanel = false },
            onSaveConfig = { contact, trial, limit, build, url, note ->
                viewModel.adminSaveConfig(contact, trial, limit, build, url, note)
            },
            onSavePayText = { viewModel.adminSavePayText(it) }
        )
    }

    if (showPasteRestore) {
        RestorePasteModal(
            onDismiss = { showPasteRestore = false },
            onSubmit = { viewModel.previewRestore(it) }
        )
    }

    restorePreview?.let { pv ->
        RestoreConfirmModal(
            preview = pv,
            onConfirm = { viewModel.confirmRestore() },
            onDismiss = { viewModel.cancelRestore() }
        )
    }

    restoreError?.let { msg ->
        ConfirmModal(
            title = "بازگردانی ممکن نیست",
            message = msg,
            confirmText = "فهمیدم",
            onConfirm = { viewModel.dismissRestoreError() },
            onDismiss = { viewModel.dismissRestoreError() }
        )
    }

    if (advisorCodeToShare.isNotBlank()) {
        AdvisorCodeShareModal(code = advisorCodeToShare, onDismiss = { advisorCodeToShare = "" })
    }

    cloudConflict?.let { info ->
        CloudConflictModal(
            info = info,
            onUseCloud = { viewModel.resolveConflictUseCloud() },
            onKeepPhone = { viewModel.resolveConflictKeepPhone() },
            onDismiss = { viewModel.dismissCloudConflict() }
        )
    }

    if (showCloudSnapshotsModal) {
        CloudSnapshotsModal(
            snapshots = cloudSnapshotsList,
            onDismiss = { showCloudSnapshotsModal = false },
            onRestore = { viewModel.restoreCloudSnapshot(it) }
        )
    }

    if (showDeleteCloudConfirmDialog) {
        DaramashLiquidModal(
            title = "⚠️ پاک‌سازی کامل اطلاعات ابری من",
            onDismiss = { showDeleteCloudConfirmDialog = false },
            footer = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DaramashDangerButton(
                        text = "🗑 بله، پاک شود",
                        onClick = {
                            showDeleteCloudConfirmDialog = false
                            viewModel.deleteMyCloudData()
                        }
                    )
                    DaramashGhostButton(
                        text = "انصراف",
                        onClick = { showDeleteCloudConfirmDialog = false }
                    )
                }
            }
        ) {
            Text(
                text = "آیا مطمئن هستید؟ تمام داده‌های پشتیبان‌گیری شده‌ی این حساب از سرور ابری به صورت غیرقابل بازگشت پاک خواهند شد.",
                fontSize = 13.sp,
                color = RedDanger,
                fontFamily = VazirmatnFontFamily
            )
        }
    }

    if (userSession.latestBuild > 18 || userSession.subStatus == "update") {
        DaramashLiquidModal(
            title = "🚀 بروزرسانی نسخه‌ی دارمش",
            onDismiss = { },
            footer = {
                if (userSession.updateUrl.isNotBlank()) {
                    DaramashPrimaryButton(
                        text = "📥 دانلود و بروزرسانی",
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(userSession.updateUrl))
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                    )
                }
            }
        ) {
            Text(
                text = "نسخه‌ی جدید دارمش آماده است. لطفا آخرین نسخه را دریافت کنید.",
                fontSize = 13.5.sp,
                color = Color.White,
                fontFamily = VazirmatnFontFamily
            )
            if (userSession.updateNote.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "تغییرات: ${userSession.updateNote}",
                    fontSize = 12.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            }
        }
    }
}

// ============================================================================
// CHROME: TOPBAR, SIDEBAR, BOTTOM CAPSULE NAV, MORPHING SEARCH DOCK
// ============================================================================

@Composable
fun DaramashTopBar(
    title: String,
    onMenuClick: () -> Unit,
    onSearchClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(Color(0x85050508))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Right side (in RTL): Menu button + Page Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xE0262632), Color(0xEB101016))
                        ),
                        CircleShape
                    )
                    .border(1.dp, DaramashBorder, CircleShape)
                    .clickable { onMenuClick() },
                contentAlignment = Alignment.Center
            ) {
                DaramashSvgIcon(
                    type = "menu",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = title,
                fontSize = 21.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                fontFamily = VazirmatnFontFamily,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Left side (in RTL): Circular Search Button
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xE0262632), Color(0xEB101016))
                    ),
                    CircleShape
                )
                .border(1.dp, DaramashBorder, CircleShape)
                .clickable { onSearchClick() },
            contentAlignment = Alignment.Center
        ) {
            DaramashSvgIcon(
                type = "search",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun DaramashSidebarDrawer(
    currentTab: NavigationTab,
    propertiesCount: Int,
    customersCount: Int,
    investorsCount: Int,
    advisorsCount: Int,
    archiveCount: Int,
    userEmail: String,
    isAdmin: Boolean = false,
    onSelectTab: (NavigationTab) -> Unit,
    onOpenHelp: () -> Unit,
    onOpenAdminPanel: (() -> Unit)? = null,
    adminPendingCount: Int = 0
) {
    Box(
        modifier = Modifier
            .fillMaxHeight()
            .width(272.dp)
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xF51A1118), Color(0xFA0A0A0E), Color(0xFA091512))
                )
            )
            .border(width = 1.dp, color = DaramashBorder)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 14.dp)
        ) {
            // .brand Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.daramash_logo),
                    contentDescription = "دارمش",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Column {
                    Text(
                        text = "دارمش",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = "سیستم مدیریت املاک",
                        fontSize = 11.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }

            Spacer(Modifier.height(6.dp))

            // Scrollable Nav Sections (.nav)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                SidebarSectionHeader("داشبورد")
                SidebarNavItem(
                    label = "خانه",
                    iconType = "home",
                    active = currentTab == NavigationTab.HOME,
                    badgeCount = 0,
                    onClick = { onSelectTab(NavigationTab.HOME) }
                )

                SidebarSectionHeader("مدیریت")
                SidebarNavItem(
                    label = "فایل‌های املاک",
                    iconType = "properties",
                    active = currentTab == NavigationTab.PROPERTIES,
                    badgeCount = propertiesCount,
                    onClick = { onSelectTab(NavigationTab.PROPERTIES) }
                )
                SidebarNavItem(
                    label = "مشتری‌ها",
                    iconType = "customers",
                    active = currentTab == NavigationTab.CUSTOMERS,
                    badgeCount = customersCount,
                    onClick = { onSelectTab(NavigationTab.CUSTOMERS) }
                )
                SidebarNavItem(
                    label = "سرمایه‌گذاران",
                    emojiIcon = "💼",
                    active = currentTab == NavigationTab.INVESTORS,
                    badgeCount = investorsCount,
                    onClick = { onSelectTab(NavigationTab.INVESTORS) }
                )

                SidebarSectionHeader("هوشمند")
                SidebarNavItem(
                    label = "پیوند سازی هوشمند",
                    iconType = "matching",
                    active = currentTab == NavigationTab.MATCHING,
                    badgeCount = 0,
                    onClick = { onSelectTab(NavigationTab.MATCHING) }
                )

                SidebarSectionHeader("شخصی")
                SidebarNavItem(
                    label = "تارگت مشاور",
                    iconType = "target",
                    active = currentTab == NavigationTab.TARGET,
                    badgeCount = 0,
                    onClick = { onSelectTab(NavigationTab.TARGET) }
                )

                SidebarSectionHeader("مدیریت املاک")
                SidebarNavItem(
                    label = "پنل مدیریت",
                    emojiIcon = "🏢",
                    active = currentTab == NavigationTab.MANAGER,
                    badgeCount = advisorsCount,
                    onClick = { onSelectTab(NavigationTab.MANAGER) }
                )

                if (isAdmin && onOpenAdminPanel != null) {
                    SidebarSectionHeader("ادمین")
                    SidebarNavItem(
                        label = "مدیریت اشتراک‌ها",
                        emojiIcon = "👑",
                        active = false,
                        badgeCount = adminPendingCount,
                        onClick = onOpenAdminPanel
                    )
                }

                SidebarSectionHeader("سیستم")
                SidebarNavItem(
                    label = "آرشیو",
                    emojiIcon = "📦",
                    active = currentTab == NavigationTab.ARCHIVE,
                    badgeCount = archiveCount,
                    onClick = { onSelectTab(NavigationTab.ARCHIVE) }
                )
                SidebarNavItem(
                    label = "سیستم",
                    emojiIcon = "⚙️",
                    active = currentTab == NavigationTab.SYSTEM,
                    badgeCount = 0,
                    onClick = { onSelectTab(NavigationTab.SYSTEM) }
                )

                SidebarSectionHeader("کمک")
                SidebarNavItem(
                    label = "راهنمای سریع",
                    emojiIcon = "❓",
                    active = false,
                    badgeCount = 0,
                    onClick = onOpenHelp
                )
            }

            // .sidebar-footer
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .border(width = 0.dp, color = Color.Transparent)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(EmeraldAccent)
                    )
                    Text(
                        text = "ذخیره‌سازی محلی فعال",
                        fontSize = 11.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x0AFFFFFF))
                        .border(1.dp, DaramashBorderSoft, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = userEmail,
                        fontSize = 11.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (isAdmin) "ادمین" else "حساب کاربری",
                        fontSize = 10.5.sp,
                        color = EmeraldBright,
                        fontWeight = FontWeight.Bold,
                        fontFamily = VazirmatnFontFamily
                    )
                }

                Text(
                    text = "دارمش نسخه ۱۸ (Build 18)",
                    fontSize = 10.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun SidebarSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = DaramashFaint,
        fontFamily = VazirmatnFontFamily,
        modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 12.dp, bottom = 4.dp)
    )
}

@Composable
private fun SidebarNavItem(
    label: String,
    iconType: String? = null,
    emojiIcon: String? = null,
    active: Boolean,
    badgeCount: Int,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    val bg = if (active) Color(0x17FFFFFF) else Color.Transparent
    val fg = if (active) Color.White else DaramashMuted

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg, shape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (iconType != null) {
            DaramashSvgIcon(
                type = iconType,
                tint = fg,
                modifier = Modifier.size(18.dp)
            )
        } else if (emojiIcon != null) {
            Text(text = emojiIcon, fontSize = 15.sp)
        }
        Text(
            text = label,
            fontSize = 13.5.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = fg,
            fontFamily = VazirmatnFontFamily,
            modifier = Modifier.weight(1f)
        )
        if (badgeCount > 0) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (active) Color(0x2E10A37F) else Color(0xFF1C1C1C))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) {
                Text(
                    text = PersianFormatters.toFa(badgeCount),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (active) EmeraldBright else DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            }
        }
    }
}

@Composable
fun DaramashFloatingBottomNav(
    backdrop: GlassBackdropState? = null,
    currentTab: NavigationTab,
    propertiesCount: Int,
    customersCount: Int,
    onSelectTab: (NavigationTab) -> Unit,
    onOpenSearch: () -> Unit
) {
    val capsuleShape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .height(58.dp)
            .glassSurface(
                backdrop = backdrop,
                shape = capsuleShape,
                blurRadius = 32.dp,
                tint = Color(0x22FFFFFF),
                fallbackFill = Color(0xE61C1C1E),
                lens = true,
                style = LiquidGlassStyle.Regular,
                specularStrength = 1.15f
            )
            .clip(capsuleShape)
            .graphicsLayer {
                shadowElevation = 18f
                shape = capsuleShape
                clip = false
            }
    ) {
        // iOS 26 multi-stop top specular
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(1.2.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.55f),
                            Color.White.copy(alpha = 0.18f),
                            Color.Transparent
                        )
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            val navItems = listOf(
                Triple(NavigationTab.HOME, "home", 0),
                Triple(NavigationTab.PROPERTIES, "properties", propertiesCount),
                Triple(NavigationTab.MATCHING, "matching", 0),
                Triple(NavigationTab.CUSTOMERS, "customers", customersCount),
                Triple(NavigationTab.TARGET, "target", 0)
            )

            navItems.forEach { (tab, iconKey, badge) ->
                val isSelected = currentTab == tab
                val itemShape = RoundedCornerShape(50)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(itemShape)
                        .then(
                            if (isSelected) {
                                Modifier
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(
                                                Color.White.copy(alpha = 0.22f),
                                                Color.White.copy(alpha = 0.08f)
                                            )
                                        ),
                                        itemShape
                                    )
                                    .border(
                                        width = 1.dp,
                                        brush = Brush.linearGradient(
                                            listOf(
                                                Color.White.copy(alpha = 0.45f),
                                                Color.White.copy(alpha = 0.08f)
                                            )
                                        ),
                                        shape = itemShape
                                    )
                            } else Modifier
                        )
                        .springPress(pressedScale = 0.9f, onClick = { onSelectTab(tab) }),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box {
                            DaramashSvgIcon(
                                type = iconKey,
                                tint = if (isSelected) Color.White else Color(0xA8FFFFFF),
                                modifier = Modifier.size(20.dp)
                            )
                            if (badge > 0) {
                                Box(
                                    modifier = Modifier
                                        .offset(x = (-10).dp, y = (-4).dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(EmeraldAccent)
                                        .padding(horizontal = 4.dp, vertical = 0.5.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = PersianFormatters.toFa(badge),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontFamily = VazirmatnFontFamily
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = tab.shortLabelFa,
                            fontSize = 10.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (isSelected) Color.White else Color(0xA8FFFFFF),
                            fontFamily = VazirmatnFontFamily,
                            maxLines = 1
                        )
                    }
                }
            }

            // Far-left circular crimson Search Trigger (.nav-search-trigger)
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .glassSurface(
                        backdrop = backdrop,
                        shape = CircleShape,
                        blurRadius = 22.dp,
                        tint = Color(0x33FF2D55),
                        fallbackFill = Color(0xE6FF2D55).copy(alpha = 0.35f),
                        style = LiquidGlassStyle.Clear,
                        specularStrength = 1.25f
                    )
                    .clip(CircleShape)
                    .border(1.dp, Color(0x88FF6E87), CircleShape)
                    .springPress(pressedScale = 0.9f, onClick = onOpenSearch),
                contentAlignment = Alignment.Center
            ) {
                DaramashSvgIcon(
                    type = "search",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun DaramashBottomSearchDock(
    backdrop: GlassBackdropState? = null,
    currentTab: NavigationTab,
    query: String,
    propertyStatusFilter: String,
    customerQualityFilter: String,
    onQueryChange: (String) -> Unit,
    onPropertyStatusChange: (String) -> Unit,
    onCustomerQualityChange: (String) -> Unit,
    onOpenAdvancedFilter: () -> Unit,
    onVoiceSearch: () -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Context-aware Filter Chips Row (.bsd-filters)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (currentTab == NavigationTab.CUSTOMERS) {
                listOf(
                    "all" to "همه",
                    "داغ" to "داغ 🔥",
                    "گرم" to "گرم",
                    "سرد" to "سرد"
                ).forEach { (k, label) ->
                    DaramashChip(
                        label = label,
                        active = customerQualityFilter == k,
                        onClick = { onCustomerQualityChange(k) }
                    )
                }
            } else {
                listOf(
                    "all" to "همه",
                    "active" to "فروشنده",
                    "sold" to "فروش رفته",
                    "inactive" to "غیرفعال"
                ).forEach { (k, label) ->
                    DaramashChip(
                        label = label,
                        active = propertyStatusFilter == k,
                        onClick = { onPropertyStatusChange(k) }
                    )
                }
                DaramashChip(
                    label = "🔍 فیلتر پیشرفته",
                    active = false,
                    onClick = onOpenAdvancedFilter
                )
            }
        }

        // Capsule Search Input Bar (.bsd-bar)
        val capsuleShape = RoundedCornerShape(50)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(62.dp)
                .glassSurface(backdrop, capsuleShape, tint = Color(0x3314141F), fallbackFill = Color(0xFA0E0E14))
                .clip(capsuleShape)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Right crimson search circle (.bsd-icon)
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0x47FF2D55), Color(0x1FFF2D55))
                        ),
                        CircleShape
                    )
                    .border(1.dp, Color(0x66FF7896), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                DaramashSvgIcon(
                    type = "search",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Input field
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) {
                    Text(
                        text = "جستجو در کد، محله، نام، تلفن...",
                        color = Color(0x75FFFFFF),
                        fontSize = 14.5.sp,
                        fontFamily = VazirmatnFontFamily
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = VazirmatnFontFamily
                    ),
                    cursorBrush = SolidColor(RubyPrimary),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Voice Search Mic button
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0x14FFFFFF), CircleShape)
                    .clickable { onVoiceSearch() },
                contentAlignment = Alignment.Center
            ) {
                Text("🎙", fontSize = 14.sp)
            }

            // Left close/clear button (.bsd-close)
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0x17FFFFFF), CircleShape)
                    .border(1.dp, Color(0x29FFFFFF), CircleShape)
                    .clickable { onClose() },
                contentAlignment = Alignment.Center
            ) {
                DaramashSvgIcon(
                    type = "close",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// ============================================================================
// PAGE 1: HOME SCREEN (viewHome in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun HomeScreen(
    properties: List<Property>,
    customers: List<Customer>,
    investors: List<Investor>,
    matchesCount: Int,
    activitiesCount: Int,
    target: AdvisorTarget,
    tetherRate: Long?,
    tetherUpdatedAt: Long,
    onRefreshTether: () -> Unit,
    onNavigate: (NavigationTab) -> Unit,
    onOpenProperty: (Property) -> Unit,
    onQuickLogProperty: (Property) -> Unit,
    onMatchProperty: (Property) -> Unit,
    onEditProperty: (Property) -> Unit,
    onArchiveProperty: (Property) -> Unit,
    onAddProperty: () -> Unit,
    onAddCustomer: () -> Unit,
    onOpenHelp: () -> Unit,
    onLoadSampleData: (() -> Unit)? = null
) {
    val activeProps = properties.filter { it.status == "فروشنده" }
    val soldProps = properties.filter { it.status.startsWith("فروش رفت") }
    val activeCustStatuses = listOf("تازه تو بازار", "در جست و جو", "آماده بازدید", "در مذاکره")
    val activeCusts = customers.filter { it.status in activeCustStatuses }
    val boughtCusts = customers.filter { it.status.startsWith("خرید کرد") }

    val fP = activeProps.count { PersianFormatters.needsFollowUp(it.lastContact, it.createdAt) }
    val fC = activeCusts.count { PersianFormatters.needsFollowUp(it.lastContact, it.createdAt) }
    val fI = investors.count { PersianFormatters.needsFollowUp(it.lastContact, it.createdAt) }
    val followN = fP + fC + fI
    val followText = listOfNotNull(
        if (fP > 0) "${PersianFormatters.toFa(fP)} فایل" else null,
        if (fC > 0) "${PersianFormatters.toFa(fC)} مشتری" else null,
        if (fI > 0) "${PersianFormatters.toFa(fI)} سرمایه‌گذار" else null
    ).joinToString(" · ")

    val targetCode = PersianFormatters.toEn(target.targetFileCode).trim()
    val targetProp = if (targetCode.isEmpty()) null else properties.find {
        PersianFormatters.toEn(it.code).trim() == targetCode
    }

    val targetStats = remember(target) { TargetMath.stats(target) }
    val targetPct = targetStats.pct

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Hero Intro (.home-intro)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = R.drawable.daramash_logo),
                    contentDescription = "دارمش",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(60.dp)
                        .clip(RoundedCornerShape(17.dp))
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "دارمش",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "سیستم حرفه‌ای مدیریت املاک — فایل، مشتری، سرمایه‌گذار و پیوند هوشمند در یک نگاه.",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Welcome empty state card when no data
        if (properties.isEmpty() && customers.isEmpty() && investors.isEmpty()) {
            item {
                LiquidGlassCard(
                    variant = LiquidCardVariant.ACCENT,
                    contentPadding = PaddingValues(18.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "🌱 سه قدم تا اولین پرونده‌ی کامل",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldBright,
                            fontFamily = VazirmatnFontFamily
                        )
                        Text(
                            text = "۱. اولین فایل ملک را ثبت کن  ·  ۲. مشتری را اضافه کن  ·  ۳. پیوند هوشمند را ببین",
                            fontSize = 12.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            DaramashPrimaryButton(
                                text = "＋ ثبت اولین فایل",
                                small = true,
                                modifier = Modifier.weight(1f),
                                onClick = onAddProperty
                            )
                            DaramashGhostButton(
                                text = "＋ ثبت مشتری",
                                small = true,
                                modifier = Modifier.weight(1f),
                                onClick = onAddCustomer
                            )
                        }
                        if (onLoadSampleData != null) {
                            DaramashGhostButton(
                                text = "📦 بارگذاری داده‌های نمونه",
                                small = true,
                                onClick = onLoadSampleData
                            )
                        }
                    }
                }
            }
        }

        // 2. Capsule Quick Toolbar (.chip-row)
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    DaramashChip(
                        label = "✨ نمای کلی",
                        active = true,
                        onClick = {}
                    )
                }
                item {
                    DaramashChip(
                        label = "🏠 فایل‌های فعال (${PersianFormatters.toFa(activeProps.size)})",
                        active = false,
                        onClick = { onNavigate(NavigationTab.PROPERTIES) }
                    )
                }
                item {
                    DaramashChip(
                        label = "🔥 مشتری‌های فعال (${PersianFormatters.toFa(activeCusts.size)})",
                        active = false,
                        onClick = { onNavigate(NavigationTab.CUSTOMERS) }
                    )
                }
                item {
                    DaramashChip(
                        label = "⏰ نیازمند پیگیری (${PersianFormatters.toFa(followN)})",
                        active = false,
                        onClick = {
                            if (fC > fP) onNavigate(NavigationTab.CUSTOMERS) else onNavigate(NavigationTab.PROPERTIES)
                        }
                    )
                }
                item {
                    DaramashChip(
                        label = "🔗 پیوند هوشمند (${PersianFormatters.toFa(matchesCount)})",
                        active = false,
                        onClick = { onNavigate(NavigationTab.MATCHING) }
                    )
                }
                item {
                    DaramashChip(
                        label = "🎯 تارگت (${PersianFormatters.toFa(targetPct)}٪)",
                        active = false,
                        onClick = { onNavigate(NavigationTab.TARGET) }
                    )
                }
            }
        }

        // 3. Bento Card 1: Live Tether Rate (.hg.span-4)
        item {
            LiquidGlassCard(
                contentPadding = PaddingValues(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0x2E10A37F))
                            .border(1.dp, Color(0x6110A37F), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "₮",
                            color = EmeraldBright,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }
                    Text(
                        text = "قیمت آنلاین تتر",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x0DFFFFFF))
                            .border(1.dp, DaramashBorder, RoundedCornerShape(8.dp))
                            .clickable { onRefreshTether() },
                        contentAlignment = Alignment.Center
                    ) {
                        DaramashSvgIcon(
                            type = "refresh",
                            tint = DaramashMuted,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = if (tetherRate != null) "${PersianFormatters.toFa("%,d".format(tetherRate))} تومان" else "—",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = EmeraldBright,
                    fontFamily = VazirmatnFontFamily,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (tetherRate != null) {
                        if (tetherUpdatedAt > 0L) {
                            "آخرین بروزرسانی: ساعت " + PersianFormatters.toFa(
                                java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(tetherUpdatedAt))
                            )
                        } else {
                            "بروزرسانی زنده · نوبیتکس / والکس / تترلند"
                        }
                    } else {
                        "برای دریافت، روی بروزرسانی بزن"
                    },
                    fontSize = 11.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // 4. Bento Card 2: Motivation Quote (.hg.span-4.motivation-card)
        item {
            LiquidGlassCard(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "“",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black,
                        color = PurpleQuote,
                        lineHeight = 28.sp
                    )
                    Text(
                        text = target.motivation.ifBlank { "هر تماس، یک قدم به معامله‌ی بعدی نزدیک‌تره." },
                        fontSize = 14.5.sp,
                        fontStyle = FontStyle.Italic,
                        fontWeight = FontWeight.Medium,
                        color = DaramashText,
                        fontFamily = VazirmatnFontFamily,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // 5. Bento Cards 6, 5, 4, 3 (2x2 Grid on mobile)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Card 6: فروش رفته / خرید کرد (.hg.sold-bought)
                    HomeBentoNumberedCard(
                        num = "۶",
                        modifier = Modifier
                            .weight(1f)
                            .height(118.dp),
                        onClick = { onNavigate(NavigationTab.PROPERTIES) }
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("فروش رفته", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = BlueInfo, fontFamily = VazirmatnFontFamily)
                                Text(PersianFormatters.toFa(soldProps.size), fontSize = 20.sp, fontWeight = FontWeight.Black, color = BlueInfo, fontFamily = VazirmatnFontFamily)
                            }
                            Text("↓", fontSize = 13.sp, color = DaramashFaint)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("خرید کرد", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                                Text(PersianFormatters.toFa(boughtCusts.size), fontSize = 20.sp, fontWeight = FontWeight.Black, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                            }
                        }
                    }

                    // Card 5: سرمایه‌گذار
                    HomeBentoNumberedCard(
                        num = "۵",
                        modifier = Modifier
                            .weight(1f)
                            .height(118.dp),
                        onClick = { onNavigate(NavigationTab.INVESTORS) }
                    ) {
                        Text("سرمایه‌گذار", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        Text(PersianFormatters.toFa(investors.size), fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Card 4: مشتری فعال
                    HomeBentoNumberedCard(
                        num = "۴",
                        modifier = Modifier
                            .weight(1f)
                            .height(118.dp),
                        onClick = { onNavigate(NavigationTab.CUSTOMERS) }
                    ) {
                        Text("مشتری فعال", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        Text(PersianFormatters.toFa(activeCusts.size), fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    }

                    // Card 3: فایل فعال
                    HomeBentoNumberedCard(
                        num = "۳",
                        modifier = Modifier
                            .weight(1f)
                            .height(118.dp),
                        onClick = { onNavigate(NavigationTab.PROPERTIES) }
                    ) {
                        Text("فایل فعال", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        Text(PersianFormatters.toFa(activeProps.size), fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    }
                }
            }
        }

        // 6. Bento Card 7: Target File (.hg.span-4.target-file-card.big)
        item {
            LiquidGlassCard(
                contentPadding = PaddingValues(18.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    NumberBadge("۷", Modifier.align(Alignment.TopStart))
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "🎯 فایل هدف${if (target.targetFileCode.isNotBlank()) " · کد ${PersianFormatters.toFa(target.targetFileCode)}" else ""}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                        if (targetProp != null) {
                            PropertyPreviewCard(
                                property = targetProp,
                                onClick = { onOpenProperty(targetProp) },
                                onQuickLog = { onQuickLogProperty(targetProp) },
                                onMatchProperty = { onMatchProperty(targetProp) },
                                onEdit = { onEditProperty(targetProp) },
                                onArchive = { onArchiveProperty(targetProp) }
                            )
                            DaramashGhostButton(
                                text = "تغییر فایل هدف",
                                small = true,
                                onClick = { onNavigate(NavigationTab.TARGET) }
                            )
                        } else {
                            Text(
                                text = target.targetFileCode.ifBlank { "تعیین نشده" },
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = AmberWarn,
                                fontFamily = VazirmatnFontFamily
                            )
                            Text(
                                text = "برای تعیین، روی تارگت مشاور بزن",
                                fontSize = 12.sp,
                                color = DaramashMuted,
                                fontFamily = VazirmatnFontFamily
                            )
                        }
                    }
                }
            }
        }

        // 7. Bento Cards 10, 9, 8, and Target Metric (2x2 Grid)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Card 10: درصد موفقیت تارگت (.hg.gold)
                    HomeBentoNumberedCard(
                        num = "۱۰",
                        variant = LiquidCardVariant.GOLD,
                        modifier = Modifier
                            .weight(1f)
                            .height(114.dp),
                        onClick = { onNavigate(NavigationTab.TARGET) }
                    ) {
                        Text("درصد موفقیت تارگت", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        Text("${PersianFormatters.toFa(targetPct)}٪", fontSize = 26.sp, fontWeight = FontWeight.Black, color = AmberWarn, fontFamily = VazirmatnFontFamily)
                    }

                    // Card 9: وضعیت مشاور (.hg.status-good)
                    HomeBentoNumberedCard(
                        num = "۹",
                        variant = LiquidCardVariant.STATUS_GOOD,
                        modifier = Modifier
                            .weight(1f)
                            .height(114.dp),
                        onClick = { onNavigate(NavigationTab.TARGET) }
                    ) {
                        Text("وضعیت مشاور", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        Text(target.status.ifBlank { "توکار هستم" }, fontSize = 17.sp, fontWeight = FontWeight.Black, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Card 8: جایگاه در رقابت
                    HomeBentoNumberedCard(
                        num = "۸",
                        modifier = Modifier
                            .weight(1f)
                            .height(114.dp),
                        onClick = { onNavigate(NavigationTab.TARGET) }
                    ) {
                        Text("جایگاه در رقابت", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        Text(if (target.rank > 0) "#${PersianFormatters.toFa(target.rank)}" else "—", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = VazirmatnFontFamily)
                    }

                    // Card Accent: واریزی هدف
                    HomeBentoNumberedCard(
                        num = null,
                        variant = LiquidCardVariant.ACCENT,
                        modifier = Modifier
                            .weight(1f)
                            .height(114.dp),
                        onClick = { onNavigate(NavigationTab.TARGET) }
                    ) {
                        Text(if (target.targetType == "contracts") "قرارداد هدف" else "واریزی هدف", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = if (!targetStats.isSet) "—"
                            else if (target.targetType == "contracts") "${PersianFormatters.toFa(target.targetContracts)} قرارداد"
                            else "${PersianFormatters.formatMoneyToman(target.targetDeposit)} ت",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = EmeraldBright,
                            fontFamily = VazirmatnFontFamily,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // 8. Follow-up Card (.hg.span-4.followup-card)
        item {
            LiquidGlassCard(
                variant = if (followN > 0) LiquidCardVariant.STATUS_MID else LiquidCardVariant.DEFAULT,
                onClick = {
                    if (fC > fP) onNavigate(NavigationTab.CUSTOMERS) else onNavigate(NavigationTab.PROPERTIES)
                },
                contentPadding = PaddingValues(18.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "⏰ نیازمند پیگیری (بیش از ۷ روز بی‌تماس)",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = PersianFormatters.toFa(followN),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = if (followN > 0) AmberWarn else Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = if (followN > 0) followText else "همه پیگیری‌ها به‌روز است",
                        fontSize = 12.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }
        }

        // 9. Monthly Report Card (📅 گزارش این ماه)
        item {
            LiquidGlassCard(
                variant = LiquidCardVariant.BLUE_REPORT,
                contentPadding = PaddingValues(18.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "📅 گزارش این ماه",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        MonthlyReportMetric(PersianFormatters.toFa(properties.size), "فایل جدید")
                        MonthlyReportMetric(PersianFormatters.toFa(customers.size), "مشتری جدید")
                        MonthlyReportMetric(PersianFormatters.toFa(matchesCount), "پیوند جدید")
                        MonthlyReportMetric(PersianFormatters.toFa(activitiesCount), "فعالیت")
                    }
                }
            }
        }

        // 10. Bento Card 11: Successful Matches (.hg.span-4.matches-card)
        item {
            LiquidGlassCard(
                variant = LiquidCardVariant.MATCHES_BIG,
                onClick = { onNavigate(NavigationTab.MATCHING) },
                contentPadding = PaddingValues(24.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    NumberBadge("۱۱", Modifier.align(Alignment.TopStart))
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🤝 پیوند های موفق",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = PersianFormatters.toFa(matchesCount),
                            fontSize = 54.sp,
                            fontWeight = FontWeight.Black,
                            color = EmeraldBright,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeBentoNumberedCard(
    num: String?,
    modifier: Modifier = Modifier,
    variant: LiquidCardVariant = LiquidCardVariant.DEFAULT,
    onClick: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    LiquidGlassCard(
        modifier = modifier,
        variant = variant,
        onClick = onClick,
        contentPadding = PaddingValues(14.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (num != null) {
                NumberBadge(num, Modifier.align(Alignment.TopStart))
            }
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                content = content
            )
        }
    }
}

@Composable
private fun NumberBadge(num: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(Color(0x0FFFFFFF))
            .border(1.dp, DaramashBorderSoft, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = num,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            color = DaramashFaint,
            fontFamily = VazirmatnFontFamily
        )
    }
}

@Composable
private fun MonthlyReportMetric(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = BlueInfo,
            fontFamily = VazirmatnFontFamily
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 10.5.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
    }
}

// ============================================================================
// PAGE 2: PROPERTIES SCREEN (viewProperties in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun PropertiesScreen(
    allPropertiesCount: Int,
    properties: List<Property>,
    filter: PropertyFilterState,
    selectedIds: Set<String>,
    onFilterChange: ((PropertyFilterState) -> PropertyFilterState) -> Unit,
    onOpenAdvancedFilter: () -> Unit,
    onSelectToggle: (String) -> Unit,
    onClearSelection: () -> Unit,
    onArchiveSelected: () -> Unit,
    onOpenDetail: (Property) -> Unit,
    onQuickLog: (Property) -> Unit,
    onMatchProperty: (Property) -> Unit,
    onEdit: (Property) -> Unit,
    onArchive: (Property) -> Unit,
    onAddNew: () -> Unit
) {
    var selMode by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // .page-head
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "فایل‌های املاک",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = "${PersianFormatters.toFa(allPropertiesCount)} فایل${if (filter.query.isNotBlank() || properties.size != allPropertiesCount) " · ${PersianFormatters.toFa(properties.size)} نتیجه" else ""}",
                        fontSize = 12.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DaramashGhostButton(
                        text = if (selMode || selectedIds.isNotEmpty()) "✕ پایان انتخاب" else "☑️ انتخاب",
                        small = true,
                        onClick = {
                            if (selMode || selectedIds.isNotEmpty()) {
                                selMode = false
                                onClearSelection()
                            } else {
                                selMode = true
                            }
                        }
                    )
                    DaramashPrimaryButton(
                        text = "＋ فایل جدید",
                        small = true,
                        onClick = onAddNew
                    )
                }
            }
        }

        // Status filter chips (.chip-row)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val statuses = listOf(
                    "all" to "همه",
                    "active" to "فروشنده",
                    "sold" to "فروش رفته",
                    "inactive" to "غیرفعال"
                )
                items(statuses) { (key, label) ->
                    DaramashChip(
                        label = label,
                        active = filter.statusFilter == key,
                        onClick = { onFilterChange { it.copy(statusFilter = key) } }
                    )
                }
            }
        }

        // Advanced Filter chip row
        item {
            val hasAdv = filter.minArea != null || filter.maxArea != null || filter.maxPrice != null ||
                filter.minBedrooms != null || filter.requireParking || filter.requireElevator ||
                filter.requireStorage || filter.requireTerrace || filter.statusFilter == "investable"
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    DaramashChip(
                        label = "🔍 فیلتر پیشرفته",
                        active = hasAdv,
                        onClick = onOpenAdvancedFilter
                    )
                }
                if (hasAdv) {
                    item {
                        DaramashChip(
                            label = "پاک کردن فیلترها",
                            active = false,
                            trailingClose = true,
                            onClick = { onFilterChange { PropertyFilterState(query = it.query) } }
                        )
                    }
                }
            }
        }

        // Sort chips (.chip-row)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val sorts = listOf(
                    "newest" to "🆕 جدیدترین",
                    "followup" to "⏰ نیازمند پیگیری",
                    "expensive" to "💰 گران‌ترین",
                    "cheapest" to "💵 ارزان‌ترین",
                    "largest" to "📐 بزرگ‌ترین"
                )
                items(sorts) { (key, label) ->
                    DaramashChip(
                        label = label,
                        active = filter.sortMode == key,
                        onClick = { onFilterChange { it.copy(sortMode = key) } }
                    )
                }
            }
        }

        if (selectedIds.isNotEmpty()) {
            item {
                LiquidGlassCard(
                    variant = LiquidCardVariant.ACCENT,
                    contentPadding = PaddingValues(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${PersianFormatters.toFa(selectedIds.size)} انتخاب",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldBright,
                            fontFamily = VazirmatnFontFamily
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DaramashDangerButton(
                                text = "🗑 آرشیو انتخاب‌شده‌ها",
                                small = true,
                                onClick = {
                                    onArchiveSelected()
                                    selMode = false
                                }
                            )
                            DaramashGhostButton(
                                text = "✕",
                                small = true,
                                onClick = {
                                    onClearSelection()
                                    selMode = false
                                }
                            )
                        }
                    }
                }
            }
        }

        if (properties.isEmpty()) {
            item {
                DaramashEmptyState(
                    icon = if (filter.query.isNotBlank() || filter.statusFilter != "all") "🔍" else "🏠",
                    title = if (filter.query.isNotBlank() || filter.statusFilter != "all") "نتیجه‌ای پیدا نشد" else "فایلی ثبت نشده",
                    hint = if (filter.query.isNotBlank() || filter.statusFilter != "all") "جستجو یا فیلتر را تغییر بده" else "اولین فایل ملک را اضافه کن",
                    buttonText = if (filter.query.isNotBlank() || filter.statusFilter != "all") null else "＋ ثبت اولین فایل",
                    onButtonClick = onAddNew
                )
            }
        } else {
            items(properties, key = { it.id }) { prop ->
                PropertyPreviewCard(
                    property = prop,
                    isSelected = prop.id in selectedIds,
                    onClick = {
                        if (selMode) onSelectToggle(prop.id) else onOpenDetail(prop)
                    },
                    onQuickLog = { onQuickLog(prop) },
                    onMatchProperty = { onMatchProperty(prop) },
                    onEdit = { onEdit(prop) },
                    onArchive = { onArchive(prop) }
                )
            }
        }
    }
}

// ============================================================================
// PAGE 3: CUSTOMERS SCREEN (viewCustomers in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun CustomersScreen(
    allCustomersCount: Int,
    customers: List<Customer>,
    query: String,
    qualityFilter: String,
    onQueryChange: (String) -> Unit,
    onQualityChange: (String) -> Unit,
    onOpenDetail: (Customer) -> Unit,
    onQuickLog: (Customer) -> Unit,
    onMatchCustomer: (Customer) -> Unit,
    onAddNew: () -> Unit,
    onEdit: (Customer) -> Unit,
    onArchive: (Customer) -> Unit
) {
    var custSort by rememberSaveable { mutableStateOf("recent") }

    val sortedCustomers = remember(customers, custSort) {
        when (custSort) {
            "urgent" -> customers.sortedByDescending { PersianFormatters.daysSinceIso(it.lastContact) }
            "budget-desc" -> customers.sortedByDescending { it.budgetMax }
            else -> customers.sortedByDescending { it.createdAt }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مشتری‌ها",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = "${PersianFormatters.toFa(allCustomersCount)} مشتری${if (query.isNotBlank()) " · ${PersianFormatters.toFa(sortedCustomers.size)} نتیجه" else ""}",
                        fontSize = 12.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
                DaramashPrimaryButton(
                    text = "＋ مشتری جدید",
                    small = true,
                    onClick = onAddNew
                )
            }
        }

        // Quality filter chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val fchips = listOf(
                    "all" to "همه",
                    "داغ" to "داغ 🔥",
                    "گرم" to "گرم",
                    "سرد" to "سرد"
                )
                items(fchips) { (k, l) ->
                    DaramashChip(
                        label = l,
                        active = qualityFilter == k,
                        onClick = { onQualityChange(k) }
                    )
                }
            }
        }

        // Sort chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val schips = listOf(
                    "recent" to "🆕 جدیدترین",
                    "urgent" to "⏰ نیازمند پیگیری",
                    "budget-desc" to "💰 بالاترین بودجه"
                )
                items(schips) { (k, l) ->
                    DaramashChip(
                        label = l,
                        active = custSort == k,
                        onClick = { custSort = k }
                    )
                }
            }
        }

        if (sortedCustomers.isEmpty()) {
            item {
                DaramashEmptyState(
                    icon = if (query.isNotBlank() || qualityFilter != "all") "🔍" else "🧑",
                    title = if (query.isNotBlank() || qualityFilter != "all") "نتیجه‌ای پیدا نشد" else "مشتری‌ای ثبت نشده",
                    hint = if (query.isNotBlank() || qualityFilter != "all") "جستجو یا فیلتر را تغییر بده" else "اولین مشتری را اضافه کن",
                    buttonText = if (query.isNotBlank() || qualityFilter != "all") null else "＋ ثبت اولین مشتری",
                    onButtonClick = onAddNew
                )
            }
        } else {
            items(sortedCustomers, key = { it.id }) { cust ->
                CustomerPreviewCard(
                    customer = cust,
                    onClick = { onOpenDetail(cust) },
                    onQuickLog = { onQuickLog(cust) },
                    onMatchCustomer = { onMatchCustomer(cust) },
                    onEdit = { onEdit(cust) },
                    onArchive = { onArchive(cust) }
                )
            }
        }
    }
}

// ============================================================================
// PAGE 4: INVESTORS SCREEN (viewInvestors in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun InvestorsScreen(
    investors: List<Investor>,
    query: String,
    onOpenDetail: (Investor) -> Unit,
    onQuickLog: (Investor) -> Unit,
    onMatchInvestor: (Investor) -> Unit,
    onAddNew: () -> Unit,
    onEdit: (Investor) -> Unit,
    onArchive: (Investor) -> Unit
) {
    var invSort by rememberSaveable { mutableStateOf("recent") }

    val filtered = remember(investors, query, invSort) {
        val q = PersianFormatters.normalizeSearch(query)
        val base = investors.filter { v ->
            if (q.isEmpty()) true else {
                (listOf(v.firstName, v.lastName, v.phone1, v.businessType) + v.neighborhoods)
                    .any { PersianFormatters.normalizeSearch(it).contains(q) }
            }
        }
        when (invSort) {
            "urgent" -> base.sortedByDescending { PersianFormatters.daysSinceIso(it.lastContact) }
            "budget-desc" -> base.sortedByDescending { it.buyAmount }
            else -> base.sortedByDescending { it.createdAt }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "سرمایه‌گذاران",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = "${PersianFormatters.toFa(investors.size)} سرمایه‌گذار",
                        fontSize = 12.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
                DaramashPrimaryButton(
                    text = "＋ سرمایه‌گذار جدید",
                    small = true,
                    onClick = onAddNew
                )
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val schips = listOf(
                    "recent" to "🆕 جدیدترین",
                    "urgent" to "⏰ نیازمند پیگیری",
                    "budget-desc" to "💰 بالاترین بودجه"
                )
                items(schips) { (k, l) ->
                    DaramashChip(
                        label = l,
                        active = invSort == k,
                        onClick = { invSort = k }
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                DaramashEmptyState(
                    icon = "💼",
                    title = "سرمایه‌گذاری ثبت نشده",
                    hint = "اولین سرمایه‌گذار را اضافه کن",
                    buttonText = "＋ ثبت اولین سرمایه‌گذار",
                    onButtonClick = onAddNew
                )
            }
        } else {
            items(filtered, key = { it.id }) { inv ->
                InvestorPreviewCard(
                    investor = inv,
                    onClick = { onOpenDetail(inv) },
                    onQuickLog = { onQuickLog(inv) },
                    onMatchInvestor = { onMatchInvestor(inv) },
                    onEdit = { onEdit(inv) },
                    onArchive = { onArchive(inv) }
                )
            }
        }
    }
}

// ============================================================================
// PAGE 5: SMART MATCHING SCREEN (viewMatching in daramashNativeRuntime.ts)
// ============================================================================

private data class NeedRow(
    val id: String,
    val kind: String,
    val name: String,
    val phone: String,
    val meta: String,
    val result: ir.daramash.app.domain.model.MatchResult,
    val hot: Boolean,
    val customer: Customer?,
    val investor: Investor?
)

private fun openWhatsAppShare(context: android.content.Context, phone: String, text: String) {
    val base = PersianFormatters.whatsappUrl(phone)
    val url = (if (base.isNotEmpty()) base else "https://wa.me/") + "?text=" + android.net.Uri.encode(text)
    try {
        context.startActivity(
            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SmartMatchingScreen(
    viewModel: DaramashViewModel,
    properties: List<Property>,
    customers: List<Customer>,
    investors: List<Investor>,
    matches: List<MatchLink>,
    initialMode: String,
    initialPropertyId: String?,
    initialNeedId: String?,
    onModeChange: (String) -> Unit,
    onPropertySelect: (String) -> Unit,
    onNeedSelect: (String) -> Unit,
    onOpenProperty: (Property) -> Unit,
    onOpenCustomer: (Customer) -> Unit,
    onOpenInvestor: (Investor) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val engine = viewModel.matchEngine

    // Only active (for sale) files take part. Everything below is computed once per input change.
    val activeProps = remember(properties) { properties.filter { it.status == "فروشنده" } }
    val ctx = remember(activeProps, customers, investors) { MatchContext.build(activeProps, customers, investors) }
    val linkedSet = remember(matches) { matches.mapTo(HashSet()) { it.propertyId + "|" + it.needId } }

    val selectedProp = activeProps.find { it.id == initialPropertyId } ?: activeProps.firstOrNull()
    val pickedCust = customers.find { it.id == initialNeedId }
    val pickedInv = investors.find { it.id == initialNeedId }
    val needCust: Customer? = pickedCust ?: if (pickedInv == null) customers.firstOrNull() else null
    val needInv: Investor? = if (needCust != null) null else (pickedInv ?: investors.firstOrNull())

    var showPickerDialog by rememberSaveable { mutableStateOf(false) }
    var minScore by rememberSaveable { mutableStateOf(50) }
    var showRejected by rememberSaveable { mutableStateOf(false) }

    val needToProperty = initialMode == "needToProperty"

    // need -> files
    val propResults = remember(needCust, needInv, activeProps, linkedSet, ctx) {
        val nId = needCust?.id ?: needInv?.id
        if (nId == null) {
            emptyList()
        } else {
            activeProps.map { p ->
                val linked = linkedSet.contains(p.id + "|" + nId)
                val r = if (needCust != null) engine.evaluateCustomerMatch(needCust, p, linked, ctx)
                else engine.evaluateInvestorMatch(needInv!!, p, linked, ctx)
                p to r
            }.sortedWith(
                compareByDescending<Pair<Property, ir.daramash.app.domain.model.MatchResult>> { it.second.score }
                    .thenByDescending { it.first.createdAt }
            )
        }
    }

    // file -> needs (customers and investors)
    val needResults = remember(selectedProp, customers, investors, linkedSet, ctx) {
        if (selectedProp == null) {
            emptyList()
        } else {
            val list = ArrayList<NeedRow>()
            customers.forEach { c ->
                list.add(
                    NeedRow(
                        id = c.id, kind = "customer", name = "🧑 " + c.fullName, phone = c.phone1,
                        meta = c.neighborhoods.joinToString("، ") + (if (c.budgetMax > 0) " · تا " + PersianFormatters.formatMoneyToman(c.budgetMax) else "") +
                            (if (c.quality == "داغ") " · 🔥 داغ" else "") +
                            (if (c.lastContact.isNotBlank()) PersianFormatters.daysSinceIso(c.lastContact).let { d -> if (d in 0..998) " · آخرین تماس ${PersianFormatters.toFa(d)} روز پیش" else "" } else ""),
                        result = engine.evaluateCustomerMatch(c, selectedProp, linkedSet.contains(selectedProp.id + "|" + c.id), ctx),
                        hot = c.quality == "داغ" || c.status == "آماده بازدید" || c.status == "در مذاکره",
                        customer = c, investor = null
                    )
                )
            }
            investors.forEach { i ->
                list.add(
                    NeedRow(
                        id = i.id, kind = "investor", name = "💼 " + i.fullName, phone = i.phone1,
                        meta = i.neighborhoods.joinToString("، ") + (if (i.buyAmount > 0) " · سقف خرید " + PersianFormatters.formatMoneyToman(i.buyAmount) else ""),
                        result = engine.evaluateInvestorMatch(i, selectedProp, linkedSet.contains(selectedProp.id + "|" + i.id), ctx),
                        hot = false,
                        customer = null, investor = i
                    )
                )
            }
            list.sortedWith(compareByDescending<NeedRow> { it.result.score }.thenByDescending { it.hot })
        }
    }

    val visibleCount: Int
    val rejectedCount: Int
    val greatCount: Int
    val goodCount: Int
    val autoCandidates: Int
    if (needToProperty) {
        val ok = propResults.filter { !it.second.rejected }
        visibleCount = ok.count { it.second.score >= minScore }
        rejectedCount = propResults.size - ok.size
        greatCount = ok.count { it.second.score >= 85 }
        goodCount = ok.count { it.second.score in 70..84 }
        autoCandidates = ok.count { it.second.score >= 85 && !it.second.isLinked }
    } else {
        val ok = needResults.filter { !it.result.rejected }
        visibleCount = ok.count { it.result.score >= minScore }
        rejectedCount = needResults.size - ok.size
        greatCount = ok.count { it.result.score >= 85 }
        goodCount = ok.count { it.result.score in 70..84 }
        autoCandidates = ok.count { it.result.score >= 85 && !it.result.isLinked }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "پیوند سازی هوشمند",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily
                )
                Text(
                    text = "${PersianFormatters.toFa(activeProps.size)} فایل فعال · ${PersianFormatters.toFa(matches.size)} پیوند ثبت‌شده",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DaramashChip(
                    label = "🧑 از نیاز → فایل",
                    active = needToProperty,
                    onClick = { onModeChange("needToProperty") }
                )
                DaramashChip(
                    label = "🏠 از فایل → نیاز",
                    active = !needToProperty,
                    onClick = { onModeChange("propertyToNeed") }
                )
            }
        }

        if ((customers.isEmpty() && investors.isEmpty()) || activeProps.isEmpty()) {
            item {
                DaramashEmptyState(
                    icon = "🔗",
                    title = if (customers.isEmpty() && investors.isEmpty()) "ابتدا یک مشتری یا سرمایه‌گذار بساز" else "فایل فعالی (وضعیت «فروشنده») نداری",
                    hint = "برای فعال شدن موتور پیوند، حداقل یک نیاز و یک فایل فعال لازم است"
                )
            }
        } else {
            // picker
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF161616))
                        .border(1.dp, DaramashBorder, RoundedCornerShape(12.dp))
                        .clickable { showPickerDialog = true }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (needToProperty) {
                            if (needCust != null) "🧑 ${needCust.fullName}" else "💼 ${needInv?.fullName ?: ""}"
                        } else {
                            "🏠 کد ${PersianFormatters.toFa(selectedProp?.code ?: "")} · ${selectedProp?.neighborhood ?: ""}"
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = "🔍 جستجو / تغییر",
                        fontSize = 12.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }

            // summary of the selected side
            item {
                LiquidGlassCard(contentPadding = PaddingValues(16.dp)) {
                    if (needToProperty) {
                        val nName = needCust?.fullName ?: needInv?.fullName ?: ""
                        Text(
                            text = (if (needCust != null) "🧑 مشتری: " else "💼 سرمایه‌گذار: ") + nName,
                            fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = buildString {
                                val nbs = needCust?.neighborhoods ?: needInv?.neighborhoods ?: emptyList()
                                if (nbs.isNotEmpty()) append("محله‌ها: ${nbs.joinToString("، ")} · ")
                                if (needCust != null) {
                                    if (needCust.areaMin > 0) append("حداقل متراژ: ${PersianFormatters.toFa(needCust.areaMin)} · ")
                                    if (needCust.bedroomsMin > 0) append("حداقل خواب: ${PersianFormatters.toFa(needCust.bedroomsMin)} · ")
                                    if (needCust.budgetMax > 0) append("بودجه: تا ${PersianFormatters.formatMoneyToman(needCust.budgetMax)}")
                                } else if (needInv != null && needInv.hasBuy == "بله" && needInv.buyAmount > 0) {
                                    append("سقف خرید: ${PersianFormatters.formatMoneyToman(needInv.buyAmount)}")
                                }
                            },
                            fontSize = 12.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily
                        )
                    } else if (selectedProp != null) {
                        Text(
                            text = "🏠 کد ${PersianFormatters.toFa(selectedProp.code)} · ${selectedProp.neighborhood}",
                            fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "متراژ: ${PersianFormatters.toFa(selectedProp.area)} متر · قیمت: ${PersianFormatters.formatMoneyToman(selectedProp.totalPrice)} تومان" +
                                (if (selectedProp.investable) " · 💼 قابل سرمایه‌گذاری" else ""),
                            fontSize = 12.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily
                        )
                    }
                }
            }

            // result summary + threshold filter
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "🔥 ${PersianFormatters.toFa(greatCount)} احتمال بالا · ${PersianFormatters.toFa(goodCount)} متوسط · ${PersianFormatters.toFa(rejectedCount)} ردشده (قطعاً نمی‌خرد)",
                        fontSize = 12.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0, 50, 70, 85).forEach { th ->
                            DaramashChip(
                                label = if (th == 0) "همه" else PersianFormatters.toFa(th) + "٪ +",
                                active = minScore == th,
                                onClick = { minScore = th }
                            )
                        }
                        if (rejectedCount > 0) {
                            DaramashChip(
                                label = "🚫 ردشده‌ها (${PersianFormatters.toFa(rejectedCount)})",
                                active = showRejected,
                                onClick = { showRejected = !showRejected }
                            )
                        }
                    }
                    if (autoCandidates > 0) {
                        DaramashPrimaryButton(
                            text = "⚡ پیوند خودکار ${PersianFormatters.toFa(autoCandidates)} مورد ۸۵٪+",
                            small = true,
                            onClick = {
                                val links = ArrayList<Triple<String, String, String>>()
                                if (needToProperty) {
                                    val nId = needCust?.id ?: needInv?.id
                                    val kind = if (needCust != null) "customer" else "investor"
                                    if (nId != null) propResults.filter { !it.second.rejected && it.second.score >= 85 && !it.second.isLinked }
                                        .forEach { links.add(Triple(it.first.id, nId, kind)) }
                                } else if (selectedProp != null) {
                                    needResults.filter { !it.result.rejected && it.result.score >= 85 && !it.result.isLinked }
                                        .forEach { links.add(Triple(selectedProp.id, it.id, it.kind)) }
                                }
                                viewModel.autoLinkMatches(links)
                            }
                        )
                    }
                }
            }

            if (needToProperty) {
                val nId = needCust?.id ?: needInv?.id
                val kind = if (needCust != null) "customer" else "investor"
                val phone = needCust?.phone1 ?: needInv?.phone1 ?: ""
                val shown = propResults.filter {
                    if (it.second.rejected) showRejected else it.second.score >= minScore
                }
                if (shown.isEmpty()) {
                    item {
                        DaramashEmptyState(
                            icon = "🔎",
                            title = "فایل مناسبی با این آستانه پیدا نشد",
                            hint = "آستانه را پایین‌تر بیاور یا «ردشده‌ها» را ببین تا دلیل ردشدن‌ها را بخوانی"
                        )
                    }
                }
                items(shown, key = { "p-" + it.first.id }) { pair ->
                    val prop = pair.first
                    val res = pair.second
                    MatchResultCard(
                        result = res,
                        title = "کد ${PersianFormatters.toFa(prop.code)} · ${prop.neighborhood} · ${PersianFormatters.toFa(prop.area)} متر",
                        meta = "${PersianFormatters.toFa(prop.bedrooms)} خواب · ${PersianFormatters.formatMoneyToman(prop.totalPrice)} تومان",
                        onToggleLink = { if (nId != null) viewModel.toggleMatch(prop.id, nId, kind, res.isLinked) },
                        onView = { onOpenProperty(prop) },
                        onSend = if (phone.isNotBlank()) ({
                            openWhatsAppShare(context, phone, PersianFormatters.formatPrivacySafePropertyShare(prop))
                        }) else null
                    )
                }
            } else if (selectedProp != null) {
                val shown = needResults.filter {
                    if (it.result.rejected) showRejected else it.result.score >= minScore
                }
                if (shown.isEmpty()) {
                    item {
                        DaramashEmptyState(
                            icon = "🔎",
                            title = "نیاز مناسبی با این آستانه پیدا نشد",
                            hint = "آستانه را پایین‌تر بیاور یا «ردشده‌ها» را ببین تا دلیل ردشدن‌ها را بخوانی"
                        )
                    }
                }
                items(shown, key = { "n-" + it.id }) { row ->
                    MatchResultCard(
                        result = row.result,
                        title = row.name,
                        meta = (if (row.phone.isNotBlank()) PersianFormatters.toFa(row.phone) + " · " else "") + row.meta,
                        onToggleLink = { viewModel.toggleMatch(selectedProp.id, row.id, row.kind, row.result.isLinked) },
                        onView = {
                            row.customer?.let { onOpenCustomer(it) }
                            row.investor?.let { onOpenInvestor(it) }
                        },
                        onSend = if (row.phone.isNotBlank()) ({
                            openWhatsAppShare(context, row.phone, PersianFormatters.formatPrivacySafePropertyShare(selectedProp))
                        }) else null
                    )
                }
            }
        }
    }

    if (showPickerDialog) {
        MatchEntityPickerModal(
            isPropertyMode = !needToProperty,
            properties = activeProps,
            customers = customers,
            investors = investors,
            onDismiss = { showPickerDialog = false },
            onPickProperty = { id ->
                onPropertySelect(id)
                showPickerDialog = false
            },
            onPickCustomer = { id ->
                onNeedSelect(id)
                showPickerDialog = false
            },
            onPickInvestor = { id ->
                onNeedSelect(id)
                showPickerDialog = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MatchResultCard(
    result: ir.daramash.app.domain.model.MatchResult,
    title: String,
    meta: String,
    onToggleLink: () -> Unit,
    onView: () -> Unit,
    onSend: (() -> Unit)?
) {
    val score = result.score
    val (scoreLabel, scoreBg, scoreFg) = when {
        result.rejected -> Triple("🚫 ردشده", Color(0x2EE5534B), RedDanger)
        score >= 85 -> Triple("احتمال خرید ${PersianFormatters.toFa(score)}٪ 🔥", Color(0x2E10A37F), EmeraldBright)
        score >= 70 -> Triple("احتمال خرید ${PersianFormatters.toFa(score)}٪", Color(0x2E7FB0FF), BlueInfo)
        score >= 50 -> Triple("احتمال خرید ${PersianFormatters.toFa(score)}٪", Color(0x2EE0A63A), AmberWarn)
        else -> Triple("احتمال خرید ${PersianFormatters.toFa(score)}٪ (ضعیف)", Color(0x2EE5534B), RedDanger)
    }

    LiquidGlassCard(
        onClick = onView,
        contentPadding = PaddingValues(18.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(scoreBg)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = scoreLabel,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = scoreFg,
                    fontFamily = VazirmatnFontFamily
                )
            }
            if (result.isLinked) {
                Text(
                    text = "✓ پیوند شده",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldBright,
                    fontFamily = VazirmatnFontFamily
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontFamily = VazirmatnFontFamily
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = meta,
            fontSize = 12.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )

        Spacer(Modifier.height(10.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            result.criteria.forEach { crit ->
                val bg = when {
                    crit.passed -> Color(0x1F10A37F)
                    crit.partial -> Color(0x24E0A63A)
                    else -> Color(0x24E5534B)
                }
                val fg = when {
                    crit.passed -> EmeraldBright
                    crit.partial -> AmberWarn
                    else -> RedDanger
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(bg)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = crit.label,
                        fontSize = 11.sp,
                        color = fg,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!result.rejected || result.isLinked) {
                if (result.isLinked) {
                    DaramashGhostButton(text = "✓ پیوند شده · لغو", small = true, onClick = onToggleLink)
                } else {
                    DaramashPrimaryButton(text = "🤝 ثبت پیوند", small = true, onClick = onToggleLink)
                }
            }
            if (onSend != null && !result.rejected) {
                DaramashGhostButton(text = "📤 ارسال در واتساپ", small = true, onClick = onSend)
            }
            DaramashGhostButton(text = "مشاهده", small = true, onClick = onView)
        }
    }
}

// ============================================================================
// PAGE 6: TARGET SCREEN (viewTarget in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TargetScreen(
    target: AdvisorTarget,
    properties: List<Property>,
    archivedProperties: List<Property>,
    customers: List<Customer>,
    investors: List<Investor>,
    matches: List<MatchLink>,
    onToggleContract: (Int) -> Unit,
    onAddDeposit: (Long, String) -> Unit,
    onRemoveDeposit: (String) -> Unit,
    onOpenEditTarget: () -> Unit,
    onOpenProperty: (Property) -> Unit,
    onQuickLogProperty: (Property) -> Unit,
    onMatchProperty: (Property) -> Unit,
    onEditProperty: (Property) -> Unit,
    onArchiveProperty: (Property) -> Unit
) {
    var depositMillionsInput by rememberSaveable { mutableStateOf("") }
    val stats = remember(target) { TargetMath.stats(target) }
    val isContracts = target.targetType == "contracts"
    val monthLabel = PersianFormatters.currentJalaliMonthLabel()

    val code = PersianFormatters.toEn(target.targetFileCode).trim()
    val activeHit = if (code.isEmpty()) null else properties.firstOrNull { PersianFormatters.toEn(it.code).trim() == code }
    val archivedHit = if (code.isEmpty() || activeHit != null) null
    else archivedProperties.firstOrNull { PersianFormatters.toEn(it.code).trim() == code }
    val recentMatches = remember(matches) { matches.sortedByDescending { it.createdAt }.take(3) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "🎯 تارگت مشاور",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = "هدف شخصی، وضعیت و رقابت درون دفتر",
                        fontSize = 12.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
                DaramashPrimaryButton(text = "✎ ویرایش تارگت", small = true, onClick = onOpenEditTarget)
            }
        }

        // motivation
        item {
            LiquidGlassCard {
                SysCardHeader("💬", "جمله‌ی انگیزشی")
                Spacer(Modifier.height(8.dp))
                Text(
                    text = target.motivation.ifBlank { "—" },
                    fontSize = 14.sp,
                    fontStyle = FontStyle.Italic,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily
                )
            }
        }

        // target file
        item {
            LiquidGlassCard {
                SysCardHeader("🎯", "فایل هدف")
                Spacer(Modifier.height(8.dp))
                SysStatRow("کد فایل", if (code.isEmpty()) "—" else PersianFormatters.toFa(code), AmberWarn)
                SysStatRow("وضعیت مشاور", target.status.ifBlank { "در حال تلاش" })
                when {
                    code.isEmpty() -> {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "هنوز فایل هدفی انتخاب نشده. با «✎ ویرایش تارگت» کد فایل را بنویس.",
                            fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily
                        )
                    }
                    activeHit != null -> {
                        Spacer(Modifier.height(10.dp))
                        PropertyPreviewCard(
                            property = activeHit,
                            onClick = { onOpenProperty(activeHit) },
                            onQuickLog = { onQuickLogProperty(activeHit) },
                            onMatchProperty = { onMatchProperty(activeHit) },
                            onEdit = { onEditProperty(activeHit) },
                            onArchive = { onArchiveProperty(activeHit) }
                        )
                    }
                    archivedHit != null -> {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "فایل کد ${PersianFormatters.toFa(code)} در آرشیو است. برای دیدنش از بخش آرشیو بازیابی‌اش کن.",
                            fontSize = 12.sp, color = AmberWarn, fontFamily = VazirmatnFontFamily
                        )
                    }
                    else -> {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "فایلی با کد ${PersianFormatters.toFa(code)} ثبت نشده. کد را بررسی کن یا فایل را بساز.",
                            fontSize = 12.sp, color = AmberWarn, fontFamily = VazirmatnFontFamily
                        )
                    }
                }
            }
        }

        // rank
        item {
            LiquidGlassCard {
                SysCardHeader("🏆", "جایگاه در رقابت")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (target.rank > 0) "#" + PersianFormatters.toFa(target.rank) else "—",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = EmeraldAccent,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = if (target.rank > 0) "جایگاه در جدول رقابت دفتر" else "هنوز ثبت نشده؛ با «✎ ویرایش تارگت» وارد کن",
                        fontSize = 12.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
            }
        }

        // month target
        item {
            LiquidGlassCard {
                SysCardHeader("📊", "تارگت ماه · $monthLabel")
                Spacer(Modifier.height(8.dp))
                SysStatRow("معیار", if (isContracts) "تعداد قرارداد" else "مبلغ واریزی")
                if (!stats.isSet) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "هنوز تارگت ماه تعیین نشده. با «✎ ویرایش تارگت» " + (if (isContracts) "تعداد قرارداد هدف" else "مبلغ هدف") + " را وارد کن.",
                        fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily
                    )
                } else {
                    SysStatRow(
                        "مقدار هدف",
                        if (isContracts) "${PersianFormatters.toFa(stats.target.toInt())} قرارداد"
                        else "${PersianFormatters.formatMoneyToman(stats.target)} تومان"
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${PersianFormatters.toFa(stats.pct)}٪",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = EmeraldAccent,
                            fontFamily = VazirmatnFontFamily
                        )
                        Text(
                            text = if (isContracts) "${PersianFormatters.toFa(stats.done.toInt())} از ${PersianFormatters.toFa(stats.target.toInt())} قرارداد" +
                                (if (stats.pct >= 100) " 🎉 هدف ماه محقق شد" else "")
                            else "${PersianFormatters.formatMoneyToman(stats.done)} از ${PersianFormatters.formatMoneyToman(stats.target)} تومان" +
                                (if (stats.pct >= 100) " 🎉 هدف ماه محقق شد" else " · مانده ${PersianFormatters.formatMoneyToman(stats.remaining)}"),
                            fontSize = 12.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF1C1C1C))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(fraction = (stats.pct / 100f).coerceIn(0.02f, 1f))
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(Brush.horizontalGradient(colors = listOf(EmeraldAccent, EmeraldBright)))
                        )
                    }

                    if (isContracts) {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            text = "روی هر قراردادِ بسته‌شده بزن:",
                            fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily
                        )
                        Spacer(Modifier.height(8.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            (0 until stats.target.toInt()).forEach { i ->
                                val isOn = stats.progress.ticks.getOrElse(i) { false }
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isOn) Color(0x3810A37F) else Color(0xFF161616))
                                        .border(1.dp, if (isOn) EmeraldAccent else DaramashBorder, RoundedCornerShape(10.dp))
                                        .clickable { onToggleContract(i) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isOn) "✓" else PersianFormatters.toFa(i + 1),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isOn) EmeraldBright else DaramashMuted,
                                        fontFamily = VazirmatnFontFamily
                                    )
                                }
                            }
                        }
                    } else {
                        Spacer(Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF161616))
                                    .border(1.dp, DaramashBorder, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (depositMillionsInput.isEmpty()) {
                                    Text(
                                        text = "مبلغ واریزی (به میلیون تومان)",
                                        fontSize = 12.5.sp, color = DaramashFaint, fontFamily = VazirmatnFontFamily
                                    )
                                }
                                BasicTextField(
                                    value = depositMillionsInput,
                                    onValueChange = { depositMillionsInput = it },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp, fontFamily = VazirmatnFontFamily),
                                    cursorBrush = SolidColor(EmeraldAccent),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            DaramashPrimaryButton(
                                text = "＋ ثبت",
                                small = true,
                                onClick = {
                                    val m = PersianFormatters.toEn(depositMillionsInput).trim().toLongOrNull()
                                    if (m != null && m > 0) {
                                        onAddDeposit(m * 1_000_000L, "واریزی")
                                        depositMillionsInput = ""
                                    }
                                }
                            )
                        }
                        if (stats.progress.deposits.isEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "هنوز واریزی‌ای برای این ماه ثبت نشده.",
                                fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily
                            )
                        } else {
                            Spacer(Modifier.height(8.dp))
                            stats.progress.deposits.forEach { dep ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF161616))
                                        .border(1.dp, DaramashBorderSoft, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "✓ ${PersianFormatters.formatMoneyToman(dep.amount)} تومان",
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldBright,
                                            fontFamily = VazirmatnFontFamily
                                        )
                                        Text(
                                            text = PersianFormatters.formatIsoToJalaliReadable(dep.date),
                                            fontSize = 11.5.sp,
                                            color = DaramashMuted,
                                            fontFamily = VazirmatnFontFamily
                                        )
                                    }
                                    DaramashCardIconBtn(
                                        emoji = "✕",
                                        style = IconBtnStyle.DANGER,
                                        onClick = { onRemoveDeposit(dep.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // successful matches
        item {
            LiquidGlassCard {
                SysCardHeader("🤝", "پیوندهای موفق")
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "این عدد خودکار از بخش «پیوند سازی هوشمند» خوانده می‌شود.",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = PersianFormatters.toFa(matches.size),
                        fontSize = 56.sp,
                        fontWeight = FontWeight.Black,
                        color = EmeraldBright,
                        fontFamily = VazirmatnFontFamily
                    )
                    Text(
                        text = "پیوند ثبت‌شده",
                        fontSize = 12.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                }
                recentMatches.forEach { m ->
                    val prop = properties.firstOrNull { it.id == m.propertyId } ?: archivedProperties.firstOrNull { it.id == m.propertyId }
                    val needName = customers.firstOrNull { it.id == m.needId }?.fullName
                        ?: investors.firstOrNull { it.id == m.needId }?.fullName ?: "—"
                    Text(
                        text = "🤝 کد ${PersianFormatters.toFa(prop?.code ?: "؟")} ↔ $needName",
                        fontSize = 12.5.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

// ============================================================================
// PAGE 7: MANAGER PANEL SCREEN (viewManager in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun ManagerPanelScreen(
    advisors: List<Advisor>,
    properties: List<Property>,
    customers: List<Customer>,
    onAddAdvisor: (String, String, String) -> Unit,
    onDeleteAdvisor: (String) -> Unit,
    groupSettings: AdvisorTarget,
    onUpdateAdvisor: (String, String, String, String) -> Unit,
    onSaveGroup: (String, Int, String, Long) -> Unit,
    onGenerateCode: (String) -> Unit,
    onImportCode: (String) -> Unit,
    onOpenProperty: (Property) -> Unit,
    onOpenCustomer: (Customer) -> Unit
) {
    var mgrTab by rememberSaveable { mutableStateOf("overview") }
    var showGroupEdit by rememberSaveable { mutableStateOf(false) }
    var editingAdvisorId by rememberSaveable { mutableStateOf("") }
    val nowMonthKey = remember {
        val c = java.util.Calendar.getInstance()
        val j = PersianFormatters.gregorianToJalali(c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH))
        "${j.first}-${j.second}"
    }
    fun monthKeyOf(ms: Long): String {
        val c = java.util.Calendar.getInstance().apply { timeInMillis = ms }
        val j = PersianFormatters.gregorianToJalali(c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH))
        return "${j.first}-${j.second}"
    }
    var showAddAdvisorModal by rememberSaveable { mutableStateOf(false) }
    var showImportCodeModal by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "🏢 پنل مدیریت املاک",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily
                )
                Text(
                    text = "گروه مشاوران دارمش",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val tabs = listOf(
                    "overview" to "📊 خلاصه",
                    "advisors" to "👥 مشاوران (${PersianFormatters.toFa(advisors.size)})",
                    "files" to "🏠 فایل‌ها (${PersianFormatters.toFa(properties.size)})",
                    "customers" to "🧑 مشتری‌ها (${PersianFormatters.toFa(customers.size)})"
                )
                items(tabs) { (k, label) ->
                    DaramashChip(
                        label = label,
                        active = mgrTab == k,
                        onClick = { mgrTab = k }
                    )
                }
            }
        }

        when (mgrTab) {
            "overview" -> {
                item {
                    LiquidGlassCard {
                        SysCardHeader("🏢", groupSettings.groupName.ifBlank { "گروه مشاوران دارمش" })
                        Spacer(Modifier.height(8.dp))
                        SysStatRow(
                            "رتبه‌ی گروه در رقابت دفتر",
                            if (groupSettings.groupRank > 0) "#" + PersianFormatters.toFa(groupSettings.groupRank) else "ثبت نشده",
                            EmeraldBright
                        )
                        SysStatRow("تعداد مشاوران فعال", PersianFormatters.toFa(advisors.size))
                        if (groupSettings.groupTargetValue > 0L) {
                            val typeLabel = when (groupSettings.groupTargetType) {
                                "contracts" -> "تعداد قرارداد"
                                "deposit" -> "واریزی (میلیون تومان)"
                                else -> "فایل ثبت‌شده"
                            }
                            val shown = if (groupSettings.groupTargetType == "deposit") groupSettings.groupTargetValue / 1_000_000L else groupSettings.groupTargetValue
                            SysStatRow("تارگت ماه گروه ($typeLabel)", PersianFormatters.toFa(shown.toInt()))
                            if (groupSettings.groupTargetType == "files") {
                                val monthFiles = properties.count { it.advisorName.isNotBlank() && monthKeyOf(it.createdAt) == nowMonthKey }
                                SysStatRow(
                                    "فایل ثبت‌شده‌ی مشاورها در این ماه",
                                    PersianFormatters.toFa(monthFiles) + " از " + PersianFormatters.toFa(shown.toInt())
                                )
                            }
                        } else {
                            SysStatRow("تارگت ماه گروه", "ثبت نشده")
                        }
                        Spacer(Modifier.height(10.dp))
                        DaramashGhostButton(
                            text = "✎ ویرایش گروه",
                            small = true,
                            onClick = { showGroupEdit = true }
                        )
                    }
                }
                item {
                    LiquidGlassCard {
                        SysCardHeader("📥", "داده‌های مشاورها")
                        Spacer(Modifier.height(8.dp))
                        SysStatRow("فایل", PersianFormatters.toFa(properties.size))
                        SysStatRow("مشتری", PersianFormatters.toFa(customers.size))
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DaramashPrimaryButton(
                                text = "📥 ثبت کد مشاور",
                                small = true,
                                onClick = { showImportCodeModal = true }
                            )
                            DaramashGhostButton(
                                text = "📤 تولید کد اشتراک",
                                small = true,
                                onClick = { onGenerateCode("مشاور ارشد") }
                            )
                        }
                    }
                }
            }
            "advisors" -> {
                item {
                    DaramashPrimaryButton(
                        text = "＋ مشاور جدید",
                        onClick = { showAddAdvisorModal = true }
                    )
                }
                if (advisors.isEmpty()) {
                    item {
                        DaramashEmptyState(
                            icon = "👥",
                            title = "هنوز مشاوری ثبت نشده",
                            hint = "مشاورهای گروه را اضافه کن"
                        )
                    }
                } else {
                    items(advisors, key = { it.id }) { adv ->
                        LiquidGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0x3810A37F))
                                        .border(1.dp, Color(0x6610A37F), RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = adv.name.take(2),
                                        fontWeight = FontWeight.Black,
                                        color = EmeraldBright,
                                        fontFamily = VazirmatnFontFamily
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(adv.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
                                    Text(adv.phone.ifBlank { "—" }, fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                                }
                                DaramashStatusPill(
                                    "فایل ${PersianFormatters.toFa(properties.count { it.advisorName == adv.name })} · مشتری ${PersianFormatters.toFa(customers.count { it.advisorName == adv.name })}",
                                    "green"
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            SysStatRow("منطقه‌ی کاری", adv.specialtyNeighborhood.ifBlank { "—" })
                            Spacer(Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                DaramashCardIconBtn(
                                    emoji = "✎",
                                    onClick = { editingAdvisorId = adv.id }
                                )
                                DaramashCardIconBtn(
                                    emoji = "🗑",
                                    style = IconBtnStyle.DANGER,
                                    onClick = { onDeleteAdvisor(adv.id) }
                                )
                            }
                        }
                    }
                }
            }
            "files" -> {
                items(properties, key = { it.id }) { p ->
                    PropertyPreviewCard(
                        property = p,
                        onClick = { onOpenProperty(p) },
                        onQuickLog = {},
                        onMatchProperty = {},
                        onEdit = {},
                        onArchive = {}
                    )
                }
            }
            "customers" -> {
                items(customers, key = { it.id }) { c ->
                    CustomerPreviewCard(
                        customer = c,
                        onClick = { onOpenCustomer(c) },
                        onQuickLog = {},
                        onMatchCustomer = {},
                        onEdit = {},
                        onArchive = {}
                    )
                }
            }
        }
    }

    if (showGroupEdit) {
        EditGroupModal(
            current = groupSettings,
            onDismiss = { showGroupEdit = false },
            onSave = onSaveGroup
        )
    }
    advisors.firstOrNull { it.id == editingAdvisorId }?.let { adv ->
        EditAdvisorModal(
            advisor = adv,
            onDismiss = { editingAdvisorId = "" },
            onSave = { n, ph, a -> onUpdateAdvisor(adv.id, n, ph, a) }
        )
    }

    if (showAddAdvisorModal) {
        AddAdvisorModal(
            onDismiss = { showAddAdvisorModal = false },
            onAdd = { name, phone, area ->
                onAddAdvisor(name, phone, area)
                showAddAdvisorModal = false
            }
        )
    }

    if (showImportCodeModal) {
        ImportAdvisorCodeModal(
            onDismiss = { showImportCodeModal = false },
            onImport = { code ->
                onImportCode(code)
                showImportCodeModal = false
            }
        )
    }
}

// ============================================================================
// PAGE 8: ARCHIVE SCREEN (viewArchive in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun ArchiveScreen(
    archivedProperties: List<Property>,
    archivedCustomers: List<Customer>,
    archivedInvestors: List<Investor>,
    onRestoreProperty: (String) -> Unit,
    onDeleteProperty: (String) -> Unit,
    onRestoreCustomer: (String) -> Unit,
    onDeleteCustomer: (String) -> Unit,
    onRestoreInvestor: (String) -> Unit,
    onDeleteInvestor: (String) -> Unit,
    onClearAll: () -> Unit
) {
    val total = archivedProperties.size + archivedCustomers.size + archivedInvestors.size
    var showClearConfirm by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "📦 آرشیو",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily
                )
                Text(
                    text = "${PersianFormatters.toFa(total)} مورد آرشیو شده — قابل بازیابی یا حذف کامل",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
                if (total > 0) {
                    Spacer(Modifier.height(8.dp))
                    DaramashGhostButton(
                        text = "🗑 پاک کردن همه‌ی آرشیو",
                        small = true,
                        onClick = { showClearConfirm = true }
                    )
                }
            }
        }

        if (total == 0) {
            item {
                DaramashEmptyState(
                    icon = "📦",
                    title = "آرشیو خالی است",
                    hint = "هر آیتمی که حذف کنی اول به اینجا می‌آید و قابل بازیابی است."
                )
            }
        } else {
            if (archivedProperties.isNotEmpty()) {
                item {
                    LiquidGlassCard {
                        SysCardHeader("🏠", "فایل‌های آرشیو شده (${PersianFormatters.toFa(archivedProperties.size)})")
                        Spacer(Modifier.height(10.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            archivedProperties.forEach { p ->
                                ArchiveRowItem(
                                    title = "کد ${PersianFormatters.toFa(p.code)} · ${p.neighborhood}",
                                    onRestore = { onRestoreProperty(p.id) },
                                    onPurge = { onDeleteProperty(p.id) }
                                )
                            }
                        }
                    }
                }
            }

            if (archivedCustomers.isNotEmpty()) {
                item {
                    LiquidGlassCard {
                        SysCardHeader("🧑", "مشتری‌های آرشیو شده (${PersianFormatters.toFa(archivedCustomers.size)})")
                        Spacer(Modifier.height(10.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            archivedCustomers.forEach { c ->
                                ArchiveRowItem(
                                    title = c.fullName,
                                    onRestore = { onRestoreCustomer(c.id) },
                                    onPurge = { onDeleteCustomer(c.id) }
                                )
                            }
                        }
                    }
                }
            }

            if (archivedInvestors.isNotEmpty()) {
                item {
                    LiquidGlassCard {
                        SysCardHeader("💼", "سرمایه‌گذاران آرشیو شده (${PersianFormatters.toFa(archivedInvestors.size)})")
                        Spacer(Modifier.height(10.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            archivedInvestors.forEach { inv ->
                                ArchiveRowItem(
                                    title = inv.fullName,
                                    onRestore = { onRestoreInvestor(inv.id) },
                                    onPurge = { onDeleteInvestor(inv.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearConfirm) {
        ConfirmModal(
            title = "پاک کردن همه‌ی آرشیو؟",
            message = "همه‌ی ${PersianFormatters.toFa(total)} مورد آرشیو برای همیشه حذف می‌شود و قابل بازیابی نیست.",
            confirmText = "پاک کردن همه",
            onConfirm = {
                showClearConfirm = false
                onClearAll()
            },
            onDismiss = { showClearConfirm = false }
        )
    }
}

@Composable
private fun ArchiveRowItem(
    title: String,
    onRestore: () -> Unit,
    onPurge: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x38000000))
            .border(1.dp, DaramashBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            fontFamily = VazirmatnFontFamily,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        DaramashPrimaryButton(text = "↩ بازیابی", small = true, onClick = onRestore)
        DaramashDangerButton(text = "🗑 حذف کامل", small = true, onClick = onPurge)
    }
}

// ============================================================================
// PAGE 9: SYSTEM & SYNC SCREEN (viewSystem in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SystemAndSyncScreen(
    viewModel: DaramashViewModel,
    onOpenCloudSnapshots: () -> Unit,
    onDeleteCloudData: () -> Unit,
    onExportJson: () -> Unit,
    onImportJson: () -> Unit,
    onPasteJson: () -> Unit,
    onExportCsv: () -> Unit,
    onExportPdf: () -> Unit,
    onTestNotification: () -> Unit
) {
    val context = LocalContext.current
    val properties by viewModel.activeProperties.collectAsState()
    val customers by viewModel.activeCustomers.collectAsState()
    val investors by viewModel.activeInvestors.collectAsState()
    val matches by viewModel.matches.collectAsState()
    val activities by viewModel.activityLogs.collectAsState()
    val archivedProps by viewModel.archivedProperties.collectAsState()
    val archivedCusts by viewModel.archivedCustomers.collectAsState()
    val archivedInvs by viewModel.archivedInvestors.collectAsState()
    val userSession by viewModel.userSession.collectAsState()
    val biometricEnabled by viewModel.biometricEnabled.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()

    val totalRecords = properties.size + customers.size + investors.size
    val archiveTotal = archivedProps.size + archivedCusts.size + archivedInvs.size

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "سیستم",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily
                )
                Text(
                    text = "مدیریت داده‌ها، بکاپ و سلامت ذخیره‌سازی",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            }
        }

        // Quick chips (.chip-row)
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DaramashChip(
                    label = "💾 بکاپ فوری JSON",
                    active = true,
                    onClick = onExportJson
                )
                DaramashChip(
                    label = "🔍 بررسی سلامت",
                    active = false,
                    onClick = {
                        viewModel.emitSnackbar("✅ دیتابیس نیتیو Room SQLite v2 سالم است (${PersianFormatters.toFa(totalRecords)} رکورد فعال)")
                    }
                )
            }
        }

        // Card 1: 💾 سلامت ذخیره‌سازی
        item {
            LiquidGlassCard {
                SysCardHeader("💾", "سلامت ذخیره‌سازی")
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "وضعیت حافظه‌ی نیتیو برنامه (Room SQLite روی همین دستگاه).",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF1C1C1C))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.18f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(50))
                            .background(EmeraldAccent)
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("SQLite WAL فعال", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    Text("ظرفیت نامحدود دستگاه", fontSize = 11.5.sp, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                }
                Spacer(Modifier.height(10.dp))
                SysStatRow("فایل‌های املاک", PersianFormatters.toFa(properties.size))
                SysStatRow("مشتری‌ها", PersianFormatters.toFa(customers.size))
                SysStatRow("سرمایه‌گذاران", PersianFormatters.toFa(investors.size))
                SysStatRow("پیوندهای موفق", PersianFormatters.toFa(matches.size))
                SysStatRow("فعالیت‌های ثبت شده", PersianFormatters.toFa(activities.size))
                SysStatRow("در آرشیو", PersianFormatters.toFa(archiveTotal))
                SysStatRow("مجموع رکوردها", PersianFormatters.toFa(totalRecords))
            }
        }

        // Card 2: 🧪 داده‌های نمونه و پاک‌سازی یک‌لمسی
        item {
            LiquidGlassCard {
                SysCardHeader("🧪", "داده‌های نمونه و پاک‌سازی")
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "مدیریت داده‌های نمونه و پاک‌سازی سریع موارد معامله‌شده.",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DaramashPrimaryButton(
                        text = "📦 بارگذاری داده‌ی نمونه",
                        small = true,
                        onClick = { viewModel.loadDemoData() }
                    )
                    DaramashDangerButton(
                        text = "🗑 حذف داده‌های نمونه",
                        small = true,
                        onClick = { viewModel.removeDemoData() }
                    )
                }
                Spacer(Modifier.height(8.dp))
                DaramashGhostButton(
                    text = "🧹 پاک‌سازی یک‌لمسی (فروش‌رفت / خریدکرد)",
                    small = true,
                    onClick = { viewModel.cleanupSoldAndBought() }
                )
            }
        }

        // Card 3: 📦 بکاپ گیری و خروجی
        item {
            LiquidGlassCard {
                SysCardHeader("📦", "بکاپ گیری")
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "دریافت فایل JSON کامل از داده‌ها، گزارش PDF و خروجی اکسل CSV.",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
                Spacer(Modifier.height(10.dp))
                SysStatRow("بکاپ خودکار روزانه", "فعال", EmeraldBright)
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DaramashPrimaryButton(text = "📥 بکاپ فوری JSON", small = true, onClick = onExportJson)
                    DaramashGhostButton(text = "📄 گزارش PDF", small = true, onClick = onExportPdf)
                    DaramashGhostButton(text = "📊 اکسل CSV", small = true, onClick = onExportCsv)
                }
            }
        }

        // Card 4: 🔄 بازگردانی و انتقال
        item {
            LiquidGlassCard {
                SysCardHeader("🔄", "بازگردانی و انتقال")
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "فایل بکاپ JSON را انتخاب کن یا متن JSON را بچسبان. قبل از جایگزینی، محتوای آن را نشانت می‌دهیم و تأیید می‌گیریم.",
                    fontSize = 12.5.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
                Spacer(Modifier.height(12.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DaramashGhostButton(text = "📂 انتخاب فایل بکاپ", small = true, onClick = onImportJson)
                    DaramashGhostButton(text = "📋 چسباندن JSON", small = true, onClick = onPasteJson)
                    DaramashGhostButton(
                        text = "📋 کپی JSON در کلیپ‌بورد",
                        small = true,
                        onClick = {
                            viewModel.exportBackupJson { json ->
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                cm?.setPrimaryClip(ClipData.newPlainText("DaramashBackup", json))
                            }
                        }
                    )
                }
            }
        }

        // Card 5: ☁️ حساب ابری و همگام‌سازی
        item {
            var showDevicesModal by rememberSaveable { mutableStateOf(false) }

            LiquidGlassCard {
                SysCardHeader("☁️", "حساب ابری و همگام‌سازی (AES-GCM)")
                Spacer(Modifier.height(6.dp))
                SysStatRow("وضعیت", userSession.syncStatusText, EmeraldBright)
                if (!userSession.isLoggedIn) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "ورود فقط از طریق حساب گوگل (Supabase OAuth) انجام می‌شود.",
                        fontSize = 12.sp,
                        color = DaramashMuted,
                        fontFamily = VazirmatnFontFamily
                    )
                    Spacer(Modifier.height(10.dp))
                    DaramashPrimaryButton(
                        text = "🌐 ورود با حساب گوگل",
                        small = false,
                        onClick = { GoogleChromeAuthLauncher.launch(context) }
                    )
                } else {
                    SysStatRow("حساب متصل", userSession.email)
                    SysStatRow("اشتراک", "${userSession.planName} · ${userSession.subStatus}")
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DaramashPrimaryButton(
                            text = "🔄 همگام‌سازی",
                            small = true,
                            onClick = { viewModel.triggerCloudSync() }
                        )
                        DaramashGhostButton(
                            text = "📜 نسخه‌های ابری",
                            small = true,
                            onClick = onOpenCloudSnapshots
                        )
                        DaramashGhostButton(
                            text = "📱 دستگاه‌ها",
                            small = true,
                            onClick = {
                                viewModel.refreshAccountStatus()
                                showDevicesModal = true
                            }
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DaramashDangerButton(
                            text = "🗑 حذف اطلاعات ابری من",
                            small = true,
                            onClick = onDeleteCloudData
                        )
                        DaramashGhostButton(
                            text = "خروج از حساب",
                            small = true,
                            onClick = { viewModel.logoutAccount() }
                        )
                    }
                }
            }

            if (showDevicesModal) {
                DeviceManagementModal(
                    session = userSession,
                    onDismiss = { showDevicesModal = false },
                    onRemoveDevice = { viewModel.removeDevice(it) }
                )
            }
        }

        // Card 5: 🔒 امنیت بیومتریک و اعلان‌های هوشمند
        item {
            val activity = context as? androidx.fragment.app.FragmentActivity
            LiquidGlassCard {
                SysCardHeader("🔒", "امنیت و اعلان‌های نیتیو")
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("قفل بیومتریک (اثرانگشت / چهره)", fontSize = 13.sp, color = Color.White, fontFamily = VazirmatnFontFamily)
                        Text("در صورت خروج از برنامه، دسترسی با اثرانگشت محافظت می‌شود", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    }
                    Switch(
                        checked = biometricEnabled,
                        onCheckedChange = { targetChecked ->
                            if (activity != null) {
                                ir.daramash.app.security.BiometricSecurityManager.authenticate(
                                    activity = activity,
                                    title = if (targetChecked) "فعال‌سازی قفل بیومتریک" else "غیرفعال‌سازی قفل بیومتریک",
                                    subtitle = "جهت تأیید هویت لطفاً اثرانگشت یا پین خود را وارد کنید",
                                    onSuccess = {
                                        viewModel.setBiometricEnabled(targetChecked)
                                        viewModel.emitSnackbar(if (targetChecked) "قفل بیومتریک با موفقیت فعال شد" else "قفل بیومتریک غیرفعال شد")
                                    },
                                    onError = { err ->
                                        viewModel.emitSnackbar("احراز هویت انجام نشد: $err")
                                    }
                                )
                            } else {
                                viewModel.setBiometricEnabled(targetChecked)
                            }
                        }
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("یادآور هوشمند پیگیری (WorkManager)", fontSize = 13.sp, color = Color.White, fontFamily = VazirmatnFontFamily)
                        Text("یادآوری خودکار فایل‌ها و مشتریان با بیش از ۷ روز بی‌تماس", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    }
                    Switch(checked = notificationsEnabled, onCheckedChange = { viewModel.setNotificationsEnabled(it) })
                }
                Spacer(Modifier.height(8.dp))
                DaramashGhostButton(
                    text = "🔔 تست اعلان پیگیری",
                    small = true,
                    onClick = onTestNotification
                )
            }
        }
    }
}

@Composable
private fun SysCardHeader(emoji: String, title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1C1C1C))
                .border(1.dp, DaramashBorder, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = emoji, fontSize = 16.sp)
        }
        Text(
            text = title,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontFamily = VazirmatnFontFamily
        )
    }
}

@Composable
private fun SysStatRow(label: String, value: String, valueColor: Color = Color.White) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.5.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = valueColor,
            fontFamily = VazirmatnFontFamily
        )
    }
}

@Composable
fun DaramashEmptyState(
    icon: String,
    title: String,
    hint: String,
    buttonText: String? = null,
    onButtonClick: (() -> Unit)? = null
) {
    LiquidGlassCard(
        contentPadding = PaddingValues(vertical = 42.dp, horizontal = 20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF161616))
                    .border(1.dp, DaramashBorder, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = icon, fontSize = 22.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontFamily = VazirmatnFontFamily
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = hint,
                fontSize = 13.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily,
                textAlign = TextAlign.Center
            )
            if (buttonText != null && onButtonClick != null) {
                Spacer(Modifier.height(16.dp))
                DaramashPrimaryButton(text = buttonText, onClick = onButtonClick)
            }
        }
    }
}
