package ir.daramash.app.presentation.glass

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * iOS 26 Liquid Glass material system for Compose.
 *
 * Keeps the original public API (GlassBackdropState / glassSource / glassSurface / springPress)
 * while upgrading the optical quality to match Apple's Liquid Glass:
 * - Stronger lens refraction + chromatic fringe (API 33+)
 * - Multi-layer specular rim + top-edge highlight
 * - Clear / Regular / Tinted style presets
 * - Soft spring press morph
 */

@Stable
class GlassBackdropState internal constructor(internal val layer: GraphicsLayer) {
    internal var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassBackdrop(): GlassBackdropState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassBackdropState(layer) }
}

/** Marks the content that glass surfaces should "see through". */
fun Modifier.glassSource(state: GlassBackdropState): Modifier = this
    .onGloballyPositioned { state.origin = it.positionInRoot() }
    .drawWithContent {
        state.layer.record {
            this@drawWithContent.drawContent()
        }
        drawLayer(state.layer)
    }

enum class LiquidGlassStyle {
    Clear,    // highly translucent (iOS Clear)
    Regular,  // balanced (default iOS Regular)
    Tinted    // more opaque / higher contrast
}

private class EffectKey {
    var key: Any? = null
}

/**
 * Draws an iOS 26-style Liquid Glass panel behind the content of this node.
 * Backward-compatible with the previous glassSurface signature.
 */
fun Modifier.glassSurface(
    backdrop: GlassBackdropState?,
    shape: Shape,
    blurRadius: Dp = 28.dp,
    tint: Color = Color(0x1FFFFFFF),
    fallbackFill: Color = Color(0xF214141C),
    lens: Boolean = true,
    style: LiquidGlassStyle = LiquidGlassStyle.Regular,
    specularStrength: Float = 1f
): Modifier = composed {
    val elementLayer = rememberGraphicsLayer()
    val holder = remember { EffectKey() }
    var position by remember { mutableStateOf(Offset.Zero) }

    val effectiveBlur = when (style) {
        LiquidGlassStyle.Clear -> 18.dp
        LiquidGlassStyle.Regular -> blurRadius
        LiquidGlassStyle.Tinted -> 36.dp
    }
    val effectiveTint = when (style) {
        LiquidGlassStyle.Clear -> Color.White.copy(alpha = 0.06f)
        LiquidGlassStyle.Regular -> tint
        LiquidGlassStyle.Tinted -> Color(0xFF1C1C1E).copy(alpha = 0.55f)
    }
    val effectiveFallback = when (style) {
        LiquidGlassStyle.Clear -> Color(0x33FFFFFF)
        LiquidGlassStyle.Regular -> fallbackFill
        LiquidGlassStyle.Tinted -> Color(0xCC1C1C1E)
    }
    val useLens = lens && style != LiquidGlassStyle.Tinted

    this
        .onGloballyPositioned { position = it.positionInRoot() }
        .drawBehind {
            val outline = shape.createOutline(size, layoutDirection, this)
            val path = Path()
            var corner = 0f
            when (outline) {
                is Outline.Rectangle -> path.addRect(outline.rect)
                is Outline.Rounded -> {
                    path.addRoundRect(outline.roundRect)
                    corner = outline.roundRect.topLeftCornerRadius.x
                }
                is Outline.Generic -> path.addPath(outline.path)
            }

            // 1. Backdrop capture + blur / refraction
            if (backdrop != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val dx = position.x - backdrop.origin.x
                val dy = position.y - backdrop.origin.y
                val radiusPx = effectiveBlur.toPx()
                val key = listOf(size.width, size.height, corner, radiusPx, useLens, style)
                if (holder.key != key) {
                    elementLayer.renderEffect = buildGlassEffect(size.width, size.height, corner, radiusPx, useLens)
                    holder.key = key
                }
                elementLayer.record {
                    translate(-dx, -dy) {
                        drawLayer(backdrop.layer)
                    }
                }
                clipPath(path) {
                    drawLayer(elementLayer)
                }
                drawPath(path, color = effectiveTint)
            } else {
                drawPath(path, color = effectiveFallback)
            }

            // 2. Soft inner luminosity (glass body)
            drawPath(
                path = path,
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.08f * specularStrength),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.32f, size.height * 0.22f),
                    radius = size.minDimension * 0.9f
                )
            )

            // 3. Primary specular rim (iOS 26 signature)
            val rimA = (0.58f * specularStrength).coerceIn(0.22f, 0.88f)
            drawPath(
                path = path,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = rimA),
                        Color.White.copy(alpha = 0.07f * specularStrength),
                        Color.White.copy(alpha = 0.30f * specularStrength)
                    ),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height)
                ),
                style = Stroke(width = 1.2.dp.toPx())
            )

            // 4. Top-edge secondary highlight
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.25f * specularStrength),
                        Color.Transparent
                    ),
                    startY = 0f,
                    endY = size.height * 0.38f
                ),
                style = Stroke(width = 0.75.dp.toPx())
            )
        }
}

private fun buildGlassEffect(w: Float, h: Float, corner: Float, blurPx: Float, lens: Boolean): RenderEffect {
    if (lens && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        return buildLensEffect(w, h, corner, blurPx)
    }
    return BlurEffect(blurPx, blurPx, TileMode.Clamp)
}

@androidx.annotation.RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun buildLensEffect(w: Float, h: Float, corner: Float, blurPx: Float): RenderEffect {
    val shader = android.graphics.RuntimeShader(LENS_AGSL)
    shader.setFloatUniform("size", w, h)
    shader.setFloatUniform("corner", corner)
    shader.setFloatUniform("bend", minOf(w, h) * 0.36f)
    val lensEffect = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content")
    val blurEffect = android.graphics.RenderEffect.createBlurEffect(
        blurPx,
        blurPx,
        android.graphics.Shader.TileMode.CLAMP
    )
    return android.graphics.RenderEffect.createChainEffect(lensEffect, blurEffect).asComposeRenderEffect()
}

/** AGSL lens – stronger refraction + chromatic edge for iOS 26 look */
private const val LENS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float corner;
uniform float bend;

half4 main(float2 xy) {
    float2 hd = size * 0.5;
    float2 p = xy - hd;
    float r = min(corner, min(hd.x, hd.y));
    float2 q = abs(p) - hd + float2(r);
    float sdf = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
    float band = max(min(hd.x, hd.y) * 0.55, 1.0);
    float depth = clamp(-sdf / band, 0.0, 1.0);
    float curve = pow(1.0 - depth, 2.2);
    float2 dir = p / max(length(p), 0.0001);
    float2 shifted = xy - dir * curve * bend;
    half4 c = content.eval(shifted);
    half4 cr = content.eval(shifted - dir * curve * bend * 0.15);
    half4 cb = content.eval(shifted + dir * curve * bend * 0.15);
    half3 rgb = half3(cr.r, c.g, cb.b);
    float luma = dot(rgb, half3(0.2126, 0.7152, 0.0722));
    rgb = mix(half3(luma), rgb, 1.38);
    float edgeLine = 1.0 - smoothstep(0.0, 2.8, -sdf);
    float2 lightDir = normalize(float2(-0.55, -0.85));
    float facing = clamp(dot(dir, lightDir) * 0.5 + 0.5, 0.0, 1.0);
    rgb += half3(edgeLine * (0.14 + 0.65 * pow(facing, 2.7)));
    return half4(clamp(rgb, 0.0, 1.0), c.a);
}
"""

/** iOS 26 press feel: soft spring + haptic, no Material ripple. */
fun Modifier.springPress(
    enabled: Boolean = true,
    haptic: Boolean = true,
    pressedScale: Float = 0.94f,
    onClick: () -> Unit
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = 0.48f,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "ios26SpringPress"
    )
    val view = LocalView.current
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled
        ) {
            if (haptic) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onClick()
        }
}

/** Floating capsule used by iOS 26 tab bars / docks */
val LiquidCapsuleShape = RoundedCornerShape(50)

/** Continuous soft corner for cards & sheets */
fun liquidContinuousCorner(radius: Dp = 22.dp) = RoundedCornerShape(radius)
