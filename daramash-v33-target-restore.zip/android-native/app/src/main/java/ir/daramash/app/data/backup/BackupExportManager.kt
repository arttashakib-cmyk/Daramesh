package ir.daramash.app.data.backup

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import ir.daramash.app.domain.model.ActivityLog
import ir.daramash.app.domain.model.Advisor
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.MatchLink
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.usecase.PersianFormatters
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class ParsedBackupData(
    val version: Int,
    val properties: List<Property>,
    val customers: List<Customer>,
    val investors: List<Investor>,
    val matches: List<MatchLink>,
    val activities: List<ActivityLog>,
    val advisors: List<Advisor>,
    val target: AdvisorTarget? = null
)

/** What a backup contains, shown to the user before anything is replaced. */
data class RestorePreview(
    val raw: String,
    val version: Int,
    val properties: Int,
    val customers: Int,
    val investors: Int,
    val archived: Int,
    val matches: Int,
    val advisors: Int,
    val hasTarget: Boolean
)

object BackupExportManager {

    const val CURRENT_BACKUP_VERSION = 6

    /**
     * Serializes the entire database state into a validated JSON string compatible with both
     * the Native Android app and legacy Daramash backups.
     */
    fun exportFullBackupJson(
        properties: List<Property>,
        customers: List<Customer>,
        investors: List<Investor>,
        matches: List<MatchLink>,
        activities: List<ActivityLog>,
        advisors: List<Advisor>,
        target: AdvisorTarget
    ): String {
        val activeProps = properties.filter { !it.isArchived }
        val archivedProps = properties.filter { it.isArchived }
        val activeCusts = customers.filter { !it.isArchived }
        val archivedCusts = customers.filter { it.isArchived }
        val activeInvs = investors.filter { !it.isArchived }
        val archivedInvs = investors.filter { it.isArchived }

        val dataObj = JSONObject().apply {
            put("_v", CURRENT_BACKUP_VERSION)
            put("properties", JSONArray(activeProps.map { serializeProperty(it) }))
            put("customers", JSONArray(activeCusts.map { serializeCustomer(it) }))
            put("investors", JSONArray(activeInvs.map { serializeInvestor(it) }))
            put("matches", JSONArray(matches.map { m ->
                JSONObject().apply {
                    put("id", m.id)
                    put("propertyId", m.propertyId)
                    put("needId", m.needId)
                    put("needKind", m.needKind)
                    put("createdAt", m.createdAt)
                }
            }))
            put("activities", JSONArray(activities.map { a ->
                JSONObject().apply {
                    put("id", a.id)
                    put("entityType", a.entityType)
                    put("entityId", a.entityId)
                    put("type", a.type)
                    put("note", a.note)
                    put("date", a.date)
                    put("createdAt", a.createdAt)
                }
            }))
            put("archived", JSONObject().apply {
                put("properties", JSONArray(archivedProps.map { serializeProperty(it) }))
                put("customers", JSONArray(archivedCusts.map { serializeCustomer(it) }))
                put("investors", JSONArray(archivedInvs.map { serializeInvestor(it) }))
            })
            put("manager", JSONObject().apply {
                put("advisors", JSONArray(advisors.map { adv ->
                    JSONObject().apply {
                        put("id", adv.id)
                        put("name", adv.name)
                        put("phone", adv.phone)
                        put("specialtyNeighborhood", adv.specialtyNeighborhood)
                        put("area", adv.specialtyNeighborhood)
                        put("createdAt", adv.createdAt)
                    }
                }))
                put("group", JSONObject().apply {
                    put("name", target.groupName)
                    put("rank", if (target.groupRank > 0) target.groupRank else JSONObject.NULL)
                    put(
                        "targetType",
                        if (target.groupTargetType == "contracts" || target.groupTargetType == "deposit") target.groupTargetType else ""
                    )
                    put("targetValue", if (target.groupTargetValue > 0L) target.groupTargetValue else JSONObject.NULL)
                })
            })
        }

        val root = JSONObject().apply {
            put("app", "daramash")
            put("version", CURRENT_BACKUP_VERSION)
            put("exportedAt", System.currentTimeMillis())
            put("data", dataObj)
            put("target", TargetCodec.toJson(target))
        }
        return root.toString(2)
    }

    /**
     * Cleans what people paste or share: UTF-8 BOM, code fences and text around the JSON.
     * Returns just the outermost {...} or null when there is none.
     */
    fun extractJsonObject(raw: String): String? {
        var t = raw.replace("\uFEFF", "").replace("\u200B", "").trim()
        if (t.startsWith("```")) {
            t = t.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
            t = t.removeSuffix("```").trim()
        }
        val first = t.indexOf('{')
        val last = t.lastIndexOf('}')
        if (first < 0 || last <= first) return null
        return t.substring(first, last + 1)
    }

    fun buildPreview(raw: String, parsed: ParsedBackupData): RestorePreview = RestorePreview(
        raw = raw,
        version = parsed.version,
        properties = parsed.properties.count { !it.isArchived },
        customers = parsed.customers.count { !it.isArchived },
        investors = parsed.investors.count { !it.isArchived },
        archived = parsed.properties.count { it.isArchived } + parsed.customers.count { it.isArchived } + parsed.investors.count { it.isArchived },
        matches = parsed.matches.size,
        advisors = parsed.advisors.size,
        hasTarget = parsed.target != null
    )

    /**
     * Validates and parses any Daramash JSON backup (v1 through v6, wrapped or unwrapped).
     * Throws an informative Persian error if the file is corrupt or invalid.
     */
    fun validateAndParseBackupJson(rawJson: String): Result<ParsedBackupData> {
        return try {
            val cleaned = extractJsonObject(rawJson)
                ?: return Result.failure(IllegalArgumentException("فرمت فایل پشتیبان معتبر نیست (باید JSON دارمش باشد)."))
            val outer = JSONObject(cleaned)
            val src = outer.optJSONObject("data") ?: outer.optJSONObject("_data") ?: outer

            if (!src.has("properties") && !src.has("customers") && !src.has("investors")) {
                return Result.failure(IllegalArgumentException("ساختار اطلاعات دارمش در این فایل یافت نشد."))
            }

            val version = src.optInt("_v", outer.optInt("version", 1))
            val properties = mutableListOf<Property>()
            val customers = mutableListOf<Customer>()
            val investors = mutableListOf<Investor>()

            val propsArr = src.optJSONArray("properties") ?: JSONArray()
            for (i in 0 until propsArr.length()) {
                propsArr.optJSONObject(i)?.let { properties.add(parseProperty(it, isArchived = false)) }
            }

            val custsArr = src.optJSONArray("customers") ?: JSONArray()
            for (i in 0 until custsArr.length()) {
                custsArr.optJSONObject(i)?.let { customers.add(parseCustomer(it, isArchived = false)) }
            }

            val invsArr = src.optJSONArray("investors") ?: JSONArray()
            for (i in 0 until invsArr.length()) {
                invsArr.optJSONObject(i)?.let { investors.add(parseInvestor(it, isArchived = false)) }
            }

            val archObj = src.optJSONObject("archived")
            if (archObj != null) {
                val archP = archObj.optJSONArray("properties") ?: JSONArray()
                for (i in 0 until archP.length()) {
                    archP.optJSONObject(i)?.let { properties.add(parseProperty(it, isArchived = true)) }
                }
                val archC = archObj.optJSONArray("customers") ?: JSONArray()
                for (i in 0 until archC.length()) {
                    archC.optJSONObject(i)?.let { customers.add(parseCustomer(it, isArchived = true)) }
                }
                val archI = archObj.optJSONArray("investors") ?: JSONArray()
                for (i in 0 until archI.length()) {
                    archI.optJSONObject(i)?.let { investors.add(parseInvestor(it, isArchived = true)) }
                }
            }

            val matches = mutableListOf<MatchLink>()
            val matchesArr = src.optJSONArray("matches") ?: JSONArray()
            for (i in 0 until matchesArr.length()) {
                val m = matchesArr.optJSONObject(i) ?: continue
                val pid = m.optString("propertyId")
                val nid = m.optString("needId")
                if (pid.isNotBlank() && nid.isNotBlank()) {
                    matches.add(
                        MatchLink(
                            id = m.optString("id").ifBlank { UUID.randomUUID().toString() },
                            propertyId = pid,
                            needId = nid,
                            needKind = m.optString("needKind", "customer"),
                            createdAt = m.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            val activities = mutableListOf<ActivityLog>()
            val actArr = src.optJSONArray("activities") ?: JSONArray()
            for (i in 0 until actArr.length()) {
                val a = actArr.optJSONObject(i) ?: continue
                activities.add(
                    ActivityLog(
                        id = a.optString("id").ifBlank { UUID.randomUUID().toString() },
                        entityType = a.optString("entityType", "property"),
                        entityId = a.optString("entityId"),
                        type = PersianFormatters.scrubSafeText(a.optString("type", "یادداشت")),
                        note = PersianFormatters.scrubSafeText(a.optString("note")),
                        date = a.optString("date", PersianFormatters.todayIso()),
                        createdAt = a.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            val advisors = mutableListOf<Advisor>()
            val mgrObj = src.optJSONObject("manager")
            val advArr = mgrObj?.optJSONArray("advisors") ?: JSONArray()
            for (i in 0 until advArr.length()) {
                val adv = advArr.optJSONObject(i) ?: continue
                val name = PersianFormatters.scrubSafeText(adv.optString("name"))
                if (name.isNotBlank()) {
                    advisors.add(
                        Advisor(
                            id = adv.optString("id").ifBlank { UUID.randomUUID().toString() },
                            name = name,
                            phone = PersianFormatters.normalizePhoneDigits(adv.optString("phone")),
                            specialtyNeighborhood = PersianFormatters.scrubSafeText(adv.optString("specialtyNeighborhood").ifBlank { adv.optString("area") }),
                            createdAt = adv.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            // target (monthly progress) and the group settings of the manager panel
            var parsedTarget: AdvisorTarget? = (outer.optJSONObject("target") ?: outer.optJSONObject("_target") ?: src.optJSONObject("target"))
                ?.let { TargetCodec.fromJson(it) }
            val groupObj = mgrObj?.optJSONObject("group")
            if (groupObj != null) {
                val base = parsedTarget ?: AdvisorTarget()
                val gType = groupObj.optString("targetType")
                parsedTarget = base.copy(
                    groupName = PersianFormatters.scrubSafeText(groupObj.optString("name")),
                    groupRank = groupObj.optInt("rank", 0).coerceAtLeast(0),
                    groupTargetType = if (gType == "contracts" || gType == "deposit") gType else base.groupTargetType,
                    groupTargetValue = groupObj.optLong("targetValue", 0L).coerceAtLeast(0L)
                )
            }

            Result.success(
                ParsedBackupData(
                    version = version,
                    properties = properties,
                    customers = customers,
                    investors = investors,
                    matches = matches,
                    activities = activities,
                    advisors = advisors,
                    target = parsedTarget
                )
            )
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("خطا در خواندن فایل پشتیبان: ${e.localizedMessage ?: "ساختار نامعتبر"}"))
        }
    }

    /**
     * Generates a UTF-8 BOM CSV export of properties and customers for Excel compatibility.
     */
    fun exportCsvString(properties: List<Property>, customers: List<Customer>): String {
        val sb = StringBuilder("\uFEFF") // UTF-8 BOM for Persian Excel
        sb.appendLine("نوع رکورد,کد/نام,محله,متراژ,خواب,قیمت کل / بودجه (تومان),وضعیت,تلفن تماس,آخرین تماس")
        properties.filter { !it.isArchived }.forEach { p ->
            sb.appendLine(
                "ملک,${csvEscape(p.code)},${csvEscape(p.neighborhood)},${p.area},${p.bedrooms},${p.totalPrice},${csvEscape(p.status)},${csvEscape(p.sellerPhone)},${csvEscape(p.lastContact)}"
            )
        }
        customers.filter { !it.isArchived }.forEach { c ->
            sb.appendLine(
                "مشتری (${c.quality}),${csvEscape(c.fullName)},${csvEscape(c.neighborhoods.joinToString(" | "))},${c.areaMin},${c.bedroomsMin},${c.budgetMax},${csvEscape(c.status)},${csvEscape(c.phone1)},${csvEscape(c.lastContact)}"
            )
        }
        return sb.toString()
    }

    /**
     * Generates a genuine multi-page A4 PDF report using Android's native PdfDocument API.
     */
    fun generatePortfolioPdfFile(
        context: Context,
        properties: List<Property>,
        customers: List<Customer>,
        investors: List<Investor>
    ): File {
        val pdf = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdf.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(16, 163, 127)
            textSize = 18f
            isFakeBoldText = true
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 30, 35)
            textSize = 11.5f
        }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(0, 0, 0)
            textSize = 13f
            isFakeBoldText = true
        }

        var y = 48f
        canvas.drawText("گزارش جامع پرتفوی املاک دارمش (Daramash Native)", 40f, y, titlePaint)
        y += 24f
        canvas.drawText(
            "تعداد فایل‌های فعال: ${PersianFormatters.toFa(properties.count { !it.isArchived })}  |  مشتریان فعال: ${PersianFormatters.toFa(customers.count { !it.isArchived })}  |  سرمایه‌گذاران: ${PersianFormatters.toFa(investors.count { !it.isArchived })}",
            40f,
            y,
            bodyPaint
        )
        y += 28f

        canvas.drawText("فهرست فایل‌های املاک:", 40f, y, headerPaint)
        y += 20f
        properties.filter { !it.isArchived }.take(18).forEachIndexed { idx, p ->
            if (y < 780f) {
                val line = "${idx + 1}. کد ${PersianFormatters.toFa(p.code)} | ${p.neighborhood} | ${PersianFormatters.toFa(p.area)} متر | ${PersianFormatters.toFa(p.bedrooms)} خواب | ${PersianFormatters.formatMoneyToman(p.totalPrice)} تومان (${p.status})"
                canvas.drawText(line, 40f, y, bodyPaint)
                y += 18f
            }
        }

        y += 14f
        if (y < 740f) {
            canvas.drawText("فهرست مشتریان فعال:", 40f, y, headerPaint)
            y += 20f
            customers.filter { !it.isArchived }.take(12).forEachIndexed { idx, c ->
                if (y < 800f) {
                    val line = "${idx + 1}. ${c.fullName} (${c.quality}) | محله: ${c.neighborhoods.joinToString("،")} | حداقل ${PersianFormatters.toFa(c.areaMin)}م | بودجه: ${PersianFormatters.formatMoneyToman(c.budgetMax)}"
                    canvas.drawText(line, 40f, y, bodyPaint)
                    y += 18f
                }
            }
        }

        pdf.finishPage(page)

        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outFile = File(exportDir, "daramash-report-${System.currentTimeMillis()}.pdf")
        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        return outFile
    }

    private fun csvEscape(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return "\"$clean\""
    }

    private fun serializeProperty(p: Property): JSONObject = JSONObject().apply {
        put("id", p.id)
        put("code", p.code)
        put("area", p.area)
        put("bedrooms", p.bedrooms)
        put("floors", p.floors)
        put("unitsPerFloor", p.unitsPerFloor)
        put("unitFloor", p.unitFloor)
        put("buildingAge", p.buildingAge)
        put("facade", p.facade)
        put("condition", p.condition)
        put("lighting", p.lighting)
        put("features", JSONObject().apply {
            put("parking", p.parking)
            put("storage", p.storage)
            put("elevator", p.elevator)
            put("terrace", p.terrace)
        })
        put("totalPrice", p.totalPrice)
        put("pricePerMeter", p.pricePerMeter)
        put("occupancy", p.occupancy)
        put("contractDuration", p.contractDuration)
        put("deposit", p.deposit)
        put("rent", p.rent)
        put("neighborhood", p.neighborhood)
        put("address", p.address)
        put("visit", p.visit)
        put("sellerName", p.sellerName)
        put("sellerPhone", p.sellerPhone)
        put("sellReason", p.sellReason)
        put("exchange", p.exchange)
        put("regDate", p.regDate)
        put("lastContact", p.lastContact)
        put("status", p.status)
        put("investable", p.investable)
        put("advisorId", p.advisorId)
        put("advisorName", p.advisorName)
        put("note", p.note)
        put("createdAt", p.createdAt)
        put("updatedAt", p.updatedAt)
        if (p.isArchived) put("archivedAt", p.archivedAt)
    }

    private fun serializeCustomer(c: Customer): JSONObject = JSONObject().apply {
        put("id", c.id)
        put("firstName", c.firstName)
        put("lastName", c.lastName)
        put("phone1", c.phone1)
        put("phone2", c.phone2)
        put("neighborhoods", JSONArray(c.neighborhoods))
        put("areaMin", c.areaMin)
        put("bedroomsMin", c.bedroomsMin)
        put("buildingAgeMax", c.buildingAgeMax)
        put("budgetMax", c.budgetMax)
        put("requiredFeatures", JSONObject().apply {
            put("parking", c.reqParking)
            put("storage", c.reqStorage)
            put("elevator", c.reqElevator)
            put("terrace", c.reqTerrace)
        })
        put("noElevatorMaxFloor", c.noElevatorMaxFloor)
        put("visitedUnits", c.visitedUnits)
        put("quality", c.quality)
        put("payment", c.payment)
        put("purpose", c.purpose)
        put("status", c.status)
        put("regDate", c.regDate)
        put("lastContact", c.lastContact)
        put("advisorId", c.advisorId)
        put("advisorName", c.advisorName)
        put("note", c.note)
        put("createdAt", c.createdAt)
        put("updatedAt", c.updatedAt)
        if (c.isArchived) put("archivedAt", c.archivedAt)
    }

    private fun serializeInvestor(inv: Investor): JSONObject = JSONObject().apply {
        put("id", inv.id)
        put("firstName", inv.firstName)
        put("lastName", inv.lastName)
        put("phone1", inv.phone1)
        put("neighborhoods", JSONArray(inv.neighborhoods))
        put("existingUnits", inv.existingUnits)
        put("hasBuy", inv.hasBuy)
        put("buyAmount", inv.buyAmount)
        put("telegramChannel", inv.telegramChannel)
        put("businessType", inv.businessType)
        put("lastContact", inv.lastContact)
        put("note", inv.note)
        put("createdAt", inv.createdAt)
        put("updatedAt", inv.updatedAt)
        if (inv.isArchived) put("archivedAt", inv.archivedAt)
    }

    private fun parseProperty(o: JSONObject, isArchived: Boolean): Property {
        val feats = o.optJSONObject("features")
        val total = o.optLong("totalPrice", 0L)
        val area = o.optInt("area", 0)
        return Property(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            code = PersianFormatters.scrubSafeText(o.optString("code")),
            area = area,
            bedrooms = o.optInt("bedrooms", 0),
            floors = o.optInt("floors", 0),
            unitsPerFloor = o.optInt("unitsPerFloor", 0),
            unitFloor = o.optInt("unitFloor", 0),
            buildingAge = o.optInt("buildingAge", 0),
            facade = PersianFormatters.scrubSafeText(o.optString("facade")),
            condition = PersianFormatters.scrubSafeText(o.optString("condition")),
            lighting = PersianFormatters.scrubSafeText(o.optString("lighting")),
            parking = feats?.optBoolean("parking") ?: o.optBoolean("parking", false),
            storage = feats?.optBoolean("storage") ?: o.optBoolean("storage", false),
            elevator = feats?.optBoolean("elevator") ?: o.optBoolean("elevator", false),
            terrace = feats?.optBoolean("terrace") ?: o.optBoolean("terrace", false),
            totalPrice = total,
            pricePerMeter = if (total > 0 && area > 0) total / area else o.optLong("pricePerMeter", 0L),
            occupancy = PersianFormatters.scrubSafeText(o.optString("occupancy", "تخلیه")),
            contractDuration = PersianFormatters.scrubSafeText(o.optString("contractDuration")),
            deposit = o.optLong("deposit", 0L),
            rent = o.optLong("rent", 0L),
            neighborhood = PersianFormatters.scrubSafeText(o.optString("neighborhood")),
            address = PersianFormatters.scrubSafeText(o.optString("address")),
            visit = PersianFormatters.scrubSafeText(o.optString("visit", "با هماهنگی")),
            sellerName = PersianFormatters.scrubSafeText(o.optString("sellerName")),
            sellerPhone = PersianFormatters.normalizePhoneDigits(o.optString("sellerPhone")),
            sellReason = PersianFormatters.scrubSafeText(o.optString("sellReason")),
            exchange = PersianFormatters.scrubSafeText(o.optString("exchange", "نمی‌کند")),
            regDate = o.optString("regDate"),
            lastContact = o.optString("lastContact"),
            status = PersianFormatters.scrubSafeText(o.optString("status", "فروشنده")),
            investable = o.optBoolean("investable", false),
            advisorId = o.optString("advisorId"),
            advisorName = PersianFormatters.scrubSafeText(o.optString("advisorName")),
            note = PersianFormatters.scrubSafeText(o.optString("note")),
            isArchived = isArchived,
            archivedAt = if (isArchived) o.optLong("archivedAt", System.currentTimeMillis()) else 0L,
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
        )
    }

    private fun parseCustomer(o: JSONObject, isArchived: Boolean): Customer {
        val feats = o.optJSONObject("requiredFeatures")
        val nbhds = mutableListOf<String>()
        val nbArr = o.optJSONArray("neighborhoods")
        if (nbArr != null) {
            for (i in 0 until nbArr.length()) {
                val s = PersianFormatters.scrubSafeText(nbArr.optString(i))
                if (s.isNotBlank()) nbhds.add(s)
            }
        }
        return Customer(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            firstName = PersianFormatters.scrubSafeText(o.optString("firstName")),
            lastName = PersianFormatters.scrubSafeText(o.optString("lastName")),
            phone1 = PersianFormatters.normalizePhoneDigits(o.optString("phone1")),
            phone2 = PersianFormatters.normalizePhoneDigits(o.optString("phone2")),
            neighborhoods = nbhds,
            areaMin = o.optInt("areaMin", 0),
            bedroomsMin = o.optString("bedroomsMin", "0").toIntOrNull() ?: o.optInt("bedroomsMin", 0),
            buildingAgeMax = o.optInt("buildingAgeMax", 0),
            budgetMax = o.optLong("budgetMax", 0L),
            reqParking = feats?.optBoolean("parking") ?: o.optBoolean("reqParking", false),
            reqStorage = feats?.optBoolean("storage") ?: o.optBoolean("reqStorage", false),
            reqElevator = feats?.optBoolean("elevator") ?: o.optBoolean("reqElevator", false),
            reqTerrace = feats?.optBoolean("terrace") ?: o.optBoolean("reqTerrace", false),
            noElevatorMaxFloor = o.optInt("noElevatorMaxFloor", 0),
            visitedUnits = o.optInt("visitedUnits", 0),
            quality = PersianFormatters.scrubSafeText(o.optString("quality", "داغ")),
            payment = PersianFormatters.scrubSafeText(o.optString("payment", "نقد")),
            purpose = PersianFormatters.scrubSafeText(o.optString("purpose", "سکونت")),
            status = PersianFormatters.scrubSafeText(o.optString("status", "در جست و جو")),
            regDate = o.optString("regDate"),
            lastContact = o.optString("lastContact"),
            advisorId = o.optString("advisorId"),
            advisorName = PersianFormatters.scrubSafeText(o.optString("advisorName")),
            note = PersianFormatters.scrubSafeText(o.optString("note")),
            isArchived = isArchived,
            archivedAt = if (isArchived) o.optLong("archivedAt", System.currentTimeMillis()) else 0L,
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
        )
    }

    private fun parseInvestor(o: JSONObject, isArchived: Boolean): Investor {
        val nbhds = mutableListOf<String>()
        val nbArr = o.optJSONArray("neighborhoods")
        if (nbArr != null) {
            for (i in 0 until nbArr.length()) {
                val s = PersianFormatters.scrubSafeText(nbArr.optString(i))
                if (s.isNotBlank()) nbhds.add(s)
            }
        }
        return Investor(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            firstName = PersianFormatters.scrubSafeText(o.optString("firstName")),
            lastName = PersianFormatters.scrubSafeText(o.optString("lastName")),
            phone1 = PersianFormatters.normalizePhoneDigits(o.optString("phone1")),
            neighborhoods = nbhds,
            existingUnits = PersianFormatters.scrubSafeText(o.optString("existingUnits")),
            hasBuy = PersianFormatters.scrubSafeText(o.optString("hasBuy", "بله")),
            buyAmount = o.optLong("buyAmount", 0L),
            telegramChannel = PersianFormatters.scrubSafeText(o.optString("telegramChannel")),
            businessType = PersianFormatters.scrubSafeText(o.optString("businessType", "آدم حسابی")),
            lastContact = o.optString("lastContact"),
            note = PersianFormatters.scrubSafeText(o.optString("note")),
            isArchived = isArchived,
            archivedAt = if (isArchived) o.optLong("archivedAt", System.currentTimeMillis()) else 0L,
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
        )
    }
}
