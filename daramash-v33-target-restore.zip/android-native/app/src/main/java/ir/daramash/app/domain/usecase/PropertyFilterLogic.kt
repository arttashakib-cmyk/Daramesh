package ir.daramash.app.domain.usecase

import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.PropertyFilterState

/** Single place for the property list filter; used by the list and by the live count in the advanced filter. */
object PropertyFilterLogic {

    private fun regIso(p: Property): String {
        if (p.regDate.isNotBlank()) return p.regDate
        return try {
            java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(p.createdAt))
        } catch (_: Exception) {
            ""
        }
    }

    private fun inRange(v: Long, lo: Long?, hi: Long?, zeroIsMissing: Boolean): Boolean {
        if (lo == null && hi == null) return true
        if (zeroIsMissing && v <= 0L) return false
        if (lo != null && v < lo) return false
        if (hi != null && v > hi) return false
        return true
    }

    fun apply(list: List<Property>, f: PropertyFilterState): List<Property> {
        val q = PersianFormatters.normalizeSearch(f.query)
        val codeQ = PersianFormatters.toEn(f.code).trim().lowercase()
        return list.filter { p ->
            val matchQuery = if (q.isEmpty()) true else {
                val haystack = listOf(p.code, p.neighborhood, p.sellerName, p.sellerPhone, p.address, p.note)
                    .joinToString(" ") { PersianFormatters.normalizeSearch(it) }
                q.split(" ").all { word -> haystack.contains(word) }
            }
            val matchStatus = when (f.statusFilter) {
                "active" -> p.status == "فروشنده"
                "sold" -> PersianFormatters.isSoldStatus(p.status)
                "inactive" -> p.status != "فروشنده" && !PersianFormatters.isSoldStatus(p.status)
                "investable" -> p.investable
                else -> true
            }
            val matchNb = f.neighborhoods.isEmpty() || f.neighborhoods.contains(p.neighborhood)
            val matchCode = codeQ.isEmpty() || PersianFormatters.toEn(p.code).lowercase().contains(codeQ)
            val matchArea = inRange(p.area.toLong(), f.minArea?.toLong(), f.maxArea?.toLong(), true)
            val matchPrice = inRange(p.totalPrice, f.minPrice, f.maxPrice, true)
            val matchAge = inRange(p.buildingAge.toLong(), f.minAge?.toLong(), f.maxAge?.toLong(), false)
            val matchFloor = inRange(p.unitFloor.toLong(), f.minFloor?.toLong(), f.maxFloor?.toLong(), false)
            val matchUpf = inRange(p.unitsPerFloor.toLong(), f.minUnitsPerFloor?.toLong(), f.maxUnitsPerFloor?.toLong(), true)
            val matchBedsMin = f.minBedrooms?.let { p.bedrooms >= it } ?: true
            val matchBedsChoice = f.bedChoices.isEmpty() ||
                (p.bedrooms > 0 && (f.bedChoices.contains(p.bedrooms) || (f.bedChoices.contains(4) && p.bedrooms >= 4)))
            val matchFeats = (!f.requireParking || p.parking) &&
                (!f.requireElevator || p.elevator) &&
                (!f.requireStorage || p.storage) &&
                (!f.requireTerrace || p.terrace)
            val matchDate = if (f.dateFrom.isBlank() && f.dateTo.isBlank()) true else {
                val d = regIso(p)
                d.isNotBlank() && (f.dateFrom.isBlank() || d >= f.dateFrom) && (f.dateTo.isBlank() || d <= f.dateTo)
            }
            matchQuery && matchStatus && matchNb && matchCode && matchArea && matchPrice && matchAge &&
                matchFloor && matchUpf && matchBedsMin && matchBedsChoice && matchFeats && matchDate
        }
    }

    /** Number of active advanced-filter groups (for the badge on the filter button). */
    fun activeGroups(f: PropertyFilterState): Int {
        var n = 0
        if (f.neighborhoods.isNotEmpty()) n++
        if (f.code.isNotBlank()) n++
        if (f.minArea != null || f.maxArea != null) n++
        if (f.minPrice != null || f.maxPrice != null) n++
        if (f.minAge != null || f.maxAge != null) n++
        if (f.minFloor != null || f.maxFloor != null) n++
        if (f.minUnitsPerFloor != null || f.maxUnitsPerFloor != null) n++
        if (f.bedChoices.isNotEmpty() || f.minBedrooms != null) n++
        if (f.requireParking || f.requireElevator || f.requireStorage || f.requireTerrace) n++
        if (f.dateFrom.isNotBlank() || f.dateTo.isNotBlank()) n++
        if (f.statusFilter == "investable") n++
        return n
    }
}
