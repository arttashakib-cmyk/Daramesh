package ir.daramash.app.data.backup

import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.DepositRecord
import ir.daramash.app.domain.model.MonthProgress
import ir.daramash.app.domain.usecase.PersianFormatters
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** One JSON shape for the target, shared by the app storage, backups and the web version. */
object TargetCodec {

    const val MAX_CONTRACTS = 60

    private val monthKeyRegex = Regex("^\\d{4}-\\d{2}$")

    /** Reads a number that may be missing, null, a number or a numeric string. */
    private fun num(o: JSONObject, key: String): Long {
        if (!o.has(key) || o.isNull(key)) return 0L
        return when (val v = o.opt(key)) {
            is Number -> v.toLong()
            is String -> PersianFormatters.toEn(v).trim().toDoubleOrNull()?.toLong() ?: 0L
            else -> 0L
        }
    }

    fun toJson(t: AdvisorTarget): JSONObject = JSONObject().apply {
        put("motivation", t.motivation)
        put("targetFileCode", t.targetFileCode)
        put("status", t.status)
        put("rank", if (t.rank > 0) t.rank else JSONObject.NULL)
        put("targetType", t.targetType)
        put("targetDeposit", if (t.targetDeposit > 0L) t.targetDeposit else JSONObject.NULL)
        put("targetContracts", if (t.targetContracts > 0) t.targetContracts else JSONObject.NULL)
        put("progress", JSONObject().apply {
            t.progress.forEach { (key, mp) ->
                put(key, JSONObject().apply {
                    put("ticks", JSONArray().apply { mp.ticks.forEach { put(it) } })
                    put("deposits", JSONArray().apply {
                        mp.deposits.forEach { d ->
                            put(JSONObject().apply {
                                put("id", d.id)
                                put("amount", d.amount)
                                put("title", d.title)
                                put("date", d.date)
                            })
                        }
                    })
                })
            }
        })
        put("groupName", t.groupName)
        put("groupRank", t.groupRank)
        put("groupTargetType", t.groupTargetType)
        put("groupTargetValue", t.groupTargetValue)
    }

    fun fromJson(obj: JSONObject): AdvisorTarget {
        val progress = LinkedHashMap<String, MonthProgress>()
        val pObj = obj.optJSONObject("progress")
        if (pObj != null) {
            for (key in pObj.keys()) {
                if (!monthKeyRegex.matches(key)) continue
                val m = pObj.optJSONObject(key) ?: continue
                val ticks = ArrayList<Boolean>()
                val tArr = m.optJSONArray("ticks")
                if (tArr != null) for (i in 0 until minOf(tArr.length(), MAX_CONTRACTS)) ticks.add(tArr.optBoolean(i, false))
                val deposits = ArrayList<DepositRecord>()
                val dArr = m.optJSONArray("deposits")
                if (dArr != null) {
                    for (i in 0 until dArr.length()) {
                        val d = dArr.optJSONObject(i) ?: continue
                        val amount = num(d, "amount")
                        if (amount <= 0L) continue
                        deposits.add(
                            DepositRecord(
                                id = d.optString("id").ifBlank { UUID.randomUUID().toString() },
                                amount = amount,
                                title = PersianFormatters.scrubSafeText(d.optString("title", "واریزی")),
                                date = d.optString("date").ifBlank { PersianFormatters.todayIso() }
                            )
                        )
                    }
                }
                progress[key] = MonthProgress(ticks = ticks, deposits = deposits)
            }
        }
        // keep the latest 24 months only
        val kept = progress.keys.sortedDescending().take(24).associateWith { progress.getValue(it) }

        val type = obj.optString("targetType", "deposit")
        val groupType = obj.optString("groupTargetType", "files")
        return AdvisorTarget(
            motivation = PersianFormatters.scrubSafeText(obj.optString("motivation", "")).ifBlank { AdvisorTarget().motivation },
            targetFileCode = PersianFormatters.scrubSafeText(obj.optString("targetFileCode", "")),
            status = obj.optString("status", "").ifBlank { "در حال تلاش" },
            rank = num(obj, "rank").toInt().coerceIn(0, 9999),
            targetType = if (type == "contracts") "contracts" else "deposit",
            targetDeposit = num(obj, "targetDeposit").coerceAtLeast(0L),
            targetContracts = num(obj, "targetContracts").toInt().coerceIn(0, MAX_CONTRACTS),
            progress = kept,
            groupName = PersianFormatters.scrubSafeText(obj.optString("groupName", "")),
            groupRank = num(obj, "groupRank").toInt().coerceAtLeast(0),
            groupTargetType = if (groupType in listOf("files", "contracts", "deposit")) groupType else "files",
            groupTargetValue = num(obj, "groupTargetValue").coerceAtLeast(0L)
        )
    }
}
