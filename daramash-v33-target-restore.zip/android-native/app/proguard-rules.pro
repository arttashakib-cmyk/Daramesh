# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-keep class ir.daramash.app.data.local.entity.** { *; }
-keep class ir.daramash.app.domain.model.** { *; }

# Kotlin / Coroutines
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# Compose
-dontwarn androidx.compose.**
-keep class androidx.compose.runtime.** { *; }

# Security / Tink
-dontwarn com.google.crypto.tink.**
-keep class com.google.crypto.tink.** { *; }

# SplashScreen
-keep class androidx.core.splashscreen.** { *; }

# BuildConfig runtime fields
-keepclassmembers class ir.daramash.app.BuildConfig {
    public static final java.lang.String *;
}

# Biometric / FragmentActivity
-keep class androidx.biometric.** { *; }
-keep class androidx.fragment.app.** { *; }

# Optional/annotation-only classes referenced by Tink (EncryptedSharedPreferences); R8 fails on them otherwise
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn javax.annotation.concurrent.**
-dontwarn org.checkerframework.**
-dontwarn com.google.api.client.**
-dontwarn org.joda.time.**
