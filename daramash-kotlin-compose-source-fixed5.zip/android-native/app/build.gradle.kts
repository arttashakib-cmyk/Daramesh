import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = Properties()
if (keystorePropsFile.exists()) {
    keystoreProps.load(FileInputStream(keystorePropsFile))
}

android {
    namespace = "ir.daramash.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.daramash.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 22
        versionName = "22.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        buildConfigField("String", "SUPABASE_URL", "\"https://kkplxjyinzifignpjkwx.supabase.co\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtrcGx4anlpbnppZmlnbnBqa3d4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA5NTM3MzAsImV4cCI6MjEwNjUyOTczMH0.Zhw-NcNNjsOWvmVB_4J-d8aDSBlBLt6nz2vFLnokjiM\"")
        buildConfigField("String", "ADMIN_EMAIL", "\"arttashakib@gmail.com\"")
        buildConfigField("String", "AI_WORKER_URL", "\"https://daramash-ai.arttashakib.workers.dev\"")
    }

    signingConfigs {
        create("release") {
            val ksFile = file("daramash-release.jks")
            if (ksFile.exists()) {
                storeFile = ksFile
                storePassword = System.getenv("DARAMASH_KEYSTORE_PASSWORD")
                    ?: keystoreProps.getProperty("storePassword", "daramash2025")
                keyAlias = System.getenv("DARAMASH_KEY_ALIAS")
                    ?: keystoreProps.getProperty("keyAlias", "daramash")
                keyPassword = System.getenv("DARAMASH_KEY_PASSWORD")
                    ?: keystoreProps.getProperty("keyPassword", "daramash2025")
                enableV1Signing = true
                enableV2Signing = true
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.11"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.04.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    // Jetpack Compose UI & Material 3
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Room Database (SQLite)
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // WorkManager for background follow-up reminders & periodic cloud sync
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // Biometric Authentication
    implementation("androidx.biometric:biometric:1.1.0")

    // Chrome Custom Tabs for Google OAuth
    implementation("androidx.browser:browser:1.8.0")

    // Encrypted SharedPreferences
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Kotlin Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")

    // Unit Tests
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.0")
    testImplementation("org.json:json:20231013")
}
