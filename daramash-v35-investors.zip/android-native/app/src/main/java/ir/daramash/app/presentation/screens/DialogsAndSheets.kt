package ir.daramash.app.presentation.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.daramash.app.domain.model.ActivityLog
import ir.daramash.app.domain.model.AdvisorTarget
import ir.daramash.app.domain.model.Customer
import ir.daramash.app.domain.model.Investor
import ir.daramash.app.domain.model.Property
import ir.daramash.app.domain.model.PropertyFilterState
import ir.daramash.app.domain.model.UserSession
import ir.daramash.app.domain.usecase.PersianFormatters
import ir.daramash.app.presentation.viewmodel.AdminUserRow
import ir.daramash.app.domain.usecase.PropertyFilterLogic
import ir.daramash.app.presentation.theme.DaramashBorder
import ir.daramash.app.presentation.theme.DaramashBorderSoft
import ir.daramash.app.presentation.theme.DaramashFaint
import ir.daramash.app.presentation.theme.DaramashMuted
import ir.daramash.app.presentation.theme.DaramashSpecular
import ir.daramash.app.presentation.theme.EmeraldAccent
import ir.daramash.app.presentation.theme.EmeraldBright
import ir.daramash.app.presentation.theme.AmberWarn
import ir.daramash.app.presentation.theme.GlassGradBottom
import ir.daramash.app.presentation.theme.GlassGradMid
import ir.daramash.app.presentation.theme.GlassGradTop
import ir.daramash.app.presentation.theme.RubyPrimary
import ir.daramash.app.presentation.theme.VazirmatnFontFamily
import java.util.UUID

val DEFAULT_NEIGHBORHOODS = listOf(
    "پونک", "سردار شمال", "شهرک نفت", "طالقانی", "همیلا",
    "شهرک هما", "جنت مرکز", "جنت جنوب", "جنت شمال", "باغ فیض",
    "اباذر", "آلاله شرقی", "شهرزیبا", "شهران", "سازمان شمال",
    "سازمان مرکز", "سازمان جنوب", "پروانه", "بهار N", "بهار S", "فردوس شرق"
)

// ============================================================================
// BASE LIQUID MODAL SHELL (.overlay & .modal in src/index.css)
// ============================================================================

@Composable
fun DaramashLiquidModal(
    title: String,
    onDismiss: () -> Unit,
    footer: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val shape = RoundedCornerShape(26.dp)
        var appeared by remember { mutableStateOf(false) }
        androidx.compose.runtime.LaunchedEffect(Unit) { appeared = true }
        val enterScale by androidx.compose.animation.core.animateFloatAsState(
            targetValue = if (appeared) 1f else 0.9f,
            animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 380f),
            label = "modalScale"
        )
        val enterAlpha by androidx.compose.animation.core.animateFloatAsState(
            targetValue = if (appeared) 1f else 0f,
            animationSpec = androidx.compose.animation.core.tween(180),
            label = "modalAlpha"
        )
        Box(
            modifier = Modifier
                .graphicsLayer {
                    scaleX = enterScale
                    scaleY = enterScale
                    alpha = enterAlpha
                }
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 20.dp)
                .clip(shape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(GlassGradTop, GlassGradMid, GlassGradBottom)
                    ),
                    shape
                )
                .border(1.dp, DaramashBorder, shape)
        ) {
            // Top specular highlight
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .height(1.dp)
                    .align(Alignment.TopCenter)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, DaramashSpecular, Color.Transparent)
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // .modal-head
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = VazirmatnFontFamily
                    )
                    DaramashCardIconBtn(
                        emoji = "✕",
                        onClick = onDismiss
                    )
                }

                // Scrollable Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 470.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    content = content
                )

                // .modal-foot
                if (footer != null) {
                    Spacer(Modifier.height(16.dp))
                    footer()
                }
            }
        }
    }
}

@Composable
fun DaramashModalTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
        val shape = RoundedCornerShape(10.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = if (singleLine) 42.dp else 76.dp)
                .clip(shape)
                .background(Color(0xFF161616), shape)
                .border(1.dp, DaramashBorder, shape)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            contentAlignment = if (singleLine) Alignment.CenterStart else Alignment.TopStart
        ) {
            if (value.isEmpty() && placeholder.isNotEmpty()) {
                Text(
                    text = placeholder,
                    fontSize = 13.sp,
                    color = DaramashFaint,
                    fontFamily = VazirmatnFontFamily
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = singleLine,
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 13.5.sp,
                    fontFamily = VazirmatnFontFamily
                ),
                cursorBrush = SolidColor(EmeraldAccent),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ============================================================================
// 1. ADD CHOOSER MODAL (fabAction in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun AddEntityChooserModal(
    onDismiss: () -> Unit,
    onSelectProperty: () -> Unit,
    onSelectCustomer: () -> Unit,
    onSelectInvestor: () -> Unit
) {
    DaramashLiquidModal(
        title = "＋ افزودن",
        onDismiss = onDismiss
    ) {
        WelcomeStepButton(icon = "🏠", label = "فایل ملک", onClick = onSelectProperty)
        WelcomeStepButton(icon = "🧑", label = "مشتری", onClick = onSelectCustomer)
        WelcomeStepButton(icon = "💼", label = "سرمایه‌گذار", onClick = onSelectInvestor)
    }
}

@Composable
private fun WelcomeStepButton(
    icon: String,
    label: String,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0x0DFFFFFF), shape)
            .border(1.dp, DaramashBorder, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x2E10A37F))
                .border(1.dp, Color(0x6110A37F), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = icon, fontSize = 16.sp)
        }
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontFamily = VazirmatnFontFamily
        )
    }
}

// ============================================================================
// 2. QUICK HELP MODAL (helpDialog in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun QuickHelpModal(onDismiss: () -> Unit) {
    val lines = listOf(
        "➕ با دکمه‌ی «＋» فایل، مشتری یا سرمایه‌گذار اضافه کن.",
        "🔎 در «پیوند» برای هر مشتری فایل مناسب (یا برعکس) را با دلیلش ببین.",
        "✍️ تماس و پیام را از روی کارت ثبت کن تا فایل‌ها «بی‌تماس» نمانند.",
        "🔍 در لیست فایل‌ها «فیلتر پیشرفته» داری؛ همه‌ی موارد را می‌شود فیلتر کرد.",
        "🎯 در «تارگت» هدف ماه را بنویس و پیشرفتت را تیک بزن.",
        "💾 داده‌ها روی همین گوشی ذخیره می‌شوند؛ از «سیستم» بکاپ بگیر.",
        "🏢 در «پنل مدیریت» مشاوران و فایل و مشتری‌هایشان را ببین.",
        "ℹ️ نسخه‌ی برنامه: ۱۸ (Native Kotlin + Jetpack Compose)"
    )
    DaramashLiquidModal(
        title = "راهنمای سریع",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "باشه", onClick = onDismiss)
            }
        }
    ) {
        lines.forEach { l ->
            Text(
                text = l,
                fontSize = 13.5.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily,
                lineHeight = 24.sp
            )
        }
    }
}

// ============================================================================
// 3. PROPERTY FORM MODAL (openForm('property') in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertyFormDialog(
    initial: Property?,
    onDismiss: () -> Unit,
    onSave: (Property) -> Unit
) {
    var code by rememberSaveable { mutableStateOf(initial?.code ?: "") }
    var neighborhood by rememberSaveable { mutableStateOf(initial?.neighborhood ?: "پونک") }
    var areaStr by rememberSaveable { mutableStateOf(initial?.area?.takeIf { it > 0 }?.toString() ?: "") }
    var bedroomsStr by rememberSaveable { mutableStateOf(initial?.bedrooms?.takeIf { it > 0 }?.toString() ?: "2") }
    var totalPriceMillionsStr by rememberSaveable {
        mutableStateOf(
            initial?.totalPrice?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: ""
        )
    }
    var buildingAgeStr by rememberSaveable { mutableStateOf(initial?.buildingAge?.takeIf { it > 0 }?.toString() ?: "") }
    var unitFloorStr by rememberSaveable { mutableStateOf(initial?.unitFloor?.takeIf { it > 0 }?.toString() ?: "") }
    var floorsStr by rememberSaveable { mutableStateOf(initial?.floors?.takeIf { it > 0 }?.toString() ?: "") }
    var unitsPerFloorStr by rememberSaveable { mutableStateOf(initial?.unitsPerFloor?.takeIf { it > 0 }?.toString() ?: "") }
    var facade by rememberSaveable { mutableStateOf(initial?.facade ?: "سنگ") }
    var condition by rememberSaveable { mutableStateOf(initial?.condition ?: "بازسازی شده") }
    var lighting by rememberSaveable { mutableStateOf(initial?.lighting ?: "دوکله نور") }
    var occupancy by rememberSaveable { mutableStateOf(initial?.occupancy ?: "تخلیه") }
    var contractDuration by rememberSaveable { mutableStateOf(initial?.contractDuration ?: "") }
    var depositMillionsStr by rememberSaveable {
        mutableStateOf(initial?.deposit?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: "")
    }
    var rentMillionsStr by rememberSaveable {
        mutableStateOf(initial?.rent?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: "")
    }
    var visit by rememberSaveable { mutableStateOf(initial?.visit ?: "با هماهنگی") }
    var sellReason by rememberSaveable { mutableStateOf(initial?.sellReason ?: "") }
    var exchange by rememberSaveable {
        mutableStateOf(
            initial?.exchange?.let { if (it.isBlank() || it == "نمی‌کند") "نمی‌کند" else "می‌کند" } ?: "نمی‌کند"
        )
    }
    var sellerName by rememberSaveable { mutableStateOf(initial?.sellerName ?: "") }
    var sellerPhone by rememberSaveable { mutableStateOf(initial?.sellerPhone ?: "") }
    var address by rememberSaveable { mutableStateOf(initial?.address ?: "") }
    var status by rememberSaveable { mutableStateOf(initial?.status ?: "فروشنده") }
    var parking by rememberSaveable { mutableStateOf(initial?.parking ?: true) }
    var elevator by rememberSaveable { mutableStateOf(initial?.elevator ?: true) }
    var storage by rememberSaveable { mutableStateOf(initial?.storage ?: true) }
    var terrace by rememberSaveable { mutableStateOf(initial?.terrace ?: false) }
    var investable by rememberSaveable { mutableStateOf(initial?.investable ?: false) }
    var note by rememberSaveable { mutableStateOf(initial?.note ?: "") }
    var regDateIso by rememberSaveable { mutableStateOf(initial?.regDate?.takeIf { it.isNotBlank() } ?: PersianFormatters.todayIso()) }
    var lastContactIso by rememberSaveable { mutableStateOf(initial?.lastContact?.takeIf { it.isNotBlank() } ?: PersianFormatters.todayIso()) }

    val areaVal = PersianFormatters.toEn(areaStr).toIntOrNull() ?: 0
    val rawMillions = PersianFormatters.toEn(totalPriceMillionsStr).toLongOrNull() ?: 0L
    val totalVal = if (rawMillions in 1..999_999L) rawMillions * 1_000_000L else rawMillions
    val computedPpm = if (areaVal > 0 && totalVal > 0) totalVal / areaVal else 0L

    val depMillions = PersianFormatters.toEn(depositMillionsStr).toLongOrNull() ?: 0L
    val depositVal = if (depMillions in 1..999_999L) depMillions * 1_000_000L else depMillions
    val rentMillions = PersianFormatters.toEn(rentMillionsStr).toLongOrNull() ?: 0L
    val rentVal = if (rentMillions in 1..999_999L) rentMillions * 1_000_000L else rentMillions

    val initialSnap = remember { listOf<Any?>(code, neighborhood, areaStr, bedroomsStr, totalPriceMillionsStr, buildingAgeStr, unitFloorStr, floorsStr, unitsPerFloorStr, facade, condition, lighting, occupancy, contractDuration, depositMillionsStr, rentMillionsStr, visit, sellReason, exchange, sellerName, sellerPhone, address, status, parking, elevator, storage, terrace, investable, note, regDateIso, lastContactIso).joinToString("\u0001") }
    val isDirty = listOf<Any?>(code, neighborhood, areaStr, bedroomsStr, totalPriceMillionsStr, buildingAgeStr, unitFloorStr, floorsStr, unitsPerFloorStr, facade, condition, lighting, occupancy, contractDuration, depositMillionsStr, rentMillionsStr, visit, sellReason, exchange, sellerName, sellerPhone, address, status, parking, elevator, storage, terrace, investable, note, regDateIso, lastContactIso).joinToString("\u0001") != initialSnap
    var showDiscard by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf("") }
    val requestClose: () -> Unit = { if (isDirty) showDiscard = true else onDismiss() }

    DaramashLiquidModal(
        title = if (initial == null) "＋ فایل جدید" else "✎ ویرایش فایل کد ${PersianFormatters.toFa(initial.code)}",
        onDismiss = requestClose,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = requestClose)
                DaramashPrimaryButton(
                    text = if (initial == null) "ثبت فایل" else "ذخیره تغییرات",
                    onClick = onClick@{
                        val badNum = invalidNumberLabel(listOf("متراژ" to areaStr, "تعداد خواب" to bedroomsStr, "قیمت کل" to totalPriceMillionsStr, "سن ساختمان" to buildingAgeStr, "طبقه‌ی واحد" to unitFloorStr, "کل طبقات" to floorsStr, "تعداد واحد در طبقه" to unitsPerFloorStr, "ودیعه" to depositMillionsStr, "اجاره" to rentMillionsStr))
                        if (badNum != null) {
                            formError = "«$badNum» را با عدد معتبر وارد کن"
                            return@onClick
                        }
                        if (invalidPhone(sellerPhone)) {
                            formError = "شماره‌ی تلفن معتبر نیست"
                            return@onClick
                        }
                        formError = ""
                        val prop = Property(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            code = code.ifBlank { PersianFormatters.toFa((1050..9999).random()) },
                            neighborhood = neighborhood.ifBlank { "پونک" },
                            area = areaVal,
                            bedrooms = PersianFormatters.toEn(bedroomsStr).toIntOrNull() ?: 2,
                            totalPrice = totalVal,
                            pricePerMeter = computedPpm,
                            unitFloor = PersianFormatters.toEn(unitFloorStr).toIntOrNull() ?: 1,
                            floors = PersianFormatters.toEn(floorsStr).toIntOrNull() ?: 4,
                            unitsPerFloor = PersianFormatters.toEn(unitsPerFloorStr).toIntOrNull() ?: 2,
                            buildingAge = PersianFormatters.toEn(buildingAgeStr).toIntOrNull() ?: 0,
                            facade = facade,
                            condition = condition,
                            lighting = lighting,
                            occupancy = occupancy,
                            contractDuration = if (occupancy == "دست مستاجر") contractDuration else "",
                            deposit = if (occupancy == "دست مستاجر") depositVal else 0L,
                            rent = if (occupancy == "دست مستاجر") rentVal else 0L,
                            visit = visit,
                            sellReason = sellReason,
                            exchange = exchange,
                            sellerName = sellerName,
                            sellerPhone = sellerPhone,
                            address = address,
                            status = status,
                            parking = parking,
                            elevator = elevator,
                            storage = storage,
                            terrace = terrace,
                            investable = investable,
                            note = note,
                            regDate = regDateIso,
                            lastContact = lastContactIso,
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                        onSave(prop)
                    }
                )
            }
        }
    ) {
        if (formError.isNotBlank()) {
            Text(formError, fontSize = 12.sp, color = Color(0xFFFF8A80), fontFamily = VazirmatnFontFamily)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = code,
                onValueChange = { code = it },
                label = "کد فایل *",
                placeholder = "مثلاً ۱۰۴۲",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = neighborhood,
                onValueChange = { neighborhood = it },
                label = "محله *",
                placeholder = "پونک",
                modifier = Modifier.weight(1.3f)
            )
        }

        // Quick neighborhood chips
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DEFAULT_NEIGHBORHOODS.forEach { nb ->
                DaramashChip(
                    label = nb,
                    active = neighborhood == nb,
                    onClick = { neighborhood = nb }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = areaStr,
                onValueChange = { areaStr = it },
                label = "متراژ (متر)",
                placeholder = "۷۸",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = bedroomsStr,
                onValueChange = { bedroomsStr = it },
                label = "تعداد خواب",
                placeholder = "۲",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
        }

        DaramashModalTextField(
            value = totalPriceMillionsStr,
            onValueChange = { totalPriceMillionsStr = it },
            label = "قیمت کل (به میلیون تومان — مثلاً ۱۴۲۰۰ برای ۱۴٫۲ میلیارد)",
            placeholder = "۱۴۲۰۰",
            keyboardType = KeyboardType.Number
        )

        if (totalVal > 0L) {
            Text(
                text = "💰 ${PersianFormatters.formatMoneyToman(totalVal)} تومان" +
                    if (computedPpm > 0L) " · متری ${PersianFormatters.formatMoneyToman(computedPpm)} تومان" else "",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldBright,
                fontFamily = VazirmatnFontFamily
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = unitFloorStr,
                onValueChange = { unitFloorStr = it },
                label = "طبقه واحد",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = floorsStr,
                onValueChange = { floorsStr = it },
                label = "کل طبقات",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = unitsPerFloorStr,
                onValueChange = { unitsPerFloorStr = it },
                label = "واحد در طبقه",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = buildingAgeStr,
                onValueChange = { buildingAgeStr = it },
                label = "سن بنا",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
        }

        Text("نمای ساختمان:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("سنگ", "سنگ و گرانیت", "تراورتن", "آجر", "ترکیبی", "سیمان", "گرانیت", "رومی").forEach { f ->
                DaramashChip(label = f, active = facade == f, onClick = { facade = f })
            }
        }

        Text("وضعیت داخلی ملک:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("نوساز", "بازسازی شده", "تمیز", "نقاشی‌شده", "نیاز به بازسازی").forEach { c ->
                DaramashChip(label = c, active = condition == c, onClick = { condition = c })
            }
        }

        Text("نورگیری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("خطی پرده خور", "دوکله نور جنوبی", "دوکله نور شمالی", "خواب رو به بیرون", "فول پاسیو", "پاسیو باز", "سالن پرده خور").forEach { l ->
                DaramashChip(label = l, active = lighting == l, onClick = { lighting = l })
            }
        }

        Text("وضعیت سکونت:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("تخلیه", "دست مستاجر", "مالک ساکن").forEach { occ ->
                DaramashChip(label = occ, active = occupancy == occ, onClick = { occupancy = occ })
            }
        }

        if (occupancy == "دست مستاجر") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DaramashModalTextField(
                    value = contractDuration,
                    onValueChange = { contractDuration = it },
                    label = "اتمام قرارداد مستاجر",
                    placeholder = "مثلاً ۶ ماه دیگر",
                    modifier = Modifier.weight(1.2f)
                )
                DaramashModalTextField(
                    value = depositMillionsStr,
                    onValueChange = { depositMillionsStr = it },
                    label = "ودیعه مستاجر (میلیون)",
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f)
                )
                DaramashModalTextField(
                    value = rentMillionsStr,
                    onValueChange = { rentMillionsStr = it },
                    label = "اجاره ماهانه (میلیون)",
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Text("نحوه هماهنگی بازدید:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("با هماهنگی", "کلید املاک", "آزاد", "ساکن / مستاجر", "فقط عصرها").forEach { v ->
                DaramashChip(label = v, active = visit == v, onClick = { visit = v })
            }
        }

        DaramashModalTextField(
            value = sellReason,
            onValueChange = { sellReason = it },
            label = "علت فروش",
            placeholder = "خودت بنویس (مثلاً مهاجرت، خرید واحد بزرگ‌تر)"
        )

        Text("معاوضه (تهاتر):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("می‌کند", "نمی‌کند").forEach { ex ->
                DaramashChip(label = ex, active = exchange == ex, onClick = { exchange = ex })
            }
        }

        Text("وضعیت فایل:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("فروشنده", "فروش رفت", "کنسل کرد", "فروشنده نیست").forEach { st ->
                DaramashChip(
                    label = st,
                    active = status == st,
                    onClick = { status = st }
                )
            }
        }

        Text("امکانات ملک:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("🚗 پارکینگ", parking, { parking = !parking })
            DaramashChip("📦 انباری", storage, { storage = !storage })
            DaramashChip("🛗 آسانسور", elevator, { elevator = !elevator })
            DaramashChip("🌿 تراس", terrace, { terrace = !terrace })
            DaramashChip("✨ فول امکانات", parking && elevator && storage && terrace, { val all = !(parking && elevator && storage && terrace); parking = all; elevator = all; storage = all; terrace = all })
            DaramashChip("💼 قابل سرمایه‌گذاری", investable, { investable = !investable })
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = sellerName,
                onValueChange = { sellerName = it },
                label = "نام فروشنده",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = sellerPhone,
                onValueChange = { sellerPhone = it },
                label = "شماره تماس",
                keyboardType = KeyboardType.Phone,
                modifier = Modifier.weight(1.2f)
            )
        }

        DaramashModalTextField(
            value = address,
            onValueChange = { address = it },
            label = "آدرس دقیق"
        )

        DaramashDateRow("تاریخ ثبت", regDateIso) { regDateIso = it }
        DaramashDateRow("تاریخ آخرین تماس", lastContactIso) { lastContactIso = it }
        DaramashModalTextField(
            value = note,
            onValueChange = { note = it },
            label = "توضیحات",
            singleLine = false
        )
    }
    if (showDiscard) {
        ConfirmModal(
            title = "خروج بدون ذخیره؟",
            message = "تغییراتی که وارد کردی ذخیره نشده و از بین می‌رود. خارج می‌شوی؟",
            confirmText = "خروج بدون ذخیره",
            onConfirm = {
                showDiscard = false
                onDismiss()
            },
            onDismiss = { showDiscard = false }
        )
    }
}

// ============================================================================
// 4. CUSTOMER FORM MODAL (openForm('customer') in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomerFormDialog(
    initial: Customer?,
    onDismiss: () -> Unit,
    onSave: (Customer) -> Unit
) {
    var firstName by rememberSaveable { mutableStateOf(initial?.firstName ?: "") }
    var lastName by rememberSaveable { mutableStateOf(initial?.lastName ?: "") }
    var phone1 by rememberSaveable { mutableStateOf(initial?.phone1 ?: "") }
    var phone2 by rememberSaveable { mutableStateOf(initial?.phone2 ?: "") }
    var selectedNbs by rememberSaveable { mutableStateOf(initial?.neighborhoods ?: listOf("پونک")) }
    var areaMinStr by rememberSaveable { mutableStateOf(initial?.areaMin?.takeIf { it > 0 }?.toString() ?: "") }
    var bedroomsMinStr by rememberSaveable { mutableStateOf(initial?.bedroomsMin?.takeIf { it > 0 }?.toString() ?: "2") }
    var budgetMillionsStr by rememberSaveable {
        mutableStateOf(
            initial?.budgetMax?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: ""
        )
    }
    var ageMaxStr by rememberSaveable { mutableStateOf(initial?.buildingAgeMax?.takeIf { it > 0 }?.toString() ?: "") }
    var noElevatorMaxFloorStr by rememberSaveable {
        mutableStateOf(initial?.noElevatorMaxFloor?.takeIf { it > 0 }?.toString() ?: "")
    }
    var visitedUnitsStr by rememberSaveable {
        mutableStateOf(initial?.visitedUnits?.takeIf { it > 0 }?.toString() ?: "")
    }
    var quality by rememberSaveable { mutableStateOf(initial?.quality ?: "داغ") }
    var payment by rememberSaveable { mutableStateOf(initial?.payment ?: "نقد") }
    var purpose by rememberSaveable { mutableStateOf(initial?.purpose ?: "سکونت") }
    var status by rememberSaveable { mutableStateOf(initial?.status ?: "در جست و جو") }
    var reqParking by rememberSaveable { mutableStateOf(initial?.reqParking ?: true) }
    var reqElevator by rememberSaveable { mutableStateOf(initial?.reqElevator ?: true) }
    var reqStorage by rememberSaveable { mutableStateOf(initial?.reqStorage ?: false) }
    var reqTerrace by rememberSaveable { mutableStateOf(initial?.reqTerrace ?: false) }
    var note by rememberSaveable { mutableStateOf(initial?.note ?: "") }
    var regDateIso by rememberSaveable { mutableStateOf(initial?.regDate?.takeIf { it.isNotBlank() } ?: PersianFormatters.todayIso()) }
    var lastContactIso by rememberSaveable { mutableStateOf(initial?.lastContact?.takeIf { it.isNotBlank() } ?: PersianFormatters.todayIso()) }

    val rawMillions = PersianFormatters.toEn(budgetMillionsStr).toLongOrNull() ?: 0L
    val budgetVal = if (rawMillions in 1..999_999L) rawMillions * 1_000_000L else rawMillions

    val initialSnap = remember { listOf<Any?>(firstName, lastName, phone1, phone2, selectedNbs, areaMinStr, bedroomsMinStr, budgetMillionsStr, ageMaxStr, noElevatorMaxFloorStr, visitedUnitsStr, quality, payment, purpose, status, reqParking, reqElevator, reqStorage, reqTerrace, note, regDateIso, lastContactIso).joinToString("\u0001") }
    val isDirty = listOf<Any?>(firstName, lastName, phone1, phone2, selectedNbs, areaMinStr, bedroomsMinStr, budgetMillionsStr, ageMaxStr, noElevatorMaxFloorStr, visitedUnitsStr, quality, payment, purpose, status, reqParking, reqElevator, reqStorage, reqTerrace, note, regDateIso, lastContactIso).joinToString("\u0001") != initialSnap
    var showDiscard by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf("") }
    val requestClose: () -> Unit = { if (isDirty) showDiscard = true else onDismiss() }

    DaramashLiquidModal(
        title = if (initial == null) "＋ مشتری جدید" else "✎ ویرایش ${initial.fullName}",
        onDismiss = requestClose,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = requestClose)
                DaramashPrimaryButton(
                    text = if (initial == null) "ثبت مشتری" else "ذخیره تغییرات",
                    onClick = onClick@{
                        val badNum = invalidNumberLabel(listOf("حداقل متراژ" to areaMinStr, "حداقل خواب" to bedroomsMinStr, "بودجه" to budgetMillionsStr, "حداکثر سن بنا" to ageMaxStr, "حداکثر طبقه‌ی بدون آسانسور" to noElevatorMaxFloorStr))
                        if (badNum != null) {
                            formError = "«$badNum» را با عدد معتبر وارد کن"
                            return@onClick
                        }
                        if (invalidPhone(phone1)) {
                            formError = "شماره‌ی تلفن معتبر نیست"
                            return@onClick
                        }
                        if (invalidPhone(phone2)) {
                            formError = "شماره‌ی تلفن معتبر نیست"
                            return@onClick
                        }
                        formError = ""
                        val cust = Customer(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            firstName = firstName,
                            lastName = lastName.ifBlank { "مشتری" },
                            phone1 = phone1,
                            phone2 = phone2,
                            neighborhoods = selectedNbs,
                            areaMin = PersianFormatters.toEn(areaMinStr).toIntOrNull() ?: 0,
                            bedroomsMin = PersianFormatters.toEn(bedroomsMinStr).toIntOrNull() ?: 0,
                            buildingAgeMax = PersianFormatters.toEn(ageMaxStr).toIntOrNull() ?: 0,
                            budgetMax = budgetVal,
                            noElevatorMaxFloor = PersianFormatters.toEn(noElevatorMaxFloorStr).toIntOrNull() ?: 0,
                            visitedUnits = PersianFormatters.toEn(visitedUnitsStr).toIntOrNull() ?: 0,
                            quality = quality,
                            payment = payment,
                            purpose = purpose,
                            status = status,
                            reqParking = reqParking,
                            reqElevator = reqElevator,
                            reqStorage = reqStorage,
                            reqTerrace = reqTerrace,
                            note = note,
                            regDate = regDateIso,
                            lastContact = lastContactIso,
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                        onSave(cust)
                    }
                )
            }
        }
    ) {
        if (formError.isNotBlank()) {
            Text(formError, fontSize = 12.sp, color = Color(0xFFFF8A80), fontFamily = VazirmatnFontFamily)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = firstName,
                onValueChange = { firstName = it },
                label = "نام",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = lastName,
                onValueChange = { lastName = it },
                label = "نام خانوادگی *",
                modifier = Modifier.weight(1.2f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = phone1,
                onValueChange = { phone1 = it },
                label = "شماره تماس اصلی *",
                keyboardType = KeyboardType.Phone,
                modifier = Modifier.weight(1.2f)
            )
            DaramashModalTextField(
                value = phone2,
                onValueChange = { phone2 = it },
                label = "شماره دوم (اختیاری)",
                keyboardType = KeyboardType.Phone,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("محله‌های مورد نظر (${PersianFormatters.toFa(selectedNbs.size)} انتخاب شده):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "انتخاب همه",
                    fontSize = 11.sp,
                    color = EmeraldBright,
                    fontWeight = FontWeight.Bold,
                    fontFamily = VazirmatnFontFamily,
                    modifier = Modifier.clickable { selectedNbs = DEFAULT_NEIGHBORHOODS }
                )
                Text(
                    text = "پاک کردن",
                    fontSize = 11.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily,
                    modifier = Modifier.clickable { selectedNbs = emptyList() }
                )
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val isAllSelected = selectedNbs.size == DEFAULT_NEIGHBORHOODS.size
            DaramashChip(
                label = "🌐 تمام منطقه",
                active = isAllSelected,
                onClick = { selectedNbs = if (isAllSelected) emptyList() else DEFAULT_NEIGHBORHOODS }
            )
            DEFAULT_NEIGHBORHOODS.forEach { nb ->
                val isOn = nb in selectedNbs
                DaramashChip(
                    label = nb,
                    active = isOn,
                    onClick = {
                        selectedNbs = if (isOn) selectedNbs - nb else selectedNbs + nb
                    }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = areaMinStr,
                onValueChange = { areaMinStr = it },
                label = "حداقل متراژ",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = bedroomsMinStr,
                onValueChange = { bedroomsMinStr = it },
                label = "حداقل خواب",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = ageMaxStr,
                onValueChange = { ageMaxStr = it },
                label = "حداکثر سن بنا",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = budgetMillionsStr,
                onValueChange = { budgetMillionsStr = it },
                label = "حداکثر بودجه (میلیون تومان)",
                placeholder = "مثلاً ۱۵۰۰۰",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(1.3f)
            )
            DaramashModalTextField(
                value = visitedUnitsStr,
                onValueChange = { visitedUnitsStr = it },
                label = "واحدهای دیده‌شده",
                placeholder = "۰",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.weight(0.9f)
            )
        }

        Text("کیفیت مشتری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("داغ", "گرم", "سرد").forEach { q ->
                DaramashChip(label = q, active = quality == q, onClick = { quality = q })
            }
        }

        Text("نحوه پرداخت:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("نقد", "نیاز به فروش واحد", "ضعیف").forEach { p ->
                DaramashChip(label = p, active = payment == p, onClick = { payment = p })
            }
        }

        Text("قصد خرید:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("سکونت", "سرمایه‌گذاری", "تبدیل به احسن", "رهن دادن").forEach { pr ->
                DaramashChip(label = pr, active = purpose == pr, onClick = { purpose = pr })
            }
        }

        Text("وضعیت مشتری:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("تازه تو بازار", "در جست و جو", "آماده بازدید", "در مذاکره", "خرید کرد", "منصرف شد", "خریدار نیست").forEach { st ->
                DaramashChip(label = st, active = status == st, onClick = { status = st })
            }
        }

        Text("امکانات مورد نیاز:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("🚗 پارکینگ", reqParking, { reqParking = !reqParking })
            DaramashChip("🛗 آسانسور", reqElevator, { reqElevator = !reqElevator })
            DaramashChip("📦 انباری", reqStorage, { reqStorage = !reqStorage })
            DaramashChip("🌿 تراس", reqTerrace, { reqTerrace = !reqTerrace })
            DaramashChip("✨ فول امکانات", reqParking && reqElevator && reqStorage && reqTerrace, { val all = !(reqParking && reqElevator && reqStorage && reqTerrace); reqParking = all; reqElevator = all; reqStorage = all; reqTerrace = all })
        }

        if (!reqElevator) {
            DaramashModalTextField(
                value = noElevatorMaxFloorStr,
                onValueChange = { noElevatorMaxFloorStr = it },
                label = "حداکثر طبقه بدون آسانسور (مثلاً ۲)",
                keyboardType = KeyboardType.Number
            )
        }

        DaramashDateRow("تاریخ ثبت", regDateIso) { regDateIso = it }
        DaramashDateRow("تاریخ آخرین تماس", lastContactIso) { lastContactIso = it }
        DaramashModalTextField(
            value = note,
            onValueChange = { note = it },
            label = "توضیحات و نیازمندی‌های خاص",
            singleLine = false
        )
    }
    if (showDiscard) {
        ConfirmModal(
            title = "خروج بدون ذخیره؟",
            message = "تغییراتی که وارد کردی ذخیره نشده و از بین می‌رود. خارج می‌شوی؟",
            confirmText = "خروج بدون ذخیره",
            onConfirm = {
                showDiscard = false
                onDismiss()
            },
            onDismiss = { showDiscard = false }
        )
    }
}

// ============================================================================
// 5. INVESTOR FORM MODAL (openForm('investor') in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InvestorFormDialog(
    initial: Investor?,
    allProperties: List<Property> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (Investor) -> Unit
) {
    var firstName by rememberSaveable { mutableStateOf(initial?.firstName ?: "") }
    var lastName by rememberSaveable { mutableStateOf(initial?.lastName ?: "") }
    var phone1 by rememberSaveable { mutableStateOf(initial?.phone1 ?: "") }
    var selectedNbs by rememberSaveable { mutableStateOf(initial?.neighborhoods ?: emptyList()) }
    var existingUnits by rememberSaveable { mutableStateOf(initial?.existingUnits ?: "") }
    var buyMillionsStr by rememberSaveable {
        mutableStateOf(
            initial?.buyAmount?.takeIf { it > 0 }?.let { (it / 1_000_000L).toString() } ?: ""
        )
    }
    var telegramChannel by rememberSaveable { mutableStateOf(initial?.telegramChannel ?: "") }
    var businessType by rememberSaveable { mutableStateOf(initial?.businessType ?: "") }
    var hasBuy by rememberSaveable {
        mutableStateOf(initial?.hasBuy?.let { if (it == "بله" || it == "به‌شرط ملک خوب") "بله" else "خیر" } ?: "خیر")
    }
    var note by rememberSaveable { mutableStateOf(initial?.note ?: "") }
    var lastContactIso by rememberSaveable { mutableStateOf(initial?.lastContact?.takeIf { it.isNotBlank() } ?: PersianFormatters.todayIso()) }

    val rawMillions = PersianFormatters.toEn(buyMillionsStr).toLongOrNull() ?: 0L
    val buyVal = if (rawMillions in 1..999_999L) rawMillions * 1_000_000L else rawMillions

    val initialSnap = remember { listOf<Any?>(firstName, lastName, phone1, selectedNbs, existingUnits, buyMillionsStr, telegramChannel, businessType, hasBuy, note, lastContactIso).joinToString("\u0001") }
    val isDirty = listOf<Any?>(firstName, lastName, phone1, selectedNbs, existingUnits, buyMillionsStr, telegramChannel, businessType, hasBuy, note, lastContactIso).joinToString("\u0001") != initialSnap
    var showDiscard by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf("") }
    val requestClose: () -> Unit = { if (isDirty) showDiscard = true else onDismiss() }

    DaramashLiquidModal(
        title = if (initial == null) "＋ سرمایه‌گذار جدید" else "✎ ویرایش سرمایه‌گذار",
        onDismiss = requestClose,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = requestClose)
                DaramashPrimaryButton(
                    text = "ذخیره",
                    onClick = onClick@{
                        val badNum = invalidNumberLabel(listOf("مبلغ خرید" to buyMillionsStr))
                        if (badNum != null) {
                            formError = "«$badNum» را با عدد معتبر وارد کن"
                            return@onClick
                        }
                        if (invalidPhone(phone1)) {
                            formError = "شماره‌ی تلفن معتبر نیست"
                            return@onClick
                        }
                        if (firstName.isBlank() && lastName.isBlank()) {
                            formError = "نام یا نام خانوادگی را وارد کن"
                            return@onClick
                        }
                        formError = ""
                        onSave(
                            Investor(
                                id = initial?.id ?: UUID.randomUUID().toString(),
                                firstName = firstName,
                                lastName = lastName,
                                phone1 = phone1,
                                neighborhoods = selectedNbs,
                                existingUnits = existingUnits,
                                buyAmount = if (hasBuy == "بله") buyVal else 0L,
                                hasBuy = hasBuy,
                                telegramChannel = telegramChannel,
                                businessType = businessType,
                                note = note,
                                lastContact = lastContactIso,
                                createdAt = initial?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                    }
                )
            }
        }
    ) {
        if (formError.isNotBlank()) {
            Text(formError, fontSize = 12.sp, color = Color(0xFFFF8A80), fontFamily = VazirmatnFontFamily)
        }
        Text("هویت", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(
                value = firstName,
                onValueChange = { firstName = it },
                label = "نام",
                modifier = Modifier.weight(1f)
            )
            DaramashModalTextField(
                value = lastName,
                onValueChange = { lastName = it },
                label = "نام خانوادگی",
                modifier = Modifier.weight(1f)
            )
        }
        DaramashModalTextField(
            value = phone1,
            onValueChange = { phone1 = it },
            label = "شماره تماس",
            keyboardType = KeyboardType.Phone
        )

        Text("تخصص و موجودی", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("محله‌های تخصصی (${PersianFormatters.toFa(selectedNbs.size)}):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            Text(
                text = "پاک کردن",
                fontSize = 11.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily,
                modifier = Modifier.clickable { selectedNbs = emptyList() }
            )
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val isAllSelected = DEFAULT_NEIGHBORHOODS.all { it in selectedNbs }
            DaramashChip(
                label = "🌐 تمام منطقه",
                active = isAllSelected,
                onClick = { selectedNbs = if (isAllSelected) emptyList() else DEFAULT_NEIGHBORHOODS }
            )
            DEFAULT_NEIGHBORHOODS.forEach { nb ->
                val isOn = nb in selectedNbs
                DaramashChip(
                    label = nb,
                    active = isOn,
                    onClick = { selectedNbs = if (isOn) selectedNbs - nb else selectedNbs + nb }
                )
            }
        }

        DaramashModalTextField(
            value = existingUnits,
            onValueChange = { existingUnits = it },
            label = "واحدهای موجود",
            placeholder = "لیست کد فایل‌ها یا توضیحات — مثلاً ۱۰۴۲، ۱۰۵۰",
            singleLine = false
        )

        // Live code lookup (found / archived / not registered), like the web form
        val typedCodes = remember(existingUnits) {
            val normalized = PersianFormatters.toEn(existingUnits)
            Regex("\\b\\d{4,5}\\b").findAll(normalized).map { it.value }.distinct().toList()
        }
        if (typedCodes.isNotEmpty()) {
            Text("🔍 پیش‌نمایش کدهای تشخیص‌داده‌شده:", fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                typedCodes.forEach { rawCode ->
                    val foundProp = allProperties.find { PersianFormatters.toEn(it.code) == rawCode }
                    if (foundProp != null) {
                        val statusTag = if (foundProp.isArchived) "در آرشیو است 🗄" else "پیدا شد ✅"
                        DaramashChip(
                            label = "کد ${PersianFormatters.toFa(rawCode)}: ${foundProp.neighborhood} (${PersianFormatters.toFa(foundProp.area)}م) · $statusTag",
                            active = true,
                            onClick = {}
                        )
                    } else {
                        DaramashChip(
                            label = "کد ${PersianFormatters.toFa(rawCode)}: ثبت نشده ℹ️",
                            active = false,
                            onClick = {}
                        )
                    }
                }
            }
        }

        Text("خرید", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
        Text("خرید دارد؟", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("خیر", "بله").forEach { hb ->
                DaramashChip(label = hb, active = hasBuy == hb, onClick = { hasBuy = hb })
            }
        }
        if (hasBuy == "بله") {
            DaramashModalTextField(
                value = buyMillionsStr,
                onValueChange = { buyMillionsStr = it },
                label = "اگر بله، چقدر؟ (میلیون تومان)",
                placeholder = "مثلاً ۲۰۰۰۰ برای ۲۰ میلیارد",
                keyboardType = KeyboardType.Number
            )
        }

        Text("ارتباط", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
        DaramashModalTextField(
            value = telegramChannel,
            onValueChange = { telegramChannel = it },
            label = "لینک کانال تلگرامی سرمایه‌گذار",
            placeholder = "https://t.me/...",
            keyboardType = KeyboardType.Uri
        )

        Text("نوع کاسب", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("آدم حسابی", "چقر", "چینی", "فکر می‌کنه خوبه!").forEach { bt ->
                DaramashChip(
                    label = bt,
                    active = businessType == bt,
                    onClick = { businessType = if (businessType == bt) "" else bt }
                )
            }
        }

        Text("پیگیری", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = VazirmatnFontFamily)
        DaramashDateRow("آخرین تماس", lastContactIso) { lastContactIso = it }
        DaramashModalTextField(
            value = note,
            onValueChange = { note = it },
            label = "توضیحات",
            singleLine = false
        )
    }
    if (showDiscard) {
        ConfirmModal(
            title = "خروج بدون ذخیره؟",
            message = "تغییراتی که وارد کردی ذخیره نشده و از بین می‌رود. خارج می‌شوی؟",
            confirmText = "خروج بدون ذخیره",
            onConfirm = {
                showDiscard = false
                onDismiss()
            },
            onDismiss = { showDiscard = false }
        )
    }
}

// ============================================================================
// 6. DETAIL MODALS (detailModal in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertyDetailDialog(
    property: Property,
    logs: List<ActivityLog>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onQuickLog: (String, String) -> Unit
) {
    val context = LocalContext.current
    var logType by rememberSaveable { mutableStateOf("تماس") }
    var logNote by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "🏠 فایل کد ${PersianFormatters.toFa(property.code)} · ${property.neighborhood}",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(
                    text = "📤 اشتراک فایل",
                    small = true,
                    onClick = {
                        val shareText = PersianFormatters.formatPrivacySafePropertyShare(property)
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "ارسال مشخصات فایل"))
                    }
                )
                DaramashGhostButton(text = "✎ ویرایش", small = true, onClick = onEdit)
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        DetailSectionBox("مشخصات اصلی") {
            DetailDlRow("کد فایل", PersianFormatters.toFa(property.code))
            DetailDlRow("وضعیت", property.status)
            DetailDlRow("محله", property.neighborhood)
            DetailDlRow("متراژ", "${PersianFormatters.toFa(property.area)} متر")
            DetailDlRow("خواب", PersianFormatters.toFa(property.bedrooms))
            DetailDlRow("طبقه", "${PersianFormatters.toFa(property.unitFloor)} از ${PersianFormatters.toFa(property.floors)} (${PersianFormatters.toFa(property.unitsPerFloor)} واحدی)")
            DetailDlRow("سن بنا", "${PersianFormatters.toFa(property.buildingAge)} سال")
            if (property.facade.isNotBlank()) DetailDlRow("نما", property.facade)
            if (property.condition.isNotBlank()) DetailDlRow("وضعیت داخلی", property.condition)
            if (property.lighting.isNotBlank()) DetailDlRow("نورگیری", property.lighting)
        }

        DetailSectionBox("امکانات و شرایط سکونت") {
            val feats = listOfNotNull(
                if (property.parking) "🚗 پارکینگ" else null,
                if (property.elevator) "🛗 آسانسور" else null,
                if (property.storage) "📦 انباری" else null,
                if (property.terrace) "🌿 تراس" else null
            )
            DetailDlRow("امکانات", if (feats.isNotEmpty()) feats.joinToString(" · ") else "ندارد")
            DetailDlRow("سکونت", property.occupancy)
            if (property.occupancy == "دست مستاجر") {
                if (property.contractDuration.isNotBlank()) DetailDlRow("اتمام قرارداد", property.contractDuration)
                if (property.deposit > 0) DetailDlRow("ودیعه", "${PersianFormatters.formatMoneyToman(property.deposit)} تومان")
                if (property.rent > 0) DetailDlRow("اجاره", "${PersianFormatters.formatMoneyToman(property.rent)} تومان")
            }
            DetailDlRow("نحوه بازدید", property.visit)
            DetailDlRow("علت فروش", property.sellReason)
            DetailDlRow("معاوضه", property.exchange)
        }

        DetailSectionBox("قیمت و شرایط") {
            DetailDlRow("قیمت کل", "${PersianFormatters.formatMoneyToman(property.totalPrice)} تومان")
            if (property.pricePerMeter > 0) {
                DetailDlRow("قیمت متری", "${PersianFormatters.formatMoneyToman(property.pricePerMeter)} تومان")
            }
            DetailDlRow("قابل سرمایه‌گذاری", if (property.investable) "بله 💼" else "خیر")
        }

        if (property.sellerName.isNotBlank() || property.sellerPhone.isNotBlank() || property.address.isNotBlank()) {
            DetailSectionBox("فروشنده و آدرس") {
                if (property.sellerName.isNotBlank()) DetailDlRow("نام فروشنده", property.sellerName)
                if (property.sellerPhone.isNotBlank()) DetailDlRow("شماره تماس", PersianFormatters.toFa(property.sellerPhone))
                if (property.address.isNotBlank()) DetailDlRow("آدرس", property.address)
            }
        }

        // Activity Logger (.act-bar)
        DetailSectionBox("📋 ثبت فعالیت و تاریخچه (${PersianFormatters.toFa(logs.size)})") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("تماس", "بازدید", "مذاکره", "تغییر قیمت", "یادداشت", "معامله").forEach { t ->
                    DaramashChip(label = t, active = logType == t, onClick = { logType = t })
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DaramashModalTextField(
                    value = logNote,
                    onValueChange = { logNote = it },
                    label = "توضیح کوتاه",
                    placeholder = "نتیجه تماس یا بازدید...",
                    modifier = Modifier.weight(1f)
                )
                DaramashPrimaryButton(
                    text = "＋ ثبت",
                    small = true,
                    onClick = {
                        onQuickLog(logType, logNote.ifBlank { "ثبت $logType" })
                        logNote = ""
                    }
                )
            }
            if (logs.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                logs.take(8).forEach { a ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF161616))
                            .border(1.dp, DaramashBorderSoft, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(a.type, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
                            if (a.note.isNotBlank()) {
                                Text(a.note, fontSize = 12.sp, color = Color.White, fontFamily = VazirmatnFontFamily)
                            }
                        }
                        Text(
                            text = PersianFormatters.formatIsoToJalaliReadable(a.date),
                            fontSize = 11.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerDetailDialog(
    customer: Customer,
    logs: List<ActivityLog>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onMatch: () -> Unit,
    onArchive: () -> Unit,
    onQuickLog: (String, String) -> Unit
) {
    DaramashLiquidModal(
        title = "🧑 ${customer.fullName}",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "🔎 فایل مناسب", small = true, onClick = onMatch)
                DaramashGhostButton(text = "✎ ویرایش", small = true, onClick = onEdit)
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        DetailSectionBox("مشخصات مشتری") {
            DetailDlRow("نام", customer.fullName)
            DetailDlRow("شماره تماس اصلی", PersianFormatters.toFa(customer.phone1))
            if (customer.phone2.isNotBlank()) DetailDlRow("شماره دوم", PersianFormatters.toFa(customer.phone2))
            DetailDlRow("کیفیت", customer.quality)
            DetailDlRow("وضعیت", customer.status)
            DetailDlRow("نحوه پرداخت", customer.payment)
            DetailDlRow("قصد خرید", customer.purpose)
            DetailDlRow("حداقل متراژ", "${PersianFormatters.toFa(customer.areaMin)} متر")
            DetailDlRow("حداکثر بودجه", "${PersianFormatters.formatMoneyToman(customer.budgetMax)} تومان")
            if (customer.visitedUnits > 0) DetailDlRow("واحدهای دیده‌شده", "${PersianFormatters.toFa(customer.visitedUnits)} واحد")
            if (customer.neighborhoods.isNotEmpty()) {
                DetailDlRow("محله‌ها", customer.neighborhoods.joinToString("، "))
            }
            val reqs = listOfNotNull(
                if (customer.reqParking) "پارکینگ" else null,
                if (customer.reqElevator) "آسانسور" else null,
                if (customer.reqStorage) "انباری" else null,
                if (customer.reqTerrace) "تراس" else null
            )
            if (reqs.isNotEmpty()) DetailDlRow("امکانات الزامی", reqs.joinToString(" · "))
            if (!customer.reqElevator && customer.noElevatorMaxFloor > 0) {
                DetailDlRow("حداکثر طبقه بدون آسانسور", "طبقه ${PersianFormatters.toFa(customer.noElevatorMaxFloor)}")
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InvestorDetailDialog(
    investor: Investor,
    logs: List<ActivityLog>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onMatch: () -> Unit,
    onArchive: () -> Unit,
    onQuickLog: (String, String) -> Unit
) {
    val context = LocalContext.current
    var logType by rememberSaveable { mutableStateOf("تماس") }
    var logNote by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "💼 ${investor.fullName}",
        onDismiss = onDismiss,
        footer = {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DaramashGhostButton(text = "🔎 فایل مناسب", small = true, onClick = onMatch)
                DaramashGhostButton(text = "✎ ویرایش", small = true, onClick = onEdit)
                DaramashGhostButton(text = "🗄 آرشیو", small = true, onClick = onArchive)
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        // quick contact
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (investor.phone1.isNotBlank()) {
                DaramashGhostButton(
                    text = "📞 تماس",
                    small = true,
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + PersianFormatters.toEn(investor.phone1))))
                    }
                )
                DaramashGhostButton(
                    text = "💬 واتساپ",
                    small = true,
                    onClick = {
                        val url = PersianFormatters.whatsappUrl(investor.phone1)
                        if (url.isNotEmpty()) {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            } catch (_: Exception) {
                            }
                        }
                    }
                )
            }
            if (investor.telegramChannel.isNotBlank()) {
                DaramashGhostButton(
                    text = "✈️ تلگرام",
                    small = true,
                    onClick = {
                        val url = telegramHref(investor.telegramChannel)
                        if (url.isNotEmpty()) {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            } catch (_: Exception) {
                            }
                        }
                    }
                )
            }
        }

        DetailSectionBox("هویت") {
            DetailDlRow("نام", investor.fullName)
            DetailDlRow("شماره تماس", if (investor.phone1.isBlank()) "—" else PersianFormatters.toFa(investor.phone1))
        }
        DetailSectionBox("تخصص و موجودی") {
            DetailDlRow("محله‌های تخصصی", neighborhoodsText(investor.neighborhoods).ifBlank { "—" })
            DetailDlRow("واحدهای موجود", investor.existingUnits.ifBlank { "—" })
        }
        DetailSectionBox("خرید") {
            DetailDlRow("خرید دارد؟", investor.hasBuy.ifBlank { "—" })
            if (investor.hasBuy == "بله" && investor.buyAmount > 0L) {
                DetailDlRow("مبلغ خرید", "${PersianFormatters.formatMoneyToman(investor.buyAmount)} تومان")
            }
        }
        DetailSectionBox("ارتباط، نوع کاسب و پیگیری") {
            if (investor.telegramChannel.isNotBlank()) DetailDlRow("کانال تلگرام", investor.telegramChannel)
            DetailDlRow("نوع کاسب", investor.businessType.ifBlank { "—" })
            DetailDlRow(
                "آخرین تماس",
                if (investor.lastContact.isBlank()) "—"
                else PersianFormatters.formatIsoToJalaliReadable(investor.lastContact)
            )
        }
        if (investor.note.isNotBlank()) {
            DetailSectionBox("توضیحات") {
                Text(
                    text = investor.note,
                    fontSize = 13.sp,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily,
                    lineHeight = 22.sp
                )
            }
        }

        DetailSectionBox("📋 ثبت فعالیت و تاریخچه (${PersianFormatters.toFa(logs.size)})") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("تماس", "واتساپ", "مذاکره", "یادداشت", "معامله").forEach { t ->
                    DaramashChip(label = t, active = logType == t, onClick = { logType = t })
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DaramashModalTextField(
                    value = logNote,
                    onValueChange = { logNote = it },
                    label = "توضیح کوتاه",
                    placeholder = "نتیجه‌ی تماس یا مذاکره...",
                    modifier = Modifier.weight(1f)
                )
                DaramashPrimaryButton(
                    text = "＋ ثبت",
                    small = true,
                    onClick = {
                        onQuickLog(logType, logNote.ifBlank { "ثبت $logType" })
                        logNote = ""
                    }
                )
            }
            if (logs.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                logs.take(8).forEach { a ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF161616))
                            .border(1.dp, DaramashBorderSoft, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = "${a.type} · ${PersianFormatters.formatIsoToJalaliReadable(a.date)}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldBright,
                            fontFamily = VazirmatnFontFamily
                        )
                        if (a.note.isNotBlank()) {
                            Text(
                                text = a.note,
                                fontSize = 12.sp,
                                color = DaramashMuted,
                                fontFamily = VazirmatnFontFamily
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeviceManagementModal(
    session: ir.daramash.app.domain.model.UserSession,
    onDismiss: () -> Unit,
    onRemoveDevice: (String) -> Unit
) {
    DaramashLiquidModal(
        title = "📱 مدیریت دستگاه‌ها و اشتراک",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "بستن", small = true, onClick = onDismiss)
            }
        }
    ) {
        DetailSectionBox("وضعیت اشتراک دارمش") {
            val statusFa = when (session.subStatus) {
                "active" -> "فعال"
                "pending" -> "در انتظار بررسی"
                "expired" -> "منقضی شده"
                "blocked" -> "مسدود"
                "device_limit" -> "تکمیل سقف دستگاه"
                else -> session.subStatus
            }
            DetailDlRow("پلن اشتراک", session.planName)
            DetailDlRow("وضعیت اکانت", statusFa)
            DetailDlRow("روزهای باقیمانده", "${PersianFormatters.toFa(session.daysLeft)} روز")
            DetailDlRow("سقف دستگاه مجاز", "${PersianFormatters.toFa(session.maxDevices)} دستگاه")
        }

        DetailSectionBox("تمدید و پشتیبانی") {
            Text(
                text = if (session.payText.isNotBlank()) session.payText else ("برای تمدید اشتراک یا افزایش سقف دستگاه‌ها با ادمین تماس بگیر." + if (session.contact.isNotBlank()) "\n" + session.contact else ""),
                fontSize = 12.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily,
                lineHeight = 20.sp
            )
        }

        DetailSectionBox("دستگاه‌های متصل (${PersianFormatters.toFa(session.devices.size)})") {
            if (session.devices.isEmpty()) {
                Text(
                    text = "اطلاعات دستگاه‌ها در حال بارگذاری است...",
                    fontSize = 12.sp,
                    color = DaramashMuted,
                    fontFamily = VazirmatnFontFamily
                )
            } else {
                session.devices.forEach { dev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF161616))
                            .border(1.dp, DaramashBorderSoft, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = dev.label + if (dev.isCurrent) " (همین دستگاه)" else "",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (dev.isCurrent) EmeraldBright else Color.White,
                                fontFamily = VazirmatnFontFamily
                            )
                            if (dev.lastSeen.isNotBlank()) {
                                Text(
                                    text = "آخرین فعالیت: ${PersianFormatters.formatIsoToJalaliReadable(dev.lastSeen)}",
                                    fontSize = 11.sp,
                                    color = DaramashMuted,
                                    fontFamily = VazirmatnFontFamily
                                )
                            }
                        }
                        if (!dev.isCurrent) {
                            DaramashDangerButton(
                                text = "حذف",
                                small = true,
                                onClick = { onRemoveDevice(dev.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailSectionBox(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x0AFFFFFF))
            .border(1.dp, DaramashBorderSoft, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
        content()
    }
}

@Composable
private fun DetailDlRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White, fontFamily = VazirmatnFontFamily)
    }
}

// ============================================================================
// 7. QUICK ACTIVITY POPOVER DIALOG (showQuickLogMenu in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun QuickActivityPopoverDialog(
    title: String,
    onDismiss: () -> Unit,
    onSaveLog: (String, String) -> Unit
) {
    var customNote by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "✍️ اقدام سریع · $title",
        onDismiss = onDismiss
    ) {
        WelcomeStepButton("📞", "ثبت تماس تلفنی") { onSaveLog("تماس", customNote.ifBlank { "تماس تلفنی انجام شد" }) }
        WelcomeStepButton("💬", "ثبت پیام واتساپ") { onSaveLog("واتساپ", customNote.ifBlank { "پیام واتساپ ارسال شد" }) }
        WelcomeStepButton("👁", "ثبت بازدید حضوری") { onSaveLog("بازدید", customNote.ifBlank { "بازدید حضوری انجام شد" }) }
        WelcomeStepButton("🤝", "ثبت جلسه مذاکره") { onSaveLog("مذاکره", customNote.ifBlank { "مذاکره انجام شد" }) }
        DaramashModalTextField(
            value = customNote,
            onValueChange = { customNote = it },
            label = "یادداشت اختیاری",
            placeholder = "توضیح کوتاه..."
        )
        if (customNote.isNotBlank()) {
            DaramashPrimaryButton(
                text = "📝 ثبت یادداشت",
                onClick = { onSaveLog("یادداشت", customNote) }
            )
        }
    }
}

// ============================================================================
// 8. ADVANCED PROPERTY FILTER MODAL (openPropFilter in daramashNativeRuntime.ts)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdvancedPropertyFilterDialog(
    current: PropertyFilterState,
    allProperties: List<Property>,
    onDismiss: () -> Unit,
    onApply: (PropertyFilterState) -> Unit
) {
    var selNbs by remember { mutableStateOf(current.neighborhoods) }
    var codeStr by rememberSaveable { mutableStateOf(current.code) }
    var minAreaStr by rememberSaveable { mutableStateOf(current.minArea?.toString() ?: "") }
    var maxAreaStr by rememberSaveable { mutableStateOf(current.maxArea?.toString() ?: "") }
    var minPriceStr by rememberSaveable { mutableStateOf(current.minPrice?.let { (it / 1_000_000L).toString() } ?: "") }
    var maxPriceStr by rememberSaveable { mutableStateOf(current.maxPrice?.let { (it / 1_000_000L).toString() } ?: "") }
    var minAgeStr by rememberSaveable { mutableStateOf(current.minAge?.toString() ?: "") }
    var maxAgeStr by rememberSaveable { mutableStateOf(current.maxAge?.toString() ?: "") }
    var minFloorStr by rememberSaveable { mutableStateOf(current.minFloor?.toString() ?: "") }
    var maxFloorStr by rememberSaveable { mutableStateOf(current.maxFloor?.toString() ?: "") }
    var minUpfStr by rememberSaveable { mutableStateOf(current.minUnitsPerFloor?.toString() ?: "") }
    var maxUpfStr by rememberSaveable { mutableStateOf(current.maxUnitsPerFloor?.toString() ?: "") }
    var selBeds by remember { mutableStateOf(current.bedChoices) }
    var reqParking by rememberSaveable { mutableStateOf(current.requireParking) }
    var reqElevator by rememberSaveable { mutableStateOf(current.requireElevator) }
    var reqStorage by rememberSaveable { mutableStateOf(current.requireStorage) }
    var reqTerrace by rememberSaveable { mutableStateOf(current.requireTerrace) }
    var onlyInvestable by rememberSaveable { mutableStateOf(current.statusFilter == "investable") }
    var dateFrom by rememberSaveable { mutableStateOf(current.dateFrom) }
    var dateTo by rememberSaveable { mutableStateOf(current.dateTo) }
    var pickingFrom by remember { mutableStateOf(false) }
    var pickingTo by remember { mutableStateOf(false) }
    var filterError by remember { mutableStateOf("") }

    fun num(str: String): Int? = PersianFormatters.toEn(str).trim().toIntOrNull()
    fun millions(str: String): Long? {
        val r = PersianFormatters.toEn(str).trim().toLongOrNull() ?: return null
        return if (r in 1..999_999L) r * 1_000_000L else r
    }

    fun draft(): PropertyFilterState = current.copy(
        statusFilter = if (onlyInvestable) "investable" else if (current.statusFilter == "investable") "all" else current.statusFilter,
        neighborhoods = selNbs,
        code = codeStr.trim(),
        minArea = num(minAreaStr),
        maxArea = num(maxAreaStr),
        minPrice = millions(minPriceStr),
        maxPrice = millions(maxPriceStr),
        minAge = num(minAgeStr),
        maxAge = num(maxAgeStr),
        minFloor = num(minFloorStr),
        maxFloor = num(maxFloorStr),
        minUnitsPerFloor = num(minUpfStr),
        maxUnitsPerFloor = num(maxUpfStr),
        bedChoices = selBeds,
        minBedrooms = null,
        requireParking = reqParking,
        requireElevator = reqElevator,
        requireStorage = reqStorage,
        requireTerrace = reqTerrace,
        dateFrom = dateFrom,
        dateTo = dateTo
    )

    val matchCount = PropertyFilterLogic.apply(allProperties, draft()).size

    DaramashLiquidModal(
        title = "🔍 فیلتر پیشرفته‌ی فایل‌ها",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(
                    text = "پاک کردن همه",
                    onClick = {
                        onApply(
                            PropertyFilterState(
                                query = current.query,
                                statusFilter = if (current.statusFilter == "investable") "all" else current.statusFilter,
                                sortMode = current.sortMode,
                                advisorId = current.advisorId
                            )
                        )
                        onDismiss()
                    }
                )
                DaramashPrimaryButton(
                    text = "نمایش ${PersianFormatters.toFa(matchCount)} فایل",
                    onClick = onClick@{
                        val d = draft()
                        fun bad(a: Long?, b: Long?) = a != null && b != null && a > b
                        val badLabel = when {
                            bad(d.minArea?.toLong(), d.maxArea?.toLong()) -> "متراژ"
                            bad(d.minPrice, d.maxPrice) -> "قیمت"
                            bad(d.minAge?.toLong(), d.maxAge?.toLong()) -> "سن بنا"
                            bad(d.minFloor?.toLong(), d.maxFloor?.toLong()) -> "طبقه"
                            bad(d.minUnitsPerFloor?.toLong(), d.maxUnitsPerFloor?.toLong()) -> "تعداد واحد در طبقه"
                            d.dateFrom.isNotBlank() && d.dateTo.isNotBlank() && d.dateFrom > d.dateTo -> "تاریخ"
                            else -> null
                        }
                        if (badLabel != null) {
                            filterError = "در «$badLabel»، مقدار «از» نباید بیشتر از «تا» باشد"
                            return@onClick
                        }
                        filterError = ""
                        onApply(d)
                        onDismiss()
                    }
                )
            }
        }
    ) {
        if (filterError.isNotBlank()) {
            Text(filterError, fontSize = 12.sp, color = Color(0xFFFF8A80), fontFamily = VazirmatnFontFamily)
        }
        Text("محله:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DEFAULT_NEIGHBORHOODS.forEach { nb ->
                DaramashChip(
                    label = nb,
                    active = selNbs.contains(nb),
                    onClick = { selNbs = if (selNbs.contains(nb)) selNbs - nb else selNbs + nb }
                )
            }
        }

        DaramashModalTextField(
            value = codeStr,
            onValueChange = { codeStr = it },
            label = "کد فایل",
            placeholder = "مثلاً ۱۰۴۲"
        )

        FilterRangeRow("متراژ", minAreaStr, maxAreaStr, { minAreaStr = it }, { maxAreaStr = it })
        FilterRangeRow("قیمت کل (میلیون تومان)", minPriceStr, maxPriceStr, { minPriceStr = it }, { maxPriceStr = it })
        FilterRangeRow("سن بنا (سال)", minAgeStr, maxAgeStr, { minAgeStr = it }, { maxAgeStr = it })

        Text("تعداد خواب:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(1, 2, 3, 4).forEach { b ->
                DaramashChip(
                    label = if (b == 4) "۴ و بیشتر" else PersianFormatters.toFa(b) + " خواب",
                    active = selBeds.contains(b),
                    onClick = { selBeds = if (selBeds.contains(b)) selBeds - b else selBeds + b }
                )
            }
        }

        Text("امکانات (همه‌ی موارد انتخابی باید داشته باشد):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("🚗 پارکینگ", reqParking, { reqParking = !reqParking })
            DaramashChip("📦 انباری", reqStorage, { reqStorage = !reqStorage })
            DaramashChip("🛗 آسانسور", reqElevator, { reqElevator = !reqElevator })
            DaramashChip("🌿 تراس", reqTerrace, { reqTerrace = !reqTerrace })
        }

        FilterRangeRow("طبقه‌ی واحد", minFloorStr, maxFloorStr, { minFloorStr = it }, { maxFloorStr = it })
        FilterRangeRow("تعداد واحد در هر طبقه", minUpfStr, maxUpfStr, { minUpfStr = it }, { maxUpfStr = it })

        Text("تاریخ ثبت فایل:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashGhostButton(
                text = if (dateFrom.isBlank()) "از تاریخ" else "از " + PersianFormatters.formatIsoToJalaliReadable(dateFrom),
                small = true,
                onClick = { pickingFrom = true }
            )
            DaramashGhostButton(
                text = if (dateTo.isBlank()) "تا تاریخ" else "تا " + PersianFormatters.formatIsoToJalaliReadable(dateTo),
                small = true,
                onClick = { pickingTo = true }
            )
            if (dateFrom.isNotBlank() || dateTo.isNotBlank()) {
                DaramashGhostButton(text = "پاک کردن تاریخ", small = true, onClick = { dateFrom = ""; dateTo = "" })
            }
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("💼 فقط فایل‌های قابل سرمایه‌گذاری", onlyInvestable, { onlyInvestable = !onlyInvestable })
        }
    }

    if (pickingFrom) {
        DaramashPersianDatePickerModal(
            onDismiss = { pickingFrom = false },
            onDateSelected = { dateFrom = it; pickingFrom = false }
        )
    }
    if (pickingTo) {
        DaramashPersianDatePickerModal(
            onDismiss = { pickingTo = false },
            onDateSelected = { dateTo = it; pickingTo = false }
        )
    }
}

@Composable
private fun FilterRangeRow(
    label: String,
    minValue: String,
    maxValue: String,
    onMin: (String) -> Unit,
    onMax: (String) -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DaramashModalTextField(
            value = minValue,
            onValueChange = onMin,
            label = "$label (از)",
            placeholder = "از",
            keyboardType = KeyboardType.Number,
            modifier = Modifier.weight(1f)
        )
        DaramashModalTextField(
            value = maxValue,
            onValueChange = onMax,
            label = "$label (تا)",
            placeholder = "تا",
            keyboardType = KeyboardType.Number,
            modifier = Modifier.weight(1f)
        )
    }
}

// ============================================================================
// 9. MATCH ENTITY PICKER MODAL (openMatchPicker in daramashNativeRuntime.ts)
// ============================================================================

@Composable
fun MatchEntityPickerModal(
    isPropertyMode: Boolean,
    properties: List<Property>,
    customers: List<Customer>,
    onDismiss: () -> Unit,
    onPickProperty: (String) -> Unit,
    onPickCustomer: (String) -> Unit,
    investors: List<ir.daramash.app.domain.model.Investor> = emptyList(),
    onPickInvestor: (String) -> Unit = {}
) {
    var searchQ by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = if (isPropertyMode) "انتخاب فایل" else "انتخاب مشتری یا سرمایه‌گذار",
        onDismiss = onDismiss
    ) {
        DaramashModalTextField(
            value = searchQ,
            onValueChange = { searchQ = it },
            label = "جستجو",
            placeholder = if (isPropertyMode) "کد، محله، نام فروشنده..." else "نام، شماره، محله..."
        )
        val q = PersianFormatters.normalizeSearch(searchQ)
        if (isPropertyMode) {
            properties.filter {
                q.isEmpty() || PersianFormatters.normalizeSearch("${it.code} ${it.neighborhood} ${it.sellerName}").contains(q)
            }.forEach { p ->
                WelcomeStepButton(
                    icon = "🏠",
                    label = "کد ${PersianFormatters.toFa(p.code)} · ${p.neighborhood} · ${PersianFormatters.toFa(p.area)} متر",
                    onClick = { onPickProperty(p.id) }
                )
            }
        } else {
            customers.filter {
                q.isEmpty() || PersianFormatters.normalizeSearch("${it.fullName} ${it.phone1}").contains(q)
            }.forEach { c ->
                WelcomeStepButton(
                    icon = "🧑",
                    label = "${c.fullName} · ${c.neighborhoods.joinToString("، ")}",
                    onClick = { onPickCustomer(c.id) }
                )
            }
            investors.filter {
                q.isEmpty() || PersianFormatters.normalizeSearch("${it.fullName} ${it.phone1}").contains(q)
            }.forEach { inv ->
                WelcomeStepButton(
                    icon = "💼",
                    label = "${inv.fullName} · ${inv.neighborhoods.joinToString("، ")}",
                    onClick = { onPickInvestor(inv.id) }
                )
            }
        }
    }
}

// ============================================================================
// 10. EDIT TARGET MODAL & ADVISOR MODALS & AI ASSISTANT MODAL
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditTargetModal(
    current: AdvisorTarget,
    properties: List<Property>,
    archivedProperties: List<Property>,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int, String, Long, Int) -> Unit
) {
    var code by rememberSaveable { mutableStateOf(current.targetFileCode) }
    var mot by rememberSaveable { mutableStateOf(current.motivation) }
    var status by rememberSaveable { mutableStateOf(current.status.ifBlank { "در حال تلاش" }) }
    var rankStr by rememberSaveable { mutableStateOf(if (current.rank > 0) current.rank.toString() else "") }
    var type by rememberSaveable { mutableStateOf(current.targetType) }
    var depMillions by rememberSaveable {
        mutableStateOf(if (current.targetDeposit > 0L) (current.targetDeposit / 1_000_000L).toString() else "")
    }
    var contractsStr by rememberSaveable {
        mutableStateOf(if (current.targetContracts > 0) current.targetContracts.toString() else "")
    }

    val codeTrim = PersianFormatters.toEn(code).trim()
    val active = if (codeTrim.isEmpty()) null else properties.firstOrNull { PersianFormatters.toEn(it.code).trim() == codeTrim }
    val archived = if (codeTrim.isEmpty() || active != null) null else archivedProperties.firstOrNull { PersianFormatters.toEn(it.code).trim() == codeTrim }
    val lookup = when {
        codeTrim.isEmpty() -> ""
        active != null -> "✓ فایل پیدا شد: ${active.neighborhood} · ${PersianFormatters.toFa(active.area)} متر"
        archived != null -> "این فایل در آرشیو است"
        else -> "فایلی با این کد ثبت نشده"
    }

    DaramashLiquidModal(
        title = "🎯 ویرایش تارگت",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "ذخیره",
                    onClick = {
                        val rank = PersianFormatters.toEn(rankStr).trim().toIntOrNull() ?: 0
                        val dep = (PersianFormatters.toEn(depMillions).trim().toLongOrNull() ?: 0L) * 1_000_000L
                        val cnt = PersianFormatters.toEn(contractsStr).trim().toIntOrNull() ?: 0
                        onSave(code, mot, status, rank, type, dep, cnt)
                        onDismiss()
                    }
                )
            }
        }
    ) {
        DaramashModalTextField(
            value = mot,
            onValueChange = { mot = it },
            label = "جمله‌ی انگیزشی",
            singleLine = false
        )
        Text("وضعیت مشاور:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("توکار هستم", "در حال تلاش", "تو کار نیستم").forEach { st ->
                DaramashChip(st, status == st, { status = st })
            }
        }
        DaramashModalTextField(
            value = rankStr,
            onValueChange = { rankStr = it },
            label = "جایگاه در رقابت (اختیاری)",
            placeholder = "مثلاً ۳",
            keyboardType = KeyboardType.Number
        )
        DaramashModalTextField(
            value = code,
            onValueChange = { code = it },
            label = "کد فایل هدف",
            placeholder = "مثلاً ۱۰۴۲"
        )
        if (lookup.isNotEmpty()) {
            Text(
                text = lookup,
                fontSize = 12.sp,
                color = if (active != null) EmeraldBright else AmberWarn,
                fontFamily = VazirmatnFontFamily
            )
        }
        Text("نوع تارگت ماه:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("💰 مبلغ واریزی", type == "deposit", { type = "deposit" })
            DaramashChip("🤝 تعداد قرارداد", type == "contracts", { type = "contracts" })
        }
        if (type == "contracts") {
            DaramashModalTextField(
                value = contractsStr,
                onValueChange = { contractsStr = it },
                label = "تعداد قرارداد هدف در ماه (حداکثر ۶۰)",
                placeholder = "مثلاً ۳",
                keyboardType = KeyboardType.Number
            )
        } else {
            DaramashModalTextField(
                value = depMillions,
                onValueChange = { depMillions = it },
                label = "مبلغ هدف واریزی (میلیون تومان)",
                placeholder = "مثلاً ۳۵۰",
                keyboardType = KeyboardType.Number
            )
        }
        Text(
            text = "پیشرفت هر ماه جداگانه ثبت می‌شود و با شروع ماه شمسی جدید از صفر شروع می‌شود.",
            fontSize = 11.5.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
    }
}

@Composable
fun AddAdvisorModal(
    onDismiss: () -> Unit,
    onAdd: (String, String, String) -> Unit
) {
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var area by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "＋ مشاور جدید",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "افزودن",
                    onClick = { if (name.isNotBlank()) onAdd(name, phone, area) }
                )
            }
        }
    ) {
        DaramashModalTextField(value = name, onValueChange = { name = it }, label = "اسم مشاور *")
        DaramashModalTextField(value = phone, onValueChange = { phone = it }, label = "شماره تماس", keyboardType = KeyboardType.Phone)
        DaramashModalTextField(value = area, onValueChange = { area = it }, label = "منطقه‌ی کاری", placeholder = "مثلاً پونک، ستارخان")
    }
}

@Composable
fun ImportAdvisorCodeModal(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var code by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "📥 ثبت کد یا JSON مشاور",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "ثبت",
                    onClick = { if (code.isNotBlank()) onImport(code) }
                )
            }
        }
    ) {
        DaramashModalTextField(
            value = code,
            onValueChange = { code = it },
            label = "کد DRZ1 / DRM1 یا JSON را بچسبان",
            placeholder = "DRM1:...",
            singleLine = false
        )
    }
}

@Composable
fun AiAssistantDialog(
    aiResponse: String,
    isLoading: Boolean,
    onAsk: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var prompt by rememberSaveable { mutableStateOf("") }

    DaramashLiquidModal(
        title = "✨ دستیار هوشمند دارمش",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "بستن", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = if (isLoading) "در حال تحلیل..." else "تحلیل هوشمند",
                    enabled = !isLoading,
                    onClick = { onAsk(prompt) }
                )
            }
        }
    ) {
        Text(
            text = "🔒 حریم خصوصی امن: نام مالکین، شماره‌ها و آدرس‌های دقیق هرگز ارسال نمی‌شوند.",
            fontSize = 12.sp,
            color = EmeraldBright,
            fontFamily = VazirmatnFontFamily
        )
        DaramashModalTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = "سوال یا دستور تحلیل",
            placeholder = "مثلاً: کدام فایل‌ها امروز اولویت تماس دارند؟"
        )
        if (isLoading) {
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = RubyPrimary)
            }
        } else if (aiResponse.isNotBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF161616))
                    .border(1.dp, DaramashBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = aiResponse,
                    fontSize = 13.sp,
                    color = Color.White,
                    fontFamily = VazirmatnFontFamily,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

// ============================================================================
// 11. PERSIAN JALALI DATE PICKER MODAL
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DaramashPersianDatePickerModal(
    onDismiss: () -> Unit,
    onDateSelected: (String) -> Unit
) {
    val (curJy, curJm, curJd) = remember {
        val cal = java.util.Calendar.getInstance()
        PersianFormatters.gregorianToJalali(
            cal.get(java.util.Calendar.YEAR),
            cal.get(java.util.Calendar.MONTH) + 1,
            cal.get(java.util.Calendar.DAY_OF_MONTH)
        )
    }

    var selectedYear by rememberSaveable { mutableStateOf(curJy) }
    var selectedMonth by rememberSaveable { mutableStateOf(curJm) }
    var selectedDay by rememberSaveable { mutableStateOf(curJd) }

    DaramashLiquidModal(
        title = "📅 انتخاب تاریخ شمسی",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "تأیید تاریخ",
                    onClick = {
                        val iso = PersianFormatters.jalaliToIso(selectedYear, selectedMonth, selectedDay)
                        onDateSelected(iso)
                        onDismiss()
                    }
                )
            }
        }
    ) {
        Text("سال شمسی:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (1400..1406).forEach { y ->
                DaramashChip(
                    label = PersianFormatters.toFa(y),
                    active = selectedYear == y,
                    onClick = { selectedYear = y }
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("ماه:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            PersianFormatters.JALALI_MONTH_NAMES.forEachIndexed { idx, mName ->
                val mNum = idx + 1
                DaramashChip(
                    label = mName,
                    active = selectedMonth == mNum,
                    onClick = { selectedMonth = mNum }
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        val maxDays = if (selectedMonth <= 6) 31 else if (selectedMonth <= 11) 30 else 29
        Text("روز ($maxDays روز):", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            (1..maxDays).forEach { d ->
                DaramashChip(
                    label = PersianFormatters.toFa(d),
                    active = selectedDay == d,
                    onClick = { selectedDay = d }
                )
            }
        }
    }
}

// ============================================================================
// 12. ADMIN SUBSCRIPTION MANAGEMENT MODAL (is_admin)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminSubscriptionModal(
    session: UserSession,
    users: List<AdminUserRow>,
    onReload: () -> Unit,
    onExtend: (String, Int) -> Unit,
    onBlock: (String, Boolean) -> Unit,
    onClearDevices: (String) -> Unit,
    onDismiss: () -> Unit,
    onSaveConfig: (contact: String, trialDays: Int, devLimit: Int, build: Int, url: String, note: String) -> Unit,
    onSavePayText: (String) -> Unit
) {
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var contactInput by rememberSaveable { mutableStateOf(session.contact) }
    var trialDaysInput by rememberSaveable { mutableStateOf(session.trialDays.toString()) }
    var devLimitInput by rememberSaveable { mutableStateOf(session.maxDevices.toString()) }
    var buildInput by rememberSaveable { mutableStateOf(session.latestBuild.toString()) }
    var urlInput by rememberSaveable { mutableStateOf(session.updateUrl) }
    var noteInput by rememberSaveable { mutableStateOf(session.updateNote) }
    var payTextInput by rememberSaveable { mutableStateOf(session.payText) }

    DaramashLiquidModal(
        title = "👑 مدیریت اشتراک‌ها (پنل ادمین)",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "بستن", onClick = onDismiss)
            }
        }
    ) {
        DaramashModalTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = "جستجوی ایمیل کاربر...",
            placeholder = "user@gmail.com"
        )

        androidx.compose.runtime.LaunchedEffect(Unit) { onReload() }

        val nowMs = System.currentTimeMillis()
        fun stateOf(u: AdminUserRow): String =
            if (u.blocked) "blocked" else if (u.expiresAt <= 0L) "pending" else if (u.expiresAt > nowMs) "active" else "expired"
        val cnt = users.groupingBy { stateOf(it) }.eachCount()
        Text(
            text = "کل: ${PersianFormatters.toFa(users.size)} · فعال: ${PersianFormatters.toFa(cnt["active"] ?: 0)} · در انتظار: ${PersianFormatters.toFa(cnt["pending"] ?: 0)} · منقضی: ${PersianFormatters.toFa(cnt["expired"] ?: 0)} · مسدود: ${PersianFormatters.toFa(cnt["blocked"] ?: 0)}",
            fontSize = 11.5.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily
        )
        users
            .filter { searchQuery.isBlank() || it.email.lowercase().contains(searchQuery.trim().lowercase()) }
            .forEach { u ->
                val st = stateOf(u)
                val label = when (st) {
                    "active" -> "فعال"
                    "pending" -> "در انتظار"
                    "expired" -> "منقضی"
                    else -> "مسدود"
                }
                val sub = when (st) {
                    "active" -> "${PersianFormatters.toFa(((u.expiresAt - nowMs + 86_399_999L) / 86_400_000L).toInt())} روز مانده"
                    "expired" -> "اشتراکش تمام شده"
                    "pending" -> "هنوز فعال نشده"
                    else -> "مسدود"
                } + " · فضا: ${PersianFormatters.toFa((u.usageBytes / 1_048_576L).toInt())} مگ · دستگاه: ${PersianFormatters.toFa(u.devices)}"
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x0DFFFFFF))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(u.email, fontSize = 12.sp, color = Color.White, fontFamily = VazirmatnFontFamily)
                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    }
                    Text(sub, fontSize = 11.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(7, 30, 90, 365).forEach { d ->
                            DaramashChip("+" + PersianFormatters.toFa(d) + " روز", false, { onExtend(u.userId, d) })
                        }
                        DaramashChip("آزادسازی دستگاه‌ها", false, { onClearDevices(u.userId) })
                        DaramashChip(if (u.blocked) "رفع مسدودی" else "مسدود", false, { onBlock(u.userId, !u.blocked) })
                    }
                }
            }

        Spacer(Modifier.height(8.dp))
        Text("⚙️ تنظیمات عمومی سامانه (کنترل از سرور)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
        DaramashModalTextField(value = contactInput, onValueChange = { contactInput = it }, label = "آیدی تلگرام یا شماره واتس‌اپ ادمین", placeholder = "@admin")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(value = trialDaysInput, onValueChange = { trialDaysInput = it }, label = "روز دوره آزمایشی (۰ = خاموش)", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f))
            DaramashModalTextField(value = devLimitInput, onValueChange = { devLimitInput = it }, label = "حداکثر دستگاه (۱ تا ۱۰)", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DaramashModalTextField(value = buildInput, onValueChange = { buildInput = it }, label = "شماره build نسخه جدید", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f))
            DaramashModalTextField(value = urlInput, onValueChange = { urlInput = it }, label = "لینک دانلود APK (https)", placeholder = "https://...", modifier = Modifier.weight(1.5f))
        }
        DaramashModalTextField(value = noteInput, onValueChange = { noteInput = it }, label = "توضیحات به‌روزرسانی (اختیاری)")
        DaramashPrimaryButton(
            text = "💾 ذخیره تنظیمات عمومی",
            small = true,
            onClick = {
                onSaveConfig(
                    contactInput.trim(),
                    trialDaysInput.toIntOrNull() ?: 0,
                    devLimitInput.toIntOrNull() ?: 2,
                    buildInput.toIntOrNull() ?: 18,
                    urlInput.trim(),
                    noteInput.trim()
                )
            }
        )

        Spacer(Modifier.height(12.dp))
        Text("💳 متن راهنمای پرداخت (به کاربر نمایش داده می‌شود)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldBright, fontFamily = VazirmatnFontFamily)
        DaramashModalTextField(value = payTextInput, onValueChange = { payTextInput = it }, label = "متن کارت حساب / شرایط پرداخت", singleLine = false)
        DaramashPrimaryButton(
            text = "💾 ذخیره متن پرداخت",
            small = true,
            onClick = { onSavePayText(payTextInput.trim()) }
        )
    }
}

@Composable
fun CloudSnapshotsModal(
    snapshots: List<ir.daramash.app.domain.model.CloudHistorySnapshot>,
    onDismiss: () -> Unit,
    onRestore: (Long) -> Unit
) {
    DaramashLiquidModal(
        title = "📜 نسخه‌های ابری ذخیره‌شده (تا ۳ نسخه)",
        onDismiss = onDismiss,
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                DaramashPrimaryButton(text = "بستن", onClick = onDismiss)
            }
        }
    ) {
        if (snapshots.isEmpty()) {
            Text("هیچ نسخه ابری قبلی یافت نشد.", fontSize = 13.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        } else {
            snapshots.forEach { snap ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x0FFFFFFF))
                        .border(1.dp, DaramashBorderSoft, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "نسخه ${PersianFormatters.toFa(snap.id)}",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = VazirmatnFontFamily
                        )
                        Text(
                            text = "${PersianFormatters.toFa(snap.rawBytes / 1024)} کیلوبایت",
                            fontSize = 11.5.sp,
                            color = DaramashMuted,
                            fontFamily = VazirmatnFontFamily
                        )
                    }
                    DaramashPrimaryButton(
                        text = "↩ بازگردانی",
                        small = true,
                        onClick = {
                            onRestore(snap.id)
                            onDismiss()
                        }
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun CloudConflictModal(
    info: ir.daramash.app.data.repository.CloudConflictInfo,
    onUseCloud: () -> Unit,
    onKeepPhone: () -> Unit,
    onDismiss: () -> Unit
) {
    DaramashLiquidModal(
        title = "☁️ اطلاعات حساب با این گوشی فرق دارد",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DaramashGhostButton(text = "نگه داشتن اطلاعات این گوشی", small = true, onClick = onKeepPhone)
                DaramashPrimaryButton(text = "استفاده از اطلاعات ابری", small = true, onClick = onUseCloud)
            }
        }
    ) {
        DetailSectionBox("روی حساب (ابر)") {
            DetailDlRow("فایل‌ها", PersianFormatters.toFa(info.cloudProps))
            DetailDlRow("مشتری‌ها", PersianFormatters.toFa(info.cloudCusts))
            DetailDlRow("سرمایه‌گذارها", PersianFormatters.toFa(info.cloudInvs))
        }
        DetailSectionBox("روی این گوشی") {
            DetailDlRow("فایل‌ها", PersianFormatters.toFa(info.localProps))
            DetailDlRow("مشتری‌ها", PersianFormatters.toFa(info.localCusts))
            DetailDlRow("سرمایه‌گذارها", PersianFormatters.toFa(info.localInvs))
        }
        Text(
            text = "با گزینه‌ی اول، یک نسخه‌ی پشتیبان از اطلاعات گوشی روی همین گوشی می‌ماند. با گزینه‌ی دوم، اطلاعات ابری با اطلاعات این گوشی جایگزین می‌شود.",
            fontSize = 12.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily,
            lineHeight = 20.sp
        )
    }
}

@Composable
fun DaramashDateRow(label: String, iso: String, onChange: (String) -> Unit) {
    var picking by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        DaramashGhostButton(
            text = if (iso.isBlank()) "انتخاب تاریخ" else PersianFormatters.formatIsoToJalaliReadable(iso),
            small = true,
            onClick = { picking = true }
        )
    }
    if (picking) {
        DaramashPersianDatePickerModal(
            onDismiss = { picking = false },
            onDateSelected = {
                onChange(it)
                picking = false
            }
        )
    }
}

private fun invalidNumberLabel(pairs: List<Pair<String, String>>): String? {
    for ((label, v) in pairs) {
        val t = PersianFormatters.toEn(v).trim()
        if (t.isNotEmpty() && t.toDoubleOrNull() == null) return label
    }
    return null
}

private fun invalidPhone(v: String): Boolean {
    val d = PersianFormatters.toEn(v).filter { it.isDigit() }
    return d.isNotEmpty() && (d.length < 10 || d.length > 13)
}

@Composable
fun ConfirmModal(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    DaramashLiquidModal(
        title = title,
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(text = confirmText, onClick = onConfirm)
            }
        }
    ) {
        Text(
            text = message,
            fontSize = 13.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily,
            lineHeight = 22.sp
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditGroupModal(
    current: AdvisorTarget,
    onDismiss: () -> Unit,
    onSave: (String, Int, String, Long) -> Unit
) {
    var name by rememberSaveable { mutableStateOf(current.groupName) }
    var rankStr by rememberSaveable { mutableStateOf(if (current.groupRank > 0) current.groupRank.toString() else "") }
    var type by rememberSaveable { mutableStateOf(current.groupTargetType) }
    var valueStr by rememberSaveable {
        mutableStateOf(
            if (current.groupTargetValue <= 0L) ""
            else if (current.groupTargetType == "deposit") (current.groupTargetValue / 1_000_000L).toString()
            else current.groupTargetValue.toString()
        )
    }
    DaramashLiquidModal(
        title = "👥 تنظیمات گروه",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "ذخیره",
                    onClick = {
                        val raw = PersianFormatters.toEn(valueStr).trim().toLongOrNull() ?: 0L
                        val value = if (type == "deposit") raw * 1_000_000L else raw
                        val rank = PersianFormatters.toEn(rankStr).trim().toIntOrNull() ?: 0
                        onSave(name, rank, type, value)
                        onDismiss()
                    }
                )
            }
        }
    ) {
        DaramashModalTextField(
            value = name,
            onValueChange = { name = it },
            label = "اسم گروه",
            placeholder = "گروه مشاوران دارمش"
        )
        Text("نوع تارگت ماه گروه:", fontSize = 11.5.sp, color = DaramashMuted, fontFamily = VazirmatnFontFamily)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DaramashChip("📄 فایل ثبت‌شده", type == "files", { type = "files" })
            DaramashChip("🤝 تعداد قرارداد", type == "contracts", { type = "contracts" })
            DaramashChip("💰 واریزی", type == "deposit", { type = "deposit" })
        }
        DaramashModalTextField(
            value = valueStr,
            onValueChange = { valueStr = it },
            label = if (type == "deposit") "تارگت ماه گروه (میلیون تومان)" else "تارگت ماه گروه (تعداد)",
            placeholder = "مثلاً ۵۰",
            keyboardType = KeyboardType.Number
        )
        DaramashModalTextField(
            value = rankStr,
            onValueChange = { rankStr = it },
            label = "رتبه‌ی گروه در رقابت دفتر (اختیاری)",
            placeholder = "مثلاً ۱",
            keyboardType = KeyboardType.Number
        )
    }
}

@Composable
fun EditAdvisorModal(
    advisor: ir.daramash.app.domain.model.Advisor,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by rememberSaveable { mutableStateOf(advisor.name) }
    var phone by rememberSaveable { mutableStateOf(advisor.phone) }
    var area by rememberSaveable { mutableStateOf(advisor.specialtyNeighborhood) }
    DaramashLiquidModal(
        title = "✎ ویرایش مشاور",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "ذخیره",
                    onClick = {
                        if (name.isNotBlank()) {
                            onSave(name, phone, area)
                            onDismiss()
                        }
                    }
                )
            }
        }
    ) {
        DaramashModalTextField(value = name, onValueChange = { name = it }, label = "نام مشاور")
        DaramashModalTextField(
            value = phone,
            onValueChange = { phone = it },
            label = "شماره تماس",
            keyboardType = KeyboardType.Phone
        )
        DaramashModalTextField(value = area, onValueChange = { area = it }, label = "محله‌ی تخصصی")
    }
}

@Composable
fun AdvisorCodeShareModal(code: String, onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var managerPhone by rememberSaveable { mutableStateOf("") }
    fun copy() {
        val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("daramash", code))
        android.widget.Toast.makeText(context, "کد کپی شد", android.widget.Toast.LENGTH_SHORT).show()
    }
    fun share() {
        try {
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, code)
            }
            context.startActivity(
                android.content.Intent.createChooser(send, "ارسال کد").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }
    fun whatsApp() {
        val digits = PersianFormatters.toEn(managerPhone).filter { it.isDigit() }
        val intl = when {
            digits.isEmpty() -> ""
            digits.startsWith("0") -> "98" + digits.drop(1)
            else -> digits
        }
        if (code.length > 3000) {
            share()
            return
        }
        val url = "https://wa.me/" + intl + "?text=" + android.net.Uri.encode(code)
        try {
            context.startActivity(
                android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            share()
        }
    }
    DaramashLiquidModal(
        title = "📤 ارسال کد اشتراک به مدیر",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "کپی کد", small = true, onClick = { copy() })
                DaramashGhostButton(text = "اشتراک‌گذاری", small = true, onClick = { share() })
                DaramashPrimaryButton(text = "ارسال در واتساپ", small = true, onClick = { whatsApp() })
            }
        }
    ) {
        Text(
            text = "کد اشتراک آماده است (${PersianFormatters.toFa(code.length)} کاراکتر). شماره‌ی واتساپ مدیر را بنویس (اختیاری) و ارسال را بزن. اگر کد خیلی بلند باشد، از لیست اشتراک‌گذاری استفاده می‌شود.",
            fontSize = 12.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily,
            lineHeight = 21.sp
        )
        DaramashModalTextField(
            value = managerPhone,
            onValueChange = { managerPhone = it },
            label = "شماره‌ی واتساپ مدیر (اختیاری)",
            placeholder = "۰۹۱۲۳۴۵۶۷۸۹",
            keyboardType = KeyboardType.Phone
        )
    }
}

@Composable
fun RestorePasteModal(onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var text by rememberSaveable { mutableStateOf("") }
    fun pasteFromClipboard() {
        val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
        val clip = cm?.primaryClip
        val pasted = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(context)?.toString() else null
        if (pasted.isNullOrBlank()) {
            android.widget.Toast.makeText(context, "کلیپ‌بورد خالی است", android.widget.Toast.LENGTH_SHORT).show()
        } else {
            text = pasted
        }
    }
    DaramashLiquidModal(
        title = "📋 بازگردانی با چسباندن JSON",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(
                    text = "بررسی و ادامه",
                    onClick = {
                        onSubmit(text)
                        onDismiss()
                    }
                )
            }
        }
    ) {
        Text(
            text = "متن JSON بکاپ دارمش (از اپ، نسخه‌ی وب یا فایل) را اینجا بچسبان. قبل از جایگزینی، محتوای آن را نشانت می‌دهیم و تأیید می‌گیریم.",
            fontSize = 12.sp,
            color = DaramashMuted,
            fontFamily = VazirmatnFontFamily,
            lineHeight = 21.sp
        )
        DaramashGhostButton(text = "📋 چسباندن از کلیپ‌بورد", small = true, onClick = { pasteFromClipboard() })
        DaramashModalTextField(
            value = text,
            onValueChange = { text = it },
            label = "متن JSON",
            placeholder = "{ \"_meta\": ... }",
            singleLine = false
        )
        if (text.isNotBlank()) {
            Text(
                text = "${PersianFormatters.toFa(text.length)} کاراکتر",
                fontSize = 11.sp,
                color = DaramashMuted,
                fontFamily = VazirmatnFontFamily
            )
        }
    }
}

@Composable
fun RestoreConfirmModal(
    preview: ir.daramash.app.data.backup.RestorePreview,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    DaramashLiquidModal(
        title = "🔄 تأیید بازگردانی",
        onDismiss = onDismiss,
        footer = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                DaramashGhostButton(text = "انصراف", onClick = onDismiss)
                DaramashPrimaryButton(text = "بازگردانی", onClick = onConfirm)
            }
        }
    ) {
        Text(
            text = "فایل معتبر است. این‌ها داخلش پیدا شد:",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontFamily = VazirmatnFontFamily
        )
        DetailSectionBox("محتوای فایل") {
            DetailDlRow("فایل‌ها", PersianFormatters.toFa(preview.properties))
            DetailDlRow("مشتری‌ها", PersianFormatters.toFa(preview.customers))
            DetailDlRow("سرمایه‌گذارها", PersianFormatters.toFa(preview.investors))
            DetailDlRow("آرشیو", PersianFormatters.toFa(preview.archived))
            DetailDlRow("پیوندها", PersianFormatters.toFa(preview.matches))
            DetailDlRow("مشاورها", PersianFormatters.toFa(preview.advisors))
            DetailDlRow("تارگت و پیشرفت ماه‌ها", if (preview.hasTarget) "دارد" else "ندارد")
        }
        Text(
            text = "⚠️ همه‌ی اطلاعات فعلی این گوشی با محتوای این فایل جایگزین می‌شود. پیش از آن یک نسخه‌ی پشتیبان محلی از اطلاعات فعلی گرفته می‌شود.",
            fontSize = 12.sp,
            color = AmberWarn,
            fontFamily = VazirmatnFontFamily,
            lineHeight = 21.sp
        )
    }
}
